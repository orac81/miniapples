/* ZXCODE.C - Convert File.o ZX80/1 Basic <-> Ascii
(C) A.Millett 2015, freeware.

 Imp simple part-working version (zx80.o -> asc only)
->ZXCODE100  8.10.2015
 Dbug for proper basic end, line#>255 etc..
->ZXCODE101  9.10.2015
 Imp cmd line commands -d/e/80/81.
 Imp zx80_encode - encode from ascii to file.o
->ZXCODE102  9.10.2015
->ZXCODE103  10.10.2015
 Imp zx81_decode..
->ZXCODE104  18.10.2015
 Imp zx81_encode..
->ZXCODE105  18.10.2015
 Debug zx81_encode.
 Imp HANDLE_FLOATS
->ZXCODE106  19.10.2015

*/

#define PROG_VERSION "1.06"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define TRUE  1
#define FALSE 0
typedef unsigned char BYTE;

#define MAX_FILE 16384
#define MAX_BUFFER 512

#define HANDLE_FLOATS  TRUE

/*---------------------------------------------------------------------------- 
  io_ .. Misc IO functions
----------------------------------------------------------------------------*/

#define io_putchar putchar

  /* Write a string */
void io_puts (char *pOut) 
{
    char ch;
    while (  (ch = *pOut)  ) {
      io_putchar(ch);
      pOut ++;
    }
}

  /* Write an int */
void io_putint (int x)
{
    if (x<0) {
      x = -x; io_putchar ('-');
    }
    if (x>9) {
      io_putint (x/10);
    }
    io_putchar ('0' + x%10);
}

  /* Print a string then an integer */
void io_putsi (char *pStr, int x)
{
   io_puts (pStr); io_putint (x);
}


  /*  Write block of data (pData) of size (nbytes) to file (szFile) */
  /*    ret FALSE if error */
int io_FileSave (char *szFile, void *pData, int nbytes)
{
    FILE *hFile;
    int cret;
    if (szFile == NULL || *szFile == 0) return FALSE;
    hFile = fopen (szFile, "w+b");
    if (hFile == NULL) return FALSE;
    cret = fwrite (pData, 1, nbytes, hFile);
    fclose (hFile);
    if (cret < nbytes) return FALSE;
    return TRUE;
}

  /*  Read block of data (pData) of size (nbytes) from file (szFile) */
  /*    ret #read, or 0 if error */
int io_FileLoad (char *szFile, void *pData, int nbytes)
{
    FILE *hFile;
    int cret;
    if (szFile == NULL || *szFile == 0) return 0;
    hFile = fopen (szFile, "rb");
    if (hFile == NULL) return 0;
    cret = fread (pData, 1, nbytes, hFile);
    fclose (hFile);
    return cret;
}

/*---------------------------------------------------------------------------- 
  ZX80_..  decode/encode fns..

ZX80 Basic start 4028 .. (4008)-1
  File.o = 4000 .. (E_LINE)-1
  ____0___1___2___3___4___5___6___7___8___9___A___B___C___D___E___F____
  00 SPC  "  [: ][..][' ][ '][. ][ .][.']{::}{..}{''}GBP  $   :   ?  0F
  10  (   )   -   +   *   /   =   >   <   ;   ,   .   0   1   2   3  1F
  20  4   5   6   7   8   9   A   B   C   D   E   F   G   H   I   J  2F
  30  K   L   M   N   O   P   Q   R   S   T   U   V   W   X   Y   Z  3F

----------------------------------------------------------------------------*/


#define BLK ""		/* Unused chr */
		
		/* ZX80 Chrset as Ascii */
char *pZX80charset[256] = {
   " ","\x22","\\: ","\\..","\\' ","\\ '","\\. ","\\ .","\\.'","\\##","\\,,","\\~~",
   "#","$",":","?","(",")","-","+","*","/","=",">","<",";",",",".",		/* '$'=13 */
   "0","1","2","3","4","5","6","7","8","9",					/* '0'=28 */
   "A","B","C","D","E","F","G","H","I","J","K","L","M",				/* 'A'=38 */
   "N","O","P","Q","R","S","T","U","V","W","X","Y","Z",
   BLK, BLK, BLK, BLK, BLK, BLK, BLK, BLK, BLK, BLK, BLK, BLK, BLK, BLK, BLK, BLK,	/* 64..127 unused */
   BLK, BLK, BLK, BLK, BLK, BLK, BLK, BLK, BLK, BLK, BLK, BLK, BLK, BLK, BLK, BLK, 
   BLK, BLK, BLK, BLK, BLK, BLK, BLK, BLK, BLK, BLK, BLK, BLK, BLK, BLK, BLK, BLK, 
   BLK, BLK, BLK, BLK, BLK, BLK, BLK, BLK, BLK, BLK, BLK, BLK, BLK, BLK, BLK, BLK, 
   "\\::","%\x22","\\ :","\\''","\\.:","\\:.","\\':","\\:'","\\'.","\\@@","\\;;","\\!!",
   "%#","%$","%:","%?","%(","%)","%-","%+","%*","%/","%=","%>","%<","%;","%,","%.",
   "%0","%1","%2","%3","%4","%5","%6","%7","%8","%9",				/* Inv '0'=156 */
   "%A","%B","%C","%D","%E","%F","%G","%H","%I","%J","%K","%L","%M",		/* Inv 'A'=166 */
   "%N","%O","%P","%Q","%R","%S","%T","%U","%V","%W","%X","%Y","%Z",
   BLK, BLK, BLK, BLK, BLK, BLK, BLK, BLK, BLK, BLK, BLK, BLK, BLK, BLK, BLK, BLK, 
   BLK, BLK, BLK, BLK, "\x22",
   " THEN"," TO ",";",",",")","("," NOT ","-","+","*","/"," AND "," OR ","**","=",">","<",   /* then=213.. */
   " LIST "," RETURN"," CLS"," DIM "," SAVE "," FOR "," GO TO ",
   " POKE "," INPUT "," RANDOMISE "," LET ","?","?"," NEXT "," PRINT ","?"," NEW",
   " RUN "," STOP"," CONTINUE "," IF "," GO SUB "," LOAD "," CLEAR "," REM ","?"
};

  /* Decode basic binary data */
int zx80_decode (char *pName)
{
    int fpos;
    int fend;
    int cline;
    int flen;
    BYTE cchr;
    BYTE *pData;

    pData = malloc (MAX_FILE+16);
    if (pData == NULL) return 0;
    flen = io_FileLoad (pName, pData, MAX_FILE);
    if (flen == 0) {
      free (pData);
      return 0;
    }

    fend = pData [8] + (pData[9] << 8) - 0x4000;		/* Calc basic end pos from @(4008) */
    fpos = 40;		/* ZX80 basic code starts at $4028 */
    while (fpos < fend) {
      cchr = pData [fpos];
      fpos ++;
      if (fpos > fend) break;
      cline = pData [fpos] + ((int) cchr << 8);
      io_putint (cline);
      while (1) {
        fpos ++;
        cchr = pData [fpos];
	if (cchr == 0x76 || fpos > flen) break;
        io_puts (pZX80charset[cchr]);
      }
      io_puts ("\n");
      fpos ++;
    }
    free (pData);
    return fpos;
}

/*---------------------------------------------------------------------------- 
  encode_ .. encode fns..
----------------------------------------------------------------------------*/

char szIn [MAX_BUFFER+16];

BYTE pHeadZX80[] = {	/* ZX80 header $4000-4028 */
  0xff,0x88,0xfe,0xff,0x5b,0x40,0x32,0x00, 0xff,0x40,0x5a,0x40,0x5c,0x40,0x5d,0x40,
  0x5d,0x40,0x02,0x00,0x00,0x00,0x00,0x00, 0x00,0x00,0xb0,0x07,0x00,0x00,0xe8,0xa4,
  0x49,0x40,0x00,0x00,0x21,0x17,0x5b,0x40 };

#define ZX80_TOK_START 213	/* Start point for token list encode */

  /* Encode Ascii data into zx80 binary file.o */
int zx80_encode (char *pName)
{
    BYTE *pData;
    char *pRet;
    int fpos;
    int cline;
    int inpos;
    int inlen;
    int tok;
    int toklen;
    char *pTok;

    pData = malloc (MAX_FILE+64);
    if (pData == NULL) return 0;
    fpos = 40;
    memcpy (pData, pHeadZX80, fpos);
    while (1) {
      inpos = 0;
      pRet = fgets (szIn, MAX_BUFFER, stdin);		/* Read line from std input */
      if (pRet == NULL) break;
      inlen = strlen (szIn);
      if (inlen < 1) break;
      cline = atoi (szIn);
      if (cline == 0) continue;		/* No line #, next line.. */
      pData [fpos] = cline >> 8;
      fpos ++;
      pData [fpos] = cline & 255;
      fpos ++;
      while (isdigit (szIn [inpos])) {
        inpos ++;
      }
      while (inpos < inlen) {
      		/* Search token list for match, start at "THEN".. */
        for (tok = ZX80_TOK_START; tok < ZX80_TOK_START+256; tok ++) {
	  pTok  = pZX80charset [(BYTE) (tok & 255)];
	  if (*pTok) {
	    toklen = strlen (pTok);
	    if (memcmp (pTok, szIn+inpos, toklen) == 0) {	/* Found matching token */
	      pData [fpos] = (BYTE) tok;
	      fpos ++;
	      if (fpos >= MAX_FILE) {
	        free (pData);
	        return 0;
	      }
	      inpos += strlen (pTok);
	      break;
	    }
	  }
	}
	if (tok >= (ZX80_TOK_START+256)) break;		/* Matching token not found, skip line.. */
      }
      pData [fpos] = 0x76;		/* End of line marker */
      fpos ++;
    }
    pData [8] = fpos & 255;
    pData [9] = 0x40 + (fpos >> 8);		/* save basic end pos @(4008) */
    pData [fpos] = 0x80;		/* End of file */
    fpos ++;
    pData [10] = fpos & 255;
    pData [11] = 0x40 + (fpos >> 8);		/* save basic end pos @(400A) */
    io_FileSave (pName, pData, fpos);
    free (pData);
    return fpos;
}

/*---------------------------------------------------------------------------- 
  zx81_.. decode/encode fn..

ZX81 Basic start 407D - Chrset:
  ____0___1___2___3___4___5___6___7___8___9___A___B___C___D___E___F____
  00 SPC [' ][ '][''][. ][: ][.'][:']{::}{..}{''} "  GBP  $   :   ?  0F
  10  (   )   >   <   =   +   -   *   /   ;   ,   .   0   1   2   3  1F
  20  4   5   6   7   8   9   A   B   C   D   E   F   G   H   I   J  2F
  30  K   L   M   N   O   P   Q   R   S   T   U   V   W   X   Y   Z  3F

----------------------------------------------------------------------------*/

 
char *pZX81charset[256]={
    " ","\\' ","\\ '","\\''","\\. ","\\: ","\\.'","\\:'","\\##","\\,,","\\~~","\x22","#",
    "$",":","?","(",")",">","<","=","+","-","*","/",";",",",".",
    "0","1","2","3","4","5","6","7","8","9",			/* '0'=28 ($1C) */
    "A","B","C","D","E","F","G","H","I","J","K","L","M",	/* 'A'=38 ($26) */
    "N","O","P","Q","R","S","T","U","V","W","X","Y","Z",
    "RND","INKEY$ ","PI",					/* 'RND'=64 ($40) */
    BLK,BLK,BLK,
    BLK,BLK,BLK,BLK,BLK,BLK,BLK,BLK,BLK,BLK,
    BLK,BLK,BLK,BLK,BLK,BLK,BLK,BLK,BLK,BLK,
    BLK,BLK,BLK,BLK,BLK,BLK,BLK,BLK,BLK,BLK,
    BLK,BLK,BLK,BLK,BLK,BLK,BLK,BLK,BLK,BLK,
    BLK,BLK,BLK,BLK,BLK,BLK,BLK,BLK,BLK,BLK,
    BLK,BLK,BLK,BLK,BLK,BLK,BLK,BLK,
    "\\::","\\.:","\\:.","\\..","\\':","\\ :","\\'.","\\ .","\\@@","\\;;","\\!!","%\"",
    "%�","%$","%:","%?","%(","%)","%>","%<","%=","%+",
    "%-","%*","%/","%;","%,","%.",
    "%0","%1","%2","%3","%4","%5","%6","%7","%8","%9",
    "%A","%B","%C","%D","%E","%F","%G","%H","%I","%J","%K","%L","%M",
    "%N","%O","%P","%Q","%R","%S","%T","%U","%V","%W","%X","%Y","%Z",
    "\\\x22","AT ","TAB ",BLK,"CODE ","VAL ","LEN ","SIN ",
    "COS ","TAN ","ASN ","ACS ","ATN ","LN ","EXP ","INT ","SQR ","SGN ",
    "ABS ","PEEK ","USR ","STR$ ","CHR$ ","NOT ","**"," OR "," AND ","<=",
    ">=","<>"," THEN"," TO "," STEP "," LPRINT "," LLIST "," STOP"," SLOW"," FAST",
    " NEW"," SCROLL"," CONT "," DIM "," REM "," FOR "," GOTO "," GOSUB "," INPUT "," LOAD ",
    " LIST "," LET "," PAUSE "," NEXT "," POKE "," PRINT "," PLOT "," RUN "," SAVE "," RAND ",
    " IF "," CLS"," UNPLOT "," CLEAR"," RETURN"," COPY"
};
  
  /* Decode basic binary data (name.p) */
int zx81_decode (char *pName)
{
    int fpos;
    int fend;
    int cline;
    int linelen;
    int flen;
    BYTE cchr;
    BYTE *pData;

    pData = malloc (MAX_FILE+16);
    if (pData == NULL) return 0;
    flen = io_FileLoad (pName, pData, MAX_FILE);
    if (flen == 0) {
      free (pData);
      return 0;
    }
		/* NAME.P loaded : zx81mem from $4009.. */
    fend = pData [3] + (pData[4] << 8) - 0x4009;		/* Calc basic end pos from @($400C) */
    fpos = 0x0074;		/* ZX81 basic code starts at $407D (minus $4009) */
    while (fpos < fend) {
      cchr = pData [fpos];
      fpos ++;
      if (fpos > fend) break;
      cline = pData [fpos] + ((int) cchr << 8);
      io_putint (cline);
      fpos ++;
      linelen = pData [fpos] + (pData [fpos + 1] << 8);
      fpos ++;
      while (1) {
        fpos ++;
        cchr = pData [fpos];
	if (cchr == 0x76 || fpos > flen) break;
	if (cchr == 0x7e) {	/* Floating point in-line binary number, skip */
	  fpos += 5;
	  continue;
	}
        io_puts (pZX81charset[cchr]);
      }
      io_puts ("\n");
      fpos ++;
    }
    free (pData);
    return fpos;
}

/*---------------------------------------------------------------------------- 
  Str2Float - Imported from bas2tap
----------------------------------------------------------------------------*/

#if HANDLE_FLOATS

#include <math.h>

#define log2(x)       (log (x) / log (2.0))                                /* If your compiler doesn't know the 'log2' function */

#define SHIFT31BITS   (double)2147483648.0                                                                            /* (= 2^31) */

/**********************************************************************************************************************************/
/* Pre   : `BasicLineNo' holds the current BASIC line number, `BasicLine' points into the line, `SpectrumLine' points to the      */
/*         TAPped Spectrum line.                                                                                                  */
/* Post  : If there was a (floating point) number at this position, it has been processed into `SpectrumLine' and `LineIndex' is  */
/*         pointing after the number.                                                                                             */
/*         The return value is: 0 = no number, 1 = number done, -1 = number error (already reported).                             */
/* Import: None.                                                                                                                  */
/**********************************************************************************************************************************/

int Str2Float (char **BasicLine, BYTE **SpectrumLine)
{
  char   *StartOfNumber;
  double  Value   = 0.0;
  double  Divider = 1.0;
  double  Exp     = 0.0;
  BYTE    Sign    = 0x00;
  unsigned long Mantissa;

  if (!isdigit (**BasicLine) &&  (**BasicLine) != '.') return (0);
  StartOfNumber = *BasicLine;
  while (isdigit (**BasicLine))                                                                    /* First read the integer part */
    Value = Value * 10 + *((*BasicLine) ++) - '0';
  if ((**BasicLine) == '.')                                                                                    /* Decimal point ? */
  {                                                                                                      /* Read the decimal part */
    (*BasicLine) ++;
    while (isdigit (**BasicLine))
      Value = Value + (Divider /= 10) * (*((*BasicLine) ++) - '0');
  }
  if ((**BasicLine) == 'e' || (**BasicLine) == 'E')                                                                 /* Exponent ? */
  {
    (*BasicLine) ++;
    if ((**BasicLine) == '+')                                                            /* Both "Ex" and "E+x" do the same thing */
      (*BasicLine) ++;
    else if ((**BasicLine) == '-')                                                                           /* Negative exponent */
    {
      Sign = 0xFF;
      (*BasicLine) ++;
    }
    while (isdigit (**BasicLine))                                                                      /* Read the exponent value */
      Exp = Exp * 10 + *((*BasicLine) ++) - '0';
    if (Sign != 0x00)                                                           /* Raise the resulting value to the read exponent */
      Value = Value * pow (10.0, Exp);
    else
      Value = Value / pow (10.0, Exp);
  }
  strncpy ((char *)*SpectrumLine, StartOfNumber, *BasicLine - StartOfNumber);                     /* Insert the ASCII value first */
  (*SpectrumLine) += (*BasicLine - StartOfNumber);
  {
    if (Value < 0)
    {
      Sign = 0x80;                                                                              /* Sign bit is high bit of byte 2 */
      Value = -Value;
    }
    else
      Sign = 0x00;
    Exp = floor (log2 (Value));
    if (Exp < -129 || Exp > 126) return (-1);

    Mantissa = (unsigned long)floor ((Value / pow (2.0, Exp) - 1.0) * SHIFT31BITS + 0.5);                   /* Calculate mantissa */
    *((*SpectrumLine) ++) = 0x0E;                                                                         /* Insert number marker */
    *((*SpectrumLine) ++) = (BYTE)Exp + 0x81;                                                                  /* Insert exponent */
    *((*SpectrumLine) ++) = (BYTE)((Mantissa >> 24) & 0x7F) | Sign;                                            /* Insert mantissa */
    *((*SpectrumLine) ++) = (BYTE)((Mantissa >> 16) & 0xFF);                                                     /* (Big endian!) */
    *((*SpectrumLine) ++) = (BYTE)((Mantissa >> 8) & 0xFF);
    *((*SpectrumLine) ++) = (BYTE)(Mantissa & 0xFF);
  }
  return (1);
}

#endif	/* HANDLE_FLOATS */

/*---------------------------------------------------------------------------- 
  zx81_encode .. 
----------------------------------------------------------------------------*/

BYTE pHeadZX81[] = {	/* ZX81 header $4009-407D */
  0x00,0xa0,0x00,0xe8,0x42,0xe9,0x42,0x01,  0x43,0x19,0x43,0x36,0x43,0x3d,0x43,0x00,
  0x00,0x3e,0x43,0x3e,0x43,0x00,0x5d,0x40,  0x00,0x02,0x8c,0x00,0xbf,0xfd,0xff,0x37,
  0xe8,0x42,0x8c,0x00,0x00,0x6f,0xde,0x8d,  0x0c,0x77,0x33,0xe2,0x8b,0x00,0x00,0xbc,
  0x21,0x18,0x40,0x00,0x00,0x00,0x00,0x00,  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
  0x00,0x00,0x00,0x76,0x00,0x00,0x00,0x00,  0x00,0x81,0x00,0x00,0x00,0x00,0x80,0x80,
  0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,  0x80,0x80,0x89,0x97,0x90,0x00,0x00,0x00,
  0x00,0x00,0x00,0x00  };

#define ZX81_TOK_START 64	/* Start point for token list encode */

  /* Encode Ascii data into zx81 binary file.p */
int zx81_encode (char *pName)
{
    BYTE *pData;
    char *pRet;
    int fpos;
    int cline;
    int inpos;
    int inlen;
    int tok;
    int toklen;
    char *pTok;
    int lenpos,linelen;
    int x;

    pData = malloc (MAX_FILE+64);
    if (pData == NULL) return 0;
    fpos = 0x0074;		/* ZX81 basic code starts at $407D (minus $4009) */
    memcpy (pData, pHeadZX81, fpos);
    while (1) {
      inpos = 0;
      pRet = fgets (szIn, MAX_BUFFER, stdin);		/* Read line from std input */
      if (pRet == NULL) break;
      inlen = strlen (szIn);
      if (inlen < 1) break;
      cline = atoi (szIn);
      if (cline == 0) continue;		/* No line #, next line.. */
      pData [fpos] = cline >> 8;
      fpos ++;
      pData [fpos] = cline & 255;
      lenpos = fpos+1;			/* Offset to later put line-length word */
      fpos += 3;
      while (isdigit (szIn [inpos])) {
        inpos ++;
      }
      while (inpos < inlen) {
      		/* Search token list for match, start at "AT".. */
        for (tok = ZX81_TOK_START; tok < (ZX81_TOK_START+256); tok ++) {
	  pTok  = pZX81charset [(BYTE) (tok & 255)];
	  if (*pTok) {
	    toklen = strlen (pTok);
	    if (memcmp (pTok, szIn+inpos, toklen) == 0) {	/* Found matching token */
	      pData [fpos] = (BYTE) tok;
	      fpos ++;
	      if (fpos >= MAX_FILE) {
	        free (pData);
	        return 0;
	      }
	      inpos += strlen (pTok);
	      break;
	    }
	  }
	}
	if (tok >= (ZX81_TOK_START+256)) break;		/* Matching token not found, skip line.. */
      }
      pData [fpos] = 0x76;		/* End of line marker */
      fpos ++;
      linelen = fpos - lenpos - 2;
      pData [lenpos] = (linelen & 255);
      pData [lenpos+1] = (linelen >> 8);
    }
    memset (pData + fpos, 0x76,25);	/* Empty Display file, 25 lines */
    pData [fpos+25] = 0x80;		/* End of vars marker */
    x = fpos + 0x4009;
    pData [3] = x & 255;
    pData [4] = (x >> 8);		/* save basic end pos @(400C) D_File */
    x ++;
    pData [5] = x & 255;
    pData [6] = (x >> 8);		/* save basic end pos @(400E) */
    x += 25;
    pData [11] = pData [7] = x & 255;
    pData [12] = pData [8] = (x >> 8);		/* save basic end pos @(4010) */
    io_FileSave (pName, pData, fpos+26);
    free (pData);
    return fpos;
}

/*---------------------------------------------------------------------------- 
  main command parser
----------------------------------------------------------------------------*/


int main (int argc, char *argv[])
{
    char *pName;
    int xtype;		/* 0=zx80, 1=zx81.. */
    int decode;

    xtype = 0;
    decode = TRUE;
    pName = argv [1];

    if (pName && *pName == '-') {	/* Mode param: -d80, -d81, -e80, -e81 */
      switch (toupper(pName [1])) {
        case 'D':
          decode = TRUE; break;
        case 'E':
          decode = FALSE; break;
	default:
	  return 0;
      } 
      if (pName [3] == '0') xtype = 0;
      if (pName [3] == '1') xtype = 1;
      pName = argv [2];
    }

    if (argc < 2 ||  pName == NULL || *pName == 0) {
      io_puts (
	"ZXCODE " PROG_VERSION "- Convert ZX binary basic files to/from ascii.\n"
	"   (C) A.Millett 2015. Freeware.\n"
	" Usage ZXCODE [-d80][-d81][-e80][-e81] FILENAME\n"
	" ie: zxcode -d80 file.o   - Decode ZX80 basic file to Ascii\n"
	" ie: zxcode -d81 file.p >file.txt  - Decode ZX81 basic file.\n"
	" ie: zxcode -e80 file.o <file.txt  - Encode Ascii to ZX80.\n"
	"");
      return 0;
    }

    if (*pName == '!') {	/* Test */
      int x;
      for (x=0; x<256; x++) {
        io_putsi (" ",x);
	io_puts (":");
	io_puts (pZX80charset[x]);
      }
      io_puts ("\n ZX80 chrset.\n");
      return 0;
    }

    if (decode) {
      if (xtype) {
        zx81_decode (pName);
      } else {
        zx80_decode (pName);
      }
    } else {
      if (xtype) {
        zx81_encode (pName);
      } else {
        zx80_encode (pName);
      }
    }
}

