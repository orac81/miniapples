#!/bin/sh
# z80asm compile:  z80asm filename
.\z80asm.elf -i %1.asm -o %1.p
