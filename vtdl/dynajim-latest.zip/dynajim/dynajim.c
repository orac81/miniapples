/* DYNAMITE JIM - A Simple demo game for the VTDL library. 
   (C) A.Millett 2012-2026. Released as free software under GPL3.

-> dynajim100, 20.3.2026  (was vfallzone)
   Imp UDGs. 
-> dynajim102, 25.3.2026
-> dynajim103, 27.3.2026
[v20 hi1263\]
-> dynajim104, 29.3.2026
-> dynajim105, 6.4.2026
*/

#define PROG_NAME "DYNAMITE JIM 1.05"

#define TDL_IO_DIRECT 1		/* Use direct screen poke for print */
// #define TDL_IO_SYS 1		/* Use OS/Kernal calls for print */

#ifdef TDL_PATH		/* User sets TDL_PATH */
 #include TDL_PATH
#else
 #include "../tdl/tdl.c"
#endif

#define PROG_DEBUG     TRUE
#define FULL_VERSION   TRUE		/* Add extra features */

/*-----------------------------------------------------------------------
   game_ playing code..
-------------------------------------------------------------------------*/

#if (TDL_UDG_MAX > 0)	/* Are UDGs available? If so, set them up.. */

BYTE pPix[] = {
  //  "vfall1.bmp" size 96 x 16, Bitdepth=1, #char: 12 x 2
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,  // chr:1
  0x18,0x18,0xe7,0x3c,0x3c,0x3c,0x24,0x66,  // chr:2
  0x99,0x5a,0x24,0x3c,0x3c,0x3c,0x24,0x66,  // chr:3
  0x08,0x22,0x1c,0x5d,0x1c,0x22,0x08,0x00,  // chr:4
  0x7c,0xc6,0xde,0xc6,0xde,0xde,0x7c,0x00,  // chr:5
  0x00,0x36,0x7f,0x77,0x7f,0x36,0x1c,0x08,  // chr:6
  0x00,0x00,0xfd,0xfe,0xfc,0xfc,0x00,0x00,  // chr:7
  0x18,0x24,0x24,0x18,0x18,0x24,0x24,0x18,  // chr:8
  0x00,0x00,0x66,0x99,0x99,0x66,0x00,0x00,  // chr:9
  0x3c,0x42,0x99,0xa5,0xa5,0x99,0x42,0x3c,  // chr:10

  //0x00,0x01,0x02,0xfc,0xfc,0xfc,0x00,0x00,  // chr:7
};

  /* Game char codes */
#define CHR_SPC      TDL_CHR_ASC32
#define CHR_PLAYER   TDL_UDG_START + 1
#define CHR_PLAYER2  TDL_UDG_START + 2
#define CHR_MINE     TDL_UDG_START + 3
#define CHR_FREEZE   TDL_UDG_START + 4
#define CHR_TARGET   TDL_UDG_START + 5
#define CHR_DYNAMITE TDL_UDG_START + 6
#define CHR_EDGEV    TDL_UDG_START + 7
#define CHR_EDGEH    TDL_UDG_START + 8
#define CHR_EDGE     TDL_UDG_START + 9

#else 	/* No UDGs.. */

 #ifdef TDL_HAS_PETSCII

	/* PETCII Game char codes */
  #define CHR_SPC      TDL_CHR_ASC32
  #define CHR_PLAYER   81
  #define CHR_PLAYER2  87
  #define CHR_MINE     TDL_ASC2CHR(':')
  #define CHR_FREEZE   TDL_ASC2CHR('F')
  #define CHR_TARGET   83
  #define CHR_DYNAMITE TDL_ASC2CHR('D')
  #define CHR_EDGEV    102
  #define CHR_EDGEH    102
  #define CHR_EDGE     102

 #else

	/* ASCII Game char codes */
  #define CHR_SPC      TDL_CHR_ASC32
  #define CHR_PLAYER   TDL_ASC2CHR('*')
  #define CHR_PLAYER2  TDL_ASC2CHR('+')
  #define CHR_MINE     TDL_ASC2CHR(':')
  #define CHR_FREEZE   TDL_ASC2CHR('F')
  #define CHR_TARGET   TDL_ASC2CHR('$')
  #define CHR_DYNAMITE TDL_ASC2CHR('D')
  #define CHR_EDGEV    TDL_ASC2CHR('!')
  #define CHR_EDGEH    TDL_ASC2CHR('-')
  #define CHR_EDGE     TDL_ASC2CHR('+')

 #endif

#endif

  /* Game char colours */
#define COL_MINE     TDL_COL_PURPLE
#define COL_PLAYER   TDL_COL_WHITE
#define COL_FREEZE   TDL_COL_BLUE
#define COL_TARGET   TDL_COL_YELLOW
#define COL_DYNAMITE TDL_COL_RED
#define COL_EDGE     TDL_COL_CYAN
#define COL_EDGE2    TDL_COL_GREEN

  /* No of obj on start screen */
#define NO_TARGETS  4
#define NO_DYNAMITE 3
#define NO_FREEZERS 5
#define NO_FREEMOVE 4	/* # free moves given by a freezer */
#define FALL_RATE (level*2+4)	/* # mines falling per move */

BYTE playx,playy;	/* Player pos */
BYTE ntarget;		/* # Targets remaining */
BYTE freemv;		/* No of "free" moves without mines falling */
BYTE ndynamite;		/* # Dynamites collected */
BYTE key;		/* User key stroke */
BYTE level;		/* Level */
UINT score;
UINT hiscore = 0;

#if TDL_VDUX < 32  /* Adjust help for screen size */

char szHelp[] = 
  "\n\n(C)A.MILLETT 2026\n\n"
  // "KEYS 789UOJKL MOVE\n"
  "KEYS QWEADZXC MOVE\n"
  "SPC=DYNAMITE\n"
  "K=QUIT\n"
  "\n";

#else /* Wider screen */

char szHelp[] = 
  "\n\n(C) A.MILLETT 2026.FREEWARE/GPL3\n\n"
  "GUIDE JIM THROUGH FALLING MINES.\n"
  "COLLECT 3 HEARTS FOR NEXT\n"
  "LEVEL. COLLECT DYNAMITE OR\n"
  "FREEZERS (F) TO HALT MINES.\n\n"
  "USE KEYS 'QWEADZXC' TO MOVE.\n"
  "SPC = DETONATE DYNAMITE.\n"
  "K = QUIT.\n"
  "\n";

#endif

void game_help () 
{
    char key;
    TDL_ScreenClr ();
    TDL_PrintStr ((char *) PROG_NAME);
    TDL_Ink (TDL_COL_YELLOW);
    TDL_PrintStr (szHelp);
    TDL_Ink (TDL_COL_PURPLE);
    TDL_PrintSI ((char *) "HI:",   hiscore); 
    TDL_Ink (TDL_COL_CYAN);
    TDL_PrintStr ((char *) "\n\nHIT SPACE");
    do {
      TDL_Rand ();	/* Randomise sequence */ 
      key = TDL_GetKey ();
    } while (key != 32);
}

  /* Find random empty square */
UINT game_randpos ()
{
    UINT r;
    BYTE z;
    for (z=200; z; z++) {
      r = (TDL_Rand () % (TDL_ScreenPos (TDL_VDUX, TDL_VDUY-3))) + TDL_ScreenPos (0,2);
      if (TDL_ScreenGet (r) == CHR_SPC) return r;
    }
    return 0;
}

  /* Display score, free mvs, level */
void score_update ()
{
    UINT pos;
    TDL_GotoXY (1,1);
    TDL_PrintInt (score);
    #if (TDL_UDG_MAX > 0)	/* Are UDGs available? */
      pos = TDL_ScreenPos (0,0);
      TDL_GotoXY (8,1);
      TDL_PrintInt (ndynamite);
      TDL_ScreenSet (pos+5, CHR_DYNAMITE, COL_DYNAMITE); 
      TDL_GotoXY (13,1);
      TDL_PrintInt (freemv);
      TDL_ScreenSet (pos+10, CHR_FREEZE, COL_FREEZE); 
      TDL_GotoXY (TDL_VDUX-4,1);
      TDL_PrintInt (FALL_RATE);
      TDL_PrintSI ((char *) ",",level);
      TDL_ScreenSet (TDL_VDUX-7, CHR_MINE, COL_MINE); 
    #else
      TDL_PrintSI ((char *) " DY:",ndynamite);
      TDL_PrintSI ((char *) " FR:",freemv);
      TDL_PrintSI ((char *) " LV:",level);
    #endif
}

void game_sound (BYTE n)
{
    UINT r;
    while (n) {
     r = TDL_Rand ();
     TDL_Sound (TDL_SOUND_LO + (r & 127)* TDL_SOUND_STEP, 1);
     n --;
     TDL_Sleep (20);
    }
    TDL_SoundOff (1);
}

  /* Progress to next level. */
void game_new_level () 
{
    BYTE x,y,z;
    UINT pos;
    level ++;
    TDL_ScreenClr ();    
    freemv = 1;
	/* Put player in center */
    playx = TDL_VDUX/2;
    playy = TDL_VDUY/2;
    TDL_ScreenSet (TDL_ScreenPos (playx, playy), CHR_PLAYER, COL_PLAYER); 
	/* Draw edges */
    for (x=0; x< TDL_VDUX; x++) {
      TDL_ScreenSet (TDL_ScreenPos(x,1), CHR_EDGEH, COL_EDGE2); 
      TDL_ScreenSet (TDL_ScreenPos(x,TDL_VDUY-1), CHR_EDGEH, COL_EDGE2); 
    }
    for (y=1; y< TDL_VDUY; y++) {
      TDL_ScreenSet (TDL_ScreenPos(0,y), CHR_EDGEV, COL_EDGE2); 
      TDL_ScreenSet (TDL_ScreenPos(TDL_VDUX-1,y), CHR_EDGEV, COL_EDGE2); 
    }
    TDL_ScreenSet (TDL_ScreenPos(0,1), CHR_EDGE, COL_EDGE); 
    TDL_ScreenSet (TDL_ScreenPos(TDL_VDUX-1,1), CHR_EDGE, COL_EDGE); 
    TDL_ScreenSet (TDL_ScreenPos(0,TDL_VDUY-1), CHR_EDGE, COL_EDGE); 
    TDL_ScreenSet (TDL_ScreenPos(TDL_VDUX-1,TDL_VDUY-1), CHR_EDGE, COL_EDGE); 
	/* Draw targets */
    ntarget = NO_TARGETS;
    for (z=0; z<NO_TARGETS; z++) {
      pos = game_randpos ();
      if (pos) TDL_ScreenSet (pos, CHR_TARGET, COL_TARGET); 
    }
	/* Draw freezers */
    for (z=0; z<NO_FREEZERS; z++) {
      pos = game_randpos ();
      if (pos) TDL_ScreenSet (pos, CHR_FREEZE, COL_FREEZE); 
    }
    for (z=0; z<NO_DYNAMITE; z++) {
      pos = game_randpos ();
      if (pos) TDL_ScreenSet (pos, CHR_DYNAMITE, COL_DYNAMITE); 
    }
    score_update ();
    game_sound (10);
}

void game_new ()
{
    level = 0;		
    score = 0;
    ndynamite = 2;	/* Start with 2 sticks */
    game_new_level ();
}

  /* Move direction array (keys around S) (dir bit 01=x,23=y) */
BYTE keydir [] = "QWE\0ASD\0ZXC";

//BYTE keydir [] = "789\0456\0123";	// Num Keypad

BYTE player_move ()
{
    BYTE mvdir,px,py;
    BYTE x,y,z=0;
    UINT pos;
    BYTE ch;
    do {
      #if FULL_VERSION		/* Add player anmation */
	TDL_Sleep (20);
        z ++;
        TDL_ScreenSet (TDL_ScreenPos (playx, playy), ((z & 16) ? CHR_PLAYER : CHR_PLAYER2), COL_PLAYER); 
      #endif
      key = TDL_GetKey ();
      key = TDL_TOUPPER (key);
    } while (key == 0);

    if (key == ' ' && ndynamite > 0) {		/* Detonate a stick of Dynamite! */
      ndynamite --;
      for (y = playy-1; y <= playy+1; y++) {
        for (x = playx-1; x <= playx+1; x++) {
          pos = TDL_ScreenPos (x, y);
          ch = TDL_ScreenGet  (pos);
          if (ch == CHR_MINE) {			/* Wipe all mines around player */
            TDL_ScreenSet (pos, TDL_ASC2CHR('*'), TDL_COL_RED); 
            game_sound (2);
            TDL_ScreenSetNC (pos, CHR_SPC); 
	  }
	}
      }
      return FALSE;
    }
    if (key == 'K') return TRUE;
	/* Is it a direction key? mvdir:bits01=X,23=Y */
    for (mvdir=0; mvdir<12; mvdir++) {
      if (key == keydir[mvdir]) goto play1;
    }
    return FALSE;
play1:
    TDL_ScreenSetNC (TDL_ScreenPos (playx, playy), CHR_SPC); 
    px = playx + (mvdir & 3)-1;  
    py = playy + (mvdir >> 2)-1;
    pos = TDL_ScreenPos (px, py);
    ch = TDL_ScreenGet  (pos);
    switch (ch) {
      case CHR_SPC:
        playx = px; playy = py;
	break;

      case CHR_MINE:	/* Hit mine, game ends */
        for (z=0; z<14; z++) {
	  TDL_ScreenSet (pos, CHR_MINE, COL_MINE);
          game_sound (2);
	  TDL_ScreenSet (pos, CHR_PLAYER, COL_PLAYER); 
          game_sound (2);
	}
        return TRUE;

      case CHR_TARGET:
        game_sound (2);
        freemv ++;
	score += level;
        playx = px; playy = py;
        ntarget --;
        if (ntarget == 1) {	/* Next level..  */
	  game_new_level ();
        } 
        score_update ();
	break;

      case CHR_FREEZE:
        game_sound (2);
	score += level*2;
        freemv += 4;		/* Add some free moves */
        playx = px; playy = py;
        score_update ();
	break;

      case CHR_DYNAMITE:
        game_sound (2);
	score += level*2;
        freemv ++;
        ndynamite ++;
        playx = px; playy = py;
        score_update ();
	break;

      default:
    }
    TDL_ScreenSet (TDL_ScreenPos (playx, playy), CHR_PLAYER, COL_PLAYER); 

    if (freemv) {	/* Dont drop if there are "free" moves */
      freemv --;
    } else {		/* Drop mines.. */
      for (z = FALL_RATE; z; z--) {
        pos = game_randpos ();
        if (pos) TDL_ScreenSet (pos, CHR_MINE, COL_MINE); 
      }
    }
    score_update ();
    return FALSE;
}

  /* Main game loop */
void game_Loop ()
{
    BYTE x;
    while (1) {
      // TDL_ScreenBackground (TDL_COL_BLACK, TDL_COL_BLACK);
      game_help ();	/* Display title screen & help */
      game_new ();	/* Start a new game */
      //for (x=0; x<TDL_VDUX; x++) {TDL_PrintChar (48+(x%10));}
      while (1) {
        if (player_move ()) break;
      }
      if (score > hiscore) hiscore = score;
      TDL_Sleep (1000);
    }
}

	/* Main program */
int main ()
{
    TDL_Initialise (0,NULL);
    #if (TDL_UDG_MAX > 0)	/* Are UDG gfx available? If so, set up.. */
      TDL_UDG_Init (pPix, TDL_UDG_START, sizeof (pPix));
    #endif
    TDL_SoundInit ();
    game_Loop ();	/* Main game loop */
    return 0;
}
