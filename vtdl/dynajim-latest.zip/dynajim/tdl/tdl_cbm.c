/* TDL 2.xx - Very Tiny Development Layer for portable small apps.
  (C) A.Millett 2012-2026. Released as open software under GNU GPL3 license.
  TDL Library released under (less restrictive) LGPL license.

*/

#include <stdio.h>
#include <stdlib.h>

/*-----------------------------------------------------------------------
   Common CBM defines, vars, fwd declarations
-------------------------------------------------------------------------*/

#define TDL_FAST __zeropage		/* Fast (zeropage,register etc) variable definition */

#define TDL_VDU_STATIC TRUE	 /* VDU size/colour parameters are static/limited */
#define TDL_HAS_UDG  TRUE	/* Tell user program UDGs are available */

#define TDL_POKE(AD,BY) *((BYTE *) ((UINT) (AD)))=(BYTE) (BY);
#define TDL_PEEK(AD) ((BYTE) *((BYTE *) ((UINT) (AD))))

#define TDL_ADD_CR  TRUE		/* Add CR if LF sent (TDL_PrintSring) */


void TDL_PrintChar (BYTE ch);		/* Fwd declare */
void TDL_ScreenClr ();
void TDL_GotoXY (BYTE x, BYTE y);
void TDL_Ink (BYTE ink);
BYTE TDL_GetKey ();
UINT TDL_Clock ();
#define TDL_CLOCKS_PER_SEC 60

BYTE TDL_border;
BYTE TDL_screen;

BYTE TDL_cursorx ;
BYTE TDL_cursory ;
BYTE TDL_ink ;

void TDL_PrintCharRaw (BYTE ch)
{
    __asm {
      lda ch
      jsr $ffd2
    }
}

/*-----------------------------------------------------------------------
   C64 specific code
-------------------------------------------------------------------------*/

#ifdef TDL_C64

#define TDL_VDUX 40
#define TDL_VDUY 25

#define TDL_HAS_PETSCII TRUE 	/* Tell program PETSCII is available (if UDGs not used) */

  /*. TDL_ScreenPos(X,Y) - Calc Screen char position from X,Y (0 to max-1) */
#define TDL_ScreenPos(X,Y) ((X)+((Y)<<5)+( (Y)<<3))

  /*. TDL_ScreenSet(POS,BYT,COL) - Poke VDU pos with char & colour */
#define TDL_ScreenSet(POS,BYT,COL)  {TDL_pScreen[POS] = BYT; TDL_pCol[POS] = COL; }

  /*. TDL_ScreenSet(POS,BYT,COL) - Poke VDU pos with char (No colour) */
#define TDL_ScreenSetNC(POS,BYT)  TDL_pScreen[POS] = BYT;

  /*. TDL_ScreenGet(POS) - Peek VDU pos, ret char */
#define TDL_ScreenGet(POS) (TDL_pScreen[POS])			/* Get VDU char */

#define TDL_UDG_START 64		/* Start of UDG chars */
#define TDL_UDG_MAX 128			/* #UDG chars */
#define TDL_CHR_ASC32   32		/* Poke-code Ascii 32-63*/
#define TDL_CHR_ASC64   0		/* Ascii 64-95 */
#define TDL_CHR_ASC96   0		/* Ascii 96-127 */
#define TDL_ASC2CHR(C) ((C)&63)		/* Convert ascii to chr code */

#define TDL_CBM_JIFFY 0xa0			// CBM Jiffy clock (hi to lo)
#define TDL_CBM_KEYDOWN 0xc5		// Keydown peek loc, c64=c5,v20=c5,c16=07f6.
#define TDL_CBM_KEY2ASC  0xeb81		// ROM table convert scancode (@C5) to asc.
#define TDL_CBM_KEYSHIFT 0x028d		// Shift Key status
#define TDL_CBM_VDULOC  0x8000	/* Screen loc  */
#define TDL_CBM_COLRAM  0xd800	/* Colour ram loc */
#define TDL_CBM_CHRSET  0x8800	// Hires RAM Char set location

const UINT TDL_CBM_ROMSET  = 0xd000;	// Hires Char set location

const UINT TDL_C64_MEMCTL  = 0xd018;  	// VIC Memory Control Register: Bit:4-7 (VDU Base Bit 13-10) Bit:1-3 (Char Set Bit 13-11)
const UINT TDL_C64_BORDER  = 0xd020;	// VIC border colour
const UINT TDL_C64_SCREEN  = 0xd021;	// VIC screen colour
const UINT TDL_C64_REG_6510  = 1;		// C64 - 6510 I/O register
const UINT TDL_C64_INTERRUPT = 56334;	// Bit 0 turns IRQ on/off
const UINT TDL_C64_CIA2 = 0xdd00;		// CIA#2, lo 2 bits control VIC bank. (0=c000,1=8000,2=4000,3=0000(def))
const UINT TDL_C64_CIA2DIR = 0xdd02;	// CIA#2, dir reg.

#define TDL_C64_SID      0xd400		// C64 SID registers
#define TDL_C64_SIDV1    0xd400		// Voice 1:Freq lo,hi:Fout= (Fin * 0.059604645) hz.
#define TDL_C64_SIDV1PW  0xd402		// Pulse Width lo,hi :0-0FFF
#define TDL_C64_SIDV1CTL 0xd404		// Control bits. 6=Pulse,5=Saw,4=Tri,0=Gate
#define TDL_C64_SIDV1AD  0xd405		// Attack  (bit4-7), Decay (b0-3)
#define TDL_C64_SIDV1SR  0xd406		// Sustain (bit4-7), Release (b0-3)
#define TDL_C64_SIDV2    0xd407		// Voice 2
#define TDL_C64_SIDV3    0xd40e		// Voice 3
#define TDL_C64_SIDVOL   0xd418
#define TDL_C64_SIDVOX_STEP 7		// Gap between voices

BYTE *TDL_pScreen = (BYTE *) ((UINT) TDL_CBM_VDULOC);	/* Ptr to screen */
BYTE *TDL_pCol = (BYTE *) ((UINT) TDL_CBM_COLRAM);	/* Ptr to colour ram */

  /* Native Colour codes */
#define TDL_COL_BLACK   0
#define TDL_COL_RED     2	/* 1:Bit 0 */
#define TDL_COL_GREEN   5	/* 2:Bit 1 */
#define TDL_COL_YELLOW  7
#define TDL_COL_BLUE    6	/* 4:Bit 2 */
#define TDL_COL_PURPLE  4
#define TDL_COL_CYAN    3
#define TDL_COL_WHITE   1

  /* System-Native Colours (poke codes), in RGB order, (0-7) */
BYTE TDL_RGBI2COL[]={0,2,5,7,6,4,3,1, 11,10,13,7,14,4,3,1};   /* Colour Conversion Table for ScreenSet */

#define TDL_RGBItoCol(RGBI) TDL_RGBI2COL[RGBI]

BYTE TDL_COL2INK[] = {144,5,28,159,156,30,31,158};	// Convert CBM poke to ink print codes.


#define TDL_SCANCODE_NONE 255

  /*. BYTE TDL_GetKeyDown ()  -  Get key held down */
BYTE TDL_GetKeyDown ()
{
    BYTE key;
    key = TDL_PEEK(TDL_CBM_KEYDOWN);
    return TDL_PEEK (TDL_CBM_KEY2ASC + key);  // 255=none. EB81 (60289) rom translate table
}

  /*. BYTE TDL_GetKey_Shift () - Return shift status */
BYTE TDL_GetKey_Shift ()
{
    return TDL_PEEK (TDL_CBM_KEYSHIFT);
}

void TDL_ScreenClr ()
{
    TDL_PrintCharRaw (5);
    TDL_PrintCharRaw (147);
    TDL_GotoXY (1,1);
    TDL_Ink (TDL_COL_WHITE);
}



  /*. void TDL_Sleep (int tim)  - Sleep (tim) milliseconds */
void TDL_Sleep (int tim) 
{
      BYTE last;
      do {
	#if IS_OSCAR	
         __asm {
	     lda TDL_CBM_JIFFY+2
	   looptim:
	     cmp TDL_CBM_JIFFY+2
	     beq looptim
	 };
	#else
	  last = TDL_PEEK (TDL_CBM_JIFFY+2);
	  while (TDL_PEEK (TDL_CBM_JIFFY+2) == last);		// Delay 1 jiffy (but OSCAR optimizes this out!)
	#endif
	tim = tim - 17;		// Approx 1/60 sec (avoids divide)
      } while (tim > 0);
}

void TDL_FrameSync ()
{
    // TDL_Sleep (17);  // Crude method 
    __asm {
        sei
      syncloop:
        ldx $d012      // Raster - Wait for line 255
        inx
        bne syncloop
        cli
    };
}

#define TDL_SOUND_TYPE UINT

#define TDL_SOUND_NVOICE 3	// No of voices
  // Convert Freq (in hertz) to Tone val. (FHz * 16.5)
#define TDL_SOUND_FREQ2TONE(FHz) ((UINT) ((FHz)<<4) + ((FHz)>>1) )

#define TDL_SOUND_LO  0
#define TDL_SOUND_HI  65535
#define TDL_SOUND_STEP  256	// Simple scaling step for fx

#define TDL_SOUND_C4  4291	// C4  261.63Hz  (Middle C) 
#define TDL_SOUND_A4  7217	// A4, 440Hz
#define TDL_SOUND_C5  8293	// C5, 523.26Hz
#define TDL_SOUND_A5  14435	// A5, 880Hz

  /* Simple sound tone generator (voice 0-2) */
void TDL_Sound (UINT val, BYTE voice)
{
    voice *= TDL_C64_SIDVOX_STEP;
    TDL_POKE (TDL_C64_SIDV1+voice,   val & 0xff);
    TDL_POKE (TDL_C64_SIDV1+1+voice, val >> 8);
    TDL_POKE (TDL_C64_SIDV1CTL+voice,0x21);
}

void TDL_SoundOff (BYTE voice)
{
    TDL_POKE (TDL_C64_SIDV1CTL+voice*TDL_C64_SIDVOX_STEP,0);
}

void TDL_SoundInit ()
{
    BYTE voice;
    for (voice=0; voice < TDL_C64_SIDVOX_STEP*3; voice += TDL_C64_SIDVOX_STEP) {
      TDL_POKE (TDL_C64_SIDV1PW+voice,8);
      TDL_POKE (TDL_C64_SIDV1AD+voice,0);
      TDL_POKE (TDL_C64_SIDV1SR+voice,0xf0);
    }
    TDL_POKE (TDL_C64_SIDVOL,15);
}

  /* Set up the UDG chr set */
void TDL_UDG_Init (BYTE *pPix, UINT chstart, UINT psize)
{
    UINT p;
    BYTE *pSet = (BYTE *) TDL_CBM_CHRSET;
    chstart *= 8;
	// Copy char set data 
    for (p= 0; p< psize; p++) {
      pSet [chstart+p]= pPix [p];
    } 
}

  /*. void TDL_ScreenBackground (BYTE screen, BYTE border) - Set background */
void TDL_ScreenBackground (BYTE screen, BYTE border)
{
    TDL_POKE (TDL_C64_BORDER,   border);
    TDL_POKE (TDL_C64_BORDER+1, screen);
}

  /* Initialise TDL lib */
UINT TDL_Initialise (UINT mode, BYTE *pData)
{
    UINT p;
    TDL_ScreenBackground (TDL_COL_BLACK, TDL_COL_BLACK);
    //iocharmap(IOCHM_PETSCII_2); 	// Oscar map petscii
    //TDL_POKE (TDL_C64_BORDER,   0);
    //TDL_POKE (TDL_C64_BORDER+1, 0);
    TDL_POKE (TDL_C64_CIA2DIR, TDL_PEEK(TDL_C64_CIA2DIR) | 3);	// Select VIC bank dir
    TDL_POKE (TDL_C64_CIA2, (TDL_PEEK(TDL_C64_CIA2) & 252) | 1);	// Select VIC bank $8000
    TDL_POKE (TDL_C64_MEMCTL, 2);	// Set VDU 8000 (bits 4-7), CHRSET $8800 (bits 1-3)
	// poke648,128:poke55,0:poke56,128:poke1024,0:poke43,1:poke44,4:rem like pet basic
    TDL_POKE (648,128);
    {
      BYTE *pSrc  = (BYTE *) TDL_CBM_ROMSET;
      BYTE *pDest = (BYTE *) TDL_CBM_CHRSET;
      //BYTE *pIntr = (BYTE *) TDL_C64_INTERRUPT;
      BYTE *pMemCtl = (BYTE *) TDL_C64_REG_6510;
      __asm { sei };
      //*pIntr = *pIntr & 254;		// IRQ off
      *pMemCtl = *pMemCtl & 0xfb;	// Bit 2 off
      for (p=0; p<2048; p++) {		// Copy orig ROM set to RAM
	pDest [p] = pSrc [p];
      }
      *pMemCtl = *pMemCtl | 4;
      //TDL_POKE (VIC_MEMCTL, 0x1d);	// Set VDU=$0400,CHRSET=$3000 (def $15)
      __asm { cli };
      //*pIntr = *pIntr | 1;		// IRQ back on
    }
    TDL_ScreenClr ();
    return 0;
}


#endif 	// TDL_C64

/*-----------------------------------------------------------------------
   VIC20 specific code
-------------------------------------------------------------------------*/

#ifdef TDL_VIC20		/* Unexpanded VIC */

#pragma stacksize (128)		/* Keep stack/heap small */
#pragma heapsize (32)

#define TDL_VDUX 22
#define TDL_VDUY 23

	/*. TDL_ScreenPos(X,Y) - Calc Screen char position from X,Y (0 to max-1) */
#define TDL_ScreenPos(X,Y) ((X)+(Y)*TDL_VDUX)
	/*. TDL_ScreenSet(POS,BYT,COL) - Poke VDU pos with char & colour */
#define TDL_ScreenSet(POS,BYT,COL)  {TDL_pScreen[POS] = BYT; TDL_pCol[POS] = COL; }	/* Set VDU char & col */
	/*. TDL_ScreenSet(POS,BYT,COL) - Poke VDU pos with char (No colour set) */
#define TDL_ScreenSetNC(POS,BYT)  TDL_pScreen[POS] = BYT;	
	/*. TDL_ScreenSet(POS,BYT,COL) - Peek VDU pos, ret char */


#define TDL_ScreenSet(POS,BYT,COL)  {TDL_pScreen[POS] = BYT; TDL_pCol[POS] = COL;} 	/* Set VDU char & col */
#define TDL_ScreenGet(POS) (TDL_pScreen[POS])			/* Get VDU char */
#define TDL_UDG_START 32		/* Start of UDG chars */
#define TDL_UDG_MAX 32			/* #UDG chars */
		/* For VIC20 Unexpanded, Chrset @$1c00, PETSCII is CHR 128-255 */
#define TDL_CHR_ASC32   128+32		/* Ascii 32-63 */
#define TDL_CHR_ASC64   128		/* Ascii 64-95 */
#define TDL_CHR_ASC96   128		/* Ascii 96-127 */
#define TDL_ASC2CHR(C) (((C) & 63) | 128) 	/* Convert ascii to chr code */

	// VIC regs
#define TDL_V20_HPOS    0x9000		// bits 0-6 horizontal pos/centering, bit 7 sets interlace scan (36864) [PAL:12,NTSC:5]
#define TDL_V20_VPOS    0x9001		// vert position [PAL:38,NTSC:25]
#define TDL_V20_HSIZE   0x9002		// bits 0-6 set # of columns, bit 7 part video matrix address
#define TDL_V20_VSIZE   0x9003		// bits 1-6 set # of rows, bit 0 for 8x8 or 8x16 chars
#define TDL_V20_RASTER  0x9004		// current video raster line
#define TDL_V20_VIDADD  0x9005		// Vid/chrset address: bits 0-3 charset address, bits 4-7 screen address.  (36869)
#define TDL_V20_PENH    0x9006		// Light pen horiz
#define TDL_V20_PENV    0x9007		// Light pen vert
#define TDL_V20_PADX    0x9008		// Paddle X
#define TDL_V20_PADY    0x9009		// Paddle Y
#define TDL_V20_VOICE1  0x900a		// Voice osc 1 (128-255) bit 7 on/off (36874)
#define TDL_V20_VOICE2  0x900b		// Voice osc 2 (128-255) bit 7 on/off
#define TDL_V20_VOICE3  0x900c		// Voice osc 3 (128-255) bit 7 on/off
#define TDL_V20_NOISE   0x900d		// Voice noise (128-255) bit 7 on/off
#define TDL_V20_VOL     0x900e		// bit 0-3 overall volume, bits 4-7 aux color in multicolor mode.
#define TDL_V20_BACKCOL 0x900f		// Screen/border color, bits 4-7 screen background, bits 0-2 border, bit 3 for inverted/normal mode (36879)

#define TDL_CBM_JIFFY    0xa0		// CBM Jiffy clock (hi to lo)
#define TDL_CBM_KEYDOWN  0xc5		// Keydown peek loc, c64=c5,v20=c5,c16=07f6.
#define TDL_CBM_KEY2ASC  0xec5e		// ROM table convert scancode (@C5) to asc.
#define TDL_CBM_KEYSHIFT 0x028d		// Shift Key status
#define TDL_CBM_VDULOC   0x1e00	/* Screen loc  */
#define TDL_CBM_COLRAM   0x9600	/* Colour ram loc */
#define TDL_CBM_CHRSET   0x1c00	// Hires RAM Char set location

const UINT TDL_CBM_ROMSET  = 0x8000;	// Hires Char set location

BYTE *TDL_pScreen = (BYTE *) ((UINT) TDL_CBM_VDULOC);	/* Ptr to screen */
BYTE *TDL_pCol = (BYTE *) ((UINT) TDL_CBM_COLRAM);	/* Ptr to colour ram */

  /* Native system colour codes */
#define TDL_COL_BLACK  0
#define TDL_COL_RED    2	/* 1:Bit 0 */
#define TDL_COL_GREEN  5	/* 2:Bit 1 */
#define TDL_COL_YELLOW 7
#define TDL_COL_BLUE   6	/* 4:Bit 2 */
#define TDL_COL_PURPLE 4
#define TDL_COL_CYAN   3
#define TDL_COL_WHITE  1

  /* System-Native Colours (poke codes), in RGB order, (0-7) RED=+1, GREEN=+2, BLUE=+4 */
BYTE TDL_RGBI2COL[]={0,2,5,7,6,4,3,1, 11,10,13,7,14,4,3,1};   /* Colour Conversion Table for ScreenSet */

#define TDL_RGBItoCol(RGBI) TDL_RGBI2COL[RGBI]

/*
BYTE TDL_RGBI2INK[] = {144,28,30,158,31,156,159,5};	// CBM ink print codes, RGB 0-7 (bits 0,1,2) to ink code 
*/

BYTE TDL_COL2INK[] = {144,5,28,159,156,30,31,158};	// Convert CBM poke to ink print codes.


#define TDL_SCANCODE_NONE 255

  /*. BYTE TDL_GetKey_scancode ()  -  Get key raw scancode (key held down) */
BYTE TDL_GetKeyDown ()
{
    BYTE key;
    key = TDL_PEEK (TDL_CBM_KEYDOWN);
    return TDL_PEEK (TDL_CBM_KEY2ASC + key);  // EC5E (60510) v20 rom translate table
}

  /* OLD: BYTE TDL_GetKeyDown () { return TDL_PEEK(TDL_CBM_KEYDOWN);} */

  /*. BYTE TDL_GetKey_Shift () - Return shift status */
BYTE TDL_GetKey_Shift ()
{
    return TDL_PEEK (TDL_CBM_KEYSHIFT);
}

void TDL_ScreenClr ()
{
    UINT p;
    TDL_GotoXY (1,1);
    TDL_Ink (TDL_COL_WHITE);
    TDL_PrintCharRaw (5);
    TDL_PrintCharRaw (147);
    #ifdef TDL_VIC20		/* For VIC20 Unexpanded, Chrset @$1c00, PETSCII is CHR 128-255 */
      for (p=0; p<512; p++) {
        TDL_pScreen[p] = TDL_CHR_ASC32;  
      }
    #endif
}


  // Sleep (tim) milliseconds
void TDL_Sleep (int tim) 
{
      BYTE last;
      do {
	#if IS_OSCAR	
         __asm {
	     lda TDL_CBM_JIFFY+2
	   looptim:
	     cmp TDL_CBM_JIFFY+2
	     beq looptim
	 };
	#else
	  last = TDL_PEEK (TDL_CBM_JIFFY+2);
	  while (TDL_PEEK (TDL_CBM_JIFFY+2) == last);		// Delay 1 jiffy (but OSCAR optimizes this out!)
	#endif
	tim = tim - 17;		// Approx 1/60 sec (avoids divide)
      } while (tim > 0);
}

  /* Wait for start of frame, for animation etc. */
void TDL_FrameSync ()
{
    // TDL_Sleep (17);  // Q&D method 
 __asm {
   lda #100
   sei
  sync1:
   cmp TDL_V20_RASTER	// Vic20 Raster register (lo)
   bne sync1
   cli
   rts
 }; 
}

#define TDL_SOUND_TYPE BYTE

#define TDL_SOUND_C4  131	// Rough note vals
#define TDL_SOUND_A4  181
#define TDL_SOUND_C5  192
#define TDL_SOUND_A5  218

#define TDL_SOUND_LO  128
#define TDL_SOUND_HI  255
#define TDL_SOUND_STEP  1	// Simple scaling step for fx

 /* VIC C2:131,140,145,151,158,161,166,173,178,181,185,189  C3:192,197,200,293,206,208,211,214,216,218,220,222 */

  /* Simple sound generator */
void TDL_Sound (BYTE val, BYTE voice)
{
    TDL_POKE (TDL_V20_VOICE1+voice, val);
}

void TDL_SoundOff (BYTE voice)
{
    TDL_POKE (TDL_V20_VOICE1+voice, 0);
}

void TDL_SoundInit () 
{
    TDL_POKE (TDL_V20_VOL, 15);
}

  /* Set up the UDG chr set */
void TDL_UDG_Init (BYTE *pPix, UINT chstart, UINT psize)
{
    UINT p;
    BYTE *pSet = (BYTE *) TDL_CBM_CHRSET;
    chstart *= 8;
	// Copy char set data 
    for (p= 0; p< psize; p++) {
      pSet [chstart+p]= pPix [p];
    } 
}

  /*. void TDL_ScreenBackground (BYTE screen, BYTE border) - Set background */
void TDL_ScreenBackground (BYTE screen, BYTE border)
{
    TDL_POKE (TDL_V20_BACKCOL, 8 | border | (screen << 4));
}

  /* Initialise TDL lib */
UINT TDL_Initialise (UINT mode, BYTE *pData)
{
    UINT p;
    TDL_ScreenBackground (TDL_COL_BLACK, TDL_COL_BLACK);
    //iocharmap(IOCHM_PETSCII_2); 	// Oscar map petscii
    TDL_POKE (TDL_V20_VIDADD, 0xff);		// Set VDU=$1e00,CHRSET=$1c00
    TDL_ScreenClr ();
    return 0;
}

#endif 	// TDL_VIC20

/*-----------------------------------------------------------------------
   PET specific code
-------------------------------------------------------------------------*/

#if defined(TDL_PET) || defined(TDL_PET80)

#define TDL_VDUY 25

#if defined(TDL_PET80)
 #define TDL_VDUX 80
#else
 #define TDL_VDUX 40
#endif

#define TDL_HAS_PETSCII TRUE 	/* Tell program PETSCII is available (if UDGs not used) */

  /*. TDL_ScreenPos(X,Y) - Calc Screen char position from X,Y (0 to max-1) */
#define TDL_ScreenPos(X,Y) ((X)+((Y)*TDL_VDUX))

  /*. TDL_ScreenSet(POS,BYT,COL) - Poke VDU pos with char & colour */
#define TDL_ScreenSet(POS,BYT,COL)  {TDL_pScreen[POS] = BYT; }

  /*. TDL_ScreenSet(POS,BYT,COL) - Poke VDU pos with char (No colour) */
#define TDL_ScreenSetNC(POS,BYT)  TDL_pScreen[POS] = BYT;

  /*. TDL_ScreenGet(POS) - Peek VDU pos, ret char */
#define TDL_ScreenGet(POS) (TDL_pScreen[POS])			/* Get VDU char */

#define TDL_UDG_START 0		/* Start of UDG chars */
#define TDL_UDG_MAX 0			/* #UDG chars */
#define TDL_CHR_ASC32   32		/* Poke-code Ascii 32-63*/
#define TDL_CHR_ASC64   0		/* Ascii 64-95 */
#define TDL_CHR_ASC96   0		/* Ascii 96-127 */
#define TDL_ASC2CHR(C) ((C)&63)		/* Convert ascii to chr code */

#define TDL_CBM_JIFFY 0x8d		// CBM Jiffy clock (hi to lo)
#define TDL_CBM_KEYDOWN 0x97		// Keydown peek loc, c64=c5,v20=c5,c16=07f6,pet=97.
#define TDL_CBM_KEY2ASC  0xeb81		// ROM table convert scancode (@C5) to asc.
#define TDL_CBM_KEYSHIFT 0x98		// Shift Key status
#define TDL_CBM_VDULOC  0x8000	/* Screen loc  */

BYTE *TDL_pScreen = (BYTE *) ((UINT) TDL_CBM_VDULOC);	/* Ptr to screen */

  /* Native Colour codes */
#define TDL_COL_BLACK   0
#define TDL_COL_RED     2	/* 1:Bit 0 */
#define TDL_COL_GREEN   5	/* 2:Bit 1 */
#define TDL_COL_YELLOW  7
#define TDL_COL_BLUE    6	/* 4:Bit 2 */
#define TDL_COL_PURPLE  4
#define TDL_COL_CYAN    3
#define TDL_COL_WHITE   1

  /* System-Native Colours (poke codes), in RGB order, (0-7) */
BYTE TDL_RGBI2COL[]={0,2,5,7,6,4,3,1, 11,10,13,7,14,4,3,1};   /* Colour Conversion Table for ScreenSet */

#define TDL_RGBItoCol(RGBI) TDL_RGBI2COL[RGBI]

BYTE TDL_COL2INK[] = {144,5,28,159,156,30,31,158};	// Convert CBM poke to ink print codes.


#define TDL_SCANCODE_NONE 255

  /*. BYTE TDL_GetKeyDown ()  -  Get key held down */
BYTE TDL_GetKeyDown ()
{
    BYTE key;
    key = TDL_PEEK(TDL_CBM_KEYDOWN);
    return TDL_PEEK (TDL_CBM_KEY2ASC + key);  // 255=none. EB81 (60289) rom translate table
}

  /*. BYTE TDL_GetKey_Shift () - Return shift status */
BYTE TDL_GetKey_Shift ()
{
    return TDL_PEEK (TDL_CBM_KEYSHIFT);
}

void TDL_ScreenClr ()
{
    TDL_PrintCharRaw (147);
    TDL_GotoXY (1,1);
}


  /*. void TDL_Sleep (int tim)  - Sleep (tim) milliseconds */
void TDL_Sleep (int tim) 
{
      BYTE last;
      do {
	#if IS_OSCAR	
         __asm {
	     lda TDL_CBM_JIFFY+2
	   looptim:
	     cmp TDL_CBM_JIFFY+2
	     beq looptim
	 };
	#else
	  last = TDL_PEEK (TDL_CBM_JIFFY+2);
	  while (TDL_PEEK (TDL_CBM_JIFFY+2) == last);		// Delay 1 jiffy (but OSCAR optimizes this out!)
	#endif
	tim = tim - 17;		// Approx 1/60 sec (avoids divide)
      } while (tim > 0);
}

void TDL_FrameSync ()
{
    TDL_Sleep (17);  	// Simple method 
}

#define TDL_SOUND_TYPE BYTE

#define TDL_SOUND_NVOICE 1	// No of voices

#define TDL_SOUND_LO  0
#define TDL_SOUND_HI  255
#define TDL_SOUND_STEP  1	// Simple scaling step for fx

#define TDL_SOUND_C4  100	// Rough note vals
#define TDL_SOUND_A4  150
#define TDL_SOUND_C5  200
#define TDL_SOUND_A5  220

  /* Simple sound tone generator */
void TDL_Sound (BYTE val, BYTE voice)
{
    TDL_POKE (0xe84b,0x10);	// poke 59467,16
    TDL_POKE (0xe84a,0x0f); 	// poke 59466,15:waveform
    TDL_POKE (0xe848,val);	// poke59464,x
}

void TDL_SoundOff (BYTE voice)
{
    TDL_POKE (0xe84b,0);
}

void TDL_SoundInit ()
{
}

  /* Set up the UDG chr set */
void TDL_UDG_Init (BYTE *pPix, UINT chstart, UINT psize)
{
}

  /*. void TDL_ScreenBackground (BYTE screen, BYTE border) - Set background */
void TDL_ScreenBackground (BYTE screen, BYTE border)
{
}

  /* Initialise TDL lib */
UINT TDL_Initialise (UINT mode, BYTE *pData)
{
    TDL_POKE (59468,12);	/* Upper case PETSCII */
    TDL_ScreenClr ();
    return 0;
}


#endif 	// TDL_PET

/*-----------------------------------------------------------------------
   C16 specific code
-------------------------------------------------------------------------*/

#ifdef TDL_C16

#define TDL_VDUX 40
#define TDL_VDUY 25

#define TDL_HAS_PETSCII TRUE 	/* Tell program PETSCII is available (if UDGs not used) */

  /*. TDL_ScreenPos(X,Y) - Calc Screen char position from X,Y (0 to max-1) */
#define TDL_ScreenPos(X,Y) ((X)+((Y)<<5)+( (Y)<<3))

  /*. TDL_ScreenSet(POS,BYT,COL) - Poke VDU pos with char & colour */
#define TDL_ScreenSet(POS,BYT,COL)  {TDL_pScreen[POS] = BYT; TDL_pCol[POS] = COL; }

  /*. TDL_ScreenSet(POS,BYT,COL) - Poke VDU pos with char (No colour) */
#define TDL_ScreenSetNC(POS,BYT)  TDL_pScreen[POS] = BYT;

  /*. TDL_ScreenGet(POS) - Peek VDU pos, ret char */
#define TDL_ScreenGet(POS) (TDL_pScreen[POS])			/* Get VDU char */

#define TDL_UDG_START 64		/* Start of UDG chars */
#define TDL_UDG_MAX 192			/* #UDG chars */
#define TDL_CHR_ASC32   32		/* Poke-code Ascii 32-63*/
#define TDL_CHR_ASC64   0		/* Ascii 64-95 */
#define TDL_CHR_ASC96   0		/* Ascii 96-127 */
#define TDL_ASC2CHR(C) ((C)&63)		/* Convert ascii to chr code */

#define TDL_CBM_JIFFY 0xa3		// CBM Jiffy clock (hi to lo)
#define TDL_CBM_KEYDOWN 0x07f6		// Keydown peek loc, c64=c5,v20=c5,c16=07f6.
#define TDL_CBM_KEY2ASC  0xe026		// ROM table convert scancode to asc.
#define TDL_CBM_KEYSHIFT 0x0543		// Shift Key status
#define TDL_CBM_VDULOC  0x0c00		/* Screen loc  */
#define TDL_CBM_COLRAM  0x0800		/* Colour ram loc */

#define TDL_TED_ROMSEL   0xff3e		// A write to this address selects ROM at $8000-FFFF
#define TDL_TED_RAMSEL   0xff3f		// A write to this address selects RAM at $8000-FFFF

#define TDL_TED_VOX1LO  0xff0e		// Low byte of frequency for voice 1
#define TDL_TED_VOX2LO  0xff0f		// Low byte of frequency for voice 2
#define TDL_TED_VOX2HI  0xFF10       	// High bits of frequency for voice 2
#define TDL_TED_VOXVOL  0xFF11		// bit0-3=Volume (0-F) bit4=Sel vox1, bit5 SelTone vox2, bit6=Sel noise vox2
#define TDL_TED_MEMCTL  0xff12  	// Bitmap/Character Memory Control (Bit0-1:Sound MSB, Bit 2:chr/bmp ROM/RAM, Bit3-5:Bmp Base 8K steps)
const BYTE TDL_TED_MEMCTL_TEXT = 196;		// Bit 2 on for Text (use ROM)
const BYTE TDL_TED_MEMCTL_GFX  = 192;		// Bit 2 off for GFX (use RAM)
const UINT TDL_TED_CHRBASE  = 0xff13;  	// System Clock and Character Memory Control (Bit 2-7:chr base 1K steps) 
#define  TDL_TED_RASTER   0xff1d 	//Current raster line (Bit 0-7)

const UINT TDL_CBM_BORDER  = 0xff19;	// border colour
const UINT TDL_CBM_BACK    = 0xff15;	// back colour

const UINT TDL_PTR_CHRSET  = 0x3800;	// Hires Char set location (NOTE - Check its past end-of-code) (ie: 0x6000)
const UINT TDL_PTR_ROMSET  = 0xd000;	// Hires Char set location

const UINT TDL_CBM_REG_6510  = 1;		// C64 - 6510 I/O register

BYTE *TDL_pScreen = (BYTE *) ((UINT) TDL_CBM_VDULOC);	/* Ptr to screen */
BYTE *TDL_pCol = (BYTE *) ((UINT) TDL_CBM_COLRAM);	/* Ptr to colour ram */

  /* Native Colour codes */
#define TDL_COL_BLACK   0
#define TDL_COL_RED     0x42	/* 1:Bit 0 */
#define TDL_COL_GREEN   0x45	/* 2:Bit 1 */
#define TDL_COL_YELLOW  0x67
#define TDL_COL_BLUE    0x46	/* 4:Bit 2 */
#define TDL_COL_PURPLE  0x44
#define TDL_COL_CYAN    0x43
#define TDL_COL_WHITE   0x71

  /* System-Native Colours (poke codes), in RGB order, (0-7) */
BYTE TDL_RGBI2COL[]={0,2,5,7,6,4,3,1, 11,10,13,7,14,4,3,1};   /* Colour Conversion Table for ScreenSet */

#define TDL_RGBItoCol(RGBI) TDL_RGBI2COL[RGBI]

BYTE TDL_COL2INK[] = {144,5,28,159,156,30,31,158};	// Convert CBM poke to ink print codes.

#define TDL_SCANCODE_NONE 255

  /*. BYTE TDL_GetKeyDown ()  -  Get key held down */
BYTE TDL_GetKeyDown ()
{
    BYTE key;
    key = TDL_PEEK(TDL_CBM_KEYDOWN);
    return TDL_PEEK (TDL_CBM_KEY2ASC + key);  // 255=none. use rom translate table
}

  /*. BYTE TDL_GetKey_Shift () - Return shift status */
BYTE TDL_GetKey_Shift ()
{
    return TDL_PEEK (TDL_CBM_KEYSHIFT);
}

void TDL_ScreenClr ()
{
    TDL_PrintCharRaw (5);
    TDL_PrintCharRaw (147);
    TDL_GotoXY (1,1);
    TDL_Ink (TDL_COL_WHITE);
}


  /*. void TDL_Sleep (int tim)  - Sleep (tim) milliseconds */
void TDL_Sleep (int tim) 
{
      BYTE last;
      do {
	#if IS_OSCAR	
         __asm {
	     lda TDL_CBM_JIFFY+2
	   looptim:
	     cmp TDL_CBM_JIFFY+2
	     beq looptim
	 };
	#else
	  last = TDL_PEEK (TDL_CBM_JIFFY+2);
	  while (TDL_PEEK (TDL_CBM_JIFFY+2) == last);		// Delay 1 jiffy (but OSCAR optimizes this out!)
	#endif
	tim = tim - 17;		// Approx 1/60 sec (avoids divide)
      } while (tim > 0);
}

void TDL_FrameSync ()
{
    //TDL_Sleep (17);  // Crude method 
    __asm {
			// Sync action to screen refresh
	lda #190
	sei
      SyncLoop:
	cmp TDL_TED_RASTER
	bne SyncLoop
	cli
    }; 
}

#define TDL_SOUND_TYPE UINT

#define TDL_SOUND_NVOICE 2	// No of voices

#define TDL_SOUND_LO  0
#define TDL_SOUND_HI  1023
#define TDL_SOUND_STEP  4	// Simple scaling step for fx (pow2)

#define TDL_SOUND_C4  596	// (Middle C) Rough note vals
#define TDL_SOUND_A4  770
#define TDL_SOUND_C5  810
#define TDL_SOUND_A5  897
#define TDL_SOUND_C6  917

  /* Simple sound tone generator */
void TDL_Sound (UINT val, BYTE voice)
{
    TDL_POKE (TDL_TED_VOX2LO, val & 0xff);
    TDL_POKE (TDL_TED_VOX2HI, (val >> 8) & 3);
    TDL_POKE (TDL_TED_VOXVOL,0x2f);
}

void TDL_SoundOff (BYTE voice)
{
      TDL_POKE (TDL_TED_VOXVOL,0);
}

void TDL_SoundInit ()
{
}

  /* Set up the UDG chr set */
void TDL_UDG_Init (BYTE *pPix, UINT chstart, UINT psize)
{
    UINT p;
    BYTE *pSet = (BYTE *) TDL_PTR_CHRSET;
    chstart *= 8;
	// Copy char set data 
    for (p= 0; p< psize; p++) {
      pSet [chstart+p]= pPix [p];
    } 
}

  /*. void TDL_ScreenBackground (BYTE screen, BYTE border) - Set background */
void TDL_ScreenBackground (BYTE screen, BYTE border)
{
    TDL_POKE (TDL_CBM_BORDER,   border);
    TDL_POKE (TDL_CBM_BACK,   screen);
}

  /* Initialise TDL lib */
UINT TDL_Initialise (UINT mode, BYTE *pData)
{
    UINT p;
    BYTE *pSrc  = (BYTE *) TDL_PTR_ROMSET;
    BYTE *pDest = (BYTE *) TDL_PTR_CHRSET;
    TDL_ScreenBackground (TDL_COL_BLACK, TDL_COL_BLACK);
    TDL_POKE (TDL_TED_MEMCTL, TDL_TED_MEMCTL_GFX);		// Switch GFX ROM to RAM
    TDL_POKE (TDL_TED_CHRBASE, (TDL_PTR_CHRSET/256));		// Set CHRSET base in RAM. Check this is past code-end!
        __asm {
	  sta TDL_TED_ROMSEL
	} 
        /* __asm {
	  sei
	  sta TDL_TED_ROMSEL
	} */
        for (p=0; p<1024; p++) {		// Copy orig ROM set to RAM
	  pDest [p] = pSrc [p];
        }
        /* __asm {
	  sta TDL_TED_RAMSEL
	  cli
	} */

    TDL_ScreenClr ();
    return 0;
}


#endif 	// TDL_C16

/*-----------------------------------------------------------------------
   Common code for all CBM machines
-------------------------------------------------------------------------*/

  /* Get 16bit clock */
UINT TDL_Clock ()
{
    #if IS_OSCAR	
      __asm {
	lda TDL_CBM_JIFFY+2
        sta accu
	lda TDL_CBM_JIFFY+1
        sta accu+1
      };
    #else
      return (TDL_PEEK (TDL_CBM_JIFFY+2) | (256*TDL_PEEK (TDL_CBM_JIFFY+1)) );
    #endif
}

#ifdef TDL_IO_SYS	/* Use System IO calls */

  /*. void TDL_PrintChar (BYTE ch) - Print ASC char (using direct drawing) */
void TDL_PrintChar (BYTE ch)
{
    __asm {
      #ifdef TDL_VIC20	
       lda #18
       jsr $ffd2
      #endif
      lda ch
      jsr $ffd2
    }
}

  /*. BYTE TDL_GetKey () - get char from keyboard */
char TDL_GetKey ()
{
    return __asm {
      jsr $ffe4
      sta accu
    };
}

  /*. void TDL_Ink (BYTE ink) - Set print ink */
void TDL_Ink (BYTE ink)
{
    TDL_PrintChar (TDL_COL2INK [ink]);
}

   /* Set cursor pos (generic CBM) */
void TDL_GotoXY (BYTE x, BYTE y)
{
    BYTE z;
    TDL_PrintChar (19);
    for (z=1; z<y; z++) TDL_PrintChar (17);
    for (z=1; z<x; z++) TDL_PrintChar (29);
}

#endif


#ifdef TDL_IO_DIRECT	/* Print using direct screen access */

  /*. void TDL_PrintChar (BYTE ch) - Print ASC char (using direct drawing) */
void TDL_PrintChar (BYTE ch)
{
    UINT pos;
    if (ch < 32) {
      if (ch == 10) {
        TDL_cursorx = 0;
        if (TDL_cursory < TDL_VDUY) TDL_cursory ++;
      }
      return;
    }
    pos = TDL_ScreenPos (TDL_cursorx, TDL_cursory);
    ch = TDL_ASC2CHR (ch);
    TDL_ScreenSet (pos, ch, TDL_ink);
    TDL_cursorx ++;
    if (TDL_cursorx >= TDL_VDUX) {
      TDL_cursorx = 0;
      if (TDL_cursory < TDL_VDUY) TDL_cursory ++;
    }
}

  /*. BYTE TDL_GetKey () - get char from keyboard */
BYTE TDL_GetKey ()
{
    return __asm {
      jsr $ffe4
      sta accu
    };
}

  /*. void TDL_Ink (BYTE ink) - Set print ink */
void TDL_Ink (BYTE ink)
{
     TDL_ink = ink;
}

   /*. void TDL_GotoXY (BYTE x, BYTE y) - Set cursor pos (1,1..X,Y) */
void TDL_GotoXY (BYTE x, BYTE y)
{
    TDL_cursorx = x-1;
    TDL_cursory = y-1;
}

#endif
