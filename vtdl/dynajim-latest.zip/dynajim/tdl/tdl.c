/* TDL 2.xx - Very Tiny Development Layer for portable small apps.
  (C) A.Millett 2012-2026. Released as open software under GNU GPL3 license.

  (See "tdl_cbm.c" and "tdl_zx.c" for platform dep code.
  (See TDL1.0 version for early notes, then Skattabugz/Dynajim )
  Add C16 and PET code. 
-> vtdl125, 5.4.2026
  Imp more Sound details. 
  Imp TDL_HAS_PETSCII .
-> vtdl126, 7.4.2026

*/

#define TDL_VERSION 126

#include "tdl.h"

/*-----------------------------------------------------------------------
   Select target machine include file
-------------------------------------------------------------------------*/
  
#ifdef TDL_CBM
  #include "tdl_cbm.c"
#endif

#ifdef TDL_ZX
  #include "tdl_zx.c"
#endif


/*-----------------------------------------------------------------------
   Common generic code for all machines.
-------------------------------------------------------------------------*/

  /* void TDL_PrintStr (char *pStr) - Print a null-term string */
void TDL_PrintStr (char *pStr)	
{
	char ch;
	while (ch = *pStr) {
	  TDL_PrintChar ( ch);
	  if (ch == 10 && TDL_ADD_CR) TDL_PrintChar (13);
	  ++ pStr;
	}
}

  /* Print int using no division/recursion */

UINT TDL_decimal[]={10000,1000,100,10,1};

void TDL_PrintInt (UINT x)		
{
    BYTE digit, n;
    BYTE pr = 0;
    UINT sub;
    for (digit=0; digit<5; digit++) {
      sub = TDL_decimal[digit];
      n=0;
      while (x>= sub) {
        x=x-sub; n++;
      }
      if (n || digit==4) pr = 1;	/* kill leading zeros */
      if (pr) TDL_PrintChar (48+n);
    }
}

  /* void TDL_PrintSI (char *pStr) - Print a string, then int */
void TDL_PrintSI (char *istr, int iint)
{
	TDL_PrintStr (istr);
	TDL_PrintInt (iint);
}


  /* UINT TDL_Rand () - Simple 16 bit rnd gen */
UINT TDL_rndseed = 0;
UINT TDL_Rand ()
{
    TDL_rndseed = (UINT) (4737 * TDL_rndseed) + 1231;
    return (TDL_rndseed >> 8) ^ TDL_rndseed;
}
