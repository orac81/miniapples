/* Sound.C  -  Simplest VTDL demo */

#define TDL_IO_DIRECT 1	/* Set TDL_IO_CON, TDL_IO_SYS or TDL_IO_DIRECT */

#ifdef TDL_PATH		/* User sets TDL_PATH */
 #include TDL_PATH
#else
 #include "../tdl/tdl.c"
#endif

int main ()
{
    UINT x;
    UINT pos = 0;
    TDL_Initialise (0,NULL);
    TDL_Ink (TDL_COL_PURPLE);
    TDL_PrintStr ((char *) "SOUND EFFECTS!\n\nHIT SPACE");
    TDL_SoundInit ();
    for (x=TDL_SOUND_C4; x<TDL_SOUND_A5; x += TDL_SOUND_STEP) {
      TDL_Sound (x,0);
      TDL_Sleep (20);
    }
    while (TDL_GetKey () == 0) {
      x = TDL_SOUND_LO + (TDL_Rand () % (TDL_SOUND_HI - TDL_SOUND_LO));
      TDL_Sound (x,0);
      TDL_Sleep (20);
    }
    TDL_SoundOff (0);
    return 0;
}
