/* HELLO.C  -  Simplest VTDL demo */

#define TDL_IO_DIRECT 1	/* Set TDL_IO_CON, TDL_IO_SYS or TDL_IO_DIRECT */

#ifdef TDL_PATH		/* User sets TDL_PATH */
 #include TDL_PATH
#else
 #include "../tdl/tdl.c"
#endif

int main ()
{
    UINT x;
    UINT pos = 0;
    TDL_Initialise (0,NULL);
    TDL_Ink (TDL_COL_PURPLE);
	TDL_PrintStr ((char *) "CHARACTER SET: ");
	pos = TDL_ScreenPos(0,3);
    for (x=32; x<96; x++) {
      TDL_ScreenSet (pos, TDL_ASC2CHR(x), TDL_COL_WHITE);
      pos ++;
    }
    while (TDL_GetKey () == 0);
    return 0;
}
