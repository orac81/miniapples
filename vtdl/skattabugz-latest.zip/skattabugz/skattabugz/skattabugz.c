/* Skattabugz - a small fast paced game for TDL. 
   (C) A.Millett 2012-2026. Released as free software under GPL3.

  Test version, design aliens, font. 
  Imp draw_bug, clr_bug.
  Imp bare bones, simple animation demo.
  (Some bugs with OSCAR64 copying font?)
-> skatabug100, 25.1.2026
  Imp tables alienx[],alieny[],aliendir[] for aliens.
  Imp simple animation using table.
-> skatabug101, 27.1.2026
  Imp CHR_EGGS in center.
  Imp simple colour.
-> skatabug102, 27.1.2026
  Imp separate c64 library
  Imp player base and movement.
-> skatabug103, 29.1.2026
  Imp missile_move, alien_kill, simple score. Almost playable!
-> skatabug104, 29.1.2026
  Imp smaller printi, 
-> skatabug105, 30.1.2026
  Imp UDG lib as part of TDL2.xx lib
  Tidy up System names, various TDL/UDG functions.
  Imp FULL_VER to enable/disable font. 
-> skatabug106, 1.2.2026      (C64=2361 bytes)
  Imp TDL_VIC20 builds unexp V20 version. 
  Continue tidy up TDL libs.. 
-> skatabug107, 2.2.2026      (C64=2270 bytes, V20=2266)
  Imp Colour anagement, TDL_COL_BLACK..TDL_COL_WHITE.
-> skatabug108, 2.2.2026  
  Add Alien Bombs.
  Improve alien speed/timings.
-> skatabug109, 3.2.2026  
  Imp Bomb routines (bomb_drop, bomb_move..) if FULL_VERSION set
-> skatabug110, 6.2.2026
  Tidy up bits. V20 add #pragma stacksize (256) , #pragma heapsize (64)
  Imp player_loose_life.
  Imp gamemode, set bit0=slow, bit1= no bombs.
-> skatabug111, 7.2.2026  
  Improve behaviour of missiles/bombs.
  Imp seperate tdl_cbm.c lib.
-> skatabug112, 10.2.2026  
-> skatabug113, 10.2.2026  
  Tidy printing IO, imp TDL_IO_CON, TDL_IO_SYS, TDL_IO_DIRECT 
  Imp printed colour.
  Start sound calls.
-> skatabug114, 11.2.2026  
  Imp more TDL_Sound.. Abstract fns. Imp SID ver. 
  Imp SOUNDOFF (gamemode & 4).
-> skatabug115, 14.2.2026  
  Tidy up function names.
  Imp outline zx Spectrum version, lib "tdl_zx.c".
  Imp simple tests, ie: demo/test-udg.c
  Rough zx version running, missing i/o, etc.
-> skatabug116, 17.2.2026
  Cont imp zx spectrum version.
  Imp TDL_FrameSync, keybd in, colours, etc.
  Imp asm version zx_drawchar.
-> skatabug117, 18.2.2026
  Imp MODE_SLOW, MODE_FAST etc.
-> skatabug118, 19.2.2026
  Tidy up use of colour, remove "ink" vars.
  Put common code in tdl.c
-> skatabugz119, 20.2.2026
  Tidy up TDL_GetKeyDown, return simple ASC via ROM lookup.
-> skatabugz120, 20.2.2026
  Tidy up naming.
-> skatabugz121, 21.2.2026
  Rewrite alien_move for better flicker free update.
-> skatabugz122, 22.2.2026
  Imp shift detect (zx)
-> skatabugz123, 22.2.2026

todo: joystick, shift=fire,  Sound, bombs, Flyback sync,
      Icons, VCBCC. Vic20-8K,C16. ZX, DOS, SDL. skittabugs? custom-print-colour,

To build: ./tdlmakosc.sh  skattabugz/skattabugz -O2
or: oscar64 -D TDL_CBM -D TDL_C64=1 -D IS_OSCAR=1 -O2 -tm=c64 skattabugz.c -o=skattabugz-c64.prg

*/  

#define PROG_NAME "SKATTABUGZ 1.23-BETA"

#ifdef TDL_VIC20	/* Save a little memory */
 #define TDL_IO_SYS 1		/* Set TDL_IO_CON, TDL_IO_SYS or TDL_IO_DIRECT */
#else
 #define TDL_IO_DIRECT 1
#endif

#ifdef TDL_PATH		/* User sets TDL_PATH */
 #include TDL_PATH
#else
 #include "../tdl/tdl.c"
#endif


#define PROG_DEBUG     TRUE
#define FULL_VERSION   TRUE		/* Add extra features */

/*-----------------------------------------------------------------------
   game_ playing code..
-------------------------------------------------------------------------*/

BYTE pPix[] = {

  //  "skata6.bmp" size 96 x 32, Bitdepth=1, #char: 12 x 4
   // Heart, Egg, Bang, spare
  0x00,0x36,0x7f,0x77,0x7f,0x36,0x1c,0x08,  // chr:1
  0x00,0x3c,0x7a,0x76,0x6e,0x5e,0x3c,0x00,  // chr:2
  0x92,0x44,0x28,0x82,0x28,0x44,0x92,0x00,  // chr:3
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,  // chr:4
   // Alien (10x8, 4x2 chars) phase 0-3
  0x00,0x0c,0x1e,0x73,0x9e,0x1e,0x21,0x12,  // chr:5
  0x00,0x00,0x40,0x80,0x00,0x00,0x00,0x00,  // chr:6
  0x00,0x03,0x07,0x3c,0x07,0x07,0x08,0x08,  // chr:7
  0x00,0x00,0x80,0xf0,0x80,0x80,0x40,0x40,  // chr:8
  0x00,0x00,0x09,0x07,0x01,0x01,0x02,0x04,  // chr:9
  0x00,0xc0,0xe0,0x38,0xe4,0xe0,0x10,0x08,  // chr:10
  0x00,0x00,0x00,0x03,0x00,0x00,0x00,0x00,  // chr:11
  0x00,0x30,0x78,0xcf,0x78,0x78,0x84,0x84,  // chr:12
   // Player Base (10x8, 4x2 chars) phase 0-3
  0x0c,0x1e,0x7f,0xff,0xff,0xff,0xff,0xc0,  // chr:13
  0x00,0x00,0x80,0xc0,0xc0,0xc0,0xc0,0xc0,  // chr:14
  0x03,0x07,0x1f,0x3f,0x3f,0x3f,0x3f,0x30,  // chr:15
  0x00,0x80,0xe0,0xf0,0xf0,0xf0,0xf0,0x30,  // chr:16
  0x00,0x01,0x07,0x0f,0x0f,0x0f,0x0f,0x0c,  // chr:17
  0xc0,0xe0,0xf8,0xfc,0xfc,0xfc,0xfc,0x0c,  // chr:18
  0x00,0x00,0x01,0x03,0x03,0x03,0x03,0x03,  // chr:19
  0x30,0x78,0xfe,0xff,0xff,0xff,0xff,0x03,  // chr:20
   // Player Missile (8x8, 4 chars, phase 0-3)
  0x40,0x40,0x40,0x40,0x40,0x40,0x40,0x40,  // chr:21
  0x10,0x10,0x10,0x10,0x10,0x10,0x10,0x10,  // chr:22
  0x04,0x04,0x04,0x04,0x04,0x04,0x04,0x04,  // chr:23
  0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,  // chr:24
	// Alien Bomb (8x8, 4 char, phase 0-3)
  0x18,0x18,0x00,0x00,0x00,0x00,0x00,0x00,  // chr:25
  0x00,0x00,0x18,0x18,0x00,0x00,0x00,0x00,  // chr:26
  0x00,0x00,0x00,0x00,0x18,0x18,0x00,0x00,  // chr:27
  0x00,0x00,0x00,0x00,0x00,0x00,0x18,0x18,  // chr:28
0};

#define ALIEN_BOMBS TRUE	/* Enable Alien bombs */

#define ALIEN_TOP  2		/* Alien top/bot rows */
#define ALIEN_BOT  (TDL_VDUY-5)

#define ALIEN_MAX (ALIEN_BOT-ALIEN_TOP+1)*2   	/* Max # aliens*/
#define ALIEN_XMAX TDL_VDUX*4-6		/* Max X alien pos (in 1/4 chars) */
#define ALIEN_RIGHT 1			/* alien is moving right */
#define ALIEN_LEFT  2
#define ALIEN_TYPE 8 
#define BOMB_MAX 8

#define CHR_SPC     TDL_CHR_ASC32
#define CHR_HEART   TDL_UDG_START
#define CHR_EGG     TDL_UDG_START+1
#define CHR_BANG    TDL_UDG_START+2
#define CHR_ALIEN   TDL_UDG_START+4
#define CHR_PLAYER  TDL_UDG_START+12
#define CHR_MISSILE TDL_UDG_START+20
#define CHR_BOMB    TDL_UDG_START+24

#define COL_EGG     TDL_COL_RED
#define COL_HEART   TDL_COL_PURPLE
#define COL_BANG    TDL_COL_RED
#define COL_ALIEN   TDL_COL_GREEN
#define COL_ALIEN2  TDL_COL_YELLOW
#define COL_PLAYER  TDL_COL_WHITE
#define COL_MISSILE TDL_COL_CYAN

#define VOX_MISSILE 2
#define VOX_ALIEN   0

#define PLAYER_Y TDL_VDUY-1	/* Player Y max pos */

#define MODE_SLOW    1
#define MODE_FAST    2
#define MODE_NOBOMB  4
#define MODE_NOSOUND 8

BYTE gamemode = 0;	/* Bit0=slow, Bit1 =fast, Bit2=no bombs, Bit3=No sound */
BYTE calien;
BYTE naliens;
BYTE alienx   [ALIEN_MAX];	/* 0..(TDL_VDUX*4)-1 */
BYTE alieny   [ALIEN_MAX];	/* 0..TDL_VDUY-1 */
BYTE aliendir [ALIEN_MAX];
#if FULL_VERSION
 BYTE bombx [BOMB_MAX];
 BYTE bomby [BOMB_MAX];
 BYTE nbombs;
#endif
TDL_FAST BYTE playerx;
TDL_FAST BYTE missilex,missiley;		/* Player Missile pos (y=0=none) */
UINT score;			/* Flayer score */
UINT hiscore=0;
BYTE level;
BYTE nhearts;
BYTE cframe;		/* Frame counter */
UINT crand;		/* Current rand# */
BYTE pulse;

void alien_draw (BYTE x, BYTE y, BYTE col);
void score_update ();
void player_loose_life ();

	/* Init code */
void game_Init ()
{
    TDL_Initialise (0,NULL);
    TDL_UDG_Init (pPix, TDL_UDG_START, sizeof (pPix));
    TDL_SoundInit ();
}

void game_Finish () {}

void score_update ()
{
    UINT pos;
    TDL_GotoXY (1,1);
    TDL_PrintInt (score);
    TDL_PrintChar ('0');
    //TDL_PrintSI ((char *) " HI:",   hiscore);
    // TDL_PrintSI ((char *) "  LEV:",  level);
    pos= TDL_ScreenPos(TDL_VDUX-10,0);
    #if 1
     TDL_ScreenSet (pos, CHR_HEART, COL_HEART); 
     TDL_GotoXY (TDL_VDUX-7,1);
     TDL_PrintInt (nhearts);
     TDL_PrintChar (32);
    #endif
    TDL_ScreenSet (pos+6, CHR_ALIEN, TDL_COL_CYAN); 
    TDL_ScreenSet (pos+7, CHR_ALIEN+1, TDL_COL_CYAN); 
    TDL_GotoXY (TDL_VDUX-1,1);
    TDL_PrintInt (level);
}

#if TDL_VDUX < 32  /* Adjust help for screen size */

char szHelp[] = 
  "\n\n(C)A.MILLETT 2026\n"
  "FREEWARE/GPL3\n\n"
  "I,P= MOVE\n"
  "SHIFT= FIRE\n"
  "X= QUIT\n"
  //"\n\0" "1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890" // 100 Bytes test filler
  "\n";

#else /* Wider screen */

char szHelp[] = 
  "\n\n(C) A.MILLETT 2026.FREEWARE/GPL3\n\n"
  "BUGZ WANNA STEAL YOUR HEARTS!\n\n"
  "SHIFT = FIRE\n"
  "I,P (OR Q,E)= MOVE L/R\n"
  "X = QUIT\n\n"
  "HIT M NOW FOR MODE.\n"
  " +1=SLOW,+2=FAST,+4=NO BOMB\n"
  " +8=NO SOUND\n"
  "\n";

#endif
  
void game_help ()
{
    UINT p;
    char key;
help_loop:
    TDL_ScreenClr ();
    TDL_PrintStr ((char *) PROG_NAME);
    TDL_Ink (TDL_COL_YELLOW);
    TDL_PrintStr (szHelp);
    TDL_Ink (TDL_COL_PURPLE);
    TDL_PrintSI ((char *) "HI:",   hiscore);  TDL_PrintChar ('0');
    TDL_PrintSI ((char *) "\nMODE (M):",gamemode); 
    TDL_Ink (TDL_COL_CYAN);
    TDL_PrintStr ((char *) "\n\nHIT SPACE");
     //for (p=0; p<32; p++) { TDL_ScreenSet (p,CHR_HEART+p,7);  }
    do { 
      key = TDL_GetKey ();
      if (key == 77 || key == 109) {
	gamemode = (gamemode + 1) & 15;
	goto help_loop;
      }
    } while (key != 32);
    TDL_ScreenClr ();
}

void game_new_level ()
{
    BYTE x,y;
	/* Initialise alien pos */
    level ++;
    missiley = 0;
    calien = 0;
    naliens = 0;
    #if FULL_VERSION
      nbombs = 0;
    #endif 	// FULL_VERSION
    for (y=ALIEN_TOP; y<ALIEN_BOT; y++) {
      alienx [naliens] = 0;
      alieny [naliens] = y;
      aliendir [naliens] = 0;
      alien_draw (0, y, COL_ALIEN);
      naliens ++;
      alienx [naliens] = ALIEN_XMAX;
      alieny [naliens] = y;
      aliendir [naliens] = 0;
      alien_draw (ALIEN_XMAX, y, COL_ALIEN);
      naliens ++;
      if (naliens> ALIEN_MAX-2) break;
    }
}

void game_new ()
{
    BYTE x,y;
    UINT p;
    playerx = 16;
    score = 0;
    level = 0;
    game_new_level ();
    for (y=ALIEN_TOP; y<ALIEN_BOT; y++) {
      for (x=TDL_VDUX/2-3; x<TDL_VDUX/2+3; x++) {
	p = TDL_ScreenPos(x,y);
        TDL_ScreenSet (p, CHR_HEART, COL_HEART);
	nhearts ++;
      }
    }
}

#if FULL_VERSION

void bomb_drop (BYTE bx, BYTE by)
{
    UINT pos;
    if (nbombs >= BOMB_MAX) return;
    if (gamemode & MODE_NOBOMB) return;		/* Bombs disabled */
    bx = (bx+2)/4; by = (by+1)*4;
    pos = TDL_ScreenPos (bx,by/4);
    if (TDL_ScreenGet (pos) != CHR_SPC) return;
    bombx[nbombs] = bx;
    bomby[nbombs] = by;
    nbombs ++;
}

  /* Ripple del bomb */ 
void bomb_remove (BYTE cb)
{
    nbombs --;
    for (;cb < nbombs; cb++) {
      bombx [cb] = bombx [cb+1];
      bomby [cb] = bomby [cb+1];
    }
}

BYTE bomb_move (BYTE clr)
{
    UINT pos;
    BYTE cb,bx,by;
    BYTE ch;
    for (cb = 0; cb<nbombs; cb++) {
      bx = bombx [cb]; by = bomby [cb]; 
      pos = TDL_ScreenPos (bx,by/4);
      TDL_ScreenSetNC (pos, CHR_SPC);
      if (clr) continue;
      by ++;
      if (by > TDL_VDUY*4-2) {		/* Bottom of screen */
	bomb_remove (cb);
	return FALSE;
      }
      pos = TDL_ScreenPos (bx,by/4);
      ch = TDL_ScreenGet (pos);
      if (ch != CHR_SPC) {
        if (ch >= CHR_PLAYER && ch < CHR_PLAYER + 8) {	// Bomb hit player?
	  bomb_remove (cb);
	  player_loose_life ();
	  return TRUE;
	}
	bomb_remove (cb);
        return FALSE;
      }
      TDL_ScreenSet (pos, CHR_BOMB+(by & 3), TDL_COL_CYAN);
      bomby [cb] = by;
    }
    return FALSE;
}

#endif 		// FULL_VERSION

  /* Convert scaled x,y to screen pos */
UINT game_xy2pos (BYTE x, BYTE y)
{
   return TDL_ScreenPos((x/4),((UINT) y));
}

  /* Draw alien in 4 phase pos (X=0..TDL_VDUX*4) */
void alien_draw (BYTE x, BYTE y, BYTE col)
{
    UINT pos;
    BYTE c;
    pos = game_xy2pos (x,y);
    c = (x&3)*2;
    TDL_ScreenSet (pos,   CHR_ALIEN+c,   col); 
    TDL_ScreenSet (pos+1, CHR_ALIEN+1+c, col); 
}
  
void alien_clr (BYTE x, BYTE y)
{
    UINT pos;
    pos = game_xy2pos (x,y);
    TDL_ScreenSetNC (pos, CHR_SPC); 
    TDL_ScreenSetNC (pos+1, CHR_SPC);
}


void alien_move ()
{
    BYTE cm;
    UINT pos;
    BYTE ch;
    BYTE nmove; 
    BYTE y;
    BYTE gomove;
    BYTE alx,aly,aldir;

    #if TDL_VDUX < 32	  /* Adjust speed for screen size */
      nmove = (5+level)/2;    		/* Calc how many aliens to move per frame (1/60sec) */
    #else
      nmove = 2+level;
    #endif
    if (nmove > naliens) nmove = naliens;
    gomove = cframe + (BYTE) crand;
    for (cm=0; cm<nmove; cm ++) {
      if (calien >= naliens) {		/* Loop back to start.. */
        calien = 0;
	pulse ++;
        if ((gamemode & MODE_NOSOUND) == 0 && (pulse & 3) == 0) {
	  //TDL_Sound (TDL_SOUND_LO + (cframe & 63)* TDL_SOUND_STEP, VOX_ALIEN);
	  TDL_Sound (TDL_SOUND_LO + (crand & 63)* TDL_SOUND_STEP, VOX_ALIEN);
	}
      }
      aldir = aliendir [calien]; 
      alx = alienx [calien]; 
      aly = alieny [calien]; 
      if (aldir == 0) {		/* Not moving */
        if (calien == 0 || naliens < 3 || gomove == calien) {		/* Randomly start moving, or always move top alien*/
          if (alx == 0) {
	    aldir |= ALIEN_RIGHT;
          } else {
            aldir |= ALIEN_LEFT;
          }
          if (cframe < 32) {		/* Move alien down 1 row? */
            y=aly+1; if (y >= ALIEN_BOT) y = ALIEN_TOP;
            pos = game_xy2pos (alx,y);
            ch = TDL_ScreenGet (pos);
            if (ch == CHR_SPC) {
              alien_clr (alx, aly);
              aly = y;
	    }
          }
        }
      } else {		/* Alien already in motion.. */
	//alien_clr (alx, aly);
        if (aldir & ALIEN_RIGHT) {
          alx ++;
          if ((alx & 3) == 0) {			/* New square */
            pos = game_xy2pos (alx,aly)+1;
            TDL_ScreenSetNC (pos-2, CHR_SPC);	 /* Del trailing char */
	    ch = TDL_ScreenGet (pos);
            if (ch != CHR_SPC) {		/* Hit something? */
	      if (ch == CHR_HEART) {
	        TDL_ScreenSet (pos, CHR_EGG, COL_EGG); 
	        nhearts --;
	        score_update ();
	      }
	      if (ch == CHR_EGG) TDL_ScreenSetNC (pos, CHR_SPC); 
	      alx --;			/* reverse dir */
	      aldir = ALIEN_LEFT;	
            }
          } 
	  if (alx == ALIEN_XMAX) aldir = 0;	/* Stop at right edge */
        } else {	/* must be ALIEN_LEFT */
          alx --;
          if ((alx & 3) == 3) {			/* New square */
            pos = game_xy2pos (alx,aly);
            TDL_ScreenSetNC (pos+2, CHR_SPC);	 /* Delete trailing char */
	    ch = TDL_ScreenGet (pos);
            if (ch != CHR_SPC) {		/* Hit something? */
	      if (ch == CHR_HEART) {
	        TDL_ScreenSet (pos, CHR_EGG, COL_EGG); 
	        nhearts --;
	        score_update ();
	      }
	      if (ch == CHR_EGG) TDL_ScreenSetNC (pos, CHR_SPC); 
	      alx ++;			/* Reverse dir */
	      aldir = ALIEN_RIGHT;	
	    }
	  }
	  if (alx == 0) aldir = 0;
        }
		/* Update position */
        alien_draw (alx, aly, COL_ALIEN2);
      }
      aliendir [calien] = aldir; 
      alienx [calien] = alx; 
      alieny [calien] = aly; 
      #if FULL_VERSION
		/* Drop a bomb? */
	if (((BYTE) crand) < level+2 && aldir) bomb_drop (alx,aly);
      #endif
      calien ++;
    }
}

  /* Missile has hit alien, remove it */
void alien_kill ()
{
    BYTE kalien,d;
    BYTE alx,aly;
    for (kalien = 0; kalien < naliens; kalien ++) {
      aly = alieny [kalien];
      if (aly == missiley) {
        alx = alienx [kalien];
        if (missilex-alx < 7) {
          alien_clr (alx,aly);
		/* ripple delete alien from table */
	  for (d=kalien; d < naliens; d ++) {
	    aliendir [d] = aliendir [d+1]; 
	    alienx   [d] = alienx   [d+1]; 
	    alieny   [d] = alieny   [d+1]; 
          }
	  missiley = 0;
	  TDL_SoundOff (VOX_MISSILE);
	  naliens --;
	  return;
        }
      }
    }
        /* This part should never be reached! */
}

void missile_move ()
{
    UINT pos;
    BYTE ch;
    if (missiley == 0) {
      TDL_SoundOff (VOX_MISSILE);
      return;
    }
    pos = game_xy2pos (missilex, missiley);
    ch = TDL_ScreenGet (pos);
    if (ch >= CHR_MISSILE && ch < CHR_MISSILE+4) TDL_ScreenSetNC (pos, CHR_SPC); 
    if ((gamemode & MODE_NOSOUND) == 0) {
      TDL_Sound (TDL_SOUND_C4+(missiley * TDL_SOUND_STEP*4), VOX_MISSILE);
    }
    missiley --;
    if (missiley == 0) return;
    pos = game_xy2pos (missilex, missiley);
    ch = TDL_ScreenGet (pos);
    if (ch >= CHR_ALIEN && ch < CHR_ALIEN+8) {
      score += level;
      alien_kill ();	/* kill alien at missilex,missiley */
      score_update ();
      return;
    }
    if (ch != CHR_SPC && ch < CHR_BOMB) {	/* Only keep going if empty space */
      missiley = 0;
      TDL_SoundOff (VOX_MISSILE);
      return;
    }
    TDL_ScreenSet (pos, CHR_MISSILE+(missilex & 3), COL_MISSILE); 
}

void player_clr ()
{
    UINT pos;
    pos = game_xy2pos (playerx, PLAYER_Y);
    TDL_ScreenSetNC (pos,   CHR_SPC); 
    TDL_ScreenSetNC (pos+1, CHR_SPC); 
}

void player_draw ()
{
    UINT pos;
    BYTE phase;
    pos = game_xy2pos (playerx, PLAYER_Y);
    phase = (playerx & 3)*2;
    TDL_ScreenSet (pos,   phase+CHR_PLAYER,   COL_PLAYER); 
    TDL_ScreenSet (pos+1, phase+CHR_PLAYER+1, COL_PLAYER); 
}

  /* Move player base, fire missile.. */
void player_move ()
{
    BYTE key;
    BYTE dir=0;
    key = TDL_GetKeyDown ();
    if (key != TDL_SCANCODE_NONE) {
      player_clr ();
      if (key == 'I' || key == 'Q') {		/* Move left */
	if (playerx>6) playerx --;
      }
      if (key == 'P' || key == 'E') {		/* Move right */
        if (playerx < TDL_VDUX*4-12) playerx ++;
      }
      if (key == 'X') nhearts = 0;	/* Quit */
    }
    if (key == 'Z' || TDL_GetKey_Shift()) {		/* Fire missile */
      if (missiley == 0) {
        missiley = PLAYER_Y;
        missilex = playerx + 2;
        TDL_ScreenSet (TDL_VDUX, CHR_SPC, COL_MISSILE); 
      }
    } 
    player_draw ();
}

#if FULL_VERSION

  /* Player hit, loose a life, remove half of the hearts */
void player_loose_life ()
{
    BYTE x,y,ch;
    BYTE nremove;
    UINT pos;
    nremove = (1+nhearts)/2;	/* No of hearts to remove */
    pos = game_xy2pos (playerx, PLAYER_Y);
    TDL_ScreenSet (pos,   CHR_BANG, COL_BANG); 
    TDL_ScreenSet (pos+1, CHR_BANG, COL_BANG); 
    
    TDL_Sleep (500);
    for (y=ALIEN_TOP; y<ALIEN_BOT; y++) {
      for (x=TDL_VDUX/2-3; x<TDL_VDUX/2+3; x++) {
        if (nremove == 0) {
	  return;
	}
	pos = TDL_ScreenPos(x,y);
        ch = TDL_ScreenGet (pos);
        if (ch == CHR_HEART) {
          TDL_ScreenSet (pos, CHR_BANG, COL_BANG);
	  //TDL_FrameSync ();	/* Sync animation to frame */
          TDL_Sleep (60);
          TDL_ScreenSetNC (pos, CHR_SPC);
          nhearts --; nremove --;
	  score_update ();
        }
      }
    }
}

#endif 	// FULL_VERSION

  /* Main game loop */
void game_Loop ()
{
    BYTE x;
    while (1) {
      game_help ();
      game_new ();
      //for (x=0; x<TDL_VDUX; x++) {TDL_PrintChar (48+(x%10));}
      score_update ();
      while (nhearts) {
        cframe++;
        crand = TDL_Rand ();		/* Current rand # */
        missile_move ();
        if (naliens == 0) {
	  #if FULL_VERSION
            bomb_move (1);		/* Clr old bombs */
	  #endif
          game_new_level ();
          //score += (UINT) nhearts;
          score_update ();
	}
        player_move ();
	if ((gamemode & MODE_FAST) == 0 || (cframe & 1)) {
	  TDL_FrameSync ();	/* Sync animation to frame */
        }
        if ((cframe & 1) || (gamemode & MODE_SLOW)==0) {
	  alien_move ();
	}
	#if FULL_VERSION
	  if (cframe & 1) bomb_move (0);
 	#endif 	// FULL_VERSION
	TDL_SoundOff (VOX_ALIEN);
      }
      if (score > hiscore) hiscore = score;
      TDL_SoundOff (VOX_MISSILE);
      TDL_ScreenBackground (TDL_COL_BLACK, TDL_COL_RED);
      //TDL_GotoXY (1,2); TDL_Ink (TDL_COL_RED); TDL_PrintStr ((char *) " GAME OVER ");
      TDL_Sleep (3000);
      TDL_ScreenBackground (TDL_COL_BLACK, TDL_COL_BLACK);
    }
}

	/* Main program */
int main ()
{
    game_Init ();
    game_Loop ();	/* Main game loop */
    game_Finish ();
    return 0;
}
