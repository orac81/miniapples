/* TDL 2.xx - Very Tiny Development Layer for portable small apps.
  (C) A.Millett 2012-2026. Released as open software under GNU GPL3 license.
  TDL Library released under (less restrictive) LGPL license.

*/

#include <stdio.h>
#include <stdlib.h>

/*-----------------------------------------------------------------------
   Common ZX Spectrum defines and console functions
-------------------------------------------------------------------------*/

#define TDL_FAST 		/* Fast (zeropage,register etc) variable definition */

#define TDL_VDU_STATIC TRUE	 /* VDU size/colour parameters are static/limited */
#define TDL_HAS_UDG  TRUE	/* Tell user program (psuedo) UDGs are available */

#define TDL_POKE(AD,BY) *((BYTE *) ((UINT) (AD)))=(BYTE) (BY);
#define TDL_PEEK(AD) ((BYTE) *((BYTE *) ((UINT) (AD))))

#define TDL_ADD_CR  TRUE			/* Add CR if LF sent */

void TDL_PrintChar (BYTE ch);		/* Fwd declare */

/*-----------------------------------------------------------------------
   ZX-Spectrum specific code
-------------------------------------------------------------------------*/
#define TDL_VDUX 32
#define TDL_VDUY 24
	/*. TDL_ScreenPos(X,Y) - Calc Screen char position from X,Y (0 to max-1) */
#define TDL_ScreenPos(X,Y) ((X)+(Y)*TDL_VDUX)

#define TDL_UDG_START 128		/* Start of UDG chars */
#define TDL_UDG_MAX 128			/* #UDG chars */

#define TDL_CHR_ASC32   32		/* Map Ascii 32-63.. */
#define TDL_CHR_ASC64   64		/* Ascii 64-95 */
#define TDL_CHR_ASC96   96		/* Ascii 96-127 */
#define TDL_ASC2CHR(C) (C)		/* Convert ascii to chr code */


#define TDL_ZX_VDU (0x4000)
#define TDL_ZX_COLOR (0x5800)
#define TDL_ZX_CHRSET (0x3d00)	// Spectrum charset, for ascii 0x20-0x7f (32-127)
#define TDL_ZX_FRAMES 23672			/* Frame count */
#define TDL_ZX_VDUPOS(X,Y)  (((Y) & 7) * 256 + (((Y)/8) & 7) * 32 +((Y)/64) * 2048 + (X))
#define TDL_ZX_COLORPOS(X,Y)  ((X) + (Y) * 32)
#define TDL_ZX_ULA (0xfe)		// OUT to ULA, bot 3 bits = border col.

#define TDL_ZX_RED   2		// ZX raw colours (purple = TDL_ZX_RED+TDL_ZX_BLUE etc)
#define TDL_ZX_GREEN 4
#define TDL_ZX_BLUE  1

  /* Basic RGB Colours, (0-7) */
#define TDL_COL_BLACK  0
#define TDL_COL_RED    2	/* 1:Bit 0 */
#define TDL_COL_GREEN  4	/* 2:Bit 1 */
#define TDL_COL_YELLOW 6
#define TDL_COL_BLUE   1	/* 4:Bit 2 */
#define TDL_COL_PURPLE 3
#define TDL_COL_CYAN   5
#define TDL_COL_WHITE  7

BYTE TDL_RGBI2COL[]={0,2,4,6,1,3,5,7};   /* Colour Conversion Table for ScreenSet */

#define TDL_RGBItoCol(RGBI) TDL_RGBI2COL[(RGBI) & 7 ]

BYTE TDL_zx_vdu [TDL_VDUX*TDL_VDUY+2];		/* VDU char map buffer */

BYTE *TDL_UDG_ptr=0;
UINT TDL_UDG_start=128;
UINT TDL_UDG_size=0;

BYTE TDL_border;
BYTE TDL_screen;

BYTE TDL_cursorx ;
BYTE TDL_cursory ;
BYTE TDL_ink ;

#if 1		/* Set for new ASM version.. */

  /* Output UDG char to spectrum VDU (xpos 0-31,ypos 0-24) */

BYTE zx_x, zx_y, zx_ch;
UINT zx_set;

void TDL_zx_drawchar (BYTE *pSrc, BYTE xpos, BYTE ypos, BYTE ch, BYTE ink)
{
    UINT x;
    BYTE *pScreen;
    x = (UINT) (TDL_ZX_COLOR + TDL_ZX_COLORPOS(xpos,ypos));
    *((BYTE *) x) = ink;

    if (ch < TDL_UDG_start) {		/* Set ptr to ROM */
      zx_ch = ch - 32;
      zx_set = TDL_ZX_CHRSET;
    } else {
      zx_ch = ch - TDL_UDG_start;
      zx_set = (UINT) pSrc;
    }
    zx_x = xpos; 
    zx_y = ypos; 

__asm 
		; Spectrum: Draw char (A) direct at VDU x,y pos (E,D)
  ld a,(_zx_x)
  ld e,a
  ld a,(_zx_y)
  ld d,a
  ld a,(_zx_ch)
  ld hl,(_zx_set)

  ld b,0
  ld c,a
  sla c		; Mul BC by 8
  rl  b
  sla c
  rl  b
  sla c
  rl  b
  add hl,bc		; HL points to ROM char 8 bytes.

;  call get_chr_addr   ; Turn VDU x,y (E,D) into VDU address (DE)
  ld a,d
  and %00000111
  rra
  rra
  rra 
  rra
  or e
  ld e,a
  ld a,d
  and %00011000
  or  %01000000  
  ld d,a

  ld b,8	; Copy 8 Bytes from (hl) to (de)
printchar1:
  ld a,(hl)
  ld (de),a
  inc hl
  inc d
  djnz printchar1
__endasm; 

}

#else 
  /* Output UDG char to spectrum VDU (xpos 0-31,ypos 0-24) (OLD C VERSION) */
void TDL_zx_drawchar (BYTE *pSrc, BYTE xpos, BYTE ypos, BYTE ch, BYTE ink)
{
    UINT x;
    BYTE *pScreen;
    if (ch < TDL_UDG_start) {		/* Set ptr to ROM */
      ch -= 32;
      pSrc = (BYTE *) TDL_ZX_CHRSET;
    } else {
      ch -= TDL_UDG_start;
    }
    pSrc += ch * 8; 
    x = (UINT) (TDL_ZX_COLOR + TDL_ZX_COLORPOS(xpos,ypos));
    *((BYTE *) x) = ink;

    ypos = ypos << 3;
    x = ((UINT) (TDL_ZX_VDU + TDL_ZX_VDUPOS (xpos,ypos)));
    pScreen = (BYTE *) x;
    for (x=0; x<8; x++) {
      *pScreen = *pSrc;
      pScreen += 256; pSrc ++;
    }
}


#endif

	/*. void TDL_ScreenSet(UINT pos, BYTE ch, BYTE col) - Poke VDU pos with char & colour */
void TDL_ScreenSet (UINT pos, BYTE ch, BYTE col)  
{
    TDL_zx_vdu[pos] = ch; 
    TDL_zx_drawchar (TDL_UDG_ptr, (pos & 31), (pos >> 5), ch, col);
}	

#define TDL_ScreenSetNC(POS,BYT)  TDL_ScreenSet(POS,BYT,TDL_COL_WHITE)

  /*. BYTE TDL_ScreenGet (UINT pos)  - peek vdu pos */
BYTE TDL_ScreenGet (UINT pos)  
{
	return TDL_zx_vdu[pos]; 
}	

  /* Read Spectrum keyboard using ROM calls. Return ascii, or 0 if no key */
BYTE *pKeyTab = (BYTE *) 0x0205;	// Translate table in ROM
BYTE zx_key, zx_lastkey;		// Globals for asm call

  /* ZX raw key scancodes for 0xc5,peek(197) */
#define TDL_SCANCODE_NONE 0

  /*. BYTE TDL_GetKeyDown ()  -  Get key raw scancode (key held down) */
BYTE TDL_GetKeyDown ()
{
    __asm 
        call 0x028e	; Call Spec ROM, ret keydown (0-27) in E, 255 if none.
        ld a,e
        ld (_zx_key),a
    __endasm;
    if (zx_key == 255) return 0;
    return pKeyTab [zx_key];
}

#if 1

  /*. BYTE TDL_GetKey_Shift () - Return shift status (New Ver) */
BYTE TDL_GetKey_Shift ()
{
    __asm 
		;was  ld bc,0xfefe ; in a,(c)
	ld a,0xfe
	in a,(0xfe)	; Get Shift key status
	cpl		; xor 0xff
	and 1
        ld (_zx_key),a
    __endasm;
    return zx_key;
}
#else 

  /*. BYTE TDL_GetKey_Shift () - Return shift status (Old ver) */
BYTE TDL_GetKey_Shift ()
{
    __asm 
        call 0x028e	; Call Spec ROM, ret keydown (0-27) in E, 255 if none.
        ld a,d
        ld (_zx_key),a
    __endasm;
    if (zx_key == 255) return 0;
    return zx_key;
}
#endif

#if TDL_IO_DIRECT


  /*. void TDL_PrintChar (BYTE ch) - Print ASC char (using direct drawing) */
void TDL_PrintChar (BYTE ch)
{
    UINT pos;
    if (ch < 32) {
      if (ch == 10) {
        TDL_cursorx = 0;
        if (TDL_cursory < TDL_VDUY) TDL_cursory ++;
      }
      return;
    }
    pos = TDL_ScreenPos (TDL_cursorx, TDL_cursory);
    TDL_ScreenSet (pos, ch, TDL_ink);
    TDL_cursorx ++;
    if (TDL_cursorx >= TDL_VDUX) {
      TDL_cursorx = 0;
      if (TDL_cursory < TDL_VDUY) TDL_cursory ++;
    }
}

  /*. BYTE TDL_GetKey () - get char from keyboard */
BYTE TDL_GetKey ()
{
    __asm 
        call 0x028e	; Call Spec ROM, ret keydown (0-27) in E, 255 if none.
        ld a,e
        ld (_zx_key),a
    __endasm;
    if (zx_lastkey == zx_key) return 0;	// Same as last time
    zx_lastkey = zx_key;
    if (zx_key == 255) return 0;		// No key down
    return pKeyTab [zx_key];
}

  /*. void TDL_Ink (BYTE ink) - Set print ink */
void TDL_Ink (BYTE ink)
{
     TDL_ink = ink;
}

   /*. void TDL_GotoXY (BYTE x, BYTE y) - Set cursor pos (1,1..X,Y) */
void TDL_GotoXY (BYTE x, BYTE y)
{
    TDL_cursorx = x-1;
    TDL_cursory = y-1;
}

#endif


#if TDL_IO_CONIO	/* CONIO NOT WORKING, use TDL_IO_DIRECT! */

  /*. void TDL_PrintChar (BYTE ch) - Print ASC char */
void TDL_PrintChar (BYTE ch)
{
    putchar (ch);
    #if 0
      __asm
       ld a,0
       call 5633	; Setup screen
       ld a,(_ch)
       rst 16		; Print char
      __endasm;
    #endif
}

  /*. BYTE TDL_GetKey () - get char from keyboard */
BYTE TDL_GetKey ()
{
    if (kbhit () ==0) return 0;
    return getch ();
}

  /*. void TDL_Ink (BYTE ink) - Set print ink */
void TDL_Ink (BYTE ink)
{
    putchar (17); putchar (zx_screen); 	// Paper=black
    putchar (16); putchar (TDL_RGBI2COL[ink&7]); 
}

   /*. void TDL_GotoXY (BYTE x, BYTE y) - Set cursor pos (1,1..X,Y) */
void TDL_GotoXY (BYTE x, BYTE y)
{
    if (x<1 || x>32 || y<1 || y>24) return;
    putchar (22); putchar (y-1); putchar (x-1);
}

#endif

void TDL_ScreenClr ()
{
   #if 1
    UINT x;
    BYTE ink;
    ink = TDL_screen * 8 + TDL_COL_WHITE;
    for (x=0; x< TDL_VDUX * TDL_VDUY; x++) {
      ((BYTE *) TDL_ZX_COLOR) [x] = ink;
      TDL_zx_vdu [x] = 32;
    }
    for (x=0; x< TDL_VDUX * TDL_VDUY * 8; x++) {
      ((BYTE *) TDL_ZX_VDU) [x] = 0;
    }
   #else 
     call 3435     ; Asm CLS
   #endif
   TDL_Ink (TDL_COL_WHITE);
   TDL_GotoXY (1,1);
}

  /* Wait for start of frame, for animation etc. */
void TDL_FrameSync ()
{
    __asm 
      ei	; Wait for the frame refresh interrupt
      halt
    __endasm; 
}

#define TDL_CLOCK_GAP 20	// Clocks per second

  /* Get 16bit clock */
UINT TDL_Clock ()
{
     return (TDL_PEEK (TDL_ZX_FRAMES) | 256*TDL_PEEK (TDL_ZX_FRAMES+1));
}

  // Sleep (tim) milliseconds
void TDL_Sleep (int tim) 
{
    do {
      TDL_FrameSync ();
      tim -= TDL_CLOCK_GAP;
    } while (tim > 0);
}

#define TDL_SOUND_TYPE BYTE

#define TDL_SOUND_C4  100		// Rough note vals
#define TDL_SOUND_A4  200
#define TDL_SOUND_C5  300
#define TDL_SOUND_A5  400

#define TDL_SOUND_LO  1
#define TDL_SOUND_HI  512
#define TDL_SOUND_STEP  1	// Simple scaling step for fx

BYTE TDL_freq;

  /* Simple sound generator */
void TDL_Sound (BYTE val, BYTE voice)
{
    #if 0		// Use zx Beep?
    TDL_freq = val;
    __asm	
      ld hl,(_TDL_freq)	; Freq
      ld de,1		; Duration
      call 949		; ROM BEEP routine
    __endasm;
    #endif
}

void TDL_SoundOff (BYTE voice)
{
}

void TDL_SoundInit () 
{
}

  /* Set up the UDG chr set pointers */
void TDL_UDG_Init (BYTE *pPix, UINT chstart, UINT psize)
{
    TDL_UDG_ptr = pPix;
    TDL_UDG_start = chstart;
    TDL_UDG_size = psize;
}

  /*. void TDL_ScreenBackground (BYTE screen, BYTE border) - Set background */
void TDL_ScreenBackground (BYTE screen, BYTE border)
{
    TDL_border = border;
    TDL_screen = screen;
    __asm 
        ld a,(_TDL_border)
	out (0xfe),a	// Set border black
    __endasm; 
}

UINT TDL_Initialise (UINT mode, BYTE *pData)
{
    TDL_ScreenBackground (TDL_COL_BLACK, TDL_COL_BLACK);
    TDL_ScreenClr ();
    return 0;
}
