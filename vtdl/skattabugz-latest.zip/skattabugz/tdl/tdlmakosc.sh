#!/bin/sh
# tdlmakosc.sh  - Build TDL app with OSCAR64
#  Syntax  ./tdlmakosc.sh progname [parms]   
#  ie: ./tdlmakosc.sh skattabugz/skattabugz -O2 -g
#  Note   -g add asm source
echo "Building C64.."
oscar64 -D TDL_CBM -D TDL_C64=1 -D IS_OSCAR=1 -tm=c64 $2 $3 $4 $5 $1.c -o=$1-c64.prg
echo "Building VIC20.."
oscar64 -D TDL_CBM -D TDL_VIC20=1 -D IS_OSCAR=1 -tm=vic20  $2 $3 $4 $5 $1.c -o=$1-v20.prg
