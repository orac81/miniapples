rem setup Z88dk z80 C compiler
path %PATH%;z:\mnt\sda7\m\z88dk\bin.x86;
set ZCCCFG=z:\mnt\sda7\m\z88dk\lib\config
