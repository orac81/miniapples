/* "tdl_dos.c"  : DOS lib for TDL.
   For TDL 2.xx - Very Tiny Development Layer for portable small apps.
  (C) A.Millett 2012-2026. Released as open software under GNU LGPL license.
  TDL Library released under (less restrictive) LGPL license.

*/

#include <stdio.h>
#include <stdlib.h>
#include <dos.h>	/* Defines union REGS, INT86 */

/*-----------------------------------------------------------------------
   Common DOS defines, vars, fwd declarations
-------------------------------------------------------------------------*/

#define TDL_FAST register		/* Fast (zeropage,register etc) variable definition */

#define TDL_VDU_STATIC TRUE	 /* VDU size/colour parameters are static/limited */
#define TDL_HAS_UDG    TRUE	/* Tell user program UDGs are available */

#define TDL_POKE(AD,BY) *((BYTE far *) ((ULONG) (AD)))=(BYTE) (BY);
#define TDL_PEEK(AD) ((BYTE) *((BYTE far *) ((ULONG) (AD))))

#define TDL_ADD_CR  TRUE		/* Add CR if LF sent (TDL_PrintSring) */

#define TDL_SHIFT_LR   3	/* Left/right shift */


void TDL_PrintChar (BYTE ch);		/* Fwd declare */
void TDL_ScreenClr ();
void TDL_GotoXY (BYTE x, BYTE y);
void TDL_Ink (BYTE ink);
BYTE TDL_GetKey ();
ULONG TDL_Clock ();

#define TDL_CLOCKS_PER_SEC 18

//union REGS TDL_inr, TDL_outr;	/* Define register access */
//struct SREGS TDL_sregs;			/* Segment regs */

/*========================================================================
   DOS Specific Code
==========================================================================*/

#define TDL_RAM 640		/* Amount of RAM (Kb, approx) for platform */

#if TDL_DOS_BIOS		/* Use simple BIOS calls, no  UDGs */
 #ifndef TDL_DOS_DEFMODE
	/* Mode 1, 40x25 */
  #define TDL_DOS_DEFMODE 1 		/* Default gfx mode */
  #define TDL_VDUX 40
  #define TDL_VDUY 25
	/* Mode 0x12, 80x30 */
  //#define TDL_DOS_DEFMODE 0x12 		/* Default gfx mode */
  //#define TDL_VDUX 80
  //#define TDL_VDUY 30
 #endif
 #define TDL_UDG_START 0		/* Start of UDG chars */
 #define TDL_UDG_MAX   0		/* #UDG chars */

#else
 #define TDL_DOS_DEFMODE 0x13 		/* Default gfx mode */
 #define TDL_VDUX 40
 #define TDL_VDUY 25

 #define TDL_HAS_HIRES TRUE
 #define TDL_VDU_HIX 320			/* Hi-res pixel screen size (static) */
 #define TDL_VDU_HIY 200
 #define TDL_VDU_HICOL 8			/* Hi res colour depth (#bits) */

 #ifdef TDL_REQ_TEXT
  #define TDL_UDG_MAX 0			/* Text only, no UDG chars */
 #else
  #define TDL_UDG_MAX 128		/* #UDG chars */
 #endif
 #define TDL_UDG_START 128		/* Start of UDG chars */
#endif

#define TDL_CHR_ASC32   32		/* Map Ascii 32-63.. */
#define TDL_CHR_ASC64   64		/* Ascii 64-95 */
#define TDL_CHR_ASC96   96		/* Ascii 96-127 */
#define TDL_ASC2CHR(C) (C)		/* Convert ascii to chr code */

#define TDL_DOS_PVGA   0xa0000000L      /* VGA bmp */


  /* Native Colour codes */
#define TDL_COL_BLACK   0
#define TDL_COL_BLUE    1	/* 1:Bit 0 */
#define TDL_COL_GREEN   2	/* 2:Bit 1 */
#define TDL_COL_CYAN    3
#define TDL_COL_RED     4	/* 4:Bit 2 */
#define TDL_COL_PURPLE  5
#define TDL_COL_YELLOW  14
#define TDL_COL_WHITE   15


#define TDL_RGBItoCol(RGBI) (RGBI)

BYTE TDL_DOS_Vdu [TDL_VDUX*TDL_VDUY+4];		/* VDU char map buffer */

BYTE far *TDL_PtrFont = NULL;
	/* UDG Font data */
BYTE *TDL_UDG_ptr = NULL;
UINT TDL_UDG_start=128;
UINT TDL_UDG_size=0;
	/* Back colour */
BYTE TDL_border;
BYTE TDL_screen;
	/* Char draw params */
BYTE TDL_cursorx ;
BYTE TDL_cursory ;
BYTE TDL_ink ;


/*-----------------------------------------------------------------------
   Low level DOS/BIOS functions
-------------------------------------------------------------------------*/

	/* BIOS: Set screen mode */
void TDL_DOS_SetGfxMode (int mode)
{
    union REGS regi,rego;
    //memset (&regi, 0, sizeof(regi));
    regi.x.ax = mode;
    int86 (0x10, &regi, &rego);	/* INT 10, function 0 */
}

	/* BIOS: Plot pixel */
void TDL_DOS_Plot (int xpos, int ypos, int color)
{
    union REGS regi,rego;
    regi.h.ah = 0x0c;
    regi.x.cx = xpos;
    regi.x.dx = ypos;
    regi.h.al = color;			/* XOR if bit 7 COLOR set */
    int86 (0x10, &regi, &rego);		/* INT 10, function 0c */
}

  /* Low level sound using beep/speaker */

void TDL_DOS_SoundOn (int hertz)
{
	UINT outfreq;
	if (hertz < 50) return;
        outfreq = (UINT) ((ULONG) 1331000L/hertz);	/* Calc port val */
	_outp (0x43, 0xb6);		/* Set mode */
	_outp (0x42, outfreq & 0xff);	/* Write lo */
	_outp (0x42, outfreq >> 8);	/* Write hi */
	_outp (0x61, _inp (0x61) | 3);	/* Speaker on */
}

void TDL_DOS_SoundOff ()
{
	_outp (0x61, _inp (0x61) & 0xfc);
}

	/* See: _outp, _outpw, _inp, _inpw */

#if 0
  /* BIOS: Get pointer (TDL_PtrFont) to VGA 8x8 font */
void TDL_DOS_GetFont ()
{
    union REGS regi,rego;
    struct SREGS sreg;
    //memset (&reg, 0, sizeof(reg));
    regi.x.ax = 0x1130;		/* Function 11, subf 30, get chr info */
    regi.x.bx = 0x0300;		/* Get Address font (2=8x14,3=8x8,6=8x16) */
    int86x (0x10, &regi, &rego, &sreg);
	/* cx=bytes/chr */
    TDL_PtrFont = MK_FP (sreg.es, rego.x.bp);
}
#endif

  /* BIOS: Get a char from keyboard */
int TDL_DOS_GetChar()
{
    union REGS regi,rego;
    regi.h.ah = 6;
    regi.h.dl = 0xff;
    int86 (0x21, &regi, &rego);	/* INT 10, function 0 */
    return (rego.x.ax & 0xff);
}

  /* BIOS: Goto loc x,y on vdu */
void TDL_DOS_gotoxy (int xloc, int yloc)
{
    union REGS regi,rego;
    regi.x.ax = 0x0200;
    regi.x.bx = 0;
    regi.x.dx = (xloc - 1) + ((yloc - 1) << 8);
    int86 (0x10, &regi, &rego);	/* INT 10, function 0 */
}

  /* BIOS: Print a char to screen in current ink */
void TDL_DOS_putch (int ch)
{
    union REGS regi,rego;
    regi.x.ax = (0x0e00 | ch);	/* AH=0E - Teletype output */
    regi.x.bx = TDL_ink;
    int86 (0x10, &regi, &rego);	/* INT 10, function 0 */
}

  /* BIOS: Set char at cur pos (dont advance cursor) */
void TDL_DOS_setch (int ch)
{
    union REGS regi,rego;
    regi.x.ax = (0x0900 | ch);	/* AH=09  */
    regi.x.bx = TDL_ink;
    regi.x.cx = 1;
    int86 (0x10, &regi, &rego);	/* INT 10, function 0 */
}

void TDL_DOS_ScreenBack (BYTE screen, BYTE border)
{
    union REGS regi,rego;
    regi.x.ax = 0x0b00;
    regi.x.bx = screen;
    int86 (0x10, &regi, &rego);
}

/*-----------------------------------------------------------------------
   TDL API functions
-------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------
   DOS SCREEN DRAWING
-------------------------------------------------------------------------*/

	/*. TDL_DrawPoint (UINT xpos, UINT ypos, UINT color) - Draw a pixel */
void TDL_DrawPoint (UINT xpos, UINT ypos, UINT color)
{
    TDL_DOS_Plot (xpos, ypos, color);
}

	/*. TDL_ScreenPos(X,Y) - Calc Screen char position from X,Y (0 to max-1) */
#define TDL_ScreenPos(X,Y) ((X)+(Y)*TDL_VDUX)

#if TDL_DOS_BIOS	/* Imp simple ASCII lib via BIOS */

  /*. TDL_ScreenSetXY (BYTE x, BYTE y,BYTE ch, BYTE col) - Poke VDU pos with char & colour */
void TDL_ScreenSetXY (BYTE x, BYTE y, BYTE ch, BYTE col) 
{
    TDL_DOS_Vdu[TDL_ScreenPos(x,y)] = ch; 
    TDL_DOS_gotoxy (x+1, y+1);
    TDL_ink = col;
    TDL_DOS_setch (ch);
}	

	/*. void TDL_ScreenSet(UINT pos, BYTE ch, BYTE col) - Poke VDU pos with char & colour */
void TDL_ScreenSet (UINT pos, BYTE ch, BYTE col)  
{
    BYTE x,y;
    x = pos % TDL_VDUX;
    y = pos / TDL_VDUX;
    TDL_DOS_Vdu [pos] = ch; 
    TDL_DOS_gotoxy (x+1, y+1);
    TDL_ink = col;
    TDL_DOS_setch (ch);
}

#endif

#if TDL_DOS_VGA

void TDL_ScreenSetUDG (BYTE x, BYTE y, BYTE ch, BYTE col)
{
    BYTE ych;
    BYTE *pBmp = TDL_UDG_ptr + ((ch - TDL_UDG_START) * 8);
    BYTE far *pVga;
    BYTE byt;
    pVga = ((BYTE far *) (ULONG) TDL_DOS_PVGA) + ((UINT) x*8 + ((UINT) y)*320*8);
    for (ych=0; ych<8; ych++) {
      byt = *pBmp;
      *pVga = (byt & 0x80) ? col : 0; pVga ++; 
      *pVga = (byt & 0x40) ? col : 0; pVga ++; 
      *pVga = (byt & 0x20) ? col : 0; pVga ++; 
      *pVga = (byt & 0x10) ? col : 0; pVga ++; 
      *pVga = (byt & 0x08) ? col : 0; pVga ++; 
      *pVga = (byt & 0x04) ? col : 0; pVga ++; 
      *pVga = (byt & 0x02) ? col : 0; pVga ++; 
      *pVga = (byt & 0x01) ? col : 0; 
      pVga += 313; pBmp ++;
    }
}

  /*. TDL_ScreenSetXY (BYTE x, BYTE y,BYTE ch, BYTE col) - Poke VDU pos with char & colour */
void TDL_ScreenSetXY (BYTE x, BYTE y, BYTE ch, BYTE col) 
{
    TDL_DOS_Vdu[TDL_ScreenPos(x,y)] = ch; 
    if (ch >= TDL_UDG_START && TDL_UDG_ptr) {
      TDL_ScreenSetUDG (x, y, ch, col);
      return;
    }
    TDL_DOS_gotoxy (x+1, y+1);
    TDL_ink = col;
    TDL_DOS_setch (ch);
}	

	/*. void TDL_ScreenSet(UINT pos, BYTE ch, BYTE col) - Poke VDU pos with char & colour */
void TDL_ScreenSet (UINT pos, BYTE ch, BYTE col)  
{
    BYTE x,y;
    x = pos % TDL_VDUX;
    y = pos / TDL_VDUX;
    TDL_DOS_Vdu [pos] = ch; 
    if (ch >= TDL_UDG_START && TDL_UDG_ptr) {
      TDL_ScreenSetUDG (x, y, ch, col);
      return;
    }
    TDL_DOS_gotoxy (x+1, y+1);
    TDL_ink = col;
    TDL_DOS_setch (ch);
}

#endif

  /*. void TDL_ScreenSet2 (UINT pos, BYTE char1, BYTE char2, BYTE col) - Poke VDU pos with 2 chars & colour */
void TDL_ScreenSet2 (UINT pos, BYTE char1, BYTE char2, BYTE col)  
{
    TDL_ScreenSet (pos, char1, col);
    pos ++;
    TDL_ScreenSet (pos, char2, col);
}

  /*. TDL_ScreenSetXY2 (BYTE x, BYTE y, BYTE char1, BYTE char2, BYTE col) - Poke VDU pos with 2 chars & colour */
void TDL_ScreenSetXY2 (BYTE x, BYTE y, BYTE char1, BYTE char2, BYTE col) 
{
    UINT pos;
    pos = TDL_ScreenPos(x,y);
    TDL_ScreenSet (pos, char1, col);
    pos ++;
    TDL_ScreenSet (pos, char2, col);
}

#define TDL_ScreenSetNC(POS,BYT)  TDL_ScreenSet(POS,BYT,TDL_COL_WHITE)

  /*. BYTE TDL_ScreenGet (UINT pos)  - peek vdu pos */
BYTE TDL_ScreenGet (UINT pos)  
{
    return TDL_DOS_Vdu[pos]; 
}	

  /*. BYTE TDL_ScreenGetXY (BYTE x, BYTE y)  - peek vdu pos */
BYTE TDL_ScreenGetXY (BYTE x, BYTE y)  
{
	return TDL_DOS_Vdu [TDL_ScreenPos(x,y)]; 
}	

  /*. TDL_ScreenBackground (BYTE screen, BYTE border) - Set background */
void TDL_ScreenBackground (BYTE screen, BYTE border)
{
    TDL_DOS_ScreenBack (screen, border);
}

void TDL_ScreenClr ()
{
    TDL_DOS_SetGfxMode (TDL_DOS_DEFMODE);
    memset (TDL_DOS_Vdu,32,sizeof (TDL_DOS_Vdu));
    //TDL_DOS_putch (12);
}

  /*. void TDL_PrintChar (BYTE ch) - Print ASC char */
void TDL_PrintChar (BYTE ch)
{
    TDL_DOS_putch (ch);
}

  /*. void TDL_Ink (BYTE ink) - Set print ink */
void TDL_Ink (BYTE ink)
{
     TDL_ink = ink;
}

   /*. void TDL_GotoXY (BYTE x, BYTE y) - Set cursor pos (1,1..X,Y) */
void TDL_GotoXY (BYTE x, BYTE y)
{
    TDL_cursorx = x-TDL_PRINT_ORG;
    TDL_cursory = y-TDL_PRINT_ORG;
    TDL_DOS_gotoxy (x,y);
}

/*-----------------------------------------------------------------------
   DOS KEYBOARD
-------------------------------------------------------------------------*/

#define TDL_SCANCODE_NONE 0

BYTE TDL__LastKey = 0;		/* Last key hit */

#if 1

  /* Convert Raw Keyboard Scan codes from 0x60 to Upper case Ascii */
BYTE TDL_Scan2Asc [64] =   { 0,27,49,50,51,52,53,54,55,56,57,48,45,61,8,9,81,87,69,82,84,89,85,73,79,80,91,93,13,0x82,65,83,
		68,70,71,72,74,75,76,59,39,96,0x81,92,90,88,67,86,66,78,77,44,46,47,0x81,0,0x84,0,0x88,0,0,0,0,0  };
// (SHIFT=0x81, CTRL=0x82, ALT=0x84, CAP=0x88)

  /* Internal routine, check for key-up code */
void TDL_ScanService ()
{
    BYTE scan;
    scan = _inp(0x60);
    if (scan & 0x80) {		/* Key Release */
      if (TDL_Scan2Asc [scan & 63] == TDL_TOUPPER (TDL__LastKey)) {
        TDL__LastKey = 0;
      }
    }
}

  /*. BYTE TDL_GetKeyDown ()  -  Get key held down */
  /* Note - This uses a simple method, can miss key-up. 
      If thats a problem, a full int 09h IRQ hook+handler is needed */
BYTE TDL_GetKeyDown ()
{
    TDL_GetKey ();
    TDL_ScanService ();
    return TDL_TOUPPER (TDL__LastKey);
}

#else		/* Use getkey to fake keydown */

BYTE TDL_GetKeyDown ()
{
     BYTE ch;
     TDL_GetKey ();
     return TDL_TOUPPER (TDL__LastKey);
}
#endif

  /*. BYTE TDL_GetKey_Shift () - Return shift status */
BYTE TDL_GetKey_Shift ()
{
    return (*((BYTE far *) MK_FP (0,0x0417)) );
     /* 1=Shift,4=Ctrl, 8=Alt */
}

  /*. BYTE TDL_GetKey () - get char from keyboard */
BYTE TDL_GetKey ()
{
    if (kbhit () == 0) return 0;
    TDL__LastKey = getch ();
    return TDL__LastKey;
    //return (BYTE) TDL_DOS_GetChar ();
}

/*-----------------------------------------------------------------------
   DOS JOYSTICK
-------------------------------------------------------------------------*/

  /* BYTE TDL_GetJoystick (BYTE joy)  -  Get joystick status */
#define TDL_MAX_JOYSTICK 0

  /* Test bits for joystick direction/fire */
#define TDL_JOYSTICK_UP		0
#define TDL_JOYSTICK_DOWN	0
#define TDL_JOYSTICK_LEFT	0
#define TDL_JOYSTICK_RIGHT	0
#define TDL_JOYSTICK_FIRE	0
#define TDL_JOYSTICK_HIT        0

BYTE TDL_GetJoystick (BYTE joy)
{
    return 0;
}

/*-----------------------------------------------------------------------
   DOS TIMING
-------------------------------------------------------------------------*/

  /* Get clock */
ULONG TDL_Clock ()
{
    return ((UINT) *((long far *) MK_FP (0,0x046c)));
}

  /*. void TDL_Sleep (int tim)  - Sleep (tim) milliseconds */
void TDL_Sleep (int tim) 
{
     ULONG clk = TDL_Clock () + (tim /TDL_CLOCKS_PER_SEC);
     while (TDL_Clock () < clk);
}

void TDL_FrameSync ()
{
    /* TDL_Sleep (TDL_CLOCKS_PER_SEC);  	/* Simple method */
    while ((_inp (0x03da) & 8) == 0) {
      TDL_ScanService ();
    }
    while (_inp (0x03da) & 8) {
      TDL_ScanService ();
    }
    /*     WAIT &H3DA, 8 : WAIT &H3DA, 8, 8 */

}

/*-----------------------------------------------------------------------
   DOS SOUND
-------------------------------------------------------------------------*/

#define TDL_SOUND_TYPE UINT

#define TDL_SOUND_NVOICE 1	// No of voices

#define TDL_SOUND_LO  0
#define TDL_SOUND_HI  1023
#define TDL_SOUND_STEP  4	// Simple scaling step for fx (pow2)

#define TDL_SOUND_C4  596	// (Middle C) Rough note vals
#define TDL_SOUND_A4  770
#define TDL_SOUND_C5  810
#define TDL_SOUND_A5  897
#define TDL_SOUND_C6  917

  /* Simple sound tone generator (voice 0-N) */
void TDL_Sound (UINT val, BYTE voice)
{
    TDL_DOS_SoundOn (val);
}

void TDL_SoundOff (BYTE voice)
{
    TDL_DOS_SoundOff ();
}

void TDL_SoundInit ()
{
}

/*-----------------------------------------------------------------------
   INITIALISATION & MISC
-------------------------------------------------------------------------*/

  /* Set up the UDG chr set pointers */
void TDL_UDG_Init (BYTE *pPix, UINT chstart, UINT psize)
{
    TDL_UDG_ptr = pPix;			/* Store for later use */
    TDL_UDG_start = chstart;
    TDL_UDG_size = psize;
}

  /* Request a screen resolution, sets nearest available. 
	Actual resolution in TDL_VDU_HIX, TDL_VDU_HIY, TDL_VDU_HICOL. */
BYTE TDL_ScreenMode (UINT sx, UINT sy, BYTE coldepth, BYTE flags)
{
    return TRUE;   /* Just use static 320x200x8 (0x13) mode for now */
}

UINT TDL_Initialise (UINT mode, BYTE *pData)
{
	//memset (TDL_KeyDown,0,sizeof(TDL_KeyDown));  /* Clr keydown array */
    TDL_DOS_SetGfxMode (0x13);
    TDL_Ink (TDL_COL_WHITE);
    TDL_ScreenBackground (TDL_COL_BLACK, 0);
    //TDL_ScreenClr ();
    return 0;
}

  /* void TDL_Finish () - Quit TDL */
void TDL_Finish ()
{
    TDL_DOS_SetGfxMode (3);
}
