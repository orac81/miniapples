#!/bin/sh
# ie: ./bkup.sh vtdl126
7za a -tzip zip/$1.zip tdl/* demo/* addix/* skattabugz/* dynajim/* test/*.c *.bat *.sh  *.txt  bkup
