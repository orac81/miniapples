/* TDL 2.xx - Very Tiny Development Layer for portable small apps.
  (C) A.Millett 2012-2026. Released as open software under GNU LGPL license.
  TDL Library released under (less restrictive) LGPL license.

*/

#include <stdio.h>
#include <stdlib.h>

/*-----------------------------------------------------------------------
   Common ZX Spectrum defines and console functions
-------------------------------------------------------------------------*/

#define TDL_FAST 		/* Fast (zeropage,register etc) variable definition */

#define TDL_VDU_STATIC TRUE	/* VDU size/colour parameters are static/limited */
#define TDL_HAS_UDG  TRUE	/* Tell user program (psuedo) UDGs are available */

#define TDL_POKE(AD,BY) *((BYTE *) ((UINT) (AD)))=(BYTE) (BY);
#define TDL_PEEK(AD) ((BYTE) *((BYTE *) ((UINT) (AD))))

#define TDL_ADD_CR  TRUE			/* Add CR if LF sent */

void TDL_PrintChar (BYTE ch);		/* Fwd declare */

#define TDL_CLOCKS_PER_SEC 50

#define TDL_SHIFT_LR   1	/* Left/right shift */

/*-----------------------------------------------------------------------
   ZX-Spectrum specific code
-------------------------------------------------------------------------*/
#define TDL_VDUX 32
#define TDL_VDUY 24

#ifdef TDL_REQ_HIRES
 #define TDL_HAS_HIRES TRUE
 #define TDL_VDU_HIX 256			/* Hi-res pixel screen size (static) */
 #define TDL_VDU_HIY 192
 #define TDL_VDU_HICOL 1			/* Hi res colour depth (#bits) */
#endif

#define TDL_RAM 48		/* Amount of RAM (approx) for platform */

	/*. TDL_ScreenPos(X,Y) - Calc Screen char position from X,Y (0 to max-1) */
#define TDL_ScreenPos(X,Y) ((X)+(Y)*TDL_VDUX)

#ifdef TDL_REQ_TEXT
 #define TDL_UDG_MAX 0			/* Text only, no UDG chars */
#else
 #define TDL_UDG_MAX 128		/* #UDG chars */
#endif
#define TDL_UDG_START 128		/* Start of UDG chars */

#define TDL_CHR_ASC32   32		/* Map Ascii 32-63.. */
#define TDL_CHR_ASC64   64		/* Ascii 64-95 */
#define TDL_CHR_ASC96   96		/* Ascii 96-127 */
#define TDL_ASC2CHR(C) (C)		/* Convert ascii to chr code */


#define TDL_ZX_VDU (0x4000)
#define TDL_ZX_COLOR (0x5800)
#define TDL_ZX_CHRSET (0x3d00)	// Spectrum charset, for ascii 0x20-0x7f (32-127)
#define TDL_ZX_FRAMES 23672			/* Frame count */
#define TDL_ZX_VDUPOS(X,Y)  (((Y) & 7) * 256 + (((Y)/8) & 7) * 32 +((Y)/64) * 2048 + (X))
#define TDL_ZX_COLORPOS(X,Y)  ((X) + (Y) * 32)
#define TDL_ZX_ULA (0xfe)		// OUT to ULA, bot 3 bits = border col.

/*-----------------------------------------------------------------------
   SPECTRUM SCREEN DRAWING
-------------------------------------------------------------------------*/

#define TDL_ZX_USE_ASM TRUE

#define TDL_ZX_RED   2		// ZX raw colours (purple = TDL_ZX_RED+TDL_ZX_BLUE etc)
#define TDL_ZX_GREEN 4
#define TDL_ZX_BLUE  1

  /* Basic RGB Colours, (0-7) */
#define TDL_COL_BLACK  0
#define TDL_COL_RED    2	/* 1:Bit 0 */
#define TDL_COL_GREEN  4	/* 2:Bit 1 */
#define TDL_COL_YELLOW 6
#define TDL_COL_BLUE   1	/* 4:Bit 2 */
#define TDL_COL_PURPLE 3
#define TDL_COL_CYAN   5
#define TDL_COL_WHITE  7

BYTE TDL_RGBI2COL[]={0,2,4,6,1,3,5,7};   /* Colour Conversion Table for ScreenSet */
UINT TDL__VduY [TDL_VDUY];

#define TDL_RGBItoCol(RGBI) TDL_RGBI2COL[(RGBI) & 7 ]

BYTE TDL_zx_vdu [TDL_VDUX*TDL_VDUY+2];		/* VDU char map buffer */

BYTE *TDL_UDG_ptr=0;
UINT TDL_UDG_start=128;
UINT TDL_UDG_size=0;

BYTE TDL_border;
BYTE TDL_backcol;

BYTE TDL_cursorx ;
BYTE TDL_cursory ;
BYTE TDL_ink ;

#if TDL_ZX_USE_ASM		/* Set for ASM version.. */

  /* Output UDG char to spectrum VDU (xpos 0-31,ypos 0-24) */

BYTE TDL__zx_x;
BYTE TDL__zx_y;
BYTE TDL__zx_ch;
UINT TDL__zx_set;

void TDL_zx_drawchar (BYTE *pSrc, BYTE xpos, BYTE ypos, BYTE ch, BYTE ink)
{
    UINT x;
    BYTE *pScreen;
    x = (UINT) (TDL_ZX_COLOR + TDL_ZX_COLORPOS(xpos,ypos));
    *((BYTE *) x) = ink;

    if (ch < TDL_UDG_start) {		/* Set ptr to ROM */
      TDL__zx_ch = ch - 32;
      TDL__zx_set = TDL_ZX_CHRSET;
    } else {
      TDL__zx_ch = ch - TDL_UDG_start;
      TDL__zx_set = (UINT) pSrc;
    }
    TDL__zx_x = xpos; 
    TDL__zx_y = ypos; 

__asm 
		; Spectrum: Draw char (A) direct at VDU x,y pos (E,D)
  ld a,(_TDL__zx_x)
  ld e,a
  ld a,(_TDL__zx_y)
  ld d,a
  ld a,(_TDL__zx_ch)
  ld hl,(_TDL__zx_set)

  ld b,0
  ld c,a
  sla c		; Mul BC by 8
  rl  b
  sla c
  rl  b
  sla c
  rl  b
  add hl,bc		; HL points to ROM char 8 bytes.

;  call get_chr_addr   ; Turn VDU x,y (E,D) into VDU address (DE)
  ld a,d
  and %00000111
  rra
  rra
  rra 
  rra
  or e
  ld e,a
  ld a,d
  and %00011000
  or  %01000000  
  ld d,a

  ld b,4	; Copy 8 Bytes from (hl) to (de)
printchar1:
  ld a,(hl)
  ld (de),a
  inc hl
  inc d
  ld a,(hl)
  ld (de),a
  inc hl
  inc d
  djnz printchar1
__endasm; 

}

#else 
  /* Output UDG char to spectrum VDU (xpos 0-31,ypos 0-24) (OLD C VERSION) */
void TDL_zx_drawchar (BYTE *pSrc, BYTE xpos, BYTE ypos, BYTE ch, BYTE ink)
{
    UINT x;
    BYTE *pScreen;
    if (ch < TDL_UDG_start) {		/* Set ptr to ROM */
      ch -= 32;
      pSrc = (BYTE *) TDL_ZX_CHRSET;
    } else {
      ch -= TDL_UDG_start;
    }
    pSrc += ch * 8; 
    x = (UINT) (TDL_ZX_COLOR + TDL_ZX_COLORPOS(xpos,ypos));
    *((BYTE *) x) = ink;

    //ypos = ypos << 3;
    //x = ((UINT) (TDL_ZX_VDU + TDL_ZX_VDUPOS (xpos,ypos)));
    x = ((UINT) (TDL_ZX_VDU + TDL__VduY [ypos] + xpos));
    pScreen = (BYTE *) x;
    for (x=0; x<4; x++) {
      *pScreen = *pSrc;
      pScreen += 256; pSrc ++;
      *pScreen = *pSrc;
      pScreen += 256; pSrc ++;
    }
}


#endif

	/*. void TDL_ScreenSet(UINT pos, BYTE ch, BYTE col) - Poke VDU pos with char & colour */
void TDL_ScreenSet (UINT pos, BYTE ch, BYTE col)  
{
    TDL_zx_vdu[pos] = ch; 
    TDL_zx_drawchar (TDL_UDG_ptr, (pos & 31), (pos >> 5), ch, col);
}	

  /*. void TDL_ScreenSet2 (UINT pos, BYTE char1, BYTE char2, BYTE col) - Poke VDU pos with 2 chars & colour */
void TDL_ScreenSet2 (UINT pos, BYTE char1, BYTE char2, BYTE col)  
{
    TDL_ScreenSet (pos, char1, col);
    pos ++;
    TDL_ScreenSet (pos, char2, col);
}

#define TDL_ScreenSetNC(POS,BYT)  TDL_ScreenSet(POS,BYT,TDL_COL_WHITE)

  /*. BYTE TDL_ScreenGet (UINT pos)  - peek vdu pos */
BYTE TDL_ScreenGet (UINT pos)  
{
	return TDL_zx_vdu[pos]; 
}	

  /*. BYTE TDL_ScreenGetXY (BYTE x, BYTE y)  - peek vdu pos */
BYTE TDL_ScreenGetXY (BYTE x, BYTE y)  
{
	return TDL_zx_vdu [TDL_ScreenPos(x,y)]; 
}	

  /*. TDL_ScreenSetXY (BYTE x, BYTE y,BYTE ch, BYTE col) - Poke VDU pos with char & colour */
void TDL_ScreenSetXY (BYTE x, BYTE y, BYTE ch, BYTE col) 
{
    TDL_zx_vdu [(UINT) TDL_ScreenPos(x,y)] = ch; 
    TDL_zx_drawchar (TDL_UDG_ptr, x, y, ch, col);
}

  /*. TDL_ScreenSetXY2 (BYTE x, BYTE y, BYTE char1, BYTE char2, BYTE col) - Poke VDU pos with 2 chars & colour */
void TDL_ScreenSetXY2 (BYTE x, BYTE y, BYTE char1, BYTE char2, BYTE col) 
{
    UINT pos;
    pos = TDL_ScreenPos(x,y);
    TDL_zx_vdu [pos] = char1; 
    TDL_zx_drawchar (TDL_UDG_ptr, x, y, char1, col);
    pos ++; x ++;
    TDL_zx_vdu [pos] = char2; 
    TDL_zx_drawchar (TDL_UDG_ptr, x, y, char2, col);
}

#ifdef TDL_REQ_HIRES

	/*. TDL_DrawPoint (UINT xpos, UINT ypos, UINT color) - Draw a pixel */
void TDL_DrawPoint (BYTE xpos, BYTE ypos, BYTE color)
{
#if 1
    UINT x;
    BYTE *pScreen;
    x = ((UINT) (TDL_ZX_VDU + TDL_ZX_VDUPOS (xpos/8,(UINT) ypos)));
    pScreen = (BYTE *) x;
    *pScreen |= (128 >> (xpos & 7));
#else
    TDL__zx_x = xpos;
    TDL__zx_y = ypos;
    TDL__zx_ch = color;
    __asm 
      ld a,(_TDL__zx_y)
      ld c,a
      ld l,a
      ld a,(_TDL__zx_x)
      call 0x22b0
      ld e,a
      ld a,(hl)
      or a,e
      ld (hl),a
		; call 0x22b0 ; CalcAdd. In: A=xpos, C=L=ypos: RET: HL=Screen add, A=Bit val
		; call 8933 ; Write pixel. IN:c=x(0-255) b=y(0-175),0x5c7d=coords
    __endasm; 
#endif
}

#endif

/*-----------------------------------------------------------------------
   SPECTRUM KEYBOARD
-------------------------------------------------------------------------*/

  /* Read Spectrum keyboard using ROM calls. Return ascii, or 0 if no key */
BYTE *pKeyTab = (BYTE *) 0x0205;	// Translate table in ROM
BYTE TDL__zx_key, TDL__zx_lastkey;		// Globals for asm call

  /* ZX raw key scancodes for 0xc5,peek(197) */
#define TDL_SCANCODE_NONE 0

  /*. BYTE TDL_GetKeyDown ()  -  Get key raw scancode (key held down) */
BYTE TDL_GetKeyDown ()
{
    __asm 
        call 0x028e	; Call Spec ROM, ret keydown (0-27) in E, 255 if none.
        ld a,e
        ld (_TDL__zx_key),a
    __endasm;
    if (TDL__zx_key == 255) return 0;
    return pKeyTab [TDL__zx_key];
}

#if 1

  /*. BYTE TDL_GetKey_Shift () - Return shift status (New Ver) */
BYTE TDL_GetKey_Shift ()
{
    __asm 
		;was  ld bc,0xfefe ; in a,(c)
	ld a,0xfe
	in a,(0xfe)	; Get Shift key status
	cpl		; xor 0xff
	and 1
        ld (_TDL__zx_key),a
    __endasm;
    return TDL__zx_key;
}
#else 

  /*. BYTE TDL_GetKey_Shift () - Return shift status (Old ver) */
BYTE TDL_GetKey_Shift ()
{
    __asm 
        call 0x028e	; Call Spec ROM, ret keydown (0-27) in E, 255 if none.
        ld a,d
        ld (_TDL__zx_key),a
    __endasm;
    if (TDL__zx_key == 255) return 0;
    return TDL__zx_key;
}
#endif

/*-----------------------------------------------------------------------
   SPECTRUM JOYSTICK
-------------------------------------------------------------------------*/

  /* BYTE TDL_GetJoystick (BYTE joy)  -  Get joystick status */
#define TDL_MAX_JOYSTICK 2

  /* Test bits for joystick direction/fire */
#define TDL_JOYSTICK_UP		2
#define TDL_JOYSTICK_DOWN	4
#define TDL_JOYSTICK_LEFT	16
#define TDL_JOYSTICK_RIGHT	8
#define TDL_JOYSTICK_FIRE	1
#define TDL_JOYSTICK_HIT        31

BYTE TDL_zx_joy;

BYTE TDL_joy_kemp2sinc[] = {0,8,16,0,4,12,20,0,2,10,18,0,0,0,0,0};

  /* Read Joystick buttons (0=Sinclair port="67890", 1=Kempston) */
volatile BYTE TDL_GetJoystick (BYTE joy)
{
    if (joy) {
    __asm 
        ld bc,31	; Kempstone joy port @31, return bits7-0: xxxFUDLR
        in a,(c)
	and 31
        ld (_TDL_zx_joy),a
    __endasm;
      TDL_zx_joy = TDL_joy_kemp2sinc[TDL_zx_joy & 15] + (TDL_zx_joy >> 4);
    } else {
    __asm 
        ld bc,61438	; Sinclair joy port @$fe, keys 67890, return bits7-0: xxxLUDRF
        in a,(c)
	cpl		; xor 0xff
        and 31
        ld (_TDL_zx_joy),a
    __endasm;
    }
    //if (TDL_zx_joy == TDL_JOYSTICK_HIT) return 0;  	/* All set, kempstone not connected */
    return TDL_zx_joy;
}

/* NOTE:
  Sinclair1: $effe, 000LRDUF, active low, key 6-0
  Sinclair2: $f7fe, 000FUDRL, low, key1-5
  Kempstone: $001f, 000FUDLR, high
  Fuller:    $007f, FxxxRLDU, low
*/

/*----------------------------------------------------------------------- */

#if TDL_IO_DIRECT


  /*. void TDL_PrintChar (BYTE ch) - Print ASC char (using direct drawing) */
void TDL_PrintChar (BYTE ch)
{
    UINT pos;
    if (ch < 32) {
      if (ch == 10) {
        TDL_cursorx = 0;
        if (TDL_cursory < TDL_VDUY) TDL_cursory ++;
      }
      return;
    }
    pos = TDL_ScreenPos (TDL_cursorx, TDL_cursory);
    TDL_ScreenSet (pos, ch, TDL_ink);
    TDL_cursorx ++;
    if (TDL_cursorx >= TDL_VDUX) {
      TDL_cursorx = 0;
      if (TDL_cursory < TDL_VDUY) TDL_cursory ++;
    }
}

  /*. BYTE TDL_GetKey () - get char from keyboard */
BYTE TDL_GetKey ()
{
    __asm 
        call 0x028e	; Call Spec ROM, ret keydown (0-27) in E, 255 if none.
        ld a,e
        ld (_TDL__zx_key),a
    __endasm;
    if (TDL__zx_lastkey == TDL__zx_key) return 0;	// Same as last time
    TDL__zx_lastkey = TDL__zx_key;
    if (TDL__zx_key == 255) return 0;		// No key down
    return pKeyTab [TDL__zx_key];
}

  /*. void TDL_Ink (BYTE ink) - Set print ink */
void TDL_Ink (BYTE ink)
{
     TDL_ink = ink;
}

   /*. void TDL_GotoXY (BYTE x, BYTE y) - Set cursor pos (1,1..X,Y) */
void TDL_GotoXY (BYTE x, BYTE y)
{
    TDL_cursorx = x-TDL_PRINT_ORG;
    TDL_cursory = y-TDL_PRINT_ORG;
}

#endif


#if TDL_IO_CONIO	/* CONIO NOT WORKING, use TDL_IO_DIRECT! */

  /*. void TDL_PrintChar (BYTE ch) - Print ASC char */
void TDL_PrintChar (BYTE ch)
{
    putchar (ch);
    #if 0
      __asm
       ld a,0
       call 5633	; Setup screen
       ld a,(_ch)
       rst 16		; Print char
      __endasm;
    #endif
}

  /*. BYTE TDL_GetKey () - get char from keyboard */
BYTE TDL_GetKey ()
{
    if (kbhit () ==0) return 0;
    return getch ();
}

  /*. void TDL_Ink (BYTE ink) - Set print ink */
void TDL_Ink (BYTE ink)
{
    putchar (17); putchar (zx_screen); 	// Paper=black
    putchar (16); putchar (TDL_RGBI2COL[ink&7]); 
}

   /*. void TDL_GotoXY (BYTE x, BYTE y) - Set cursor pos (1,1..X,Y) */
void TDL_GotoXY (BYTE x, BYTE y)
{
    if (x<1 || x>32 || y<1 || y>24) return;
    putchar (22); putchar (y-TDL_PRINT_ORG); putchar (x-TDL_PRINT_ORG);
}

#endif

void TDL_ScreenClr ()
{
   #if 1
    UINT x;
    BYTE ink;
    ink = TDL_backcol * 8 + TDL_COL_WHITE;
    for (x=0; x< TDL_VDUX * TDL_VDUY; x++) {
      ((BYTE *) TDL_ZX_COLOR) [x] = ink;
      TDL_zx_vdu [x] = 32;
    }
    for (x=0; x< TDL_VDUX * TDL_VDUY * 8; x++) {
      ((BYTE *) TDL_ZX_VDU) [x] = 0;
    }
   #else 
     call 3435     ; Asm CLS
   #endif
   TDL_Ink (TDL_COL_WHITE);
   TDL_GotoXY (1,1);
}

/*-----------------------------------------------------------------------
   SPECTRUM TIMING
-------------------------------------------------------------------------*/

  /* Wait for start of frame, for animation etc. */
void TDL_FrameSync ()
{
    __asm 
      ei	; Wait for the frame refresh interrupt
      halt
    __endasm; 
}

#define TDL_CLOCK_GAP 20	// Frmae in millisec

  /* Get 16bit clock */
UINT TDL_Clock ()
{
     return (TDL_PEEK (TDL_ZX_FRAMES) | 256*TDL_PEEK (TDL_ZX_FRAMES+1));
}

  // Sleep (tim) milliseconds
void TDL_Sleep (int tim) 
{
    do {
      TDL_FrameSync ();
      tim -= TDL_CLOCK_GAP;
    } while (tim > 0);
}


/*-----------------------------------------------------------------------
   SPECTRUM SOUND
-------------------------------------------------------------------------*/

BYTE TDL_freq;

#ifdef TDL_USE_ZXBEEP 	  /* Simple zx beep generator */

#define TDL_SOUND_TYPE BYTE

#define TDL_SOUND_NVOICE 1	// No of voices

#define TDL_SOUND_C4  50		// Rough note vals
#define TDL_SOUND_A4  100
#define TDL_SOUND_C5  150
#define TDL_SOUND_A5  200

#define TDL_SOUND_LO  1
#define TDL_SOUND_HI  255
#define TDL_SOUND_STEP  1	// Simple scaling step for fx


void TDL_SoundBeep (BYTE val, BYTE voice)
{
    TDL_freq = val;
    __asm	
      ld hl,(_TDL_freq)	; Freq
      ld de,1		; Duration
      call 949		; ROM BEEP routine
    __endasm;
}

/* Beep - Direct method
  lda 1,$10
beeploop:
  xor $10
  out (254),a	; Toggle bit 4 (Lo 3 bits=border)
  ld b,90
beep2:
  djnz beep2	; timer loop
  jp beeploop

*/
  
void TDL_SoundOff (BYTE voice)
{
}

void TDL_SoundInit () 
{
}

#else
		/* Use ZX-AY8912 Sound Chip */

#define TDL_SOUND_TYPE UINT

#define TDL_SOUND_NVOICE 3	// No of voices

  // Convert Freq (in hertz) to Tone val. (1.7734Mhz / (16 * FHz) )
#define TDL_SOUND_FREQ2TONE(FHz) (((UINT) 55419/((FHz)>>1)) ^0x0fff)

#define TDL_SOUND_C4  (424 ^ 0x0fff)		// C4  261.63Hz  (Middle C) 
#define TDL_SOUND_A4  (252 ^ 0x0fff)		// A4, 440Hz
#define TDL_SOUND_C5  (212 ^ 0x0fff)		// C5, 523.26Hz
#define TDL_SOUND_A5  (126 ^ 0x0fff)		// A5, 880Hz

#define TDL_SOUND_LO  0
#define TDL_SOUND_HI  4095
#define TDL_SOUND_STEP  2	// Simple scaling step for fx

UINT TDL_Int1;

  /* Send cmd to AY8912 synth, form REG*256+VAL. ie: 0x0738 sets reg7=38 */
void TDL_AyCmd (UINT reg_val)
{
	// H=reg, L=value. 
    TDL_Int1 = reg_val;
    #asm
      ld hl,(_TDL_Int1)
      ld bc, 0xfffd
      out (c), h	; out 65533,H    (0xfffd)
      ld b, 0xbf
      out (c), l	; out 49149,L    (0xbffd)
    #endasm
}

#define TDL_AY_CMD(reg,val) TDL_AyCmd((reg)*256 + (val))
#define TDL_AY_TONE(vox,tone) TDL_AY_CMD((vox)*2, (tone)&0xff); TDL_AY_CMD(1+(vox)*2, (tone)>>8); 
#define TDL_AY_VOL(vox,vol) TDL_AY_CMD(8+(vox), (vol));

  /* Simple sound generator (AY) */
void TDL_Sound (UINT val, BYTE voice)
{
    TDL_AY_TONE(voice, (val ^ 0x0fff));	// Invert tone so its low-high as others
    TDL_AY_VOL(voice, 15);
    TDL_AY_CMD(0x07,0x38);		// Enable voice
}

void TDL_SoundOff (BYTE voice)
{
    TDL_AY_VOL(voice,0);
    //TDL_AY_CMD(0x07,0x38);	
}

void TDL_SoundInit () 
{
}

#endif

  /* Set up the UDG chr set pointers */
void TDL_UDG_Init (BYTE *pPix, UINT chstart, UINT psize)
{
    TDL_UDG_ptr = pPix;
    TDL_UDG_start = chstart;
    TDL_UDG_size = psize;
}

  /*. void TDL_ScreenBackground (BYTE screen, BYTE border) - Set background */
void TDL_ScreenBackground (BYTE screen, BYTE border)
{
    TDL_border = border;
    TDL_backcol = screen;
    __asm 
        ld a,(_TDL_border)
	out (0xfe),a	// Set border colour
    __endasm; 
}

  /* Request a screen resolution, sets nearest available. 
	Actual resolution in TDL_VDU_HIX, TDL_VDU_HIY, TDL_VDU_HICOL. */
BYTE TDL_ScreenMode (UINT sx, UINT sy, BYTE coldepth, BYTE flags)
{
    return 0;   /* Just use static modes for now */
}


UINT TDL_Initialise (UINT mode, BYTE *pData)
{
    UINT y;
    TDL_ScreenBackground (TDL_COL_BLACK, TDL_COL_BLACK);
    TDL_ScreenClr ();
	/* Fill VDU Y start array */
    for (y=0; y<TDL_VDUY; y++) {
      TDL__VduY [y] = TDL_ZX_VDUPOS (0,y*8);
    }
    return 0;
}

  /* void TDL_Finish () - Quit TDL */
void TDL_Finish ()
{
}

