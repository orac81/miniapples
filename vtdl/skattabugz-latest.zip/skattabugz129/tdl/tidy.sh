#!/bin/sh
rm $1/*.asm
rm $1/*.int
rm $1/*.lbl
rm $1/*.map
rm $1/*.dbj

