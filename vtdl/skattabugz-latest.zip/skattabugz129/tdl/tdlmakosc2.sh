#!/bin/sh
# tdlmakosc2.sh  - Build TDL app with OSCAR64
#  Syntax  ./tdlmakosc2.sh progname [parms]   
#  ie: ./tdlmakosc.sh skattabugz/skattabugz -
#  Note: This version has specific build options tailored for each platform
echo "Building C64..       ($1.c)"
oscar64 -D TDL_CBM -D TDL_C64=1   -D IS_OSCAR=1 -tm=c64 -Os -Oz -Op -Oo $2 $3 $4 $5 $1.c -o=$1-c64.prg
echo "Building VIC20.."
oscar64 -D TDL_CBM -D TDL_VIC20=1 -D IS_OSCAR=1 -tm=vic20 -Os -Oz -Op -Oo $2 $3 $4 $5 $1.c -o=$1-v20.prg
echo "Building C16.."
oscar64 -D TDL_CBM -D TDL_C16=1   -D IS_OSCAR=1 -tm=plus4 -Os $2 $3 $4 $5 $1.c -o=$1-c16.prg
echo "Building PET.. (40 col)"
oscar64 -D TDL_CBM -D TDL_PET=1   -D IS_OSCAR=1 -tm=pet  -Os $2 $3 $4 $5 $1.c -o=$1-pet.prg
#echo "Building PET32k.."
#oscar64 -D TDL_CBM -D TDL_PET=1 -D IS_OSCAR=1 -tm=pet32  $2 $3 $4 $5 $1.c -o=$1-pet32k.prg
# echo "Building PET80.."
# oscar64 -D TDL_CBM -D TDL_PET80=1 -D IS_OSCAR=1 -tm=pet32  $2 $3 $4 $5 $1.c -o=$1-pet80.prg
