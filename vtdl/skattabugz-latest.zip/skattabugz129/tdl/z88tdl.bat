echo off
rem Build TDL app using Z88DK
rem ie: z88tdl test-udg
rem (NOTE: Run z88init.bat first.)
zcc +zx -vn -DTDL_ZX -startup=30 -clib=sdcc_iy %1.c -o %1-spectrum -create-app %2 %3 %4 %5

rem other cmd line examples
rem ====== z88mak.bat   (build console apps)
rem zcc +zx -o %1-spectrum -lndos -create-app %1.c  %2 %3 %4 %5
rem zcc +zx81 -o %1-zx81.p -lndos -create-app %1.c  %2 %3 %4 %5 
rem zcc +zx80 -o %1-zx80.o -lndos -create-app %1.c  %2 %3 %4 %5
rem zcc +cpm  -o %1.com    -lndos -create-app %1.c  %2 %3 %4 %5
rem ====== make spcol.c
rem zcc +zx -vn -startup=1 -clib=sdcc_iy spcol.c -o spcol -create-app
rem ====== scmakz.bat - make sconnex.c
rem copy d:\w\c\sdl\sconnex\sconnex.c .
rem rem zcc +zx81 -DIS_8BIT -DIS_ZX81 -o sconnex-zx81.p -lndos -create-app sconnex.c  
rem zcc +zx81 -DIS_8BIT -DIS_ZX81 -startup=1  -o sconnex-zx81.p -lndos -create-app sconnex.c  
rem zcc +zx   -vn -DIS_8BIT -DIS_SPEC -startup=30  -clib=sdcc_iy sconnex.c -o sconnex-spec   -create-app
