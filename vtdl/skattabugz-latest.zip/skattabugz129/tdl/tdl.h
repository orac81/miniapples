/* TDL.H  :  Header declarations */
typedef unsigned char BYTE;
typedef unsigned short int UINT;
typedef unsigned long int ULONG;

#define FALSE 0
#define TRUE  1

#define TDL_TOUPPER(CH) (((CH)>='a' && (CH)<='z') ? ((CH)-'a'+'A') : (CH))
#define TDL_TOLOWER(CH) (((CH)>='A' && (CH)<='Z') ? ((CH)-'A'+'a') : (CH))
#define TDL_ISDIGIT(CH) ((CH)>='0' && (CH)<='9')

  // Some ascii codes (Upper case)
#define TDL_ASC_A 65
#define TDL_ASC_B 66
#define TDL_ASC_C 67
#define TDL_ASC_D 68
#define TDL_ASC_E 69
#define TDL_ASC_F 70
#define TDL_ASC_G 71
#define TDL_ASC_H 72
#define TDL_ASC_I 73
#define TDL_ASC_J 74
#define TDL_ASC_K 75
#define TDL_ASC_L 76
#define TDL_ASC_M 77
#define TDL_ASC_N 78
#define TDL_ASC_O 79
#define TDL_ASC_P 80
#define TDL_ASC_Q 81
#define TDL_ASC_R 82
#define TDL_ASC_S 83
#define TDL_ASC_T 84
#define TDL_ASC_U 85
#define TDL_ASC_V 86
#define TDL_ASC_W 87
#define TDL_ASC_X 88
#define TDL_ASC_Y 89
#define TDL_ASC_Z 90

#define TDL_ASC_0 48
#define TDL_ASC_1 49
#define TDL_ASC_2 50
#define TDL_ASC_3 51
#define TDL_ASC_4 52
#define TDL_ASC_5 53
#define TDL_ASC_6 54
#define TDL_ASC_7 55
#define TDL_ASC_8 56
#define TDL_ASC_9 57
#define TDL_ASC_SPC 32
#define TDL_ASC_RET 13
