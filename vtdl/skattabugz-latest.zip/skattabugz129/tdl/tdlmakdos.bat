echo off
rem Build exe using the VTDL library and MSVC1.52
echo tdlmakdos msvc152-path dosprog [dosprog2.c ..] [flags..]
echo   ie: tdlmakdos d:\msvc15 demo\hello

echo .
echo Building DOS_VGA version: %2.exe
%1\bin\cl.exe /D "TDL_DOS" /D "TDL_DOS_VGA" /AM /nologo /Gs /G3 /FPi87 /FR /W3 /Oe /O1 /Ot /Ox /Fe%2.exe /I%1\include %2.c %3 %4 %5 %6 %7 %8 %9  -link /NOI /STACK:5120  %1\lib\oldnames.lib %1\lib\mlibc7.lib 

rem echo Building %2m.exe for DOS-VGA (min-smaller)
rem %1\bin\cl.exe /D "TDL_DOS" /D "TDL_DOS_VGA" /AM /Gs /G3 /FPi87 /FR /W3 /Oe /O2 /Fe%2m.exe /I%1\include %2.c %3 %4 %5 %6 %7 %8 %9  -link /NOI /STACK:5120  %1\lib\oldnames.lib %1\lib\mlibc7.lib 

rem echo .
rem echo Building DOS_BIOS version: %2-bios.exe
rem %1\bin\cl.exe /D "TDL_DOS" /D "TDL_DOS_BIOS" /AM /nologo /Gs /G3 /FPi87 /FR /W3 /Oe /O1 /Ot /Ox /Fe%2-bios.exe /I%1\include %2.c %3 %4 %5 %6 %7 %8 %9  -link /NOI /STACK:5120  %1\lib\oldnames.lib %1\lib\mlibc7.lib 

del *.obj
del *.sbr

rem orig: %1\bin\cl.exe /D "TDL_DOS" /AM /nologo /Gs /G3 /FR /FPi87 /W3 /Oe /O1 /Ot /Ox /I%1\include %2.c %3 %4 %5 %6 %7 %8 %9  -link /NOI /STACK:5120  %1\lib\oldnames.lib %1\lib\mlibc7.lib 
