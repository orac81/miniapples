#!/bin/sh
#  Build TDL CBM demo programs using OSCAR64
./tdlmakosc2.sh skattabugz/skattabugz ; 
./tdlmakosc2.sh addix/addix     -Os -Oz -Op -Oo
./tdlmakosc.sh dynajim/dynajim -Os -Oz -Op -Oo
./tdlmakosc.sh demo/tplasma    -Os -Oz -Op -Oo
./tdlmakosc.sh demo/hello      -Os -Oz -Op -Oo
./tdlmakosc.sh demo/test-udg   -Os -Oz -Op -Oo
./tdlmakosc.sh demo/tsound     -Os -Oz -Op -Oo
./tidy.sh addix
./tidy.sh dynajim 
./tidy.sh skattabugz
./tidy.sh demo
mv demo/*.prg demo/bin
