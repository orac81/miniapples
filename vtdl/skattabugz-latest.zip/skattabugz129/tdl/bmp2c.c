/* BMP2C.C  - Dump mono BMP as C source code in 8x8 chars.
	(C) A.Millett 2026. Freeware.

 -> BMP2C100, 24.1.2026
 Dump mono bmp, test: ./hexdump.elf skata1.bmp B4 62,10000 
*/

char szProgInfo[] = "BMP2C 1.00 - Convert mono bmp to C source. (C) A.Millett 2026. GPL3/Freeware.\n";
	"Use: bmp2c file.bmp >file.c\n"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
/* #include <io.h> */
#include <fcntl.h>
#include <ctype.h>

typedef unsigned char BYTE;
typedef unsigned short int WORD;
typedef unsigned long DWORD;
typedef unsigned int UINT;
typedef unsigned long ULONG;
typedef long LONG;

#define TRUE 1
#define FALSE 0

int file_load (char *filename, char *pdata, ULONG fstart, ULONG flen)
{
    FILE *hfile;
    int nread;
    hfile = fopen (filename, "rb");
    if (hfile == NULL) return 0;
    fseek (hfile, fstart, SEEK_SET);
    nread = fread (pdata, 1, flen, hfile);
    fclose (hfile);
    return nread;
}

ULONG file_len (char *filename)
{
    FILE *hfile;
    int cret;
    ULONG filelen;

    hfile = fopen (filename, "rb");
    if (hfile == NULL) return 0;
    fseek (hfile, 0, SEEK_END);
    filelen = ftell (hfile);
    fclose (hfile);
    return filelen;
}

  /* Convert int to ascii */
int str_val2asc (ULONG ival, char *szAsc, int ndigits, int base)
{
  int nibble,ch;
  szAsc[ndigits] = 0;
  while (ndigits) {
    nibble = ival % base;
    ival = ival / base;
    ch = '0'+nibble; 
    if (nibble > 9) ch+=7;
    ndigits --;
    szAsc[ndigits] = ch;
  }
  return (0);
}


  /* Convert ascii hex to int */
ULONG str_asc2val (char *szAsc, int base, int *slen)
{
    ULONG rval;
    int cpos;
    int cchr;
    rval = 0; cpos = 0;
    while (1) {
      cchr = szAsc [cpos]; 
      if (cchr < '0' || cchr > 'F') break; 
      if (cchr > '9') cchr = cchr - 7;
      rval = (rval * base) + cchr - '0';
      cpos ++;
    }
    if (slen) *slen = cpos;
    return rval;
}

/*-------------------------------------------------------------------------
   main() - Main routine
-------------------------------------------------------------------------*/

#define IO_RGB(r,g,b) (((r) & 0xe0) | (((g) & 0xe0) >> 3) | (((b) & 0xc0) >> 6))

#define MAX_FILENAME 256

char szSrcName [MAX_FILENAME+8] = "bmpin.bmp";

#pragma pack(1)    /* Force tight struct packing (c99 directive) */

	/* Bmp File format - 54 byte header before data */
typedef struct {
	/* BITMAPFILEHEADER.. */
   WORD    bfType;		/* "BM" - value 19778 */
   DWORD   bfSize; 
   WORD    bfReserved1; 
   WORD    bfReserved2; 
   DWORD   bfOffBits;
    
	/* BITMAPINFOHEADER.. */
   DWORD  biSize; 
   LONG   biWidth; 
   LONG   biHeight; 
   WORD   biPlanes; 
   WORD   biBitCount;
   DWORD  biCompression; 
   DWORD  biSizeImage; 
   LONG   biXPelsPerMeter; 
   LONG   biYPelsPerMeter; 
   DWORD  biClrUsed; 
   DWORD  biClrImportant; 

   BYTE pData [1];		/* Palette data (if any), then Pixel Array (upside down, min 32bit wide) */
} BMP_FILE;

  /* Convert BMP to text source code */
int bmp_convert (BMP_FILE *pBmp, ULONG flen)
{
    int x,y,cx;
    int lenx,leny;
    int pixstart;
    int linlen;
    int nchrx,nchry,nc;		/* # chars */
    int cpos;
    BYTE pixel;
    BYTE *pData;
    lenx = pBmp->biWidth;
    leny = pBmp->biHeight;
    pixstart = pBmp->bfOffBits;			/* Offset to Start of Pixel Array */
    pData = ((BYTE *) pBmp) + pixstart;
    nchrx = (lenx+1)/8; nchry = (leny+1)/8;
    linlen = (lenx/32)*4;			/* Len of each line in Bytes*/
    printf ("  //  \x22%s\x22 size %d x %d, Bitdepth=%d, #char: %d x %d\n\n  ", 
		szSrcName, lenx, leny, pBmp->biBitCount,nchrx,nchry);
    if (pBmp->bfType != 19778) return FALSE;
    if (pBmp->biBitCount != 1) return FALSE;		// Must be mono
    nc = 0;
    for (y=0; y < nchry; y++) {
      for (x=0; x < nchrx; x++) {
        cpos = (nchry-y)*8*linlen+x;
        for (cx=0; cx<8; cx++) {
	  cpos -= linlen;
          //printf (" /*%d*/ 0x%02x,",cpos,pData[cpos]);
          printf ("0x%02x,",pData[cpos]);
	}
	nc ++;
	printf ("  // chr:%d\n  ",nc); 
      }
    }
    printf ("\n");
    return TRUE;
}

int bmp_init (char *pSrcName)
{
    ULONG flen;
    int cret;
    BYTE *pMem;

    flen = file_len (pSrcName);
    if (flen == 0) {
      puts ("Cannot read source file.");
      return FALSE;
    }
    pMem = malloc (flen+64);
    if (pMem == NULL) return FALSE;
    flen = file_load (pSrcName, pMem,0,flen);
    pMem [flen]=0;
    cret = bmp_convert ((BMP_FILE *) pMem, flen);
    if (cret == FALSE) {
      free (pMem);
      puts ("Error on conversion\n");
      return FALSE;
    }
    
    free (pMem);
    return TRUE;
}

int main (int argc,char *argv[])
{
    puts (szProgInfo);
    if (argc > 1) {     /* Input file on command line */
      strcpy (szSrcName, argv[1]);
    } else {
      printf ("\n Source file:");
      fgets (szSrcName,MAX_FILENAME,stdin);
    }
    if (szSrcName [0] == 0) return 0;
    return bmp_init (szSrcName);
}

