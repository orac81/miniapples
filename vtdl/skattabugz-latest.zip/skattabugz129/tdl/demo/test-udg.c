/* TEST-UDG.C - Simple demo of TDL UDG graphics. 
     (C) A.Millett 2026. Freeware/GPL3 
   Shows animation of coloured 16x16 game counter pieces.
*/

#define TDL_IO_DIRECT 1	/* Set TDL_IO_CON, TDL_IO_SYS or TDL_IO_DIRECT */

#ifdef TDL_PATH		/* User sets TDL_PATH */
 #include TDL_PATH
#else
 #include "../tdl/tdl.c"
#endif

  /* Simple game counter piece picture, 16x16 dots in 4 8x8 UDG characters */
BYTE pPix[] = {
  0x00,0x03,0x0f,0x1c,0x3b,0x37,0x6e,0x6d,	// Top left
  0x00,0xc0,0xf0,0x38,0xdc,0xec,0x76,0xb6,	// Top right
  0x6d,0x6e,0x37,0x3b,0x1c,0x0f,0x03,0x00,	// Bottom left
  0xb6,0x76,0xec,0xdc,0x38,0xf0,0xc0,0x00,	// Bottom right
0};

  /* Draw counter at (x,y) colour (col) */
void draw_piece (BYTE x, BYTE y, BYTE col)
{
    UINT pos;
    x += x; y += y;	/* Scale pos x2 */
    pos = TDL_ScreenPos (x,y);
    TDL_ScreenSet (pos,   TDL_UDG_START,   col); 
    TDL_ScreenSet (pos+1, TDL_UDG_START+1, col);
    pos = TDL_ScreenPos (x,y+1);
    TDL_ScreenSet (pos,   TDL_UDG_START+2, col);
    TDL_ScreenSet (pos+1, TDL_UDG_START+3, col);
}

int main ()
{
    UINT crand;
    BYTE x,y,col;
    TDL_Initialise (0,NULL);
    TDL_UDG_Init (pPix, TDL_UDG_START, sizeof (pPix));	/* Give TDL the UDG gfx */
    do {
      x = TDL_Rand () % (TDL_VDUX/2);	/* Create a random pos/colour (x,y,col) */
      crand = TDL_Rand ();		
      y = crand % (TDL_VDUY/2);
      col = TDL_RGBItoCol (crand/256 & 7);
      draw_piece (x,y,col);		/* Draw it on screen */
      x = TDL_GetKey ();		/* Hit space to exit? */
    } while (x != 32);
    TDL_Finish ();
    return 0;
}
