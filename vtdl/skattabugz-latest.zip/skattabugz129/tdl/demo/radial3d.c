/* RADIAL3D.C - Classic Radial 3D plot, test VTDL hires graphics library.
 (C) A.Millett 2025. Released as free software under GNU GPL3 license.
Compile with "-lm" option (enable float lib)

*/

char szProg [] = "TDL_RADIAL3D. (C) A.Millett 2025, Freeware/GPL3.";

#include <stdio.h>
#include <math.h>

#define TDL_IO_DIRECT  1	/* Use direct screen poke for print */
#define TDL_REQ_HIRES  1	/* Request hires gfx */

#ifdef TDL_PATH		/* User sets TDL_PATH */
 #include TDL_PATH
#else
 #include "../tdl/tdl.c"
#endif

#define XSQRT sqrt
#define XCOS  cos

  /* Draw 3d Radial plot*/
void draw3d ()
{
  int x1,x2,y1,y2;
  int x4,m,x,y;
  float a,r,f,i,r2;
  const int vstep = 24;

  x1 = TDL_VDU_HIX / 2; x2 = x1 * x1;
  y1 = TDL_VDU_HIY / 2; y2 = y1 / 2;
  for (x = 0; x<=x1; x++) {
    x4 = x * x;
    m = -y1;
    a = XSQRT ((float) (x2 - x4));
    for (i = -a; i<= a; i+= TDL_VDU_HIY / vstep) {
      r = XSQRT ((float) x4 + i * i ) / (float) x1;
      f = (r - 1) * XCOS (r * 12);
      //f = ( (1 - r) ** 4) +  (1-r)*((r) ** 2) - 1; 
      // r2 = 1-r ; f = (2*r2*r2)-(r*r*r)-(r*r*r*r) ; 
      y = (int) ((float) i / 5 + f * y1);
      if (y > m) {
        m = y;
        y = y1 - y;
	TDL_DrawPoint (x1 - x, y, TDL_COL_WHITE);
	TDL_DrawPoint (x1 + x, y, TDL_COL_WHITE);
      }
    }
  }
}

	/* Main program */
int main ()
{
    TDL_Initialise (0,NULL);
	/* Request hires 320x200x8, actual resolution in TDL_VDU_HIX, TDL_VDU_HIY, TDL_VDU_HICOL */
    TDL_ScreenMode (320, 200, 8, 0);
    draw3d ();
    while (TDL_GetKey () == 0);
    TDL_Finish ();
    return 0;
}
