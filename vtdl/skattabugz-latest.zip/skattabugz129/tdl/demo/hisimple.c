/* TESTHI.C - Simple demo VTDL hires. */


#define TDL_IO_DIRECT 1		/* Use direct screen poke for print */
#define TDL_REQ_HIRES  1	/* Request hires gfx */

#ifdef TDL_PATH		/* User sets TDL_PATH */
 #include TDL_PATH
#else
 #include "../tdl/tdl.c"
#endif

  // Plot curves hires 
void test1 ()
{
    int x,y,i;
    for (i=4; i<100; i+=4) {
      for (x=-(TDL_VDU_HIX/2); x<(TDL_VDU_HIX/2); x++) {
        y = i+x*x/i;
	if ((UINT) y<TDL_VDU_HIY) TDL_DrawPoint (x+(TDL_VDU_HIX/2), y, TDL_COL_WHITE);
      }
    }
}

	/* Main program */
int main ()
{
    TDL_Initialise (0,NULL);
	/* Request hires 320x200x8, actual resolution in TDL_VDU_HIX, TDL_VDU_HIY, TDL_VDU_HICOL */
    TDL_ScreenMode (320, 200, 8, 0);
    test1 ();
    while (TDL_GetKey () == 0);
    TDL_Finish ();
    return 0;
}
