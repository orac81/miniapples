/* TLIFE1D.C - 1d Life for VTDL graphics library.
 (C) A.Millett 2025. Released as free software under GNU GPL3 license.

 */

char szProg [] = "TDL_LIFE1D. (C) A.Millett 2025, Freeware/GPL3.";

#include <stdio.h>

#define TDL_IO_DIRECT 1		/* Use direct screen poke for print */
#define TDL_REQ_HIRES  1	/* Request hires gfx */

#ifdef TDL_PATH		/* User sets TDL_PATH */
 #include TDL_PATH
#else
 #include "../tdl/tdl.c"
#endif

#define NSTATE 5	// Try 4 or 5 here
#define NRULE  (NSTATE * 4 + 4)
#define WIDE TDL_VDU_HIX

BYTE tcol [] = {
  TDL_COL_BLACK, TDL_COL_WHITE, TDL_COL_PURPLE, TDL_COL_BLUE,
  TDL_COL_YELLOW, TDL_COL_RED, TDL_COL_CYAN, TDL_COL_GREEN,
  TDL_COL_BLACK, TDL_COL_WHITE, TDL_COL_PURPLE, TDL_COL_BLUE,
  TDL_COL_YELLOW, TDL_COL_RED, TDL_COL_CYAN, TDL_COL_GREEN,
0};

BYTE life [WIDE*2 + 8];
BYTE rule [NRULE + 8];

UINT lifeseed = 1;
UINT drawtime = 0;
BYTE mode = 1;
UINT countrand = 0;	/* Random counter */

BYTE life1d ()
{
    int x,y,c;
    BYTE cmd;
    drawtime = TDL_Clock ();
    TDL_rndseed = (lifeseed+2);
	// Random rules
    for (x=0; x<NRULE; x++) {
      rule [x] = TDL_Rand () % NSTATE;
    }
	// Seed first line
    for (x=0; x<=WIDE+1; x++) {
      life [x] = TDL_Rand () % NSTATE;
    }

    TDL_ScreenClr ();
    TDL_Ink (TDL_COL_YELLOW);
    TDL_PrintSI ("SEED:",lifeseed);
    TDL_Ink (TDL_COL_CYAN);
    TDL_PrintStr (" (-FBRMQ,SPC,H=HELP)");
	// Draw screen
    for (y=10; y<TDL_VDU_HIY; y++) {
      for (x=0; x<WIDE; x++) {
        c = life[x] + life[x+1] + life [x+2];
        life [x+WIDE+1] = rule[c];
        if (mode) c = rule [c];
	#if (TDL_VDU_HICOL == 1)		/* Only 1 colour available */
 	  if (c & 1) TDL_DrawPoint (x,y, 1);
 	  if (c & 2) TDL_DrawPoint (x,y+1, 1);
	#else
	  TDL_DrawPoint (x,y, tcol [c & 15]);
	#endif
      }
      for (x=0; x<WIDE; x++) {
        life [x] = life[WIDE+x];
      }
      #if (TDL_VDU_HICOL == 1)		/* Only 1 colour available */
	y++;
      #endif
      countrand += 123;
      cmd = TDL_GetKey ();
      if (cmd) return cmd;
    }
    drawtime = TDL_Clock () - drawtime;
    return 0;
}

void help_screen ()
{
    BYTE cmd;
    TDL_ScreenClr ();
    TDL_Ink (TDL_COL_WHITE);
    TDL_PrintStr ((char *) "  ** LIFE-1D **\n\n");
    TDL_Ink (TDL_COL_GREEN);
    TDL_PrintStr ((char *) "(c)A.MILLETT 2025,FREE/GPL3.\n\n");
    TDL_Ink (TDL_COL_YELLOW);
    TDL_PrintStr ((char *)
	" H : VIEW HELP\n"
	" - : SEED -1 BACK\n"
	" F : +10 FWD\n"
	" B : -10 BACK\n"
	" T : +100 FWD\n"
	" R : RAND SEED\n"
	" M : MODE\n"
        " ENTER : REDRAW\n"
        " SPACE : NEXT SEED\n"
        " Q,ESC : QUIT\n"
    );
    TDL_Ink (TDL_COL_PURPLE);
    TDL_PrintSI ((char *) "\nSEED:",lifeseed);
    TDL_PrintSI ((char *) "\nDRAW TIME:",drawtime);
    TDL_PrintStr ((char *) "\n\n HIT SPACE.");
    do {
      countrand ++;
      cmd = TDL_GetKey ();
     } while (cmd == 0);
}

int main_Loop ()
{
    BYTE cmd = 0;
    help_screen ();
    while (1) {
      cmd = life1d ();
      if (cmd == 0) {
        do {
	  countrand ++;
          cmd = TDL_GetKey ();
        } while (cmd == 0);
      }
      cmd = TDL_TOUPPER (cmd);
      switch (cmd) {
	case 'Q' : 
	case 27 : 
	  return 0;
	case 'M' : 	// MODE
          mode = !mode;
	  break;
	case 'R' : 	// Rand seed
	  lifeseed = countrand ;
	  break;
	case 'H' : 	// Help/info screen
	  help_screen ();
	  continue;
	case 'F' : 
          lifeseed += 10;
	  break;
	case 'B' : 
          lifeseed -= 10;
	  break;
	case 'T' : 
          lifeseed += 100;
	  break;
	case '-' : 
          lifeseed --;
	  break;
	case 13 : 
	case 'A':
	  break;
	default:
          lifeseed ++;
	  break;
      }
    }
    return 0;
}

	/* Main program */
int main ()
{
    TDL_Initialise (0,NULL);
	/* Request hires 320x200x8, actual resolution in TDL_VDU_HIX, TDL_VDU_HIY, TDL_VDU_HICOL */
    TDL_ScreenMode (320, 200, 8, 0);
    main_Loop ();
    TDL_Finish ();
    return 0;
}
