/* MELBASS.C  -  Mels Disco Bassoon (AKA: Name Mels Band) 
    Collect the letters to make Mels Band Name!
       (C) A.Millett 2016-2026, released as GPL/Freeware under GNU GPL license.
   Import some code from previous RockBal
 -> rockbal106, 26.7.2026
   Simple working ver, random words.
 ->rangerj101, 29.8.26
   Add border, pick flowers for bonus
 ->rangerj102, 31.8.26
   Imp tiled chrs
 ->rangerj103, 1.9.26
   Imp "band name" gen.
 ->rangerj104, 3.9.26
 ->rangerj105, 7.9.26
   rename..
 ->melband106, 10.9.26
   Add spc in names.
   Imp PROG_EXTRA
 ->melbass107, 12.9.26
   Joystick bug
 ->melbass108, 14.9.26

*/

#define PROG_NAME "Mels Disco Bassoon"
#define PROG_VER  "1.08"
//#define PROG_EXTRA			// Add extra features

#define TDL_IO_DIRECT 1                /* Use direct screen poke for print */

#ifdef TDL_PATH                /* User sets TDL_PATH */
 #include TDL_PATH
#else
 #include "../tdl/tdl.c"
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//#define PROG_DEBUG   TRUE                /* Add some debug features (or: -D PROG_DEBUG=1) */
#if TDL_RAM < 8
 #define FULL_VERSION   FALSE
 #define WORD_GEN       FALSE
#else
 #define FULL_VERSION   TRUE                /* Add extra features */
 #define WORD_GEN       TRUE
#endif

#define USE_TITLE_SCREEN  TRUE

#if (TDL_UDG_MAX > 0)        /* Are UDGs available? If so, set them up.. */

 BYTE pPix[] = {
  //  "rangerj/rangerj.bmp" size 96 x 32, Bitdepth=1, #char: 12 x 4
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,  // +0
  0xaa,0x55,0xaa,0x55,0xaa,0x55,0xaa,0x55,
  0x00,0x7e,0x7e,0x66,0x66,0x7e,0x7e,0x00,
  0x00,0x06,0x0e,0x1c,0x98,0x63,0x1c,0x00,
  0x00,0x00,0x1e,0x21,0xd8,0x1c,0x0e,0x06,  // +4
  0x10,0x23,0x27,0x2e,0x2c,0x10,0x08,0x08,
  0x04,0x64,0x72,0x3a,0x1a,0x04,0x04,0x08,
  0xc3,0xe7,0x66,0x18,0x18,0x66,0xe7,0xc3,
  0x18,0x18,0xe7,0x3c,0x3c,0x3c,0x24,0x66,  // +8
  0x99,0x5a,0x24,0x3c,0x3c,0x3c,0x24,0x66,
 #if FULL_VERSION
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	// Letter tiles A-Z,?
  0xfe,0xc6,0xba,0x82,0xba,0xba,0xfe,0x00,  // +12
  0xfe,0x86,0xba,0x86,0xba,0x86,0xfe,0x00,
  0xfe,0xc2,0xbe,0xbe,0xbe,0xc2,0xfe,0x00,
  0xfe,0x86,0xba,0xba,0xba,0x86,0xfe,0x00,
  0xfe,0x82,0xbe,0x8e,0xbe,0x82,0xfe,0x00,  // +16
  0xfe,0x82,0xbe,0x8e,0xbe,0xbe,0xfe,0x00,
  0xfe,0xc2,0xbe,0xb2,0xba,0xc2,0xfe,0x00,
  0xfe,0xba,0xba,0x82,0xba,0xba,0xfe,0x00,
  0xfe,0xc6,0xee,0xee,0xee,0xc6,0xfe,0x00,  // +20
  0xfe,0xc2,0xf6,0xf6,0xb6,0xce,0xfe,0x00,
  0xfe,0xb6,0xae,0x9e,0xae,0xb6,0xfe,0x00,
  0xfe,0xbe,0xbe,0xbe,0xbe,0x82,0xfe,0x00,
  0xfe,0x82,0xaa,0xaa,0xba,0xba,0xfe,0x00,  // +24
  0xfe,0xba,0x9a,0xaa,0xb2,0xba,0xfe,0x00,
  0xfe,0x82,0xba,0xba,0xba,0x82,0xfe,0x00,
  0xfe,0x86,0xba,0x86,0xbe,0xbe,0xfe,0x00,
  0xfe,0xc6,0xba,0xaa,0xb2,0xc6,0xfe,0x00,  // +28
  0xfe,0x86,0xba,0x86,0xb6,0xba,0xfe,0x00,
  0xfe,0x82,0xbe,0x82,0xfa,0x82,0xfe,0x00,
  0xfe,0x82,0xee,0xee,0xee,0xee,0xfe,0x00,
  0xfe,0xba,0xba,0xba,0xba,0xc6,0xfe,0x00,  // +32
  0xfe,0xba,0xba,0xba,0xd6,0xee,0xfe,0x00,
  0xfe,0xba,0xba,0xaa,0xaa,0xc6,0xfe,0x00,
  0xfe,0xba,0xd6,0xee,0xd6,0xba,0xfe,0x00,
  0xfe,0xba,0xd6,0xee,0xee,0xee,0xfe,0x00,  // +36
  0xfe,0x82,0xfa,0xc6,0xbe,0x82,0xfe,0x00,
  0xfe,0xc6,0xba,0xf6,0xee,0xee,0xfe,0x00,
 #endif
 0};

        /* UDG character constants */
 #define CHR_EMPTY    TDL_CHR_ASC32
 #define CHR_BRICK    TDL_UDG_START + 1
 #define CHR_BRICK2   TDL_UDG_START + 2
 #define CHR_EDGEH    TDL_UDG_START + 3
 #define CHR_EDGEH2   TDL_UDG_START + 4
 #define CHR_EDGEV    TDL_UDG_START + 5
 #define CHR_EDGEV2   TDL_UDG_START + 6
 #define CHR_EDGE     TDL_UDG_START + 7
 #define CHR_FLOWER   TDL_UDG_START + 7
 #define CHR_PLAYER   TDL_UDG_START + 8
 #define CHR_PLAYER2  TDL_UDG_START + 9
 #if FULL_VERSION
  #define CHR_ALPHA    TDL_UDG_START + 12
  #define CHR_WILDCARD TDL_UDG_START + 38
 #else
  #define CHR_ALPHA    TDL_ASC2CHR('A')
  #define CHR_WILDCARD TDL_ASC2CHR('?')
 #endif

#else         /* No UDGs, ASCII/PETSCII.. */

 #ifdef TDL_HAS_PETSCII

        /* PETCII Game char codes */
  #define CHR_EMPTY    TDL_ASC2CHR(' ')
  #define CHR_PLAYER   83
  #define CHR_PLAYER2  TDL_ASC2CHR(' ')
  #define CHR_BRICK    102
  #define CHR_BRICK2   79+128
  #define CHR_EDGEV    TDL_ASC2CHR('!')
  #define CHR_EDGEV2   TDL_ASC2CHR('!')
  #define CHR_EDGEH    TDL_ASC2CHR('-')
  #define CHR_EDGEH2   TDL_ASC2CHR('-')
  #define CHR_EDGE     81
  #define CHR_FLOWER   42
  #define CHR_ALPHA    TDL_ASC2CHR('A')  // +128
  #define CHR_WILDCARD TDL_ASC2CHR('?')
#else

        /* ASCII Game char codes */
  #define CHR_EMPTY    TDL_CHR_ASC32
  #define CHR_PLAYER   TDL_ASC2CHR('*')
  #define CHR_PLAYER2  TDL_ASC2CHR(' ')
  #define CHR_BRICK    TDL_ASC2CHR('#')
  #define CHR_BRICK2   TDL_ASC2CHR('#')
  #define CHR_EDGEV    TDL_ASC2CHR('!')
  #define CHR_EDGEV2   TDL_ASC2CHR('!')
  #define CHR_EDGEH    TDL_ASC2CHR('-')
  #define CHR_EDGEH2   TDL_ASC2CHR('-')
  #define CHR_EDGE     TDL_ASC2CHR('+')
  #define CHR_FLOWER   TDL_ASC2CHR('*')
  #define CHR_ALPHA    TDL_ASC2CHR('A')
  #define CHR_WILDCARD TDL_ASC2CHR('?')

 #endif

#endif

  /* Game char colours */
#define COL_PLAYER   TDL_COL_WHITE
#define COL_BRICK    TDL_COL_BLUE
#define COL_BRICK2   TDL_COL_CYAN
#define COL_EDGE     TDL_COL_GREEN
#define COL_EDGE2    TDL_COL_RED
#define COL_ALPHA    TDL_COL_PURPLE
#define COL_WILDCARD TDL_COL_GREEN
#define COL_FLOWER   TDL_COL_RED

  /* Various game constants */
#define DENSITY_BRICK   3        /* % Density of hard bricks.. */
#define NWILDCARD 	2
#define NFLOWERS 	4

  /* Top of play area */
#define TOPX 1
#define TOPY 2
  /* Size of play area (excluding border) */
#define BRDX (TDL_VDUX - 2)
#define BRDY (TDL_VDUY - 3)
#define BRDSIZE (BRDX * BRDY)

  /* Game global vars */
UINT score;
UINT hiscore = 0;

BYTE playx,playy;
BYTE gameOver;
BYTE level;
BYTE joystick = 0;	/* Current joystick (0,1) */

#define MAX_LETTERS 19
BYTE nletters;		/* len of word */
BYTE cletter=0; 		/* Cur letter */
BYTE cword[MAX_LETTERS+5];		/* Word to find */
BYTE genword = TRUE;	/* Generate word */

void game_Help  ();
void game_DrawText ();
void game_Border (BYTE);

#if USE_TITLE_SCREEN

#if TDL_VDUX < 32	/* Minimal title screen */

char szHelp[] =
  PROG_NAME "\n" PROG_VER "\n"
  "(C)A.MILLETT 2026\n\n"
  "Collect letters in\n"
  "order. Use joy or\n"
  "QAOP/RCDF Move UDLR\n"
  "K Quits\n"
  "\n\nHit SPACE\n\n";


void game_Help ()
{
    BYTE helpkey;
    TDL_ENABLE_TEXT ;	 	/* Request text */
    TDL_ScreenClr ();
    TDL_Ink ( TDL_COL_YELLOW);
    TDL_PrintStr (szHelp);
    TDL_Ink ( TDL_COL_PURPLE);
    TDL_PrintSI ( " HI:",   hiscore);  //TDL_PrintChar ('0');
    do { 
      helpkey = TDL_GetKey ();
      #if TDL_RAM > 64
        if (helpkey == TDL_KEY_ESC || TDL_RequestQuit == TRUE) exit (0);  /* Request quit (window close) */
      #endif
    } while (helpkey != 32);
    TDL_ENABLE_UDG ;	 	/* Request UDG */
}

#else		/* >=32 cols, Full Help */

	// Help/Title screen text..   *
char szHelp[] =
	"\nHelp Mel name his band!\n"
        "Collect letters in order.\n"
        "Wildcards (?) can be used.\n"
        "You cannot cross your tracks.\n"
        "Flowers score bonus points.\n"
	"Use Joystick, or keys QAOP\n"
	"or RCDF move Up/Down/Left/R\n"
        "Hit K to end game.\n"
	"\n";

  
void game_Help ()
{
    BYTE helpkey;
    TDL_ScreenClr ();
help_loop:
    #if TDL_VDUX > 30		/* Center help text */
      TDL_SetLeftMargin ( (TDL_VDUX - 26) / 2);
    #endif
    
    TDL_GotoXY ((TDL_VDUX - 24)/2,3);
    TDL_Ink ( TDL_COL_WHITE);
    TDL_PrintStr ( PROG_NAME " " PROG_VER);
    TDL_Ink ( TDL_COL_BLUE);
    TDL_PrintStr ( "\n\n(C) A.MILLETT 2026,FREE/GPL3\n");
    TDL_Ink ( TDL_COL_YELLOW);
    TDL_PrintStr (szHelp);
    TDL_Ink ( TDL_COL_GREEN);
    TDL_PrintSI ( " High Score:",   hiscore);  //TDL_PrintChar ('0');
    TDL_Ink ( TDL_COL_PURPLE);
    #if (TDL_MAX_JOYSTICK > 1)
      TDL_PrintSI ( "\n JOY (J):",joystick+1); 
    #endif
    TDL_Ink (TDL_COL_CYAN);
    TDL_PrintStr ( "\n\n  HIT SPACE");
    game_Border (0);
    while (TDL_GetKey ()) {};	/* Clr keyboard buffer */

    do { 
      rand ();	/* Randomise */
      helpkey = TDL_GetKey ();
      helpkey = TDL_TOUPPER(helpkey);
      #if TDL_RAM > 64
        if (helpkey == TDL_KEY_ESC || TDL_RequestQuit == TRUE) exit (0);  /* Request quit (window close) */
      #endif
      #if (TDL_MAX_JOYSTICK > 1)
          if (helpkey == 'J') {
	    joystick ^= 1;	/* J=Flip joysticks */
	    goto help_loop;
	  }
      #endif
      TDL_Sleep (20);
    } while (helpkey != 32);
    TDL_SetLeftMargin (0);
}

#endif

#endif		/* USE_TITLE_SCREEN */

  /* Find random empty square */
UINT game_randpos ()
{
    UINT r;
    BYTE z;
    for (z=200; z; z++) {
      r = (rand () % (TDL_ScreenPos (TDL_VDUX, TDL_VDUY-3))) + TDL_ScreenPos (0,2);
      if (TDL_ScreenGet (r) == CHR_EMPTY) return r;
    }
    return 0;
}

void word_Show (BYTE x, BYTE y)
{
    UINT pos;
    BYTE c,col;
    pos = TDL_ScreenPos (x,y);
      col = TDL_COL_WHITE;
      for (c=0; c<nletters-cletter; c++) {
        TDL_ScreenSet (pos+c, cword[cletter+c], col); 
        col = TDL_COL_PURPLE;
        if (c+x>TDL_VDUX-5) break;
      }
      TDL_ScreenSetNC (pos+c, CHR_EMPTY); 
      TDL_ScreenSetNC (pos+c+1, CHR_EMPTY); 
}

  /* Display score, free mvs, level */
void score_update ()
{
    TDL_Ink ( TDL_COL_WHITE);
    TDL_GotoXY (2,1);
    TDL_PrintInt (score);
    TDL_Ink ( TDL_COL_YELLOW);
    TDL_GotoXY (7,1);
    #if TDL_VDUX > 38
        TDL_PrintStr ( "FIND:");
        word_Show (11,0);
    #else
        word_Show (6,0);
    #endif
    TDL_GotoXY (TDL_VDUX-1,1);
    TDL_PrintInt (level);
    TDL_ScreenSet (TDL_VDUX-4, CHR_PLAYER2, TDL_COL_PURPLE); 
}

void game_sound (BYTE n)
{
    UINT r;
    while (n) {
     r = rand ();
     TDL_Sound (TDL_SOUND_LO + (r & 127)* TDL_SOUND_STEP, 1);
     n --;
     TDL_Sleep (20);
    }
    TDL_SoundOff (1);
}

void game_Border (BYTE topy)
{
    BYTE x,y,ch;
    for (x=0; x<TDL_VDUX-1; x++) {
      ch = (x & 1) ? CHR_EDGEH : CHR_EDGEH2;
      TDL_ScreenSetXY (x, topy, ch, COL_EDGE);       
      TDL_ScreenSetXY (x, TDL_VDUY-1, ch, COL_EDGE);       
    }
    for (y=topy; y<TDL_VDUY-1; y++) {
      ch = (y & 1) ? CHR_EDGEV : CHR_EDGEV2;
      TDL_ScreenSetXY (0, y, ch, COL_EDGE);       
      TDL_ScreenSetXY (TDL_VDUX-1, y, ch, COL_EDGE);       
    }
    TDL_ScreenSetXY (0, topy, CHR_EDGE, COL_EDGE2);       
    TDL_ScreenSetXY (0, TDL_VDUY-1, CHR_EDGE, COL_EDGE2);       
    TDL_ScreenSetXY (TDL_VDUX-1, topy, CHR_EDGE, COL_EDGE2);       
    TDL_ScreenSetXY (TDL_VDUX-1, TDL_VDUY-1, CHR_EDGE, COL_EDGE2);       
}

  /* Fill (cword) with (nletters) random letters */
void word_CreateRandom ()
{
    BYTE y;
    for (y=0; y<nletters; y++) {
      cword[y] = CHR_ALPHA + rand () % 26;
    }
    cword[y] = 0;
    cword[y+1] = 0;
}

	/* Generate a random word/phrase */
#if WORD_GEN

char words1[] = "OK\0HI\0YO\0THE\0HEY\0HOT\0FUN\0BIG\0MELS\0ODD\0ITS\0ONE\0DARK\0SOME\0TEPID\0DUSKY\0SIMPLE\0OFFBEAT\0"
	"UPTEMPO\0AMAZING\0ANOTHER\0PASSIONATE\0INDIFFERENT\0INTENSE\0EXCITING\0SO\0\0";
char words2[] = "BAD\0HOT\0TOP\0TALL\0FUN\0BIG\0RED\0GIN\0LOST\0PUNK\0DANK\0FULL\0COOL\0LOST\0JAZZ\0THIN\0DISCO\0ULTRA\0FUNKY\0"
	"MUDDY\0GREEN\0BLUE\0ELECTRIC\0FOREVER\0INFINITE\0ACCEPTABLE\0VODKA\0WHISKY\0REMARKABLE\0\0";
char words3[] = "JO\0ZX\0DO\0RAT\0JAM\0FUNK\0JAZZ\0VIBE\0BUG\0VIC\0SID\0JOE\0JAR\0EMU\0DOG\0LEG\0JIVE\0BEAT\0DEAL\0FRED\0"
	"GAME\0BYTE\0ANTIC\0THING\0GRIME\0TEMPO\0GROOVE\0BASSOON\0HOOCH\0FUSION\0MOTION\0SEAGULL\0SPECTRUM\0COLLUSION\0\0";

#define NOT_WORD 0xFF

	/* Pick random word from list u*/
BYTE word_Pick (char *ptr, BYTE prob, BYTE mlen)
{
    BYTE y;
    BYTE p = 0;
    do {
      y = strlen (ptr+p);
      if (y <= mlen && (rand () & prob) == 0) return p;
      p += y + 1;	// Skip to next 
    } while (ptr[p]);
    return 0;
}

  /* Add ascii str to (cword) */
void word_Add (char *ptr, BYTE p)
{
    BYTE y = 0;
    while (*ptr) {
      cword[p] = CHR_ALPHA + (*ptr - 'A') ;
      p ++;
      ptr ++;
    }
    cword[p] = CHR_EMPTY;
    ptr ++;
    cword[p+1] = 0;
    cword[p+2] = 0;
}

	/* Create random word/phrase  */
void word_Create ()
{
    BYTE y;
    BYTE p1,p2,p3;
    BYTE l1,l2,l3;
    BYTE n = 0;
    if (genword == FALSE) {
      word_CreateRandom ();      
      return;
    }
	/* Build a composite word */
    do  {
      p3 = word_Pick (words3, 31, nletters);
      if (p3 == 0) {
        p3 = word_Pick (words3, 15, nletters);
      }
      l3 = strlen (words3+p3);
      p2 = word_Pick (words2, 31, nletters);
      if (p2 == 0) {
        p2 = word_Pick (words2, 15, nletters);
      }
      l2 = strlen (words2+p2);
      p1 = word_Pick (words1, 31, nletters);
      if (p1 == 0) {
        p1 = word_Pick (words1, 7, nletters);
      }
      l1 = strlen (words1+p1);
      if (l3 == nletters) {
        word_Add (words3+p3, 0);
        return;
      }
      if (l2+l3 == nletters) {
        word_Add (words2+p2, 0);
        word_Add (words3+p3, l2+1);
        nletters ++;
        return;
      }
      if (l1+l3 == nletters) {
        word_Add (words1+p1, 0);
        word_Add (words3+p3, l1+1);
        nletters ++;
        return;
      }
      if (l1+l2+l3 == nletters) {
        word_Add (words1+p1, 0);
        word_Add (words2+p2, l1+1);
        word_Add (words3+p3, l1+l2+2);
        nletters += 2;
        return;
      }
      n ++;
    } while (n<255);
	/* Unable to find word.. */
    word_CreateRandom();      
}

#else
	/* Just generate random letters */
void word_Create ()
{
      word_CreateRandom();      
}

#endif

  
  /* New game/level */
void game_NewLevel ()
{
    BYTE idx;
    BYTE x,y;
    UINT nitems;
    UINT pos;

    TDL_ScreenClr ();    
    game_sound (4);
    gameOver = FALSE;
    level ++;

    game_Border (1);
	/* Generate random word to find */
    nletters = level + 4 + (TDL_VDUX > 30);
    if (nletters > MAX_LETTERS) nletters = MAX_LETTERS;
    word_Create ();
    cletter = 0;

        /* Place player & space in center */
    playx = TDL_VDUX / 2;
    playy = TDL_VDUY / 2;
    TDL_ScreenSetXY (playx, playy, CHR_PLAYER, COL_PLAYER);
	/* Draw Random Bricks */
    idx = (BRDSIZE * DENSITY_BRICK) / 100;
    for (; idx; idx --) {
      pos = game_randpos ();
      if (pos) TDL_ScreenSet (pos, CHR_BRICK2, COL_BRICK2); 
    }
	/* Draw Flowers */
    for (y=0; y < NFLOWERS; y++) {
      pos = game_randpos ();
      if (pos) TDL_ScreenSet (pos, CHR_FLOWER, COL_FLOWER); 
    }
	/* Draw Letters */
    for (y=0; y < nletters; y++) {
      pos = game_randpos ();
      if (pos) TDL_ScreenSet (pos, cword[y], COL_ALPHA); 
    }
	/* Draw Wildcards */
    for (y=NWILDCARD + (nletters/8); y ; y--) {
      pos = game_randpos ();
      if (pos) TDL_ScreenSet (pos, CHR_WILDCARD, COL_WILDCARD); 
    }
    score_update ();
}


void game_New ()
{
    level = 0;
    score = 0;
    game_NewLevel ();
}

#define IS_SPACE 255

  /* Can player move to this sqr? ret 0=NO, or chr */
BYTE player_MoveAvail (BYTE px, BYTE py)
{
    BYTE ch;
    ch = TDL_ScreenGetXY (px, py);
    if (ch == CHR_EMPTY) return IS_SPACE;
    if (ch == CHR_FLOWER) return ch;
    if (ch == cword[cletter] || ch == CHR_WILDCARD) return ch;
    return 0;
}

  /* Is there any move? */
BYTE player_CanMove (BYTE px, BYTE py)
{
     if (player_MoveAvail (px+1,py)) return TRUE;
     if (player_MoveAvail (px-1,py)) return TRUE;
     if (player_MoveAvail (px,py+1)) return TRUE;
     if (player_MoveAvail (px,py-1)) return TRUE;
     return FALSE;
}

  /* Animate player, flash letters */
void player_Animate (BYTE phase)
{
    BYTE x,y;
    UINT pos;
    TDL_ScreenSetXY (playx, playy, (phase ? CHR_PLAYER2 : CHR_PLAYER), COL_PLAYER); 
    for (y = TOPY; y < TOPY + BRDY; y++) {
      for (x = TOPX; x < TOPX + BRDX; x++) {
        pos = TDL_ScreenPos (x,y);
        if (TDL_ScreenGet (pos) == cword[cletter]) {
          TDL_ScreenSet (pos, cword[cletter], phase  ? TDL_COL_WHITE : COL_ALPHA);
        }
      }
    }          
}

    BYTE px=0,py=0,dx=0,dy=0;

void player_Move ()
{
    BYTE x,y,z=0;
    BYTE ch;
    BYTE key;
    BYTE joy = 0;
    if (player_CanMove (playx,playy) == FALSE) {	/* No move left! */
      gameOver = TRUE;
      return;
    }
    do {
      #if FULL_VERSION                /* Add player anmation */
        TDL_Sleep (20);
        z ++;
        if ((z & 15) == 0) {		/* Flash next letter */
          player_Animate (z & 16);
        }
      #endif
      #if (TDL_MAX_JOYSTICK > 0)
        joy = TDL_GetJoystick (joystick);
      #endif
      key = TDL_GetKey ();
      key = TDL_TOUPPER (key);
    } while (key ==  0 && (joy & TDL_JOYSTICK_HIT) == 0);
    #if FULL_VERSION      
       player_Animate (0);	/* Put back to normal */
    #endif

    if (key == 'N') game_New ();
    #ifdef PROG_EXTRA
    #endif
    if (key == 'K' || key == TDL_KEY_ESC) {
      gameOver = TRUE;
      return;
    }
    dx = dy = 0;
    if ( joy & TDL_JOYSTICK_HIT) {
      if (joy & TDL_JOYSTICK_LEFT) dx = (BYTE) -1;
      if (joy & TDL_JOYSTICK_RIGHT) dx = 1;
      if (joy & TDL_JOYSTICK_UP) dy = (BYTE) -1;
      if (joy & TDL_JOYSTICK_DOWN) dy = 1;
    } else {
      if (key == 'O' || key == 'D' || key == TDL_KEY_LEFT  ) dx = (BYTE) -1;
      if (key == 'P' || key == 'F' || key == TDL_KEY_RIGHT ) dx = 1;
      if (key == 'Q' || key == 'R' || key == TDL_KEY_UP    ) dy = (BYTE) -1;
      if (key == 'A' || key == 'C' || key == TDL_KEY_DOWN  ) dy = 1;
    }
    if ((dx | dy) == 0) return ;
    if (joy) TDL_Sleep (100);
    TDL_ScreenSetNC (TDL_ScreenPos (playx, playy), CHR_EMPTY); 
    px = playx + dx;  
    py = playy + dy;
    ch = player_MoveAvail (px,py);
    if (ch) {		/* Move is ok.. */
      TDL_ScreenSetXY (playx, playy, CHR_BRICK, COL_BRICK); 
      if (ch == IS_SPACE) {
        playx = px; playy = py;
      } else if (ch == CHR_FLOWER) {
        game_sound (8);
        score += level * 4;
        playx = px; playy = py;
      } else {			/* Found next letter */
        game_sound (2);
        score += level;
        playx = px; playy = py;
        cletter ++;
        if (cword[cletter] == CHR_EMPTY) cletter ++;
        if (cletter >= nletters) {        /* Next level..  */ 
          #if FULL_VERSION                /* Add player anmation */
            for (z=0; z<40; z++) {
	      game_sound (2);
              TDL_ScreenSetXY (playx, playy, ((z & 1) ? CHR_PLAYER : CHR_PLAYER2), COL_PLAYER); 
            }
          #else 
            TDL_Sleep (1000);
          #endif
          game_NewLevel ();
        }
      } 
      score_update ();
    }
    TDL_ScreenSetXY (playx, playy, CHR_PLAYER, COL_PLAYER); 
    //score_update ();
}

void game_die ()
{
    BYTE x;
    for (x = 0; x < 50; x ++) {
      TDL_ScreenSetXY (playx, playy, (x&1)? CHR_EMPTY : CHR_PLAYER, TDL_COL_RED); 
      game_sound (2);
    }
    //TDL_Sleep (2000);
 }

  /* Main game loop */
void game_Loop ()
{
    while (1) {
      game_Help ();        /* Display title screen & help */
      game_New ();        /* Start a new game */
      do {
        player_Move ();
      } while (gameOver == FALSE);
      game_die ();
      if (score > hiscore) hiscore = score;
    }
}


        /* Main program */
int main ()
{
    TDL_Initialise (0,NULL);
    #if (TDL_UDG_MAX > 0)        /* Are UDG gfx available? If so, set up.. */
      TDL_UDG_Init (pPix, TDL_UDG_START, sizeof (pPix));
    #endif
    TDL_SoundInit ();
    game_Loop ();        /* Main game loop */
    return 0;
}
