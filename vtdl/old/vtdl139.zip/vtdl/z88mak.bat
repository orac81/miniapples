rem z88mak.bat  Run z88init.bat first. ie: z88mak hello
zcc +zx -o %1-spectrum -lndos -create-app %1.c  %2 %3 %4 %5
zcc +zx81 -o %1-zx81.p -lndos -create-app %1.c  %2 %3 %4 %5 
zcc +zx80 -o %1-zx80.o -lndos -create-app %1.c  %2 %3 %4 %5
zcc +cpm  -o %1.com    -lndos -create-app %1.c  %2 %3 %4 %5
