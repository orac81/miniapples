/* Assort tests for VTDL */

#define TDL_IO_DIRECT 1		/* Use direct screen poke for print */
// #define TDL_IO_SYS 1		/* Use OS/Kernal calls for print */

#ifdef TDL_PATH		/* User sets TDL_PATH */
 #include TDL_PATH
#else
 #include "../tdl/tdl.c"
#endif

UINT ctime = 0;
UINT cframe = 0;
BYTE lastkey = 0;

	/* Main program */
int main ()
{
	BYTE key;
    TDL_Initialise (0,NULL);
    do {
      TDL_FrameSync ();	/* Sync animation to frame rate */
      cframe ++;
      ctime = TDL_Clock () / TDL_CLOCKS_PER_SEC;
      TDL_GotoXY (1,1);
      TDL_PrintSI ((char *) "TIME:", ctime );
      TDL_PrintSI ((char *) " \nFRAME:",cframe);
      if (ctime) {
        TDL_PrintSI ((char *) " \nFPS:",cframe/ctime);
      }
      TDL_PrintSI ((char *) " \nJOY1:", TDL_GetJoystick (0) );
      TDL_PrintSI ((char *) " \nJOY2:", TDL_GetJoystick (1) );
      TDL_PrintSI ((char *) " \nKEYDOWN:", (UINT) TDL_GetKeyDown ());
      TDL_PrintSI ((char *) " \nSHIFT:", TDL_GetKey_Shift ());
      key = TDL_GetKey ();
      if (key) lastkey = key;
      TDL_PrintSI ((char *) " \nLASTKEY:", lastkey);
      TDL_PrintStr ((char *) "  ");
    } while (TDL_GetKey () != 'Q');
    return 0;
}
