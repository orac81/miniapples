#!/bin/sh
# ie: ./bkups.sh skattabugz119
mkdir $1
cp *.sh $1
cp *.bat $1
mkdir $1/skattabugz
cp skattabugz/*.c $1/skattabugz
cp skattabugz/*.prg $1
cp skattabugz/*.tap $1
mkdir $1/demo
cp demo/*.c $1/demo
cp demo/*.prg $1/demo
cp demo/*.tap $1/demo
mkdir $1/tdl
cp tdl/* $1/tdl
mkdir $1/util
cp util/bmp2c.c $1/util
cp util/sk*.bmp $1/util
7za a zip/$1.zip $1/*
