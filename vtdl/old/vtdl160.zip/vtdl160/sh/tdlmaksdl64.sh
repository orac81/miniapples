# Build an TDL program for SDL2, ie: ./sdlmak progname -Os [options..]
#!/bin/sh
echo "Building $1-sdl64.elf .."
gcc -D TDL_SDL2 -o $1-sdl64.elf $1.c $2 $3 $4 $5 $6 $7 $8 $9`sdl2-config --cflags --libs`
