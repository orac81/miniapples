#!/bin/sh
# tdlmakosc.sh  - Build TDL app with OSCAR64
#  Syntax  ./tdlmakosc.sh progname [parms]   
#  ie: ./tdlmakosc.sh skattabugz/skattabugz -O2 -g
#  Note   -g add asm source
echo "Building Atari..      ($1.c)"
oscar64 -D TDL_ATARI -D IS_OSCAR=1 -tm=atari $2 $3 $4 $5 $1.c -o=$1-atari.prg
oscar64 -D TDL_ATARI -D IS_OSCAR=1 -D TDL_MONO -tm=atari $2 $3 $4 $5 $1.c -o=$1-atarimono.prg
