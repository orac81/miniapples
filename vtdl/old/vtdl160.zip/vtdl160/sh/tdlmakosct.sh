./tdlmakosc.sh $1/$1 $2 $3 $4 $5 $6
./tidy.sh $1
