#!/bin/sh
#  Build TDL SDL2 demo programs..
./tdlmaksdl64.sh skattabugz/skattabugz -Os -D TDL_VDUX=24 -D TDL_VDUY=14   
mv skattabugz/skattabugz-sdl64.elf skattabugz/skattabugz-big-sdl64.elf
./tdlmaksdl64.sh skattabugz/skattabugz -Os 
./tdlmaksdl64.sh addix/addix     -Os 
./tdlmaksdl64.sh dynajim/dynajim -Os 
./tdlmaksdl64.sh wallrun/wallrun     -Os 
./tdlmaksdl64.sh owarix/owarix   -Os 
./tdlmaksdl64.sh rockbal/rockbal -Os 
./tdlmaksdl64.sh demo/tplasma    -Os -D TDL_VDUX=128 -D TDL_VDUY=64
mv demo/tplasma-sdl64.elf demo/tplasma-128x64-sdl64.elf
./tdlmaksdl64.sh demo/tplasma    -Os
./tdlmaksdl64.sh demo/hello      -Os 
./tdlmaksdl64.sh demo/test-udg   -Os 
./tdlmaksdl64.sh demo/tsound     -Os 
# ./tdlmaksdl64.sh demo/radial3d     -Os 
# ./tdlmaksdl64.sh demo/tlife1d     -Os 
# ./tdlmaksdl64.sh demo/hisimple     -Os 
mv demo/*.elf demo/bin
