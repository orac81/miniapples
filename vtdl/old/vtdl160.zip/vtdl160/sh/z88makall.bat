rem Use: z88makall [msvc1.52 folder]
rem
start /wait /b cmd /c  z88tdl  wallrun\wallrun            
start /wait /b cmd /c  z88tdl  skattabugz\skattabugz  
start /wait /b cmd /c  z88tdl  addix\addix            
start /wait /b cmd /c  z88tdl  dynajim\dynajim 
start /wait /b cmd /c  z88tdl  owarix\owarix            
start /wait /b cmd /c  z88tdl  rockbal\rockbal            
start /wait /b cmd /c  z88tdl  demo\tplasma    
start /wait /b cmd /c  z88tdl  demo\hello      
start /wait /b cmd /c  z88tdl  demo\test-udg   
start /wait /b cmd /c  z88tdl  demo\tsound     
start /wait /b cmd /c  z88tdl  demo\tlife1d
start /wait /b cmd /c  z88tdl  demo\radial3d
start /wait /b cmd /c  z88tdl  demo\hisimple
del demo\bin\*.tap
move /y demo\*.tap demo\bin 
rem try "start /wait" or "call" above..
