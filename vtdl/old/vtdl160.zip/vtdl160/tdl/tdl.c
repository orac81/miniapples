/* TDL 2.xx - Very Tiny Development Layer for portable small apps.
  (C) A.Millett 2012-2026. Released as open software under GNU LGPL license.

  (See "tdl_cbm.c" and "tdl_zx.c" for platform dep code.
  (See TDL1.0 version for early notes, then Skattabugz/Dynajim )
  Add C16 and PET code. 
-> vtdl125, 5.4.2026
  Imp more Sound details. 
  Imp TDL_HAS_PETSCII .
-> vtdl126, 7.4.2026
  Imp TDL_DOS (asc ver)
-> vtdl127, 12.4.2026
  Imp TDL_DOS, builds Dynajim.
-> vtdl128, 12.4.2026
  Imp more of DOS version..
-> vtdl129, 14.4.2026
  ZX Spec joystick.
-> vtdl130, 20.4.2026
  Imp DOS Get_KeyDown() 
-> vtdl131, 21.4.2026
  Imp TDL_ScreenSetXY.
  Write tplasma, use for benchmarks.
-> vtdl132, 22.4.2026
  Imp TDL_ScreenSet2, TDL_ScreenSetXY2.
-> vtdl133, 23.4.2026
  Imp TDL_DrawPoint (x,y,c)
-> vtdl134, 23.4.2026
  Imp TDL_ScreenMode()
  Imp TDL_Finish()
-> vtdl135, 23.4.2026
  Convert/improve ADDIX114
-> vtdl137, 29.4.2026
  Test builds +4 etc.
-> vtdl138, 30.4.2026
  Configure release zips
-> vtdl139, 30.4.2026  (release)
  Work porting TDL_SDL2, running txt mode plasma..
-> vtdl140, 2.5.2026
  SDL Colour & timers
-> vtdl141, 3.5.2026
  SDL UDGs
-> vtdl142, 3.5.2026
  Imp GetKey.
  Imp rescale win.
  Imp TDL_RequestQuit
-> vtdl143, 5.5.2026
-> vtdl144, 6.5.2026
  WallRun111
-> vtdl145, 7.5.2026
-> vtdl146, 8.5.2026
-> vtdl147, 9.5.2026
   add TDL_SetLeftMargin (x)
-> vtdl148, 10.5.2026
-> vtdl149, 11.5.2026
-> vtdl150, 12.5.2026
-> vtdl151, 15.5.2026
  Starting sigmawing
-> vtdl152, 21.5.2026
-> vtdl153, 22.5.2026
  Dev RockBalloons, small changes to VTDL
-> vtdl154, 18.6.2026
  Dev Owarix, Sigma, Swarm, Vtchess
  Odd bugs fixed.
-> vtdl155, 16.7.2026
  Add Atari 8 bit. if TDL_MONO use GR0/40column, else GR1/20column/5 color.
  Skattabugz  builds, with limits
-> vtdl156, 16.7.2026
  Atari400 builds..
-> vtdl157, 22.7.2026
  Add TDL_ENABLE_TEXT/UDG
-> vtdl158, 28.7.2026
-> vtdl159, 3.8.2026
  
*/

#define TDL_VERSION 159

#include "tdl.h"

#ifndef TDL_PRINT_ORG	/* Default origin for print, TDL_GotoXY */
  #define TDL_PRINT_ORG 1
#endif

/*-----------------------------------------------------------------------
   Select target machine include file
-------------------------------------------------------------------------*/
  
#ifdef TDL_CBM
  #include "tdl_cbm.c"
#endif

#ifdef TDL_ATARI
  #include "tdl_atari.c"
#endif

#ifdef TDL_ZX
  #include "tdl_zx.c"
#endif

#ifdef TDL_DOS
  #include "tdl_dos.c"
#endif

#ifdef TDL_SDL2
  #include "tdl_sdl2.c"
#endif


/*-----------------------------------------------------------------------
   Common generic code for all machines.
-------------------------------------------------------------------------*/

#ifndef TDL_Settings	// If not defined, define as a null function
  #define TDL_Settings(MODE,FLAG,PAR) ;
  #define TDL_ENABLE_TEXT    ;
  #define TDL_ENABLE_UDG     ;
#else
  #define TDL_ENABLE_TEXT    TDL_Settings (0, TDL_SFLAG_ASC, NULL); 	/* Request text */
  #define TDL_ENABLE_UDG     TDL_Settings (0, TDL_SFLAG_UDG, NULL); 	/* Request UDG */
#endif


  /* void TDL_PrintStr (char *pStr) - Print a null-term string */
void TDL_PrintStr (const char *pStr)	
{
	char ch;
	while (ch = *pStr) {
	  TDL_PrintChar ( ch);
	  if (ch == 10 && TDL_ADD_CR) TDL_PrintChar (13);
	  ++ pStr;
	}
}

  /* Print int using no division/recursion */

UINT TDL_decimal[]={10000,1000,100,10,1};

void TDL_PrintInt (UINT x)		
{
    BYTE digit, n;
    BYTE pr = 0;
    UINT sub;
    for (digit=0; digit<5; digit++) {
      sub = TDL_decimal[digit];
      n=0;
      while (x>= sub) {
        x=x-sub; n++;
      }
      if (n || digit==4) pr = 1;	/* kill leading zeros */
      if (pr) TDL_PrintChar (48+n);
    }
}

void TDL_PrintSignedInt (int x)		
{
    if (x < 0) {
      TDL_PrintChar ('-');
      x = -x;
    }
    TDL_PrintInt (x);
}

  /* void TDL_PrintSI (char *pStr) - Print a string, then int */
void TDL_PrintSI (const char *istr, int iint)
{
	TDL_PrintStr (istr);
	TDL_PrintInt (iint);
}


  /* UINT TDL_Rand () - Simple 16 bit rnd gen */
UINT TDL_rndseed = 0;
UINT TDL_Rand ()
{
    TDL_rndseed = (UINT) (4737 * TDL_rndseed) + 1231;
    return (TDL_rndseed >> 8) ^ TDL_rndseed;
}
