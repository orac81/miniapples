/* TDL 2.xx - Very Tiny Development Layer for portable small apps.
  (C) A.Millett 2012-2026. Released as open software under GNU LGPL license.
  TDL Library released under (less restrictive) LGPL license.

*/

#pragma region( main, 0x2080, 0x9000, , , {code, data, bss, heap, stack} )
#pragma stacksize (256)		/* Keep stack/heap small */
#pragma heapsize (0)

#include <stdio.h>
#include <stdlib.h>

/*========================================================================
   Common Atari defines, vars, fwd declarations
==========================================================================*/

#define TDL_FAST __zeropage		/* Fast (zeropage,register etc) variable definition */

#define TDL_VDU_STATIC TRUE	 /* VDU size/colour parameters are static/limited */
#define TDL_HAS_UDG  TRUE	/* Tell user program UDGs are available */

#define TDL_POKE(AD,BY) *((BYTE *) ((UINT) (AD)))=(BYTE) (BY);
#define TDL_PEEK(AD) ((BYTE) *((BYTE *) ((UINT) (AD))))
#define TDL_DOKE(AD,VAR) *((UINT *) ((UINT) (AD)))=(UINT) (VAR);
#define TDL_DEEK(AD) ( *((UINT *) ((UINT) (AD))))

#define TDL_ADD_CR  FALSE		/* Add CR if LF sent (TDL_PrintSring) */

#define TDL_SHIFT_LR   1	/* Left/right shift */
#define TDL_SHIFT_CTRL 0

#define TDL_RequestQuit  FALSE		/* Not used on this platform */

void TDL_PrintChar (BYTE ch);		/* Fwd declare */
void TDL_ScreenClr ();
void TDL_GotoXY (BYTE x, BYTE y);
void TDL_Ink (BYTE ink);
BYTE TDL_GetKey ();
UINT TDL_Clock ();
#define TDL_CLOCKS_PER_SEC 60

BYTE TDL_border;
BYTE TDL_screen;

BYTE TDL_cursorx ;	/* Current cursor pos */
BYTE TDL_cursory ;
BYTE TDL_ink ;		/* Current col */
BYTE TDL_LeftMargin= 0;	/* Left Margin */

BYTE TDL_temp;

		/* Some GetKey values */
#define TDL_KEY_ESC     3
#define TDL_KEY_LEFT    157
#define TDL_KEY_RIGHT   29
#define TDL_KEY_UP      145
#define TDL_KEY_DOWN    17
#define TDL_KEY_ENTER   13

/*========================================================================
   Atari Specific Code
==========================================================================*/

#define TDL_RAM 64		/* Amount of RAM (approx) for platform */

#define TDL_HAS_PETSCII FALSE 	/* Tell program PETSCII is available (if UDGs not used) */

#ifdef TDL_REQ_TEXT
 #define TDL_UDG_MAX 0			/* Text/Petscii only, no UDG chars */
#else
 #define TDL_UDG_MAX 32		/* #UDG chars */
#endif

#ifdef TDL_MONO
 #define TDL_VDUX 40
 #define TDL_VDUY 24
 #define TDL_UDG_START   64		/* Start of UDG chars */
#else
 #define TDL_VDUX 20
 #define TDL_VDUY 26
 #define TDL_UDG_START   32		/* Start of UDG chars */
#endif

#define TDL_CHR_ASC32   0		/* Poke-code Ascii 32-63*/
#define TDL_CHR_ASC64   32		/* Ascii 64-95 */
#define TDL_CHR_ASC96   32		/* Ascii 96-127 */
#define TDL_ASC2CHR(C) (((C)-32) & 63)		/* Convert ascii to chr code */

//#define TDL_ATARI_CHRSET   0x9C00	// Hires RAM Char set location

#define TDL_ATARI_ROMSET   0xE000	// Hires Char set location
#define TDL_ATARI_JIFFY    0x12		// Atari Jiffy clock 3 byte (hi to lo)

/*-----------------------------------------------------------------------
   ATARI OS/DEF
-------------------------------------------------------------------------*/

#define ATARI_VDU      88	// Screen top
#define ATARI_RAMTOP   106	// Hi of ram top
#define ATARI_MEMTOP   741	// Ptr memtop 
#define ATARI_DISPLIST 560	// Display list
#define ATARI_CHBAS    756	// Char set base, shadow D409
#define ATARI_ROMSET   0xE000
#define ATARI_KEYSCAN  0x02FC   // (764) Key raw scan code. (255=none)
//#define ATARI_KEYSCAN  0xD209   // (53769) Key raw scan code. (255=none)
#define ATARI_SKCTL    0xD20F   // Bit2 set if last key still down, bit3=shift
#define ATARI_NOCLIK   0x02DB   // Set to disable click.
#define ATARI_KEYDEL   0x02F1   // (753) Key delay flag (0-3), detect if key down
#define ATARI_STICK0   0x0278   // (632) Joystick 0 (0-15)
#define ATARI_STRIG0   0x0284   // (644) Joystick 0 trigger, 0=pressed.

#define ATARI_AUDCTL  0xD208	// Audio control
//#define ATARI_SKCTL  0xD20F
#define ATARI_AUDF1  0xD200		// AUDF2=D202, .. AUDF4=D206
#define ATARI_AUDC1  0xD201


#define ATARI_CIOV   $E456
#define ATARI_ICHID  $0340
#define ATARI_ICDNO  $0341
#define ATARI_ICCOM  $0342
#define ATARI_ICSTA  $0343
#define ATARI_ICBAL  $0344
#define ATARI_ICBAH  $0345
#define ATARI_ICPTL  $0346
#define ATARI_ICPTH  $0347
#define ATARI_ICBLL  $0348
#define ATARI_ICBLH  $0349
#define ATARI_ICAX1  $034A
#define ATARI_ICAX2  $034B

#define ATARI_COLOR0    0x02C4
#define ATARI_COLCRS    0x55
#define ATARI_ROWCRS    0x54
#define ATARI_ATACHR    0x02FB
#define ATARI_STORE1    0xCC
#define ATARI_STOCOL    0xCD

char atari_scr[] = "S:";

  /* Set Atari Graphics mode using OS */
void atari_Graphics (BYTE mode)
{
    __asm {
      ldx # $60			// use IOCB6 
      lda # $0c			// Close old
      sta ATARI_ICCOM,x
      jsr ATARI_CIOV

      ldx # $60
      lda # $03			// open
      sta ATARI_ICCOM,x
      lda # < atari_scr 	// Address "S:" string
      sta ATARI_ICBAL,x
      lda # > atari_scr 
      sta ATARI_ICBAH,x
      lda mode
      sta ATARI_ICAX2,x
      and #$f0
      eor #$10
      ora #$0c
      sta ATARI_ICAX1,x
      jsr ATARI_CIOV
    }
}


/* atari_SetColor
HUE: grey,gold,gold−orange,red−orange,orange,magenta,purple−blue,blue
blue,cyan,blue−green,blue−green,green,yellow−green,yellow,yellow−red */

void atari_SetColor (BYTE col, BYTE hue, BYTE lum)
{
    TDL_POKE (ATARI_COLOR0+col, (hue << 4) | lum);
}

void atari_Color (BYTE col)
{
    TDL_POKE (ATARI_STOCOL,col);
}

void atari_Position (UINT x, BYTE y)
{
    TDL_DOKE (ATARI_COLCRS, x);
    TDL_POKE (ATARI_ROWCRS, y);
}

void atari_Plot (UINT x, BYTE y)
{
    atari_Position (x,y);
    __asm {
      ldx # $60			// use IOCB6 
      lda # $0b		
      sta ATARI_ICCOM,x
      lda #0
      sta ATARI_ICBLL,x
      sta ATARI_ICBLH,x
      lda ATARI_STOCOL
      jsr ATARI_CIOV
    }
}

void atari_DrawTo (UINT x, BYTE y)
{
    atari_Position (x,y);
    __asm {
      lda ATARI_STOCOL
      sta ATARI_ATACHR
      ldx # $60			// use IOCB6 
      lda # $11		
      sta ATARI_ICCOM,x
      lda #$0c
      sta ATARI_ICAX1,x
      lda #0
      sta ATARI_ICAX2,x
      jsr ATARI_CIOV
    }
}

/*-----------------------------------------------------------------------
   ATARI SCREEN/DRAWING
-------------------------------------------------------------------------*/

  /*. TDL_ScreenPos(X,Y) - Calc Screen char position from X,Y (0 to max-1) */
#define TDL_ScreenPos(X,Y) ((X)+(Y)*TDL_VDUX)

#ifdef TDL_MONO
   /*. TDL_ScreenSet(POS,BYT,COL) - Poke VDU pos with char & colour */
 #define TDL_ScreenSet(POS,BYT,COL)  {TDL_pScreen[POS] = (BYT); }
   /*. TDL_ScreenGet(POS) - Peek VDU pos, ret char */
 #define TDL_ScreenGet(POS) (TDL_pScreen[POS])			/* Get VDU char */
  /*. TDL_ScreenGetXY(X,Y) - Peek VDU pos, ret char */
 #define TDL_ScreenGetXY(X,Y) (TDL_pScreen[TDL_ScreenPos(X,Y)] )	


#else
   /*. TDL_ScreenSet(POS,BYT,COL) - Poke VDU pos with char & colour */
 #define TDL_ScreenSet(POS,BYT,COL)  {TDL_pScreen[POS] = ((BYT) & 63) | ((COL&3)<<6) ; }
   /*. TDL_ScreenGet(POS) - Peek VDU pos, ret char */
 #define TDL_ScreenGet(POS) (TDL_pScreen[POS] & 63)			/* Get VDU char */
  /*. TDL_ScreenGetXY(X,Y) - Peek VDU pos, ret char */
 #define TDL_ScreenGetXY(X,Y) (TDL_pScreen[TDL_ScreenPos(X,Y)] & 63)	

#endif

  /*. TDL_ScreenSetNC(POS,BYT) - Poke VDU pos with char (No colour) */
#define TDL_ScreenSetNC(POS,BYT)  TDL_pScreen[POS] = BYT;

BYTE *TDL_pScreen = NULL;	/* Ptr to screen */

  /* Native Colour codes */
#define TDL_COL_BLACK   0
#define TDL_COL_RED     0	/* 1:Bit 0 */
#define TDL_COL_GREEN   1	/* 2:Bit 1 */
#define TDL_COL_YELLOW  2
#define TDL_COL_BLUE    1	/* 4:Bit 2 */
#define TDL_COL_PURPLE  0
#define TDL_COL_CYAN    1
#define TDL_COL_WHITE   3

  /* System-Native Colours (poke codes), in RGB order, (0-7) */
BYTE TDL_RGBI2COL[]={0,2,5,7,6,4,3,1, 11,10,13,7,14,4,3,1};   /* Colour Conversion Table for ScreenSet */

#define TDL_RGBItoCol(RGBI) TDL_RGBI2COL[RGBI]

BYTE TDL_COL2INK[] = {144,5,28,159,156,30,31,158};	// Convert Atari poke to ink print codes.

void TDL_ScreenClr ()
{
    UINT p;
    for (p = TDL_ScreenPos(0,0); p < TDL_ScreenPos(TDL_VDUX-1, TDL_VDUY-1); p++) {
      TDL_ScreenSetNC (p, TDL_CHR_ASC32);
    }
    TDL_GotoXY (1,1);
    TDL_Ink (TDL_COL_WHITE);
}

/*-----------------------------------------------------------------------
   ATARI KEYBOARD
-------------------------------------------------------------------------*/

#define TDL_SCANCODE_NONE 0
 
BYTE TDL__Keycode[64] = {	// Scancode to ASC translation table
  0x4C,0x4A,0x3B,0x8A,0x8B,0x4B,0x2B,0x2A,0x4F,0x80,0x50,0x55,0x0D,0x49,0x2D,0x3D, 	// 00-0F: L,J,;,F1,F2,K,+,*,O,NONE,P,U,RET,I,-,=
  0x56,0x80,0x43,0x8C,0x8D,0x42,0x58,0x5A,0x34,0x80,0x33,0x36,0x1B,0x35,0x32,0x31,	// 10-1F: V,NONE,C,F3,F4,B,X,Z,4,NONE,3,6,ESC,5,2,1
  0x2C,0x20,0x2E,0x4E,0x80,0x4D,0x2F,0x81,0x52,0x80,0x45,0x59,0x7F,0x54,0x57,0x51, 	// 20-2F: COMMA,SPC,.,N,NONE,M,/,INV,R,NONE,E,Y,TAB,T,W,Q 
  0x39,0x80,0x30,0x37,0x7E,0x38,0x3C,0x3E,0x46,0x48,0x44,0x80,0x82,0x47,0x53,0x41};	// 30-3F: 9,NONE,0,7,DEL,8,<,>,F,H,D,NONE,CAP,G,S,A

BYTE TDL__key = 0;
BYTE TDL__useKD = 0;

  /*. BYTE TDL_GetKeyDown ()  -  Get ASC key held down, 0=none */
BYTE TDL_GetKeyDown ()
{
    //BYTE k; k = TDL_GetKey (); if (k) TDL__key = k;
    if (TDL_PEEK (ATARI_KEYDEL) == 0) return 0;
    // if ( (TDL_PEEK(ATARI_SKCTL) & 4) ) return 0;
    TDL__key = TDL__Keycode [TDL_PEEK (ATARI_KEYSCAN) & 0x3F];
    TDL__useKD = 1;
    return TDL__key;
}

  /*. BYTE TDL_GetKey_Shift () - Return shift status */
BYTE TDL_GetKey_Shift ()
{
    return ((TDL_PEEK (ATARI_SKCTL) & 8) == 0);
}

  // Low level sub to get char from keybd in (A)
void io_getch2 ()
{
  __asm {
      lda 0xe425		// Look up OS table for keyboard sub
      pha 
      lda 0xe424
      pha
      rts
    }
}

  /*. BYTE TDL_GetKey () - get char from keyboard */
BYTE TDL_GetKey ()
{
    if (TDL__useKD) {		// Clr KeyScan var
      TDL_POKE (ATARI_KEYSCAN,255); TDL__useKD = 0;
    }
    if (TDL_PEEK (ATARI_KEYSCAN) == 255) return 0;
    return __asm {
      jsr io_getch2	// Return key in Acc
      cmp # 0x9B
      bne gkey1
      lda # 0x0D
gkey1:
      sta accu
    };
}


/*-----------------------------------------------------------------------
   ATARI JOYSTICK
-------------------------------------------------------------------------*/

  /* BYTE TDL_GetJoystick (BYTE joy)  -  Get joystick status */
#define TDL_MAX_JOYSTICK 2

  /* Test bits for joystick direction/fire */
#define TDL_JOYSTICK_UP		1
#define TDL_JOYSTICK_DOWN	2
#define TDL_JOYSTICK_LEFT	4
#define TDL_JOYSTICK_RIGHT	8
#define TDL_JOYSTICK_FIRE	16
#define TDL_JOYSTICK_HIT        31

BYTE TDL__Joy[16] = {0,0,0,0,0,10,9,8,0,6,5,4,0,2,1,0};

BYTE TDL_GetJoystick (BYTE joy)
{
    BYTE r;
    r = TDL__Joy [TDL_PEEK (ATARI_STICK0+joy) & 15];
    if (TDL_PEEK (ATARI_STRIG0+joy) == 0) r |= TDL_JOYSTICK_FIRE;
    return r;
}

/*-----------------------------------------------------------------------
   ATARI TIMING
-------------------------------------------------------------------------*/

void TDL_FrameSync ()
{
     __asm {
       lda TDL_ATARI_JIFFY+2
frame:
       cmp TDL_ATARI_JIFFY+2
       beq frame
     }
}

  /*. void TDL_Sleep (int tim)  - Sleep (tim) milliseconds */
void TDL_Sleep (int tim) 
{
      do {
        TDL_FrameSync ();
	tim = tim - 17;		// Approx 1/60 sec (avoids divide)
      } while (tim > 0);
}

  /* Get 16bit clock in jiffies, see TDL_CLOCKS_PER_SEC */
UINT TDL_Clock ()
{
      __asm {
	lda TDL_ATARI_JIFFY+2
        sta accu
	lda TDL_ATARI_JIFFY+1
        sta accu+1
      };
}

/*-----------------------------------------------------------------------
   ATARI SOUND
-------------------------------------------------------------------------*/


#define TDL_SOUND_TYPE BYTE

#define TDL_SOUND_NVOICE 4	// No of voices
  // Convert Freq (in hertz) to Tone val. (FHz * 16.5)
#define TDL_SOUND_FREQ2TONE(FHz) (0)

#define TDL_SOUND_LO  0
#define TDL_SOUND_HI  255
#define TDL_SOUND_STEP  1	// Simple scaling step for fx

#define TDL_SOUND_C4  100	// C4  261.63Hz  (Middle C) 
#define TDL_SOUND_A4  150	// A4, 440Hz
#define TDL_SOUND_C5  200	// C5, 523.26Hz
#define TDL_SOUND_A5  250	// A5, 880Hz
#define ATARI_AUDF1  0xD200		// AUDF2=D202, .. AUDF4=D206
#define ATARI_AUDC1  0xD201


  /* Simple sound tone generator (voice 0-n) */
void TDL_Sound (BYTE val, BYTE voice)
{
    TDL_POKE (ATARI_AUDC1+voice+voice, 0xAF);		// vol 15, Wave 10
    TDL_POKE (ATARI_AUDF1+voice+voice, val ^ 0xFF);
}

void TDL_SoundOff (BYTE voice)
{
    TDL_POKE (ATARI_AUDC1+voice+voice, 0);
}

void TDL_SoundInit ()
{
    TDL_POKE (ATARI_AUDCTL,0);		// Same as: SOUND 0,0,0,0
    TDL_POKE (ATARI_SKCTL,3);
}

/*-----------------------------------------------------------------------
   ATARI INITIALISATION & MISC
-------------------------------------------------------------------------*/

#ifndef TDL_REQ_TEXT	// Allow hires gfx

BYTE *TDL__pPix;
UINT TDL__chstart, TDL__psize;
UINT TDL__ChrSet = 0;

  /* Set up the UDG chr set mode. */
void TDL_UDG_Init (BYTE *pPix, UINT chstart, UINT psize)
{
    UINT p;
    BYTE *pDest = (BYTE *) TDL__ChrSet;
    TDL__pPix = pPix; TDL__chstart = chstart; TDL__psize = psize;

    chstart *= 8;
	// Copy char set data 
    for (p= 0; p< psize; p++) {
      pDest [chstart+p]= pPix [p];
    } 
    TDL_ScreenClr ();
}
#endif

  /*. void TDL_ScreenBackground (BYTE screen, BYTE border) - Set background */
void TDL_ScreenBackground (BYTE screen, BYTE border)
{
}

  /* Request a screen resolution, sets nearest available. 
	Actual resolution in TDL_VDU_HIX, TDL_VDU_HIY, TDL_VDU_HICOL. */
BYTE TDL_ScreenMode (UINT sx, UINT sy, BYTE coldepth, BYTE flags)
{
    return 0;   /* Just use static 320x200x8 mode for now */
}

#define TDL_SMODE_DEFAULT 0
#define TDL_SFLAG_ASC     1		/* Need ASC */
#define TDL_SFLAG_UDG     2		/* Need UDG */

#ifdef TDL_MONO
 #define TDL_Settings(MODE,FLAG,PAR) ;
#else
  /*. TDL_Settings (BYTE mode, BYTE flag, void *pParam) - set TDL control params */
 #define TDL_Settings(MODE,FLAG,PAR) TDL_AtariSettings (MODE, FLAG, PAR);
#endif

void TDL_AtariSettings (BYTE mode, BYTE flag, void *pParam)
{
    UINT z;
    if (flag == TDL_SFLAG_ASC) {	// Copy ROM chrset to RAM
      TDL_POKE (ATARI_CHBAS, ATARI_ROMSET/256);		// Set UDG ptr to ROM/ASC
    }
    if (flag == TDL_SFLAG_UDG) {	// Copy UDG chrset to RAM
      if (TDL__ChrSet == 0) return ;
      TDL_POKE (ATARI_CHBAS, TDL__ChrSet /256);		// Set UDG ptr to ram
      // TDL_UDG_Init (TDL__pPix, TDL__chstart, TDL__psize );
    }
    return ;
}


  /* Initialise TDL lib */
UINT TDL_Initialise (UINT mode, BYTE *pData)
{
    UINT display_list;
    UINT memtop,vdu,z;
    BYTE q;

    TDL__ChrSet = TDL_PEEK (ATARI_RAMTOP)-4;	// move down 1k for chrset
    TDL_POKE (ATARI_RAMTOP, TDL__ChrSet);
    TDL__ChrSet *= 256;
    #ifdef TDL_MONO		// Mono build option
      atari_Graphics (0);		// Init gfx mode 0 (40x24) to new pos
      atari_SetColor (1, 0, 12);		
      atari_SetColor (2, 0, 0);		
      //atari_SetColor (2, 13, 0);		
    #else
      atari_Graphics (1);	
      atari_SetColor (0, 5, 8);		// 0:Purple
      atari_SetColor (1, 9, 8);		// 1:Cyan
      atari_SetColor (2, 14, 12);	// 2:yellow
      atari_SetColor (3, 0, 15);	// 3:white
      atari_SetColor (4, 0, 0);		// 4:Black Background
    #endif
    TDL_pScreen = (BYTE *) ((UINT) TDL_DEEK (ATARI_VDU));
    display_list = TDL_DEEK (ATARI_DISPLIST);
    memtop = TDL_DEEK (ATARI_MEMTOP);
    TDL_POKE (ATARI_NOCLIK, 255);
    //TDL_POKE (0xD20F, 0); TDL_POKE (729, 255);

	// Copy ROM chrset to RAM
    for (z=0; z<1024; z++) {
      TDL_POKE (TDL__ChrSet + z, TDL_PEEK(ATARI_ROMSET + z));
    }
    //TDL_POKE (ramtop, 128);	// Add UDG dot to space 
    TDL_POKE (ATARI_CHBAS, TDL__ChrSet /256);	// Set UDG ptr to ram
    #ifndef TDL_MONO
      // Set 26 char 5 colour lines in Display List
      for (q=6; q<31; q++) {
        TDL_POKE (display_list+q,6);
      }
    #endif
    return 0;
}

/*========================================================================
   Common code 
==========================================================================*/


  /* void TDL_Finish () - Quit TDL */
void TDL_Finish ()
{
}

  /* Update Display (for service-loop targets) */
void TDL_UpdateDisplay ()
{
}

  /*. TDL_ScreenSetXY (BYTE x, BYTE y,BYTE ch, BYTE col) - Poke VDU pos with char & colour */
void TDL_ScreenSetXY (BYTE x, BYTE y, BYTE ch, BYTE col) 
{
    UINT pos;
    pos = TDL_ScreenPos(x,y);
    TDL_ScreenSet (pos, ch, col);
}

  /*. TDL_ScreenSetXY2 (BYTE x, BYTE y, BYTE char1, BYTE char2, BYTE col) - Poke VDU pos with 2 chars & colour */
void TDL_ScreenSetXY2 (BYTE x, BYTE y, BYTE char1, BYTE char2, BYTE col) 
{
    UINT pos;
    pos = TDL_ScreenPos(x,y);
    TDL_ScreenSet (pos, char1, col);
    pos ++;
    TDL_ScreenSet (pos, char2, col);
}

  /*. void TDL_ScreenSet2 (UINT pos, BYTE char1, BYTE char2, BYTE col) - Poke VDU pos with 2 chars & colour */
void TDL_ScreenSet2 (UINT pos, BYTE char1, BYTE char2, BYTE col)  
{
    TDL_ScreenSet (pos, char1, col);
    pos ++;
    TDL_ScreenSet (pos, char2, col);
}

#ifdef TDL_IO_SYS	/* Use System IO calls */

  /*. void TDL_PrintChar (BYTE ch) - Print ASC char  */
void TDL_PrintChar (BYTE ch)
{
    putchar ();
}

  /*. void TDL_Ink (BYTE ink) - Set print ink */
void TDL_Ink (BYTE ink)
{
}

   /* Set cursor pos (generic CBM) */
void TDL_GotoXY (BYTE x, BYTE y)
{
     TDL_POKE (85,x);
     TDL_POKE (84,y);
}

#endif


#ifdef TDL_IO_DIRECT	/* Print using direct screen access */

  /*. void TDL_PrintChar (BYTE ch) - Print ASC char (using direct drawing) */
void TDL_PrintChar (BYTE ch)
{
    UINT pos;
    if (ch < 32) {
      if (ch == 10) {		/* New line */
        TDL_cursorx = TDL_LeftMargin;
        if (TDL_cursory < TDL_VDUY) TDL_cursory ++;
      }
      return;
    }
    ch = TDL_TOUPPER (ch);
    pos = TDL_ScreenPos (TDL_cursorx, TDL_cursory);
    ch = TDL_ASC2CHR (ch);
    TDL_ScreenSet (pos, ch, TDL_ink);
    TDL_cursorx ++;
    if (TDL_cursorx >= TDL_VDUX) {
      TDL_cursorx = 0;
      if (TDL_cursory < TDL_VDUY) TDL_cursory ++;
    }
}

  /*. void TDL_Ink (BYTE ink) - Set print ink */
void TDL_Ink (BYTE ink)
{
     TDL_ink = ink;
}

   /*. void TDL_GotoXY (BYTE x, BYTE y) - Set cursor pos (1,1..X,Y) */
void TDL_GotoXY (BYTE x, BYTE y)
{
    TDL_cursorx = x-TDL_PRINT_ORG;
    TDL_cursory = y-TDL_PRINT_ORG;
}

  /*. TDL_SetLeftMargin (BYTE x)  - Set left margin for printing */
void TDL_SetLeftMargin (BYTE x)
{
    TDL_LeftMargin = x - TDL_PRINT_ORG;
}

#endif
