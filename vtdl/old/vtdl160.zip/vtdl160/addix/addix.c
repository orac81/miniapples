/* ADDIX.C  -  A simple strategy game. (C) A.Millett 1992-2014.

 Imp basics (io_.., newgame, makemove, etc)
 Simple working ver
-> ADDIX100, 3.2.2014
 
-> ADDIX101, 4.2.2014
 Imp AlphaBeta() full search.
 Imp iqlevel, etc..
-> ADDIX102, 3.3.2014
 Enable iq>9
-> ADDIX103, 3.3.2014
 Start Imp TDL lib, USE_C99, USE_TDL..
 Very simple TDL version..
-> ADDIX104, 8.3.2015
 Imp color, boxes, app_DrawCell()..
-> ADDIX105, 8.3.2015
 Imp Space/Ret make move. 
 Color hilite cursor, cur column/row..
-> ADDIX106, 8.3.2015
 Imp app_printside.. Display side, score, iq, sch pos/eval, nodes, etc.
 Imp better scaling, colors etc.
-> ADDIX107, 9.3.2015
 Imp isGameOver. 
-> ADDIX108, 10.3.2015
 Imp move time display. Imp long var for int2asc, nodes..
-> ADDIX109, 16.3.2015
-> ADDIX110, 20.3.2015
 Fix for OSCAR64
-> ADDIX111, 20.8.2025
 Convert from TDL 1.0 to VTDL 2.0.
-> ADDIX112, 26.4.2026
-> ADDIX113, 26.4.2026
 Convert from TDL 1.0 to VTDL 2.0..
 Imp many new things, Put text at top.
 Imp Help. 
 (ref 7x7,z,iq5=467nod)
-> ADDIX114, 28.4.2026
-> ADDIX115, 29.4.2026
 Small changes..
-> ADDIX116, 30.4.2026
 (BUILD use: ./tdlmakosc2.sh addix/addix )
-> ADDIX117, 30.4.2026
  Tweak for Atari400 build
-> ADDIX118, 26.7.2026

*/

#define PROG_NAME "** ADDIX 1.18 **"

#define TDL_IO_DIRECT 1		/* Use direct screen poke for print */

#ifdef TDL_PATH		/* User sets TDL_PATH */
 #include TDL_PATH
#else
 #include "../tdl/tdl.c"
#endif

#if (TDL_RAM < 8)		// Limited RAM (V20)
 #define FULL_VERSION FALSE
#else 
 #define FULL_VERSION TRUE
#endif

#define TEXT_AT_SIDE FALSE

#include <stdio.h>
#include <string.h>
#include <time.h>


void sch_callback (int , int , int);


/*-------------------------------------------------
   Engine code starts here..
---------------------------------------------------*/

#ifndef ENG_SIMPLE
 #define ENG_SIMPLE 0		/* Enable for simple 1 ply engine */
#endif

#define ENG_SORT  TRUE

#if (TDL_VDUX < 26)
  #if (TDL_VDUX < 21)
    #define BOARD_SIZE 6
    #define MAX_BOARD 6
  #else
    #define BOARD_SIZE 7
    #define MAX_BOARD 7
  #endif
  #define BMULT 8
#else 
  #define BOARD_SIZE 9
  #define MAX_BOARD 10
  #define BMULT 16
#endif

BYTE boardx = BOARD_SIZE;
BYTE boardy = BOARD_SIZE;


BYTE iqlevel = 5;	/* Level of play */
BYTE debugflag = 0;

BYTE cxpos = 0;	/* Current position */
BYTE cypos = 0;
BYTE cside = 0;		/* Current side to play 0=H, 1=V */

int scoreh,scorev;
UINT nodecount =0;
BYTE gameover = 0;
BYTE autoplay = 0;

#define VERT   1
#define HORIZ  0

#define NO_MOVE 0xff

#ifdef TDL_VIC20

 BYTE *board = (BYTE *) 828;	// Tape buffer

#else

 BYTE board [255];

#endif

#define SetBoard(x,y,a) board[(x) + ((y) * BMULT)] = a;
#define GetBoard(x,y) board[(x) + ((y) * BMULT)]

BYTE bestmove = 0;
int besteval = 0;

#if ENG_SIMPLE	

	/* Simple 1 ply engine, pick highest number */

int CompMove ()
{
    int xp,yp,v;
    bestmove = NO_MOVE; 
    besteval = -5000;
    xp = cxpos;
    yp = cypos;
    if (cside == VERT) {
      for (yp = 0; yp < boardy; yp++) {
        v = GetBoard (xp,yp);
	if (v && v > besteval) {
	  besteval = v;
	  bestmove = yp;
	}
      }
    } else {
      for (xp = 0; xp < boardx; xp++) {
        v = GetBoard (xp,yp);
	if (v && v > besteval) {
	  besteval = v;
	  bestmove = xp;
	}
      }
    }
    return bestmove;
}

#else

BYTE lastx,lasty;

int AlphaBeta (BYTE depth, int alpha, int beta, int upeval) 
{
    BYTE nmoves;
    BYTE cmove;
    BYTE sxpos,sypos;
    int seval;
    BYTE cval;

    #ifdef USE_C99    
      if (debugflag) {
        io_printsi ("\n#",depth);   
      }
    #endif
    sxpos = lastx; sypos = lasty;
    nmoves = 0;
    for (cmove = 0; cmove < boardx; cmove ++) {
      if (cside == VERT) {
        sypos = cmove;
      } else {
        sxpos = cmove;
      }
      cval = GetBoard (sxpos,sypos);
      if (cval) {
        nmoves ++;
	if (depth <= 1) {		/* Terminal node, eval.. */
	  seval = upeval + cval;	/* Use accumulated seval as score */
	  nodecount ++;
	} else {
	  SetBoard (sxpos,sypos,0);
          cside = !cside;
	  lastx = sxpos; lasty = sypos;
	  seval = -AlphaBeta (depth-1, -beta, -alpha, -(upeval + cval));
	  SetBoard (sxpos,sypos,cval);
          cside = !cside;
	}
        #ifdef USE_C99    
	  if (debugflag) {
	    io_printsi (".",sxpos+1);
	    io_printi (sypos+1);
	    io_printsi ("=",seval);
	    if (seval > alpha) io_printc ('*');
	  }
        #endif
		/* First ply.. */
	if (depth == iqlevel) {
	  if (seval > alpha) {
	    bestmove = cmove;
	  }
	  sch_callback (sxpos, sypos, seval);
	}
	if (seval > alpha) {
	  alpha = seval;
	}
	if (seval >= beta) {
	  return beta;
	}
      }
    }
    if (nmoves == 0) {	/* No moves left, game over. */
      nodecount ++;
      if (upeval > 0) upeval += 10000;		/* Add 10000 indicates winning/loosing score */
      if (upeval < 0) upeval -= 10000;
      return upeval;	
    }
    return alpha;
}

int CompMove ()
{
    int scoredif;
    nodecount = 0;
    lastx = cxpos;
    lasty = cypos;
    bestmove = NO_MOVE;
    scoredif = scoreh - scorev;
    if (cside == VERT) scoredif =- scoredif;
    besteval = AlphaBeta (iqlevel, -12000, 12000, scoredif);
    return bestmove;
}

/* 
int AlphaBeta(int depth, int alpha, int beta)
{
    if (depth == 0)
        return Evaluate();
    GenerateLegalMoves();
    while (MovesLeft()) {
        MakeNextMove();
        val = -AlphaBeta(depth - 1, -beta, -alpha);
        UnmakeMove();
        if (val >= beta)
            return beta;
        if (val > alpha)
            alpha = val;
    }
    return alpha;
}
*/

#endif

void NewGame ()
{
    BYTE xp,yp;
    UINT v;
    for (yp = 0; yp < boardy; yp++) {
      for (xp = 0; xp < boardx; xp++) {
        //v = (TDL_Rand() & 7) * (TDL_Rand() & 7) + (TDL_Rand() & 7) ;
        v = TDL_Rand() & 15;
        if (xp && yp && v > 12) v = (TDL_Rand() & 63);
        SetBoard (xp, yp, v);
      }
    }
    cside = HORIZ;
    cxpos = cypos = 0;		/* Set start pos */
    autoplay = gameover = 0;
    scorev = scoreh = besteval = nodecount = 0;
}

  /* Is game over? */
int isGameOver ()
{
    int mv;
    gameover = FALSE;
    if (cside == VERT) {
      for (mv = 0; mv < boardy; mv++) {
        if (GetBoard (cxpos, mv)) return FALSE;
      }
    } else {
      for (mv = 0; mv < boardx; mv++) {
        if (GetBoard (mv,cypos)) return FALSE;
      }
    }
    gameover = TRUE;
    return TRUE;
}

BYTE makemove (BYTE mv)
{
    BYTE val;
    if (cside == VERT) {
      cypos = mv;
    } else {
      cxpos = mv;
    }
    if ( cxpos >= boardx || cypos >= boardy) return 0;
    val = GetBoard (cxpos,cypos);
    if (val == 0) return 0;
    if (cside == VERT) {
      scorev += val;
    } else {
      scoreh += val;
    }
    SetBoard (cxpos,cypos,0);
    cside = !cside;
    return val;
}

/*-------------------------------------------------
   TDL: Front end starts here..
---------------------------------------------------*/

#ifdef CLOCKS_PER_SECOND
 #define USE_CLOCK 1		// Define this to show move time
#endif

#if (TDL_UDG_MAX > 0)	/* Are UDGs available? If so, set them up.. */

#define CHR_START (TDL_UDG_START)

BYTE pPix[] = {
  //  "vfall1.bmp" size 96 x 16, Bitdepth=1, #char: 12 x 2
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
  0x08,0x22,0x1c,0x5d,0x1c,0x22,0x08,0x00,
  0x7c,0xc6,0xde,0xc6,0xde,0xde,0x7c,0x00,
  0x00,0x36,0x7f,0x77,0x7f,0x36,0x1c,0x08,
  0x08,0x10,0x08,0x10,0x08,0x10,0x08,0x10,
  0x00,0x00,0x00,0xaa,0x55,0x00,0x00,0x00,
  //0x18,0x24,0x24,0x18,0x18,0x24,0x24,0x18,
  //0x00,0x00,0x66,0x99,0x99,0x66,0x00,0x00,
  0x3c,0x42,0x99,0xa5,0xa5,0x99,0x42,0x3c,

  //0x00,0x01,0x02,0xfc,0xfc,0xfc,0x00,0x00,  // chr:7
};

  /* Game char codes */
 #define CHR_SPC      CHR_START 
 #define CHR_CURSOR   CHR_START + 1
 #define CHR_NEGATE   CHR_START + 2
 #define CHR_TARGET   CHR_START + 3
 #define CHR_EDGEV    CHR_START + 4
 #define CHR_EDGEH    CHR_START + 5
 #define CHR_EDGE     CHR_START + 6

#else 	/* No UDGs.. */

	/* ASCII Game char codes */
  #define CHR_SPC      TDL_CHR_ASC32
  #define CHR_CURSOR   TDL_ASC2CHR('*')
  #define CHR_NEGATE   TDL_ASC2CHR('-')
  #define CHR_TARGET   TDL_ASC2CHR('$')
  #define CHR_EDGEV    TDL_ASC2CHR('!')
  #define CHR_EDGEH    TDL_ASC2CHR('-')
  #define CHR_EDGE     TDL_ASC2CHR('+')

#endif

#define COL_FRAME    TDL_COL_BLUE
#define COL_NUMBERS  TDL_COL_YELLOW
#define COL_NUMBERHI TDL_COL_WHITE

#define CELLX 3		/* Draw cell size*/
#define CELLY 2

#define DRAW_TOPX 0		/* Top of board */
#define DRAW_TOPY 4

//char szProgText [] = "Addix " PROG_VER " (C) A.Millett 1980-2026. Freeware.";

int timeStart=0, timeMove=0;
BYTE cmdkey;

BYTE txt_right;		/* Right hand text pos */

BYTE flag_twoplay = FALSE;
BYTE flag_frame = TRUE;

  /* Simple Side-print routines.. */

#if TEXT_AT_SIDE

char szVert[]  = " VERT ";
char szHoriz[] = " HOR ";

void app_SidePrintS (BYTE yline, const char *pTxt)
{
    TDL_GotoXY (txt_right, yline);
    TDL_PrintStr ((char *) pTxt);
}

  /* Print String & Int at side */

int app_SidePrintSI (BYTE yline, const char *pTxt, int val)
{
    TDL_GotoXY (txt_right, yline);
    TDL_PrintSI ((char *) pTxt, val);
}

char szTxtP[10] = "POS    ";
char szSpace[] = "       ";

void app_printpos (BYTE xpos, BYTE ypos, int eval, UINT nodes)
{
    szTxtP [4] = xpos+65; 
    ypos ++;
    szTxtP [5] = ypos+48;
    if (ypos>9) {
      szTxtP [5] = (ypos/10)+48;
      szTxtP [6] = (ypos%10)+48;
    }
    app_SidePrintS (12, szTxtP);
    if (nodes) {
      app_SidePrintS (14, (char *) "EVAL:");
      app_SidePrintS (15, szSpace);
      app_SidePrintS (15, (char *) "");
      TDL_PrintSignedInt (eval);
      app_SidePrintS (16, (char *) "NODES:");
      app_SidePrintS (17, szSpace);
      app_SidePrintSI (17, (char *) "", nodes);
      #ifdef USE_CLOCK
       app_SidePrintS (18, (char *) "TIME:");
       app_SidePrintS (19, szSpace);
       app_SidePrintSI (19, (char *) "", timeMove);
      #endif
    }
}

void app_DrawText (BYTE mode)
{
    TDL_Ink (TDL_COL_YELLOW);
    app_SidePrintS (1, (char *) "ADDIX");
    app_SidePrintS (4, szSpace);
    app_SidePrintSI (4,(char *) "IQ:", iqlevel);

    if (isGameOver ()) {		/* Game over, show result */
      TDL_Ink (TDL_COL_RED);
      if (scoreh == scorev) {
        app_SidePrintS (6, (char *) "DRAW.");
      } else {
        if (scoreh > scorev) {
          app_SidePrintS (6, szHoriz);
        } else {
          app_SidePrintS (6, szVert);
	}
        app_SidePrintS   (7, (char *) "WIN.");
      }
    } else {			/* Show side to move */
      if (cside == VERT) {
        app_SidePrintS (6, szVert);
      } else {
        app_SidePrintS (6, szHoriz);
      }
      app_SidePrintS   (7, (char *) "MOVE.");
    }
    if (flag_twoplay) {
      app_SidePrintS   (8, (char *) "2 PLAY");
    }
		/* Show score */
    TDL_Ink (TDL_COL_WHITE);
    app_SidePrintSI  (9,(char *) "H:", scoreh);
    app_SidePrintSI (10,(char *) "V:", scorev);

		/* Show comp move/search info */
    TDL_Ink (TDL_COL_PURPLE);
    app_printpos (cxpos, cypos, besteval, nodecount);
}

#else

void app_printpos (BYTE xpos, BYTE ypos, int eval, UINT nodes)
{
    TDL_Ink (TDL_COL_PURPLE);
    TDL_GotoXY (1,3);
    TDL_PrintChar (xpos+65);
    TDL_PrintChar (ypos+49);
    TDL_PrintStr ((char *) " EVAL:");
    TDL_PrintSignedInt (eval);
    TDL_PrintSI ((char *) " NODE:", nodes);
    #ifdef USE_CLOCK
      TDL_PrintSI ( (char *) " TIME:", timeMove);
    #endif
    TDL_PrintStr ( (char *) "   ");
}

void app_DrawText (BYTE mode)
{
    TDL_GotoXY (1,1); 
    TDL_Ink (TDL_COL_WHITE);
    if (isGameOver ()) {		/* Game over, show result */
      autoplay = FALSE;
      TDL_Ink (TDL_COL_RED);
      if (scoreh == scorev) {
        TDL_PrintStr ( (char *) " DRAW.");
      } else {
        if (scoreh > scorev) {
          TDL_PrintStr ( "HOR");
        } else {
          TDL_PrintStr ( "VERT");
	}
        TDL_PrintStr ( " WIN.");
      }
    } else {			/* Show side to move */
      if (mode) {
        TDL_PrintStr ( "HMM...   ");
      } else {
        TDL_PrintStr ( "YOUR MOVE");
      }
      #if FULL_VERSION
        TDL_Ink (TDL_COL_GREEN);
        TDL_PrintStr (  "   (H=HELP)");
      #endif 		// FULL_VERSION
      
    }
    TDL_PrintStr ( (char *) "   ");

    TDL_GotoXY (1,2); 
		/* Show score */
    TDL_Ink (TDL_COL_YELLOW);
    TDL_PrintSI ( (char *) "H:", scoreh);
    TDL_PrintSI ( (char *) " V:", scorev);
    TDL_Ink (TDL_COL_CYAN);
    TDL_PrintSI ( (char *) " IQ:", iqlevel);
    if (flag_twoplay) {
      TDL_PrintStr ( (char *) " 2P");
    }
    TDL_PrintStr ( (char *) "   ");
		/* Show comp move/search info */
    app_printpos (cxpos, cypos, besteval, nodecount);
}


#endif 	// TEXT_AT_SIDE

void sch_callback (int sxpos, int sypos, int seval)
{
    #ifdef USE_CLOCK
     timeMove = (clock () / CLOCKS_PER_SEC) - timeStart;
    #endif
    app_printpos (sxpos, sypos, seval, nodecount);
}

void app_DrawCell (BYTE xp, BYTE yp, BYTE cur)
{
    BYTE gx,gy;
    BYTE col = COL_NUMBERS;
    BYTE c1 ,c2;
    BYTE val;

    c1 = c2 = TDL_ASC2CHR (32);

    gx = DRAW_TOPX + 1 + xp * CELLX;
    gy = DRAW_TOPY + 1 + yp * CELLY;

    if (cside == VERT) {
      if (cxpos == xp) col = COL_NUMBERHI;
    } else {
      if (cypos == yp) col = COL_NUMBERHI;
    }
    val = GetBoard (xp,yp);
    if (val) {
      if (val < 10) {
        c2 = TDL_ASC2CHR (48) + val;
      } else {
        c1 = TDL_ASC2CHR (48) + (val / 10);
        c2 = TDL_ASC2CHR (48) + (val % 10);
      }
    }
    if (cur) {
      c1 = c2 = CHR_CURSOR;
      col = TDL_COL_WHITE; 
    }
    TDL_ScreenSetXY2 (gx, gy, c1, c2, col);
}



void app_DrawFrame ()
{
    BYTE xp,yp;
    BYTE dx,dy;
    dy = DRAW_TOPY;
    for (yp = 0; yp < boardy; yp++) {
      dx = DRAW_TOPX;
      for (xp = 0; xp < boardx; xp++) {
	TDL_ScreenSetXY (dx, dy, CHR_EDGE, COL_FRAME); 
	TDL_ScreenSetXY (dx+1, dy, CHR_EDGEH, COL_FRAME); 
	TDL_ScreenSetXY (dx+2, dy, CHR_EDGEH, COL_FRAME); 
	TDL_ScreenSetXY (dx, dy+1, CHR_EDGEV, COL_FRAME); 
	dx += CELLX;
      }
      TDL_ScreenSetXY (dx, dy, CHR_EDGE, COL_FRAME); 
      TDL_ScreenSetXY (dx, dy+1, CHR_EDGEV, COL_FRAME); 
      dy += CELLY;
    }
    dx = DRAW_TOPX;
    for (xp = 0; xp < boardx; xp++) {
	TDL_ScreenSetXY (dx, dy, CHR_EDGE, COL_FRAME); 
	TDL_ScreenSetXY (dx+1, dy, CHR_EDGEH, COL_FRAME); 
	TDL_ScreenSetXY (dx+2, dy, CHR_EDGEH, COL_FRAME); 
	dx += CELLX;
    }
    TDL_ScreenSetXY (dx, dy, CHR_EDGE, COL_FRAME); 
}

void app_DrawBoard ()
{
    BYTE xp,yp;

    if (flag_frame) app_DrawFrame ();
    //TDL_DrawRectangle (topx-2, topy-2, boardx*sqrsizex+6, boardy*sqrsizey+6, TDL_Color (80,80,80), FALSE);
    for (yp = 0; yp < boardy; yp++) {
      for (xp = 0; xp < boardx; xp++) {
        app_DrawCell (xp, yp,0);
      }
    }
    app_DrawText (0);
}


BYTE app_CursorMove (int add)
{
    BYTE n;
    for (n = 0; n < boardx; n++) {
      if (cside == VERT) {
        cypos += add;
        if (cypos >= boardy) cypos = 0;
      } else {
        cxpos += add;
        if (cxpos >= boardx) cxpos = 0;
      }
      if (GetBoard (cxpos, cypos)) return TRUE;
    }
	/* No moves left game over.. */
    return FALSE;
}

void app_CompMove ()
{
    BYTE mv,cret;
    app_DrawText (1);
    #ifdef USE_CLOCK
     timeStart = (clock () / CLOCKS_PER_SEC);
    #endif
    mv = CompMove ();
    if (mv == NO_MOVE) {
      return ;
    }
    makemove (mv);
}

  /* Make human move */
void app_ExecMove (int mvx, int mvy) 
{
    BYTE mv,cret;
    mv = mvx;
    if (cside == VERT) mv = mvy;
    cret = makemove (mv);
    if (cret == 0) return ;
    if (flag_twoplay) return ;
    app_DrawBoard ();
    app_CompMove ();
}

#if FULL_VERSION

char szHelp[] = 
  " SPACE : SELECT MOVE\n"
  " ENTER : MAKE MOVE\n"
  " N : NEW GAME\n"
  " G : COMP GO\n"
  " I : SET PLAY LEVEL\n"
  " A : AUTOPLAY\n"
  " T : TWO PLAYER MODE\n"
  " W,E : RESIZE BOARD\n\n";

char szHelp2[] = 
  "YOU PLAY HORIZONTAL MOVES, THE\n"
  "COMPUTER VERTICAL. EACH NUMBER\n"
  "TAKEN ADDS TO YOUR SCORE.\n"
  "HIGHEST SCORE WINS.\n"
  "\n";

BYTE helpkey;

void game_Help ()
{
    TDL_ENABLE_TEXT ;	 	/* Request text */
    TDL_ScreenClr ();
help_loop:
    TDL_GotoXY (4,1);
    TDL_Ink (TDL_COL_WHITE);
    TDL_PrintStr ( PROG_NAME);
    TDL_Ink (TDL_COL_PURPLE);
    TDL_PrintStr ( "\n\n(C) A.MILLETT 2026.FREEWARE/GPL3\n\n");
    TDL_Ink (TDL_COL_YELLOW);
    TDL_PrintStr (szHelp);
    TDL_Ink (TDL_COL_GREEN);
    TDL_PrintStr (szHelp2);
    TDL_Ink (TDL_COL_CYAN);
    TDL_PrintStr ( "\nHIT SPACE");
    do { 
      helpkey = TDL_GetKey ();
      helpkey = TDL_TOUPPER(helpkey);
    } while (helpkey != 32);
    TDL_ENABLE_UDG ;	 	/* Request UDG */
    TDL_ScreenClr ();
}

#endif 		// FULL_VERSION

  /* Exec human command key entry */

void game_Loop ()
{
  BYTE fr = 0;
  #if FULL_VERSION
    game_Help ();
  #endif 		// FULL_VERSION
  
  NewGame ();
  TDL_ScreenClr ();
  while (1) { 
    txt_right = boardx * 3 + DRAW_TOPX + 3;
    app_DrawBoard ();
    do {
      cmdkey = TDL_GetKey ();
      #if FULL_VERSION
        if (autoplay) {
	  if (cmdkey == 0) {
            cmdkey = 'G';
            app_DrawCell (cxpos, cypos, 1);	/* Show cursor on last move */
	    break;
	  } else {
	    autoplay = FALSE;
	  }
        }
      #endif
      TDL_FrameSync ();	
      fr ++;
      app_DrawCell (cxpos, cypos, (fr & 16));
    } while (cmdkey == 0);
    cmdkey = TDL_TOUPPER (cmdkey);

    switch (cmdkey) {
      case 32:			/* Select move */
        app_CursorMove (1);
	break;

      case 13:			/* Enter move */
        app_ExecMove (cxpos, cypos);
        break;

     #if FULL_VERSION
      case 'H':			/* Show Frame */
        game_Help ();
	break ;

      case 27:		/* Quit */
      case 3:
	return;

      case 'A':			/* AutoPlay (Comp vs Comp) */
        autoplay = TRUE;
	break ;

     #endif 		// FULL_VERSION

      case 'F':			/* Show Frame */
        flag_frame = !flag_frame;
	TDL_ScreenClr ();
	break;

      case 'G':			/* Comp go */
        app_CompMove ();
	break;

      case 'Z':			/* New game, fixed seed */
        TDL_rndseed = 0;
      case 'N':			/* New game */
	NewGame ();
        TDL_ScreenClr ();
	break;

      case 'I':			/* IQ */
        iqlevel ++;
        if (iqlevel > 9 && flag_twoplay == 0) iqlevel = 1;
	break;

      case 'T':		/* Toggle 2 player mode */
        flag_twoplay = ! flag_twoplay;
	break;

      case 'W':		/* Alter board width/height */
        if (boardx >= MAX_BOARD) break;
	boardx += 2;
	boardy += 2;
      case 'E':
        if (boardx < 4) break;
	boardy --;
	boardx --;
	// app_Init ();
	NewGame ();
        TDL_ScreenClr ();
	break;
        
    }
  }
}

	/* Main program */
int main ()
{
    TDL_Initialise (0,NULL);
    #if (TDL_UDG_MAX > 0)	/* Are UDGs available? If so, set them up.. */
      TDL_UDG_Init (pPix, CHR_START, sizeof (pPix));
    #endif
    game_Loop ();	/* Main game loop */
    TDL_Finish ();
    return 0;
}

