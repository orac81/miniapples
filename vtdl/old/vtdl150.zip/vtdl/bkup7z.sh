#!/bin/sh
# ie: ./bkup.sh vtdl126
7za a -t7z zip/$1.7z tdl/* demo/* addix/* skattabugz/* wallrun/* dynajim/* test/*.c *.bat *.sh  *.txt  bkup
