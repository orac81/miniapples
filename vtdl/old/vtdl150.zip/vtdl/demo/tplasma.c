/* TPLASMA. Demo for VTDL
   (C) A.Millett 2026. Released as free software under GPL3.
  Classic "Plasma" effect.
  
For SDL try: ./tdlmaksdl.sh demo/tplasma -Os -D TDL_VDUX=128 -D TDL_VDUY=64
*/

char szProg [] = "TDL-PLASMA. (C) A.Millett 2025, Freeware/GPL3.";

#define TDL_IO_DIRECT 1		/* Use direct screen poke for print */
// #define TDL_IO_SYS 1		/* Use OS/Kernal calls for print */

#define SHOW_FPS   1		/* Show Frames/sec. (or: -D SHOW_FPS) */
#define USE_XY     0		/* Test using XY for pos */
#define USE_DOUBLE 0		/* Test with double screen write fn */

#ifdef TDL_PATH		/* User sets TDL_PATH */
 #include TDL_PATH
#else
 #include "../tdl/tdl.c"
#endif

#if (TDL_UDG_MAX > 0)	/* Are UDGs available? If so, set them up.. */

BYTE pPix[] = {
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00, 
  0x11,0x00,0x44,0x00,0x11,0x00,0x44,0x00, 
  0x11,0x44,0x11,0x44,0x11,0x44,0x11,0x44, 
  0x55,0x22,0x55,0x22,0x55,0x22,0x55,0x22, 
  0x55,0xAA,0x55,0xAA,0x55,0xAA,0x55,0xAA, 
  0x55,0xAA,0x55,0xAA,0x55,0xAA,0x55,0xAA, 
  0x55,0xFF,0x55,0xFF,0x55,0xFF,0x55,0xFF, 
  0xEE,0xFF,0xBB,0xFF,0xEE,0xFF,0xBB,0xFF, 
  0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF, 
  0xBB,0xFF,0xEE,0xFF,0xBB,0xFF,0xEE,0xFF, 
  0x55,0xFF,0x55,0xFF,0x55,0xFF,0x55,0xFF, 
  0x55,0xAA,0x55,0xAA,0x55,0xAA,0x55,0xAA, 
  0x55,0x22,0x55,0x22,0x55,0x22,0x55,0x22, 
  0x11,0x44,0x11,0x44,0x11,0x44,0x11,0x44, 
  0x44,0x00,0x11,0x00,0x44,0x00,0x11,0x00, 
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00, 
0};

#define CHR_PLASMA   TDL_UDG_START

#else

#define CHR_PLASMA   TDL_CHR_ASC32

 #ifdef TDL_HAS_PETSCII
	/* Table of 32 PETSCII gradient bit-density weighted characters, 0..64..0 */
  BYTE densitytab[] = {
	32,46,64,25,17,0,117,223,102,105,245,128,145,138,192,174,
	160,174,192,138,145,128,245,105,102,223,117,0,17,25,64,59,
	0};
 #else
	/* Table of 32 ASCII gradient bit-density weighted characters, 0..64..0 */
  BYTE densitytab[] = {
	32,58,39,46,34,41,43,63,61,86,52,60,38,57,42,64,
	48,64,42,57,38,60,86,61,63,43,41,34,46,44,58,32,
	0};
 #endif

#endif

BYTE tabcol [] = {
  TDL_COL_RED,  TDL_COL_PURPLE, TDL_COL_WHITE,  TDL_COL_CYAN, 
  TDL_COL_BLUE, TDL_COL_GREEN,  TDL_COL_YELLOW, TDL_COL_WHITE,
  TDL_COL_RED,  TDL_COL_PURPLE, TDL_COL_WHITE,  TDL_COL_CYAN, 
  TDL_COL_BLUE, TDL_COL_GREEN,  TDL_COL_YELLOW, TDL_COL_WHITE,
0};

	/* Sine lookup table range -127..127.. */
BYTE sintab [64] = {
  128,131,134,137,140,143,146,149,152,155,159,162,165,168,171,173,
  176,179,182,185,188,190,193,196,198,201,204,206,209,211,213,216,
  218,220,222,224,226,228,230,232,234,235,237,239,240,242,243,244,
  245,247,248,249,250,251,251,252,253,253,254,254,255,255,255,255};


BYTE bufx [TDL_VDUX+8];
BYTE bufy [TDL_VDUY+8];

BYTE px1start=0;		/* Start index offset for sine tables */
BYTE px2start=0;
BYTE py1start=0;
BYTE py2start=0;

int delay = 2;
BYTE tim = 0;
BYTE syncframe = 1;

  /* Quick INT sine - input 0-255 (eq 0-360 deg) ret 0-255 (eq -1.0 to 1.0) */

BYTE qsine (BYTE x)
{
    BYTE r=sintab[x & 127];
    if (x & 64) {
      r = sintab[63-(x & 63)];
    }
    if (x & 128) {
      return (~r);
    }
    return (r);
}

  /* Render a frame to (sRender) */
void app_Draw ()
{
    BYTE x,y;
    BYTE res,res2;
    BYTE ypre;
    BYTE px1,px2,py1,py2;	
    BYTE ti1;
    UINT pos;
    
    if (tim  == 0) {
      //app_NewColors ();
    }
    ti1 = qsine(tim)/64;
		/* Gen precalc X sin pattern table bufx[] */
    px1start += 2; px2start += ti1; 
      /* px1start += 2; px2start -= 3;  */
    px1 = px1start; px2 = px2start;
    for (x=0; x<TDL_VDUX; x++) {
      bufx[x] = qsine(px1) + qsine(px2);
      px1+= 1; px2 += 2;
    }
		/* Gen precalc Y sin pattern table bufy[] */
    py1start ++; py2start -= 2;
      /* py1start ++; py2start -= 2; */
    py1 = py1start; py2 = py2start;
    for (y=0; y<TDL_VDUY; y++) {
      bufy[y] = qsine(py1) + qsine(py2);
      py1+= 2; py2 -= 1;
    }
		/* Fill screen using precalc tables */
    for (y=1; y<TDL_VDUY; y ++) {
      ypre = bufy [y];
      pos = TDL_ScreenPos (0,y);
      for (x=0; x<TDL_VDUX; x++) {
	#if (TDL_UDG_MAX > 0)		/* Are UDGs available?  */
	  #if USE_XY		/* Test using XY for plot pos */
	    res = (ypre + bufx[x]) >> 1 ;
            TDL_ScreenSetXY (x,y, CHR_PLASMA+(res & 15), tabcol [res >> 4]); 
	  #else 
	    #if USE_DOUBLE
	      res  = (ypre + bufx[x]) >> 1; 
	      x ++;
	      res2 = (ypre + bufx[x]) >> 1 ;
              TDL_ScreenSet2 (pos, CHR_PLASMA+(res & 15), CHR_PLASMA+(res2 & 15), tabcol [res >> 4]); 
	      pos += 2;
	    #else
	      res = (ypre + bufx[x]) >> 1 ;
              TDL_ScreenSet (pos, CHR_PLASMA+(res & 15), tabcol [res >> 4]); 
	      pos ++;
	    #endif
	  #endif
	#else
	  res = (ypre + bufx[x]);
          TDL_ScreenSetXY (x,y, densitytab [res & 31], tabcol [res >> 5]); 
	#endif
      }
    }
}

  /* Main program loop. */
void game_Loop ()
{
    BYTE key;
    #ifdef SHOW_FPS
      UINT nframe = 0;
      UINT clk = TDL_Clock ();
    #endif
    TDL_ScreenClr ();
    tim = 0;
	/* Main program loop */
    do {
      // TDL_GotoXY (1,1); TDL_PrintSI  ((char *) "T:", TDL_Clock ());
      // TDL_GotoXY (1,1); TDL_PrintSI  ((char *) "T:", sdltxt_font.nchar);
      // TDL_GotoXY (1,1); TDL_PrintSI  ((char *) "T:", TDL_UDG_MAX);
      
      #ifdef SHOW_FPS
	if (((UINT) TDL_Clock () - clk) > TDL_CLOCKS_PER_SEC*10) {
	  TDL_GotoXY (1,1);
	  TDL_PrintSI  ((char *) "FRAME/10SEC:", nframe);
	  #if (TDL_VDUX >= 32)
	    TDL_PrintSI ((char * ) "  SYNC:",syncframe);
	  #else
	    TDL_PrintSI ((char * ) " S",syncframe);
	  #endif
	  TDL_PrintStr ((char * ) "  ");
	  nframe = 0;
          clk = TDL_Clock ();
        }
	nframe ++;
      #endif 
      app_Draw ();
      if (syncframe) TDL_FrameSync ();	/* Sync animation to frame */
      tim ++;
      key = TDL_GetKey ();
      if (key == ' ') syncframe = !syncframe;
      #if TDL_RAM > 64
        if (key == 27) return;
        if (TDL_RequestQuit == TRUE) break;  /* Request quit (window close) */
      #endif
    } while (1);	/* until key/mouse hit */
}


	/* Main program */
int main ()
{
    TDL_Initialise (0,NULL);
    #if (TDL_UDG_MAX > 0)	/* Are UDG gfx available? If so, set up.. */
      TDL_UDG_Init (pPix, TDL_UDG_START, sizeof (pPix));
    #endif
    TDL_SoundInit ();
    game_Loop ();	/* Main game loop */
    TDL_Finish ();
    return 0;
}
