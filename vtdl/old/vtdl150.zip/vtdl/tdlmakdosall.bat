rem Use: tdlmakdosall [msvc1.52 folder]
rem
start /wait tdlmakdos %1 skattabugz\skattabugz  
start /wait tdlmakdos %1 addix\addix            
start /wait tdlmakdos.bat %1 dynajim\dynajim 
start /wait tdlmakdos.bat %1 wallrun\wallrun
start /wait tdlmakdos.bat %1 demo\tplasma    
start /wait tdlmakdos.bat %1 demo\hello      
start /wait tdlmakdos.bat %1 demo\test-udg   
start /wait tdlmakdos.bat %1 demo\tsound     
start /wait tdlmakdos.bat %1 demo\tlife1d
start /wait tdlmakdos.bat %1 demo\radial3d
start /wait tdlmakdos.bat %1 demo\hisimple
del demo\bin\*.exe
move /y demo\*.exe demo\bin 
rem try "start /wait" or "call" above..
