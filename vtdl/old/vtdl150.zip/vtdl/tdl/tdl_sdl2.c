/* "tdl_sdl2.c"  : SDL2 lib for TDL.
   For TDL 2.xx - Very Tiny Development Layer for portable small apps.

  (C) A.Millett 2012-2026. Released as open software under GNU LGPL license.
  TDL Library released under (less restrictive) LGPL license.

*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include <unistd.h>
#include <SDL.h>
#include <SDL_scancode.h>
#include <SDL_timer.h>

#include "sdlwio.c"		/* Header for font/toolbar lib */

/*-----------------------------------------------------------------------
   Common DOS defines, vars, fwd declarations
-------------------------------------------------------------------------*/

#define TDL_FAST register		/* Fast (zeropage,register etc) variable definition */

#define TDL_VDU_STATIC TRUE	 /* VDU size/colour parameters are static/limited */
#define TDL_HAS_UDG    TRUE	/* Tell user program UDGs are available */

#define TDL_POKE(AD,BY) *((BYTE far *) ((ULONG) (AD)))=(BYTE) (BY);
#define TDL_PEEK(AD) ((BYTE) *((BYTE far *) ((ULONG) (AD))))

#define TDL_ADD_CR  TRUE		/* Add CR if LF sent (TDL_PrintSring) */

#define TDL_SHIFT_LR    1	/* Left/right shift */
#define TDL_SHIFT_CTRL  2


void TDL_PrintChar (BYTE ch);		/* Fwd declare */
void TDL_ScreenClr ();
void TDL_GotoXY (BYTE x, BYTE y);
void TDL_Ink (BYTE ink);
BYTE TDL_GetKey ();
void TDL_UpdateDisplay ();
ULONG TDL_Clock ();
void TDL__Font_Init ();


char *TDL_szProg = " SDL Window";
BYTE TDL_RequestQuit = FALSE;		/* Set when window has been closed */

/*========================================================================
   SDL2 Specific Code
==========================================================================*/

#define TDL_RAM 32000		/* Amount of RAM (Kb, approx) for platform */

#ifndef TDL_VDUX
 #define TDL_VDUX 40
#endif

#ifndef TDL_VDUY
 #define TDL_VDUY 25
#endif

 //#define TDL_HAS_HIRES TRUE
#define TDL_HAS_HIRES FALSE
#define TDL_VDU_HIX 320			/* Hi-res pixel screen size (static) */
#define TDL_VDU_HIY 200
#define TDL_VDU_HICOL 24		/* Hi res colour depth (#bits) */

#ifdef TDL_REQ_TEXT
  #define TDL_UDG_MAX 0			/* Text only, no UDG chars */
#else
  #define TDL_UDG_MAX 128		/* #UDG chars */
#endif
#define TDL_UDG_START 128		/* Start of UDG chars */

#define TDL_CHR_ASC32   32		/* Map Ascii 32-63.. */
#define TDL_CHR_ASC64   64		/* Ascii 64-95 */
#define TDL_CHR_ASC96   96		/* Ascii 96-127 */
#define TDL_ASC2CHR(C) (C)		/* Convert ascii to chr code */

  /* Native Colour codes */
#define TDL_COL_BLACK   0
#define TDL_COL_BLUE    1	/* 1:Bit 0 */
#define TDL_COL_GREEN   2	/* 2:Bit 1 */
#define TDL_COL_CYAN    3
#define TDL_COL_RED     4	/* 4:Bit 2 */
#define TDL_COL_PURPLE  5
#define TDL_COL_YELLOW  6
#define TDL_COL_WHITE   7

#define TDL_RGBItoCol(RGBI) (RGBI)

SDL_Color TDL__RGBI2SDL [16] = {
  {0,0,0,0}, {0,0,255,0}, {0,255,0,0}, {0,255,255,0},
  {255,0,0,0}, {255,0,255,0}, {255,255,0,0}, {255,255,255,0},
  {0,0,0,0}, {0,0,255,0}, {0,255,0,0}, {0,255,255,0},
  {255,0,0,0}, {255,0,255,0}, {255,255,0,0}, {255,255,255,0}   };
  

BYTE TDL__Vdu [TDL_VDUX*TDL_VDUY+64];		/* VDU char map buffer */
BYTE TDL__Colour [TDL_VDUX*TDL_VDUY+64];		/* VDU colour map buffer */

	/* UDG Font data */
BYTE *TDL_UDG_ptr = NULL;
UINT TDL_UDG_start=128;
UINT TDL_UDG_size=0;
	/* Back colour */
BYTE TDL_border;
BYTE TDL_screen;
	/* Char draw params */
BYTE TDL_cursorx ;
BYTE TDL_cursory ;
BYTE TDL_ink ;
BYTE TDL_LeftMargin= 0;		/* Left Margin */

/* SDL Variables   */

SDL_Window  * TDL__hWin = NULL;		/* Main program window */
SDL_Texture * TDL__pTextureBmp = NULL;	/* Texture with piece graphic bitmaps */
SDL_Renderer * TDL__sRender = NULL;		/* Used for drawing comands */

SDLTXT_FONT TDL__sdltxt_font;	/* Bitmap font object */

SDL_DisplayMode TDL__dispMode;	/* Used to find screen size */
SDL_Event TDL__sEvent;		/* Used for event loop (kbd/mouse etc */

const BYTE * TDL__pKeyState;		/*  pointer to array from SDL_GetKeyboardState(int *numkeys); */
int TDL__numkeys = 0;

int TDL__vdux = 200;
int TDL__vduy = 200;

/*-----------------------------------------------------------------------
   SDL SCREEN DRAWING
-------------------------------------------------------------------------*/

	/*. TDL_DrawPoint (UINT xpos, UINT ypos, UINT color) - Draw a pixel */
void TDL_DrawPoint (UINT xpos, UINT ypos, UINT color)
{
    //TDL_DOS_Plot (xpos, ypos, color);
}

	/*. TDL_ScreenPos(X,Y) - Calc Screen char position from X,Y (0 to max-1) */
#define TDL_ScreenPos(X,Y) ((X)+(Y)*TDL_VDUX)

  /*. TDL_ScreenSetXY (BYTE x, BYTE y,BYTE ch, BYTE col) - Poke VDU pos with char & colour */
void TDL_ScreenSetXY (BYTE x, BYTE y, BYTE ch, BYTE col) 
{
    UINT pos = TDL_ScreenPos (x,y);
    if (pos > TDL_ScreenPos (TDL_VDUX-1, TDL_VDUY-1)) {
	printf ("TDL_ScreenSetXY overflow:%d,%d,chr=%d\n",x,y,ch);
	exit (0);
    }
    TDL__Vdu [pos] = ch; 
    TDL__Colour [pos] = col; 
}	

	/*. void TDL_ScreenSet(UINT pos, BYTE ch, BYTE col) - Poke VDU pos with char & colour */
void TDL_ScreenSet (UINT pos, BYTE ch, BYTE col)  
{
    TDL__Vdu [pos] = ch; 
    TDL__Colour [pos] = col; 
    if (pos > TDL_ScreenPos (TDL_VDUX-1, TDL_VDUY-1)) {
	printf ("TDL_ScreenSet overflow:%d,chr=%d\n",pos,ch);
	exit (0);
    }
}


  /*. void TDL_ScreenSet2 (UINT pos, BYTE char1, BYTE char2, BYTE col) - Poke VDU pos with 2 chars & colour */
void TDL_ScreenSet2 (UINT pos, BYTE char1, BYTE char2, BYTE col)  
{
    TDL_ScreenSet (pos, char1, col);
    pos ++;
    TDL_ScreenSet (pos, char2, col);
}

  /*. TDL_ScreenSetXY2 (BYTE x, BYTE y, BYTE char1, BYTE char2, BYTE col) - Poke VDU pos with 2 chars & colour */
void TDL_ScreenSetXY2 (BYTE x, BYTE y, BYTE char1, BYTE char2, BYTE col) 
{
    UINT pos;
    pos = TDL_ScreenPos(x,y);
    TDL_ScreenSet (pos, char1, col);
    pos ++;
    TDL_ScreenSet (pos, char2, col);
}

#define TDL_ScreenSetNC(POS,BYT)  TDL_ScreenSet(POS,BYT,TDL_COL_WHITE)

  /*. BYTE TDL_ScreenGet (UINT pos)  - peek vdu pos */
BYTE TDL_ScreenGet (UINT pos)  
{
    return TDL__Vdu[pos]; 
}	

  /*. BYTE TDL_ScreenGetXY (BYTE x, BYTE y)  - peek vdu pos */
BYTE TDL_ScreenGetXY (BYTE x, BYTE y)  
{
	return TDL__Vdu [TDL_ScreenPos(x,y)]; 
}	

  /*. TDL_ScreenBackground (BYTE screen, BYTE border) - Set background */
void TDL_ScreenBackground (BYTE screen, BYTE border)
{
    //TDL_DOS_ScreenBack (screen, border);
}

void TDL_ScreenClr ()
{
    memset (TDL__Vdu, TDL_CHR_ASC32, sizeof (TDL__Vdu));
    memset (TDL__Colour,0,sizeof (TDL__Colour));
    TDL_Ink (TDL_COL_WHITE);
    TDL_cursorx = TDL_cursory = 0;
}

  /*. void TDL_PrintChar (BYTE ch) - Print ASC char (using direct drawing) */
void TDL_PrintChar (BYTE ch)
{
    UINT pos;
    if (ch < 32) {
      if (ch == 10) {
        TDL_cursorx = TDL_LeftMargin;	/* Left Margin */
        if (TDL_cursory < TDL_VDUY) TDL_cursory ++;
      }
      return;
    }
    pos = TDL_ScreenPos (TDL_cursorx, TDL_cursory);
    ch = TDL_ASC2CHR (ch);
    TDL_ScreenSet (pos, ch, TDL_ink);
    TDL_cursorx ++;
    if (TDL_cursorx >= TDL_VDUX) {
      TDL_cursorx = 0;
      if (TDL_cursory < TDL_VDUY) TDL_cursory ++;
    }
}

  /*. void TDL_Ink (BYTE ink) - Set print ink */
void TDL_Ink (BYTE ink)
{
     TDL_ink = ink;
}

   /*. void TDL_GotoXY (BYTE x, BYTE y) - Set cursor pos (1,1..X,Y) */
void TDL_GotoXY (BYTE x, BYTE y)
{
    TDL_cursorx = x-TDL_PRINT_ORG;
    TDL_cursory = y-TDL_PRINT_ORG;
    //TDL_DOS_gotoxy (x,y);
}

  /*. TDL_SetLeftMargin (BYTE x)  - Set left margin for printing */
void TDL_SetLeftMargin (BYTE x)
{
    TDL_LeftMargin = x - TDL_PRINT_ORG;
}

/*-----------------------------------------------------------------------
   SDL KEYBOARD
-------------------------------------------------------------------------*/

#define TDL_SCANCODE_NONE 0

BYTE TDL__LastKey = 0;		/* Last key hit */
UINT TDL__LastScan = 0;

BYTE TDL__KeyHit = 0;
UINT TDL__KeyHitScanCode = 0;

BYTE TDL_GetKeyDown ()
{
     BYTE ch;
     TDL_GetKey ();
     if (TDL__pKeyState [TDL__LastScan] == 0) TDL__LastKey = 0;
     return TDL_TOUPPER (TDL__LastKey);
}

  /*. BYTE TDL_GetKey_Shift () - Return shift status (TDL_SHIFT_LR, TDL_SHIFT_CTRL) */
BYTE TDL_GetKey_Shift ()
{
    BYTE shift = 0;
    if (TDL__pKeyState [SDL_SCANCODE_LSHIFT] | TDL__pKeyState [SDL_SCANCODE_LSHIFT] ) {
      shift = TDL_SHIFT_LR;
    }
    if (TDL__pKeyState [SDL_SCANCODE_LCTRL] ) {
      shift |= TDL_SHIFT_CTRL;
    }
    return shift;
}


  /*. BYTE TDL_GetKey () - get char from keyboard */
BYTE TDL_GetKey ()
{
    TDL_UpdateDisplay ();
    if (TDL__KeyHit == 0) return 0;
    TDL__LastKey = TDL__KeyHit;
    TDL__LastScan = TDL__KeyHitScanCode;
    TDL__KeyHit = 0;
    return TDL__LastKey;
}


/*-----------------------------------------------------------------------
   SDL JOYSTICK
-------------------------------------------------------------------------*/

  /* BYTE TDL_GetJoystick (BYTE joy)  -  Get joystick status */
#define TDL_MAX_JOYSTICK 0

  /* Test bits for joystick direction/fire */
#define TDL_JOYSTICK_UP		0
#define TDL_JOYSTICK_DOWN	0
#define TDL_JOYSTICK_LEFT	0
#define TDL_JOYSTICK_RIGHT	0
#define TDL_JOYSTICK_FIRE	0
#define TDL_JOYSTICK_HIT        0

BYTE TDL_GetJoystick (BYTE joy)
{
    return 0;
}

/*-----------------------------------------------------------------------
   SDL TIMING
-------------------------------------------------------------------------*/

#define TDL_CLOCKS_PER_SEC  100

  /* Get clock */
ULONG TDL_Clock ()
{
    TDL_UpdateDisplay ();
    return ( (SDL_GetTicks ()/10) );	// Gets millisecs/10 since start
}

  /*. void TDL_Sleep (int delay)  - Sleep (delay) milliseconds, yeild thread */
void TDL_Sleep (int delay)
{
    TDL_UpdateDisplay ();
    SDL_Delay (delay);		// Delay X millisec 
}

void TDL_FrameSync ()
{
    TDL_Sleep (18);		// Sleep # millisecs
}

/*-----------------------------------------------------------------------
   SDL SOUND
-------------------------------------------------------------------------*/

#define TDL_SOUND_TYPE UINT

#define TDL_SOUND_NVOICE 0	// No of voices

#define TDL_SOUND_LO  0
#define TDL_SOUND_HI  1023
#define TDL_SOUND_STEP  4	// Simple scaling step for fx (pow2)

#define TDL_SOUND_C4  0	// (Middle C) Rough note vals
#define TDL_SOUND_A4  0
#define TDL_SOUND_C5  0
#define TDL_SOUND_A5  0
#define TDL_SOUND_C6  0

  /* Simple sound tone generator (voice 0-N) */
void TDL_Sound (UINT val, BYTE voice)
{
}

void TDL_SoundOff (BYTE voice)
{
}

void TDL_SoundInit ()
{
}

/*-----------------------------------------------------------------------
   SDL INITIALISATION & MISC
-------------------------------------------------------------------------*/

  /* SDL function error, display error then exit */
void sdl_error (char *pMsg)
{ 
     //printf ((char *) "%s error: %s\n", pMsg, SDL_GetError ());
     SDL_ShowSimpleMessageBox (0x10, pMsg, SDL_GetError (), NULL);     
     sleep (1);
     exit (1);
}

  /* Set up the UDG chr set pointers */
void TDL_UDG_Init (BYTE *pPix, UINT chstart, UINT psize)
{
    UINT pos;
    BYTE *pDest;

    TDL_UDG_ptr = pPix;			/* Store for later use */
    TDL_UDG_start = chstart;
    TDL_UDG_size = psize;
    SDLTXT_DestroyFont (&TDL__sdltxt_font);	/* Remove old font */

    pDest = TDL__sdltxt_font.pFontData;
    TDL__sdltxt_font.nchar += psize / 8;
    chstart = (chstart-  TDL__sdltxt_font.startchar) * 8;
    for (pos= 0; pos< psize; pos++) {
      pDest [chstart+pos]= pPix [pos];
    } 
    //TDL__DebugPrint ("nch",TDL__sdltxt_font.nchar,0);

	/* Re-Initialise bmp font */
    TDL__sdltxt_font.is_user_font = TRUE;	 	/* Create new font with extra UDGs */
    if (SDLTXT_CreateFont (TDL__sRender, &TDL__sdltxt_font) == FALSE) {
      sdl_error ( "SDLTXT_CreateFont (UDG)");
    }
    TDL_ScreenClr ();
}

  /* Request a screen resolution, sets nearest available. 
	Actual resolution in TDL_VDU_HIX, TDL_VDU_HIY, TDL_VDU_HICOL. */
BYTE TDL_ScreenMode (UINT sx, UINT sy, BYTE coldepth, BYTE flags)
{
    return TRUE;   /* Just use static 320x200 (0x13) mode for now */
}

  /* Update Display (for service-loop targets) */
void TDL_UpdateDisplay ()
{
    int cmd,keyup;
    int cret;
    int x,y;
    int pos;   
    long scalex ,scaley;
    BYTE ch,col;  
    int keyasc;
    SDL_Color rgb;

      SDLTXT_SetOutputRenderer (TDL__sRender);
	/* Sys/Mouse/Keyboard event managment */
      while (SDL_PollEvent (&TDL__sEvent)) {
	cmd = 0;
	switch (TDL__sEvent.type) {
	  case SDL_QUIT:
            TDL_RequestQuit = TRUE;	/* Window has been closed, quit. */
	    return ;

          case SDL_MOUSEBUTTONDOWN:	
	    break;

	  case SDL_KEYDOWN:
	    cmd = TDL__sEvent.key.keysym.scancode;	/* Pass key command to statement below.. */
	    break;

	  case SDL_KEYUP:
            keyup = SDL_GetKeyFromScancode ((UINT) TDL__sEvent.key.keysym.scancode);
	    if ((BYTE) keyup == TDL__LastKey) TDL__LastKey = 0;	/* Release keydown */
	    break;
	  }
		/* Process command (keystroke or toolbar) */
	  if (cmd) {
            keyasc = SDL_GetKeyFromScancode (cmd);
	    // printf ("Scan:%d,key:%d,%c. ", cmd, keyasc, (BYTE) keyasc);

            if ( keyasc < 0x80) {	/* If unicode<128, its printable ascii key */
              TDL__KeyHit = (BYTE) keyasc;	/* Keep it for TDL_GetKey(). A "stack" of 1 key! If keystrokes lost, make it a stack */
              TDL__KeyHitScanCode = cmd;		
            }
	    switch (cmd) {
	      case SDL_SCANCODE_ESCAPE:		/* Quit */
		// exit (0);
		return;

	    }
	  }
      }
	/* Ok redraw and render screen */
    SDL_SetRenderDrawColor (TDL__sRender, 0, 16, 32, 255);
    SDL_RenderClear (TDL__sRender); 

	/* Calculate font scaling factor */
    SDL_GetWindowSize (TDL__hWin, &TDL__vdux, &TDL__vduy);
    scalex = (TDL__vdux * 25) / (TDL_VDUX * 2);
    scaley = (TDL__vduy * 25) / (TDL_VDUY * 2);
    if (scalex > scaley) scalex = scaley;
    SDLTXT_SetScale (scalex); 

    SDLTXT_SetColor (255, 255, 128); 
    pos = 0;
    for (y = 0; y < TDL_VDUY; y++) {
      for (x = 0; x < TDL_VDUX; x++) {
	ch = TDL__Vdu [pos];
        if (ch != 32) {
	  col = TDL__Colour [pos];
	  rgb = TDL__RGBI2SDL [col];
	  SDLTXT_SetColor (rgb.r, rgb.g, rgb.b);
          SDLTXT_SetCursorPos (-x-1, -y-1);
          SDLTXT_PrintChar (ch);
        }
        pos ++;
      }
    }
    // SDLTOOL_Draw (&sdltool_data, TDL__sRender);
    SDL_RenderPresent (TDL__sRender); 
    //SDL_Delay (10);		/* Delay X millisec */
}

UINT TDL_Initialise (UINT mode, BYTE *pData)
{
    int cret;
    SDL_Surface * pSurfaceBmp = NULL;		/* bmps for pieces */

    TDL_Ink (TDL_COL_WHITE);
    TDL_ScreenBackground (TDL_COL_BLACK, 0);
    TDL_ScreenClr ();
    
	/* Initialise SDL libs */
    cret = SDL_Init (SDL_INIT_VIDEO);
    if (cret != 0) {
      sdl_error ((char *) "SDL_Init");
    }
    
	/* Get desktop size */
    cret = SDL_GetCurrentDisplayMode (0, &TDL__dispMode);    
    if (cret != 0) {
      sdl_error ((char *) "SDL_GetCurrentDisplayMode");
    }
    TDL__vdux = TDL__dispMode.w - 10;
    TDL__vduy = TDL__dispMode.h - 60; 

    if (SDL_CreateWindowAndRenderer (TDL__vdux, TDL__vduy, SDL_WINDOW_RESIZABLE, &TDL__hWin, &TDL__sRender) < 0) {
      sdl_error ((char *) "SDL_CreateWindowAndRenderer");
    }
    if (TDL__sRender == NULL) {
      sdl_error ((char *) "TDL__sRender is NULL");
    }
    SDL_SetWindowTitle (TDL__hWin, TDL_szProg);
    SDL_GetWindowSize (TDL__hWin, &TDL__vdux, &TDL__vduy);
    
	/* Initialise bmp font */
    //SDLTXT_PrepareFont (&TDL__sdltxt_font);  	/* Copy default font data */
    TDL__sdltxt_font.is_user_font = FALSE;	 	/* Use default font */
    if (SDLTXT_CreateFont (TDL__sRender, &TDL__sdltxt_font) == FALSE) {
      sdl_error ((char *) "SDLTXT_CreateFont");
    }
    TDL__pKeyState = SDL_GetKeyboardState (&TDL__numkeys);	/* Ptr to keyboard state array */

   #if 0	// NOT USED
	/* Init toolbar */
    cret = SDLTOOL_Create (&sdltool_data, TDL__sRender, "toolbar.bmp");
    if (cret == 0) {
      sdl_error ((char *) "SDLTOOL_Create");
    }
	/* Load piece bmps */
    pSurfaceBmp = SDL_LoadBMP ((char *) "sconnex.bmp");
    if (pSurfaceBmp == NULL) {
      flag_gfx = 1; return;
      //sdl_error ((char *) "SDL_LoadBMP ");
    }
	/* Transfer bmp to texture for rendering.. */
    TDL__pTextureBmp = SDL_CreateTextureFromSurface (TDL__sRender, pSurfaceBmp);
    if (TDL__pTextureBmp == NULL) {
      sdl_error ((char *) "SDL_CreateTextureFromSurface ");
    }
    SDL_FreeSurface (pSurfaceBmp);
   #endif
    
    //sdl_error ("Init OK ");
    return 0;
}

  /* void TDL_Finish () - Quit TDL */
void TDL_Finish ()
{
    SDLTXT_DestroyFont (&TDL__sdltxt_font);
   #if 0	// NOT USED
    SDLTOOL_Destroy (&sdltool_data);
    SDL_DestroyTexture (TDL__pTextureBmp);
   #endif
    SDL_DestroyWindow (TDL__hWin);
    SDL_Quit ();
}

