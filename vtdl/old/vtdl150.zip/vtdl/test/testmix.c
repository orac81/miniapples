/* Assort tests for VTDL */

#define TDL_IO_DIRECT 1		/* Use direct screen poke for print */
// #define TDL_IO_SYS 1		/* Use OS/Kernal calls for print */

#ifdef TDL_PATH		/* User sets TDL_PATH */
 #include TDL_PATH
#else
 #include "../tdl/tdl.c"
#endif

UINT curtime = 0;
long starttime = 0;
UINT cframe = 0;
BYTE lastkey = 0;

	/* Main program */
int main ()
{
    BYTE key,keydown;
    TDL_Initialise (0,NULL);
    starttime = TDL_Clock ();
    do {
      TDL_FrameSync ();	/* Sync animation to frame rate */
      cframe ++;
      curtime = (UINT) ((long) (TDL_Clock () - starttime) / TDL_CLOCKS_PER_SEC);
      TDL_GotoXY (1,1);
      TDL_PrintSI ( "TIME:", curtime );
      TDL_PrintSI ( " \nFRAME:",cframe);
      TDL_PrintStr ( " \nFPS:");
      if (curtime) {
        TDL_PrintInt ( cframe/curtime);
      } 
      TDL_PrintSI ( " \nJOY1:", TDL_GetJoystick (0) );
      TDL_PrintSI ( " \nJOY2:", TDL_GetJoystick (1) );
      keydown = TDL_GetKeyDown ();
      TDL_PrintSI ( " \nKEYDOWN:", keydown );
      TDL_PrintSI ( " \nSHIFT:", TDL_GetKey_Shift ());
      key = TDL_GetKey ();
      if (key) lastkey = key;
      TDL_PrintSI ( " \nLASTKEY:", lastkey);
      TDL_PrintStr ( "  (Q=QUIT)   ");
    } while (keydown != 'Q' && keydown != 27);
    return 0;
}
