/*  TWALL.C, Wall Run game, using TDL library.
      Copyright 1980-2015 A.Millett. Freeware.

  Imp very simple working demo.
->TWALL101, 14.6.2015
  Imp scoring, text status line..
->TWALL102, 14.6.2015
  Imp targets. Reasonably full working version.
->TWALL103, 15.6.2015
  Imp newdir - avoid steering into wall, etc.
->TWALL104, 18.6.2015
  Imp title screen, USE_TITLE_SCREEN..
->TWALL105, 18.6.2015
  Update for VTDL2, simple working version
->TWALL110, 6.5.2026
  Imp better GFX, tune and improve play
  Add "gun" option.
->TWALL111, 7.5.2026
  Add Ammo.
->TWALL112, 8.5.2026
->TWALL113, 8.5.2026
  Add joystick, tempo. Petscii.
->TWALL114, 8.5.2026
  Tidy title screen.
->TWALL115, 10.5.2026
  Add extend, to allow user more time to move if critical
->TWALL116, 11.5.2026

*/

#define PROG_NAME "Wall-Run 1.16"

#define TDL_IO_DIRECT 1		/* Use direct screen poke for print */

#ifdef TDL_PATH		/* User sets TDL_PATH */
 #include TDL_PATH
#else
 #include "../tdl/tdl.c"
#endif

#define PROG_DEBUG     TRUE
#define FULL_VERSION   TRUE		/* Add extra features */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define USE_TITLE_SCREEN  TRUE
#define USE_GUN           TRUE

#if (TDL_UDG_MAX > 0)	/* Are UDGs available? If so, set them up.. */

 BYTE pPix[] = {
  //  "wall1.bmp" size 96 x 16, Bitdepth=1, #char: 12 x 2
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,  // blank
  0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,  // white
  0xaa,0x55,0xaa,0x55,0xaa,0x55,0xaa,0x55,  // grey
  0x08,0x22,0x1c,0x5d,0x1c,0x22,0x08,0x00,  // mine
  0x7c,0xc6,0xde,0xc6,0xf6,0xc6,0x7c,0x00,  // slow
  0x00,0x36,0x7f,0x77,0x7f,0x36,0x1c,0x08,  // heart
  0x00,0x1c,0x3e,0x2e,0x3e,0x2e,0x7f,0x00,  // ammo
  0x18,0x24,0x24,0x18,0x18,0x24,0x24,0x18,  // edgev
  0x00,0x00,0x66,0x99,0x99,0x66,0x00,0x00,  // edgeh
  0x3c,0x42,0x99,0xa5,0xa5,0x99,0x42,0x3c,  // edge
  0x00,0x55,0xaa,0xff,0xff,0x55,0xaa,0x00,  // wallh
  0x5c,0x3a,0x5c,0x3a,0x5c,0x3a,0x5c,0x3a,  // wallv
  0x00,0x3c,0x5a,0x66,0x66,0x5a,0x3c,0x00,  // wallcorn
  0x10,0x08,0x10,0x08,0x10,0x08,0x10,0x08,  // ShotV
  0x00,0x00,0x00,0x55,0xaa,0x00,0x00,0x00,  // ShotH
 0};

	/* UDG character constants */
 #define CHR_BLANK   TDL_CHR_ASC32
 #define CHR_PLAY    TDL_UDG_START + 2
 #define CHR_COMP    TDL_UDG_START + 1
 #define CHR_MINE    TDL_UDG_START + 3
 #define CHR_SLOW    TDL_UDG_START + 4
 #define CHR_BONUS   TDL_UDG_START + 5
 #define CHR_AMMO    TDL_UDG_START + 6
 #define CHR_EDGEV   TDL_UDG_START + 7
 #define CHR_EDGEH   TDL_UDG_START + 8
 #define CHR_EDGE    TDL_UDG_START + 9
 #define CHR_WALLH   TDL_UDG_START + 10
 #define CHR_WALLV   TDL_UDG_START + 11
 #define CHR_WALL    TDL_UDG_START + 12
 #define CHR_SHOTV   TDL_UDG_START + 13
 #define CHR_SHOTH   TDL_UDG_START + 14

#else 	/* No UDGs, ASCII/PETSCII.. */

 #ifdef TDL_HAS_PETSCII

	/* PETCII Game char codes */
  #define CHR_BLANK   TDL_CHR_ASC32
  #define CHR_PLAY    160
  #define CHR_COMP    209
  #define CHR_MINE    TDL_ASC2CHR('*')
  #define CHR_SLOW    TDL_ASC2CHR('S')
  #define CHR_BONUS   83
  #define CHR_AMMO    90
  #define CHR_EDGEV   102
  #define CHR_EDGEH   102
  #define CHR_EDGE    102
  #define CHR_WALLH   160
  #define CHR_WALLV   160
  #define CHR_WALL    160
  #define CHR_SHOTV   TDL_ASC2CHR('!')
  #define CHR_SHOTH   TDL_ASC2CHR('-')

 #else

  #define CHR_BLANK   TDL_CHR_ASC32
  #define CHR_PLAY    TDL_ASC2CHR('#')
  #define CHR_COMP    TDL_ASC2CHR('#')
  #define CHR_MINE    TDL_ASC2CHR('*')
  #define CHR_SLOW    TDL_ASC2CHR('S')
  #define CHR_BONUS   TDL_ASC2CHR('$')
  #define CHR_AMMO    TDL_ASC2CHR('A')
  #define CHR_EDGEV   TDL_ASC2CHR('!')
  #define CHR_EDGEH   TDL_ASC2CHR('-')
  #define CHR_EDGE    TDL_ASC2CHR('+')
  #define CHR_WALLH   TDL_ASC2CHR('%')
  #define CHR_WALLV   TDL_ASC2CHR('%')
  #define CHR_WALL    TDL_ASC2CHR('%')
  #define CHR_SHOTV   TDL_ASC2CHR('!')
  #define CHR_SHOTH   TDL_ASC2CHR('-')

 #endif

#endif

	/* Colours of above objects */
#define COL_BLANK  TDL_COL_BLACK
#define COL_PLAY   TDL_COL_YELLOW
#define COL_COMP   TDL_COL_CYAN
#define COL_EDGE   TDL_COL_GREEN
#define COL_MINE   TDL_COL_RED
#define COL_SLOW   TDL_COL_BLUE
#define COL_BONUS  TDL_COL_PURPLE
#define COL_AMMO   TDL_COL_WHITE
#define COL_SHOT   TDL_COL_WHITE

int playPos, playDir;		/* Human player pos/dir */
int compPos, compDir;		/* Computer player pos/dir */
BYTE gameover;			
BYTE level=0;
BYTE complife;			/* How many "lifes" the comp has on each level */
BYTE tempo = 2;			/* Delay in millisec */
UINT score,hiscore;

UINT shotPos;	/* Position of bullet, 0=not in motion */
int shotDir;
BYTE nshot;	/* No of shots/ammo left */
BYTE nslow;	/* No of slow-pills left */
BYTE joystick = 0;	/* Current joystick (0,1) */
BYTE soundflag = 1;	/* Enable Sound */
BYTE shotSound=0;
 
BYTE game_help  ();
void game_DrawText ();

  /* Find a random empty screen cell */
UINT game_RandPos ()
{
    BYTE x,y;
    UINT pos;
    do {
      x = 1+(rand () % (TDL_VDUX-3));
      y = 2+(rand () % (TDL_VDUY-4));
      pos = TDL_ScreenPos (x,y);
    } while (TDL_ScreenGet (pos) != CHR_BLANK);
    return pos;
}

void game_Border (BYTE topy)
{
    BYTE x,y;
	/* Draw border */
    for (x = 0; x < TDL_VDUX; x++) {
      TDL_ScreenSetXY (x,topy, CHR_EDGEH, COL_EDGE);
      TDL_ScreenSetXY (x,TDL_VDUY-1, CHR_EDGEH, COL_EDGE);
    }
    for (y = topy; y < TDL_VDUY; y++) {
      TDL_ScreenSetXY (0,y, CHR_EDGEV, COL_EDGE);
      TDL_ScreenSetXY (TDL_VDUX-1,y, CHR_EDGEV, COL_EDGE);
    }
    TDL_ScreenSetXY (0, topy, CHR_EDGE, COL_EDGE);
    TDL_ScreenSetXY (0, TDL_VDUY-1, CHR_EDGE, COL_EDGE);
    TDL_ScreenSetXY (TDL_VDUX-1, topy, CHR_EDGE, COL_EDGE);
    TDL_ScreenSetXY (TDL_VDUX-1, TDL_VDUY-1, CHR_EDGE, COL_EDGE);
}

void game_NewLevel ()
{
    BYTE n;
    UINT pos;
    TDL_ScreenClr ();
    level ++;
    game_Border (1);

	/* Set player/comp start pos */
    playPos = TDL_ScreenPos (TDL_VDUX/4, TDL_VDUY/2-1);
    playDir = 1;
    compPos = TDL_ScreenPos ( (TDL_VDUX*3)/4, TDL_VDUY/2+1);
    compDir = -1;
    gameover = FALSE;
    complife = (level+6)/4;
    if (complife > 3) complife = 3;
    //tempo = 80 - level * 4;
    shotPos = 0;
	/* Scatter some targets and mines */
    for (n = 0; n <= level; n++) {
      pos = game_RandPos ();
      TDL_ScreenSet (pos, CHR_BONUS, COL_BONUS);
      pos = game_RandPos ();
      TDL_ScreenSet (pos, CHR_MINE, COL_MINE);
    }
    #if USE_GUN		/* Set up ammo/slow pills */
      nshot = 2;
      nslow = 1;
      for (n = 0; n <= level; n++) {
        pos = game_RandPos ();
        TDL_ScreenSet (pos, CHR_AMMO, COL_AMMO);
        /* pos = game_RandPos ();
        TDL_ScreenSet (pos, CHR_SLOW, COL_SLOW); */
      }
    #endif 	// USE_GUN
    pos = playPos;
    for (n = 0; n <= 7; n++) {	/* Make sure some sqrs clr ahead of human to start */
      TDL_ScreenSet (pos, CHR_BLANK, COL_BLANK);
      pos += playDir;
    }
    game_DrawText ();
    while (TDL_GetKey ()) {};	/* Clr keyboard buffer */
}

void game_NewGame ()
{
    level = 0;
    score = 0;
    game_NewLevel ();
}

void game_DrawText ()
{
    TDL_Ink (TDL_COL_WHITE);
    TDL_GotoXY (2,1);
    TDL_PrintInt (score);
    TDL_PrintChar (TDL_ASC2CHR('0'));
    TDL_GotoXY (10,1);
    TDL_PrintInt (nshot);
    TDL_ScreenSetXY (7,0, CHR_AMMO, COL_AMMO);
    /*
    TDL_GotoXY (15,1);
    TDL_PrintInt (nslow);
    TDL_ScreenSetXY (12,0, CHR_SLOW, COL_SLOW); 
    */
    TDL_GotoXY (TDL_VDUX-2,1);
    TDL_PrintInt (level);
    TDL_ScreenSetXY (TDL_VDUX-5,0, TDL_ASC2CHR('L') , COL_BONUS);
}

void game_Sound ()
{
    if (soundflag) {
      TDL_Sound (TDL_SOUND_C4 + (TDL_Rand () & 63)* TDL_SOUND_STEP, 1);
    }
}

void move_Delay ()
{
    BYTE x;
    for (x = 0; x< tempo; x++) {
      TDL_FrameSync ();
    }
    if (tempo == 0) TDL_Sleep (10);
}

void move_Computer ()
{
    int oldDir = compDir;
    BYTE ch;
	/* Move Computer side.. */
    if (TDL_ScreenGet (compPos + compDir) != CHR_BLANK) {	/* Comp hit something? Change dir..  */
      if (compDir < 0) compDir =-compDir;
      compDir = TDL_VDUX + 1 - compDir;
      if (rand () & 1) compDir = -compDir;	/* Random turn Left/Right */
      if (TDL_ScreenGet (compPos + compDir) != CHR_BLANK) {	/* No, Try opposite dir */
        compDir = - compDir;	
        if (TDL_ScreenGet (compPos + compDir) != CHR_BLANK) {	/* No way out! Comp looses a life */
	  if (complife > 1) {
	    complife --;
            do {
	      compPos = game_RandPos ();
            } while (TDL_ScreenGet (compPos + compDir) != CHR_BLANK);
	  } else {			/* No more lifes, next level */
	    score += level*4;
	    TDL_Sleep (1000);
	    game_NewLevel ();
            return;
	  }
	}
      }
    } 
    #if (TDL_UDG_MAX > 0)  /* Hires UDG? */
	/* If Dir changed, put in a wall-corner */
      if (oldDir != compDir) TDL_ScreenSet (compPos, CHR_WALL, COL_COMP);
      compPos += compDir;
	/* Work out if we draw Horizontal or Vertical wall */
      ch = CHR_WALLH; 	
      if ((BYTE) (compDir + 1) > 2) ch = CHR_WALLV; 
      TDL_ScreenSet (compPos, ch, COL_COMP);

    #else	/* ASCII/PETSCII */
      compPos += compDir;
      TDL_ScreenSet (compPos, CHR_COMP, COL_COMP);
    #endif
}

#if USE_GUN

void move_Shot ()
{
    BYTE hit;
    // printf ("shot:%d,%d ",shotPos,shotDir);
    if (shotPos == 0) return;
    TDL_SoundOff (1);
    hit = TDL_ScreenGet (shotPos);
    if (hit == CHR_SHOTV || hit == CHR_SHOTH) {
      TDL_ScreenSet (shotPos, CHR_BLANK, TDL_COL_BLACK);
    }
    shotPos += shotDir;
    if (shotPos < TDL_ScreenPos (1,2) || shotPos > TDL_ScreenPos (TDL_VDUX-2, TDL_VDUY-2) ) {
      shotPos = 0;
      return;
    }
    hit = TDL_ScreenGet (shotPos);
    if (hit == CHR_EDGEV || hit == CHR_EDGEH) {
      shotPos = 0;
      return;
    }
    if (hit == CHR_BLANK) {
      hit = CHR_SHOTH;
      if ((BYTE) (shotDir + 1) > 2) hit = CHR_SHOTV;
      TDL_ScreenSet (shotPos, hit, COL_SHOT);
      if (soundflag) {
        TDL_Sound (TDL_SOUND_C4+(shotSound * TDL_SOUND_STEP*2), 1);
        shotSound ++;
      }
    } else {
      TDL_ScreenSet (shotPos, CHR_BLANK, TDL_COL_BLACK);
      shotPos = 0;
    }
}
#endif

void move_Player ()
{
    BYTE key;
    BYTE hit;
    BYTE ch;
    BYTE joy = 0;
    BYTE fire = 0;
    BYTE extend = 0;
    int oldDir = playDir;
moveloop:
    //key = TDL_GetKeyDown ();
    key = TDL_GetKey ();
    key = TDL_TOUPPER (key);	/* Do this separately to getkey */

    #if (TDL_MAX_JOYSTICK > 0)
      joy = TDL_GetJoystick (joystick);
      if (joy & TDL_JOYSTICK_HIT) {
	if ((BYTE) (oldDir + 1) > 2) {		/* Select LR pair */
          if (joy & TDL_JOYSTICK_LEFT)  key = 'O';
          if (joy & TDL_JOYSTICK_RIGHT)  key = 'P';
	} else {
          if (joy & TDL_JOYSTICK_UP)  key = 'Q';
          if (joy & TDL_JOYSTICK_DOWN)  key = 'A';
	}
      }
    #endif

    switch (key) {

      case 'K':		/* Quit */
      case 27:
	gameover = TRUE;
	return;

      case 'R':
      case 'Q':
        playDir = -TDL_VDUX;
        break;

      case 'C':
      case 'A':
        playDir = TDL_VDUX;
        break;

      case 'D':
      case 'O':
        playDir = -1;
        break;

      case 'F':
      case 'P':
        playDir = 1;
        break;

      case 'H':		/* Halt/Pause */
        do {
          TDL_Sleep (20);
          key = TDL_GetKey ();
        } while (key != 32);
        break;
    }

    hit = TDL_ScreenGet (playPos + playDir);
    if (hit != CHR_BLANK && hit != CHR_BONUS && hit != CHR_AMMO) {	/* Dont allow the human turn into hazard */
      playDir = oldDir;
    }
	/* If Dir changed, put in a wall-corner */
    if (oldDir != playDir) TDL_ScreenSet (playPos, CHR_WALL, COL_PLAY);
    hit = TDL_ScreenGet (playPos + playDir);
    switch (hit) {
      case CHR_BLANK:
	break;

      case CHR_BONUS:		/* Collect Bonus target (heart) */
        score += level*4;
        game_Sound ();
	game_DrawText ();
	break;

      #if USE_GUN
       case CHR_AMMO:		/* Collect ammo */
        score += level;
        nshot ++;
        game_Sound ();
	game_DrawText ();
	break;

       case CHR_SLOW:		/* Collect Slow pill */
        score += level;
        nslow ++;
	game_DrawText ();
	break;

      #endif

      default:      /* Must be a wall, mine, edge.. */
        if (extend == 0) {	/* Give user a little more time to move */
	  extend = 1;
	  TDL_Sleep (150);
	  goto moveloop;
	}
        gameover = TRUE;
        for (hit = 0; hit < 10; hit ++) {
          TDL_ScreenSet (playPos, CHR_BLANK, COL_PLAY);
          game_Sound ();
	  TDL_Sleep (30);
          TDL_ScreenSet (playPos, CHR_WALL, COL_PLAY);
	  TDL_Sleep (30);
          TDL_SoundOff (1);
        }
	TDL_Sleep (2000);
        return;
    }
    playPos += playDir;
	/* Work out if we draw Horizontal, Vertical or Corner Wall */
    ch = CHR_WALLH; 	
    if ((BYTE) (playDir + 1) > 2) ch = CHR_WALLV; 
    TDL_ScreenSet (playPos, ch, COL_PLAY);
    #if USE_GUN
      fire = TDL_GetKey_Shift () & TDL_SHIFT_LR;
      #if (TDL_MAX_JOYSTICK > 0)
	if (joy & TDL_JOYSTICK_FIRE) fire ++;
      #endif
      if (fire && nshot && shotPos == 0) {	/* Fire a shot */
	shotPos = playPos; 
	shotDir = playDir;
	shotSound = 0;
	nshot --;
	game_DrawText ();
      }
    #endif
    return ;
}

void game_Loop ()
{
    while (1) {
      #if USE_TITLE_SCREEN
	if (game_help () ) return;
      #endif
      game_NewGame ();
      while (gameover == 0) {
        move_Player ();
	if (gameover) break;
        #if USE_GUN
	  move_Shot ();
	  move_Delay ();
	  move_Shot ();
	  move_Delay ();
	#else
	  move_Delay ();
	  move_Delay ();
	#endif
        TDL_SoundOff (1);
	move_Computer ();
        #if USE_GUN
	  move_Shot ();
	  move_Delay ();
	  move_Shot ();
	  move_Delay ();
	#else
	  move_Delay ();
	  move_Delay ();
	#endif
      }
      if (score > hiscore) hiscore = score;
    }
}

#if USE_TITLE_SCREEN

#if TDL_VDUX < 32	/* Minimal title screen */

char szHelp[] =
	"   " PROG_NAME "\n\n"
	"Keys QAOP/RCDF steer\n\n"
        "or Joy. SHIFT=Fire\n"
	"\n\nHit SPACE\n\n";

BYTE helpkey;

BYTE game_help ()
{
    UINT p;
help_loop:
    TDL_ScreenClr ();
    TDL_Ink ( TDL_COL_YELLOW);
    TDL_PrintStr (szHelp);
    TDL_Ink ( TDL_COL_PURPLE);
    TDL_PrintSI ( " HI:",   hiscore);  TDL_PrintChar ('0');
    TDL_PrintSI ( "\n Tempo (T):",tempo);
    do { 
      helpkey = TDL_GetKey ();
      helpkey = TDL_TOUPPER(helpkey);
      if (helpkey == 'T') {
	tempo = (tempo & 3) + 1;
	goto help_loop;
      }
    } while (helpkey != 32);
    return 0;
}

#else		/* >=32 cols, Full Help */

char szHelp[] =
	"\nOut-wall the computer!\n"
	"Use Joystick, or keys QAOP\n"
	"or RCDF moves Up/Down/Left/R\n"
        "Use SHIFT to fire.\n"
	"K = Quit, H = Pause.\n\n"
	"Collect bonuses for points.\n"
	"Collect Ammo for Gun.\n"
        "Hit T now to change tempo,\n"
        "S for sound, J for Joystick.\n"
	"\n";

BYTE helpkey;
  
BYTE game_help ()
{
    TDL_ScreenClr ();
help_loop:
    #if TDL_VDUX > 30		/* Center help text */
      TDL_SetLeftMargin ( (TDL_VDUX - 26) / 2);
    #endif
    
    TDL_GotoXY ((TDL_VDUX - 14)/2,3);
    TDL_Ink ( TDL_COL_WHITE);
    TDL_PrintStr ( PROG_NAME);
    TDL_Ink ( TDL_COL_BLUE);
    TDL_PrintStr ( "\n\n(C) A.MILLETT 2026,FREE/GPL3\n");
    TDL_Ink ( TDL_COL_YELLOW);
    TDL_PrintStr (szHelp);
    TDL_Ink ( TDL_COL_GREEN);
    TDL_PrintSI ( " High Score:",   hiscore);  TDL_PrintChar ('0');
    TDL_Ink ( TDL_COL_PURPLE);
    TDL_PrintSI ( "\n\n Tempo (T):",tempo);
    TDL_PrintSI ( "  Sound (S):",soundflag);
    #if (TDL_MAX_JOYSTICK > 1)
      TDL_PrintSI ( "\n JOY (J):",joystick+1); 
    #endif
    TDL_Ink (TDL_COL_CYAN);
    TDL_PrintStr ( "\n\n  HIT SPACE");
    game_Border (0);
    while (TDL_GetKey ()) {};	/* Clr keyboard buffer */

    do { 
      TDL_Rand ();	/* Randomise */
      helpkey = TDL_GetKey ();
      helpkey = TDL_TOUPPER(helpkey);
      if (helpkey == 'T') {
	tempo = (tempo & 3) + 1;
	goto help_loop;
      }
      if (helpkey == 'S') {
	soundflag = !soundflag;
	goto help_loop;
      }
      #if TDL_RAM > 64
        if (helpkey == 27 || TDL_RequestQuit == TRUE) return 1;  /* Request quit (window close) */
      #endif
      #if (TDL_MAX_JOYSTICK > 0)
        #if (TDL_MAX_JOYSTICK > 1)
          if (helpkey == 'J') {
	    joystick ^= 1;	/* J=Flip joysticks */
	    goto help_loop;
	  }
	#endif
      #endif
      TDL_Sleep (20);
    } while (helpkey != 32);
    TDL_SetLeftMargin (0);
    return 0;
}

#endif

#endif		/* USE_TITLE_SCREEN */

int main ()
{
    srand (2);
    TDL_Initialise (0,NULL);
     #if (TDL_UDG_MAX > 0)	/* Are UDG gfx available? If so, set up.. */
      TDL_UDG_Init (pPix, TDL_UDG_START, sizeof (pPix));
     #endif

    TDL_SoundInit ();
    game_Loop ();	/* Main game loop */
    return 0;

}

