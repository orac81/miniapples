#!/bin/sh
#  Build TDL SDL2 demo programs..
./tdlmaksdl.sh skattabugz/skattabugz -Os -D TDL_VDUX=24 -D TDL_VDUY=14   
mv skattabugz/skattabugz-sdl.elf skattabugz/skattabugz-big-sdl.elf
./tdlmaksdl.sh skattabugz/skattabugz -Os 
./tdlmaksdl.sh addix/addix     -Os 
./tdlmaksdl.sh dynajim/dynajim -Os 
./tdlmaksdl.sh wallrun/wallrun     -Os 
./tdlmaksdl.sh demo/tplasma    -Os -D TDL_VDUX=128 -D TDL_VDUY=64
mv demo/tplasma-sdl.elf demo/tplasma-128x64-sdl.elf
./tdlmaksdl.sh demo/tplasma    -Os
./tdlmaksdl.sh demo/hello      -Os 
./tdlmaksdl.sh demo/test-udg   -Os 
./tdlmaksdl.sh demo/tsound     -Os 
# ./tdlmaksdl.sh demo/radial3d     -Os 
# ./tdlmaksdl.sh demo/tlife1d     -Os 
# ./tdlmaksdl.sh demo/hisimple     -Os 
mv demo/*.elf demo/bin
