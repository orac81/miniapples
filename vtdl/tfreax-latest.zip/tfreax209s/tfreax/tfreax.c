/* TFREAX - a small fast paced game for TDL. 
   (C) A.Millett 2012-2026. Released as free software under GPL3.

take skattabugz133, 26.7.2026, adaapt for TFREAX.
  Imp minimal playable game derived from skattabugz.
  Remove hearts, imp nlifes, alien array, move down.
-> tfreax201  6.8.2026
  Adjust calien when deleting alien for correct animation.
-> tfreax202  7.8.2026
  Imp shelters,mode, alien dir table, new gfx.  
-> tfreax203  8.8.2026
  Imp assort features, bonus alien..
-> tfreax204  9.8.2026
  Better gfx
-> tfreax205  11.8.2026
  Better gfx
-> tfreax206  16.8.2026
-> tfreax207  18.8.2026
  Trim a few bytes for v20 ver
-> tfreax208  19.8.2026
  Tidy title screen, add border anim.
-> tfreax209  19.8.2026
  
todo: joystick, shift=fire,  Sound, bombs, Flyback sync, Better title screen,
      Icons, VCBCC. Vic20-8K, C128, CPC, BBC, C16. PET, ZX, DOS, SDL. 

To build: sh/tdlmakosc.sh  tfreax/tfreax -Os -Oz -Op -Oo  

or: oscar64 -D TDL_CBM -D TDL_C64=1 -D IS_OSCAR=1 -O2 -tm=c64 tfreax.c -o=tfreax-c64.prg

*/  

#define PROG_NAME "TFREAX 2.09"

#ifdef TDL_VIC20	/* Save a little memory */
 #define TDL_IO_SYS 1		/* Set TDL_IO_CON, TDL_IO_SYS or TDL_IO_DIRECT */
#else
 #define TDL_IO_DIRECT 1
#endif

#ifdef TDL_PATH		/* User sets TDL_PATH */
 #include TDL_PATH
#else
 #include "../tdl/tdl.c"
#endif

//#define PROG_DEBUG   TRUE		/* Add some debug features (or: -D PROG_DEBUG=1) */
//#define ALLOW_CHEAT    TRUE		/* allow N to skip level */
#define ADD_SHELTERS   TRUE
#define ADD_BONUS      TRUE		/* Add bonus special alien target */

#if (TDL_RAM >= 8 && TDL_UDG_MAX > 32)
 #define FULL_VERSION   TRUE		/* Add extra features */
#else
 #define FULL_VERSION   FALSE
#endif

#if (TDL_RAM < 8)
 #define VAR_SPEED      TRUE
#else
 #define VAR_SPEED      TRUE
#endif

/*-----------------------------------------------------------------------
   game_ playing code..
-------------------------------------------------------------------------*/

BYTE pPix[] = {
  //  "tfreax/tfreax3.bmp" size 96 x 32, Bitdepth=1, #char: 12 x 4
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,  // chr:1
  0x92,0x44,0x28,0x82,0x28,0x44,0x92,0x00,  // chr:2
  0xaa,0x55,0xaa,0x55,0xaa,0x55,0xaa,0x55,  // chr:3
  0x00,0x00,0x00,0x40,0xa2,0x55,0xaa,0x55,  // chr:4
   // Alien (10x8, 4x2 chars) phase 0-3
  0x7f,0xff,0xcc,0xcc,0x7f,0x40,0x40,0x21,  // chr:5
  0x80,0xc0,0xc0,0xc0,0x80,0x80,0x80,0x00,  // chr:6
  0x1f,0x3f,0x33,0x33,0x1f,0x08,0x08,0x10,  // chr:7
  0xe0,0xf0,0x30,0x30,0xe0,0x40,0x40,0x20,  // chr:8
  0x07,0x0f,0x0c,0x0c,0x07,0x01,0x01,0x02,  // chr:9
  0xf8,0xfc,0xcc,0xcc,0xf8,0x20,0x20,0x10,  // chr:10
  0x01,0x03,0x03,0x03,0x01,0x00,0x00,0x00,  // chr:11
  0xfe,0xff,0x33,0x33,0xfe,0x84,0x84,0x48,  // chr:12
   // Player Base (10x8, 4x2 chars) phase 0-3
  0x0c,0x1e,0x7f,0xff,0xff,0xff,0xff,0xc0,  // chr:13
  0x00,0x00,0x80,0xc0,0xc0,0xc0,0xc0,0xc0,  // chr:14
  0x03,0x07,0x1f,0x3f,0x3f,0x3f,0x3f,0x30,  // chr:15
  0x00,0x80,0xe0,0xf0,0xf0,0xf0,0xf0,0x30,  // chr:16
  0x00,0x01,0x07,0x0f,0x0f,0x0f,0x0f,0x0c,  // chr:17
  0xc0,0xe0,0xf8,0xfc,0xfc,0xfc,0xfc,0x0c,  // chr:18
  0x00,0x00,0x01,0x03,0x03,0x03,0x03,0x03,  // chr:19
  0x30,0x78,0xfe,0xff,0xff,0xff,0xff,0x03,  // chr:20
   // Player Missile (8x8, 4 chars, phase 0-3)
  0x40,0x40,0x40,0x40,0x40,0x40,0x40,0x40,  // chr:21
  0x10,0x10,0x10,0x10,0x10,0x10,0x10,0x10,  // chr:22
  0x04,0x04,0x04,0x04,0x04,0x04,0x04,0x04,  // chr:23
  0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,  // chr:24
	// Alien Bomb (8x8, 4 char, phase 0-3)
  0x18,0x10,0x00,0x00,0x00,0x00,0x00,0x00,  // chr:25
  0x00,0x00,0x18,0x08,0x00,0x00,0x00,0x00,  // chr:26
  0x00,0x00,0x00,0x00,0x08,0x18,0x00,0x00,  // chr:27
  0x00,0x00,0x00,0x00,0x00,0x00,0x10,0x18,  // chr:28

#if FULL_VERSION
	// Alien 2
  0x0c,0x1e,0x33,0x69,0xb3,0x3f,0x21,0x10,  // chr:29
  0x00,0x00,0x40,0x80,0x00,0x00,0x00,0x80,  // chr:30
  0x03,0x07,0x0c,0x39,0x0c,0x0f,0x08,0x08,  // chr:31
  0x00,0x80,0xc0,0x70,0xc0,0xc0,0x40,0x40,  // chr:32
  0x00,0x01,0x0b,0x06,0x03,0x03,0x02,0x04,  // chr:33
  0xc0,0xe0,0x30,0x98,0x34,0xf0,0x10,0x20,  // chr:34
  0x00,0x00,0x00,0x03,0x00,0x00,0x00,0x00,  // chr:35
  0x30,0x78,0xcc,0x97,0xcc,0xfc,0x84,0x84,  // chr:36

/*	// Alien 2
  0x0c,0x0c,0x3f,0x6d,0xbf,0x3f,0x21,0x12,  // chr:37
  0x00,0x00,0x40,0x80,0x00,0x00,0x00,0x00,  // chr:38
  0x07,0x03,0x0f,0x3b,0x0f,0x0f,0x08,0x08,  // chr:39
  0x80,0x00,0xc0,0x70,0xc0,0xc0,0x40,0x40,  // chr:40
  0x03,0x00,0x0b,0x06,0x03,0x03,0x02,0x04,  // chr:41
  0xf0,0xc0,0xf0,0xd8,0xf4,0xf0,0x10,0x08,  // chr:42
  0x00,0x00,0x00,0x03,0x00,0x00,0x00,0x00,  // chr:43
  0x78,0x30,0xfc,0xb7,0xfc,0xfc,0x84,0x84,  // chr:44
*/

#endif 
0};
  

#define ALIEN_TOP  2		/* Alien top/bot rows */
#if TDL_VDUX < 32 
 #define ALIEN_BOT  (TDL_VDUY-11)
#else
 #define ALIEN_BOT  (TDL_VDUY-10)
#endif

#define ALIEN_MAX (ALIEN_BOT-ALIEN_TOP+1)*((TDL_VDUX)/6)   	/* Max # aliens*/
#define ALIEN_XMAX TDL_VDUX*4-6		/* Max X alien pos (in 1/4 chars) */
#define ALIEN_RIGHT 1			/* alien is moving right */
#define ALIEN_LEFT  2
#define ALIEN_FAST  4		/* Alien double speed */
#define ALIEN_TYPE  8		/* Alien needs 2 bullets */
#define ALIEN_CHANGE_DIR(DIR) (3^(DIR))
#define ALIEN_TYPE 8 
#define BOMB_MAX 8

  // UDG poke codes
#define CHR_SPC     TDL_CHR_ASC32
#define CHR_BANG    (TDL_UDG_START+1)
#define CHR_SHELTER (TDL_UDG_START+2)
#define CHR_ALIEN   (TDL_UDG_START+4)
#define CHR_PLAYER  (TDL_UDG_START+12)
#define CHR_MISSILE (TDL_UDG_START+20)
#define CHR_BOMB    (TDL_UDG_START+24)

#if FULL_VERSION
 #define CHR_ALIEN2   (TDL_UDG_START+28)	// 2nd alien type
#else
 #define CHR_ALIEN2   (TDL_UDG_START+4)
#endif

  // If char alien?
#define CHR_IS_ALIEN(ch) ((ch >= CHR_ALIEN && ch < CHR_ALIEN+8) || (ch >= CHR_ALIEN2 && ch < CHR_ALIEN2+8))

   // Colours for above
#define COL_BANG    TDL_COL_RED
#define COL_SHELTER TDL_COL_CYAN
#define COL_ALIEN   TDL_COL_YELLOW
#define COL_ALIEN2  TDL_COL_PURPLE
#define COL_PLAYER  TDL_COL_WHITE
#define COL_MISSILE TDL_COL_CYAN

#define VOX_MISSILE 2
#define VOX_ALIEN   0

#define PLAYER_Y TDL_VDUY-1	/* Player Y max pos */

#define BONUS_Y   1		/* Mother ship Y pos */ 

#define SHELTER_WIDTH (2 + 2*(TDL_VDUX/32))
#define SHELTER_HEIGHT 3
#define SHELTER_TOPY  (TDL_VDUY - 5)

#define PLAY_FAST    4		/* Double speed */
#define PLAY_CLASSIC 8		/* Classic alien movement */
BYTE playmode = 1 + (TDL_VDUX > 30);		/* speed 0-3, 4=fast, 8=classic */
BYTE cframe=0;			/* Frame counter */
BYTE sound = TRUE;
BYTE calien;
BYTE naliens;

#if TDL_RAM < 8 && defined (TDL_FREE_RAM)		/* Limit for 5k Vic20 */
  BYTE *alienx   = (BYTE *) TDL_FREE_RAM;   		/* Use tape buffer for alien pos tables */
  BYTE *alieny   = (BYTE *) TDL_FREE_RAM+ALIEN_MAX;  
  BYTE *aliendir = (BYTE *) TDL_FREE_RAM+ALIEN_MAX*2;
#else		// Alien position tables
  BYTE alienx   [ALIEN_MAX+1];	/* 0..(TDL_VDUX*4)-1 */
  BYTE alieny   [ALIEN_MAX+1];	/* 0..TDL_VDUY-1 */
  BYTE aliendir [ALIEN_MAX+1];
#endif

BYTE alienrev ; 		/* Reverse alien dir */
BYTE alienhalt = 0;		/* Freeze descent of alien for # sweeps */

	// Table bits indicates directions of alien rows for levels (wraps after 8)
BYTE tab_alien_dir[8] = {0, 0xE0, 0, 0xAA, 0xCC, 0xAA, 0xC8, 0x40};
//  .BYTE %10101010, %00000000, %11001100, %11100000, %10101010, %11001000, %01000000, %00000000

 BYTE bombx [BOMB_MAX];
 BYTE bomby [BOMB_MAX];
 BYTE nbombs;
BYTE playerx;
BYTE missilex,missiley;		/* Player Missile pos (y=0=none) (x=4 phase) */
UINT score;			/* Flayer score */
UINT hiscore=0;
BYTE level;
BYTE nlifes;
BYTE crand = 0;		/* Current rand# */
BYTE pulse=1;
BYTE joystick = 0;	/* Current joystick (0,1) */
BYTE bonusx = 0;		/* Mother ship Xpos, 0=none */
BYTE bonusdir = 0;

#ifdef PROG_DEBUG	/* Used to show FPS */
  UINT ntime = 0;
  UINT nframe = 0;
#endif

void alien_draw (BYTE x, BYTE y, BYTE col, BYTE chr);
void score_update ();
void player_loose_life ();
void game_Init ();
void bonus_hit ();

void game_SoundOff ()
{
    TDL_SoundOff (VOX_MISSILE);
    TDL_SoundOff (VOX_ALIEN);
}

void score_update ()
{
    UINT pos;
    TDL_GotoXY (1,1);
    TDL_PrintInt (score);
    TDL_PrintChar ('0');
    #ifdef ALLOW_CHEAT
     TDL_PrintSI (" ",ALIEN_MAX);
    #endif
    pos= TDL_ScreenPos(TDL_VDUX-11,0);
    TDL_ScreenSet (pos, CHR_ALIEN, TDL_COL_CYAN); 
    TDL_ScreenSet (pos+1, CHR_ALIEN+1, TDL_COL_CYAN); 
    TDL_GotoXY (TDL_VDUX-7,1);
    TDL_PrintInt (level);
    //TDL_GotoXY (8,1); TDL_PrintInt (nlifes);
    TDL_ScreenSet (pos+7, CHR_PLAYER, TDL_COL_CYAN); 
    TDL_ScreenSet (pos+8, CHR_PLAYER+1, TDL_COL_CYAN); 
    TDL_GotoXY (TDL_VDUX-1,1);
    TDL_PrintInt (nlifes);
}

#if (TDL_VDUX < 32 || TDL_RAM < 8) 	/* Adjust help for ram/screen size */
  
char szHelp[] = 
  PROG_NAME
  "\n\n(C)A.MILLETT 2026\n\n"
  "KEYS I,P,SHIFT\n"
  "OR JOYSTICK\n\n"
  "HIT SPACE\n\n"
  //"\n\0" "1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890" // 100 Bytes test filler
  "";

	/* Minimal help */
void game_help ()
{
    BYTE helpkey;
    TDL_ENABLE_TEXT ;	 	/* Request text */
help_loop:
    TDL_ScreenClr ();
    TDL_Ink (TDL_COL_YELLOW);
    TDL_PrintStr (szHelp);
    TDL_Ink (TDL_COL_PURPLE);
    TDL_PrintSI ((char *) "HI:",   hiscore);  TDL_PrintChar ('0');
    #if VAR_SPEED
      TDL_PrintSI ((char *) "\nMODE (M):",playmode);
    #endif
    do { 
      helpkey = TDL_GetKey ();
      #if VAR_SPEED
        helpkey = TDL_TOUPPER(helpkey);
        if (helpkey == 'M') {
	  playmode = (playmode + 1) & 15;
	  goto help_loop;
        }
      #endif
    } while (helpkey != 32);
    TDL_ENABLE_UDG ;	 	/* Request UDG */
}

#else /* Wider screen, full help */

char szHelp[] = 
  "Use Joystick or:\n\n"
  "  I,P = Move L/R\n"
  "  SHIFT = FIRE\n"
  "  X = Quit\n\n"
  "Hit M to change mode/speed.\n"
  "(0-7 Speed, +8 Classic)\n"
  "\n";

BYTE tcol[4] = {TDL_COL_WHITE, TDL_COL_PURPLE, TDL_COL_CYAN, TDL_COL_YELLOW};

void game_Border ()
{
    BYTE x,y,ch,col;
    //cframe = (cframe + 1) & 63;
    cframe ++;
    for (x=0; x<TDL_VDUX; x++) {
      ch = (cframe & 3)*2 + ((cframe/4+x) & 1) ;
      //col = TDL_COL_WHITE; 
      col = tcol [((64+x-cframe/4)/2) & 3];
      TDL_ScreenSetXY (x, 0, CHR_ALIEN + ch, col);       
      TDL_ScreenSetXY (x, TDL_VDUY-1, CHR_ALIEN2 + ch, col);       
    }
    //TDL_GotoXY (1,2); TDL_PrintSI ((char *) "Z:",z);
    TDL_Sleep (100);
    TDL_FrameSync ();		/* Sync animation to frame */
}
  
void game_help ()
{
    BYTE helpkey;
    //TDL_ENABLE_TEXT ;	 	/* Request text */
    #if TDL_VDUX > 30		/* Center help text */
      TDL_SetLeftMargin ( (TDL_VDUX - 30) / 2);
    #endif
    TDL_ScreenClr ();
help_loop:
    TDL_GotoXY (1,1);
    TDL_Ink (TDL_COL_WHITE);
    TDL_PrintStr ("\n\n     " PROG_NAME);
    TDL_Ink (TDL_COL_BLUE);
    TDL_PrintStr ("\n\n(C) A.Millett 2026, Free/GPL3\n\n");
    TDL_Ink (TDL_COL_YELLOW);
    TDL_PrintStr (szHelp);
    TDL_Ink (TDL_COL_PURPLE);
    TDL_PrintSI ( "  High:",   hiscore);  
    if (hiscore) TDL_PrintChar ('0');
    #if VAR_SPEED
      TDL_PrintSI ( "\n  Mode (M):",playmode);
      TDL_PrintChar (' ');
    #endif
    #if (TDL_MAX_JOYSTICK > 1)
      TDL_PrintSI ("\n  Joy (J):",joystick+1); 
    #endif
    TDL_Ink (TDL_COL_CYAN);
    TDL_PrintStr ((char *) "\n\nHit SPACE to play");
    //while (TDL_GetKey ()) {};	/* Clr keyboard buffer */

    do { 
      helpkey = TDL_GetKey ();
      helpkey = TDL_TOUPPER(helpkey);
      #if VAR_SPEED
        if (helpkey == 'M') {
	  playmode = (playmode + 1) & 15;
	  goto help_loop;
        }
      #endif
      #if TDL_RAM > 64
        if (helpkey == TDL_KEY_ESC) exit (0);
        if (TDL_RequestQuit == TRUE) exit (0);  /* Request quit (window close) */
      #endif
      #if (TDL_MAX_JOYSTICK > 0)
        // if (TDL_GetJoystick (joystick) & TDL_JOYSTICK_FIRE) break;  
        #if (TDL_MAX_JOYSTICK > 1)
          if (helpkey == 'J') {
	    joystick ^= 1;	/* J=Flip joysticks */
	    goto help_loop;
	  }
	#endif
      #endif
      //if (helpkey) TDL_PrintSI (",",helpkey);
      game_Border ();
    } while (helpkey != 32);
    TDL_SetLeftMargin (0);
    //TDL_ENABLE_UDG ;	 	/* Request UDG */
    TDL_ScreenClr ();
}

#endif

void game_new_level ()
{
    BYTE x,y,r,d;
    BYTE tad;
    BYTE nrow;
    UINT pos;
	/* Initialise alien pos */
    game_SoundOff ();
    TDL_Sleep (500);
    TDL_ScreenClr ();
    #if ADD_SHELTERS	// Draw shelters
      for (y=0; y < SHELTER_HEIGHT; y++) {
        pos = TDL_ScreenPos (0,SHELTER_TOPY + y);
        for (x=0; x < SHELTER_WIDTH; x++) {
	  //TDL_ScreenSet (pos+TDL_VDUX/8, CHR_SHELTER, COL_SHELTER);
	  //TDL_ScreenSet (pos+(TDL_VDUX - SHELTER_WIDTH)/2, CHR_SHELTER, COL_SHELTER);
	  //TDL_ScreenSet (pos+TDL_VDUX-SHELTER_WIDTH-TDL_VDUX/8, CHR_SHELTER, COL_SHELTER);
          //pos ++;
	  TDL_ScreenSetXY (TDL_VDUX/8+x, SHELTER_TOPY + y, CHR_SHELTER, COL_SHELTER);
	  TDL_ScreenSetXY ((TDL_VDUX - SHELTER_WIDTH)/2+x, SHELTER_TOPY + y, CHR_SHELTER, COL_SHELTER);
	  TDL_ScreenSetXY (TDL_VDUX-SHELTER_WIDTH-TDL_VDUX/8+x, SHELTER_TOPY + y, CHR_SHELTER, COL_SHELTER);
        }
      }
    #endif
    level ++;
    if ((level & 7) == 0) nlifes ++;     /* Bonus life */
    tad = tab_alien_dir [level & 7];
    missiley = 0;
    alienhalt = 0;
    bonusx = 0;
    calien = 0;
    naliens = 0;
    alienrev = 0;
    nbombs = 0;
    nrow = (ALIEN_BOT - ALIEN_TOP) / 2;
    for (r=0; r < nrow; r++) {
      d = ALIEN_LEFT;
      if ((tad & 0x80) || (playmode & PLAY_CLASSIC)) d = ALIEN_RIGHT; 
      tad = tad << 1;
      if (r < (1+level/4)) d |= ALIEN_TYPE;
      y = r*2 + ALIEN_TOP + (level & 7);
      for (x=TDL_VDUX-2; x<TDL_VDUX*3+2; x+=9) {
        if (naliens> ALIEN_MAX-2) break;
        alienx [naliens] = x;
        alieny [naliens] = y;
        aliendir [naliens] = d;
        //alien_draw (x, y, COL_ALIEN, CHR_ALIEN);
        naliens ++;
      }
      d = ALIEN_CHANGE_DIR (d);
    }
    score_update ();
}

void game_new ()
{
    BYTE x,y;
    UINT p;
    playerx = 16;
    score = 0;
    level = 0;
    nlifes = 4;
    game_new_level ();
}

void bomb_drop (BYTE bx, BYTE by)
{
    UINT pos;
    if (nbombs >= BOMB_MAX) return;
    bx = (bx+2)/4; by = (by+1)*4;
    pos = TDL_ScreenPos (bx,by/4);
    if (TDL_ScreenGet (pos) != CHR_SPC) return;
    bombx[nbombs] = bx;
    bomby[nbombs] = by;
    nbombs ++;
}

  /* Ripple del bomb */ 
void bomb_remove (BYTE cb)
{
    nbombs --;
    #ifdef PROG_DEBUG
      // TDL_ScreenSet (TDL_ScreenPos (TDL_VDUX/2,0),48+nbombs, TDL_COL_YELLOW);
    #endif
    for (;cb < nbombs; cb++) {
      bombx [cb] = bombx [cb+1];
      bomby [cb] = bomby [cb+1];
    }
}

void bomb_move (BYTE clr)
{
    UINT pos;
    BYTE cb,bx,by;
    BYTE ch;
    for (cb = 0; cb<nbombs; cb++) {
      bx = bombx [cb]; by = bomby [cb]; 
      pos = TDL_ScreenPos (bx,by/4);
      TDL_ScreenSetNC (pos, CHR_SPC);
      if (clr) continue;
      by ++;
      if (by > TDL_VDUY*4-2) {		/* Bottom of screen */
	bomb_remove (cb);
	return ;
      }
      pos = TDL_ScreenPos (bx,by/4);
      ch = TDL_ScreenGet (pos);
      if (ch != CHR_SPC) {
        if (ch >= CHR_PLAYER && ch < CHR_PLAYER + 8) {	// Bomb hit player?
	  bomb_remove (cb);
	  player_loose_life ();
	  return ;
	}
        #if ADD_SHELTERS	// Hit shelters
          if (ch == CHR_SHELTER) {	// Bomb hit shelter?
            TDL_ScreenSet (pos, CHR_SHELTER+1, COL_SHELTER);
          }
          if (ch == CHR_SHELTER+1) {	// Bomb hit shelter?
            TDL_ScreenSetNC (pos, CHR_SPC);
          }
        #endif
    
	bomb_remove (cb);
        return ;
      }
      TDL_ScreenSet (pos, CHR_BOMB+(by & 3), TDL_COL_CYAN);
      bomby [cb] = by;
    }
    return ;
}

  /* Convert scaled x,y to screen pos */
UINT game_xy2pos (BYTE x, BYTE y)
{
   return TDL_ScreenPos((x/4),((UINT) y));
}

  /* Draw alien in 4 phase pos (X=0..TDL_VDUX*4) */
void alien_draw (BYTE x, BYTE y, BYTE col, BYTE chr)
{
    UINT pos;
    BYTE c;
    pos = game_xy2pos (x,y);
    c = (x&3)*2;
    TDL_ScreenSet (pos,   chr+c,   col); 
    TDL_ScreenSet (pos+1, chr+1+c, col); 
}
  
void alien_clr (BYTE x, BYTE y)
{
    UINT pos;
    pos = game_xy2pos (x,y);
    TDL_ScreenSetNC (pos, CHR_SPC); 
    TDL_ScreenSetNC (pos+1, CHR_SPC);
}


void alien_move ()
{
    BYTE cm;
    UINT pos;
    BYTE ch;
    BYTE nmove; 
    BYTE y;
    BYTE alx,aly,aldir;
    BYTE col;

    #if TDL_VDUX < 32			/* Adjust mode for screen size */
      nmove = (playmode & 3)+level/8;    	/* Calc how many aliens to move per frame (1/60sec) */
      if (nmove == 0 ) {		/* 0=move on alternate frames */
        if (cframe & 1) return;
        nmove = 1;
      }
      if (nmove > naliens) nmove = naliens;
    #else
      nmove = (playmode & 3)+1+level/8;
      if (nmove > naliens*2) nmove = naliens*2;
    #endif
    for (cm=0; cm<nmove; cm ++) {
      if (calien >= naliens) {		/* Loop back to start.. */
        if (alienrev) {			/* Reverse dir move down*/
          for (calien = 0; calien < naliens; calien ++) {
	    aliendir [calien] = ALIEN_CHANGE_DIR (aliendir [calien]);
            ch = CHR_ALIEN; col = COL_ALIEN; 
            if (aliendir [calien] & ALIEN_TYPE) {
	      ch = CHR_ALIEN2; col = COL_ALIEN2;
            }
            alien_clr (alienx [calien], alieny [calien]);
            if (alienhalt == 0) alieny [calien] ++;
            if (alieny [calien] >= PLAYER_Y) {
              nlifes = 0;	/* Game over */
	      col = TDL_COL_RED;
            }
            alien_draw (alienx [calien], alieny [calien], col, ch); 
          }
          alienrev = FALSE;
          if (alienhalt) {
            alienhalt --;
          }
        }
        calien = 0; //nmove = 0;
	pulse ++;
        if (sound && (pulse & 3) == 0) {
	  TDL_Sound (TDL_SOUND_C4 + (pulse & 31) * TDL_SOUND_STEP, VOX_ALIEN);
	}
        if (nlifes == 0 ) return;
      }

      aldir = aliendir [calien]; 
      alx = alienx [calien]; 
      aly = alieny [calien]; 
        if (aldir & ALIEN_RIGHT) {
          alx ++;
          if ((alx & 3) == 0) {			/* New square */
            pos = game_xy2pos (alx,aly)+1;
            TDL_ScreenSetNC (pos-2, CHR_SPC);	 /* Del trailing char */
	    ch = TDL_ScreenGet (pos);
          } 
	  if (alx >= ALIEN_XMAX-1) alienrev = TRUE;	/* Stop at right edge */
        } else {	/* must be ALIEN_LEFT */
          alx --;
          if ((alx & 3) == 3) {			/* New square */
            pos = game_xy2pos (alx,aly);
            TDL_ScreenSetNC (pos+2, CHR_SPC);	 /* Delete trailing char */
	    ch = TDL_ScreenGet (pos);
	  }
	  if (alx < 1) alienrev = TRUE;
        }
		/* Update position */
        ch = CHR_ALIEN; col = COL_ALIEN; 
        if (aldir & ALIEN_TYPE) {
	  ch = CHR_ALIEN2; col = COL_ALIEN2;
        }
        alien_draw (alx, aly, col, ch);
      alienx [calien] = alx; 
      alieny [calien] = aly; 
		/* Drop a bomb? */
      if (((BYTE) rand()) < level+1) bomb_drop (alx,aly);
      calien ++;
    }
}

  /* Missile has hit alien, remove it */
void alien_kill ()
{
    BYTE kalien,d;
    BYTE alx,aly;
    for (kalien = 0; kalien < naliens; kalien ++) {
      aly = alieny [kalien];
      if (aly == missiley) {
        alx = alienx [kalien];
        if ((BYTE) (missilex-alx) < 7) {
          score += level;
          if (aliendir [kalien] & ALIEN_TYPE) {		/* Double hit needed */
            aliendir [kalien] ^= ALIEN_TYPE;
	  } else {
            alien_clr (alx,aly);
		/* ripple delete alien from table */
	    for (d=kalien; d < naliens; d ++) {
	      aliendir [d] = aliendir [d+1]; 
	      alienx   [d] = alienx   [d+1]; 
	      alieny   [d] = alieny   [d+1]; 
            }
            if (calien > kalien) calien --;	/* Adjust calien move index for correct animation */
	    naliens --;
	  }
	  missiley = 0;
	  TDL_SoundOff (VOX_MISSILE);
	  return;
        }
      }
    }
        /* This part should never be reached! */
}

void missile_move ()
{
    UINT pos;
    BYTE ch;
    if (missiley == 0) {
      game_SoundOff ();
      return;
    }
    pos = game_xy2pos (missilex, missiley);
    ch = TDL_ScreenGet (pos);
    if (ch >= CHR_MISSILE && ch < CHR_MISSILE+4) TDL_ScreenSetNC (pos, CHR_SPC); 
    if (sound) {
      TDL_Sound (TDL_SOUND_C4+(missiley * TDL_SOUND_STEP*4), VOX_MISSILE);
    }
    missiley --;
    if (missiley == 0) return;
    pos = game_xy2pos (missilex, missiley);
    ch = TDL_ScreenGet (pos);
    if (CHR_IS_ALIEN (ch)) {
      #if ADD_BONUS
        if (missiley == BONUS_Y) {
          bonus_hit ();
        }
      #endif
      alien_kill ();	/* kill alien at missilex,missiley */
      score_update ();
      return;
    }
    #if ADD_SHELTERS	// Hit shelters
      if ((BYTE) (ch - (CHR_SHELTER)) < 2) {	/* Hit shelter */
        TDL_ScreenSetNC (pos, CHR_SPC);
      }
    #endif

    if (ch != CHR_SPC && ch < CHR_BOMB) {	/* Only keep going if empty space */
      missiley = 0;
      TDL_SoundOff (VOX_MISSILE);
      return;
    }
    TDL_ScreenSet (pos, CHR_MISSILE+(missilex & 3), COL_MISSILE); 
}

void player_clr ()
{
    UINT pos;
    pos = game_xy2pos (playerx, PLAYER_Y);
    TDL_ScreenSetNC (pos,   CHR_SPC); 
    TDL_ScreenSetNC (pos+1, CHR_SPC); 
}

void player_draw ()
{
    UINT pos;
    BYTE phase;
    pos = game_xy2pos (playerx, PLAYER_Y);
    phase = (playerx & 3)*2;
    TDL_ScreenSet (pos,   phase+CHR_PLAYER,   COL_PLAYER); 
    TDL_ScreenSet (pos+1, phase+CHR_PLAYER+1, COL_PLAYER); 
}


  /* Move player base, fire missile.. */
void player_move ()
{
    BYTE key;
    BYTE dir=0;
    BYTE joy = 0;
    key = TDL_GetKeyDown ();
    #if (TDL_MAX_JOYSTICK > 0)
      joy = TDL_GetJoystick (joystick);
    #endif
    //TDL_ScreenSetNC (TDL_VDUX, TDL_ASC2CHR(64+joy)); 
    if ((joy & TDL_JOYSTICK_HIT) || key != TDL_SCANCODE_NONE) {
      player_clr ();
      if ((joy & TDL_JOYSTICK_LEFT) || key == 'I') {		/* Move left */
	if (playerx>2) playerx --;
      }
      if ((joy & TDL_JOYSTICK_RIGHT) || key == 'P' ) {		/* Move right */
        if (playerx < TDL_VDUX*4-8) playerx ++;
      }
      #if FULL_VERSION
       if (key == 'S') {
         sound = !sound;
       }
      #endif
      if (key == 'X') nlifes = 0;	/* Quit */
      #if TDL_RAM > 64
        if (key == TDL_KEY_ESC) nlifes = 0;
      #endif
      #ifdef ALLOW_CHEAT
       if (key == 'N') naliens = 0;	/* next level */
      #endif
    }
    if ((joy & TDL_JOYSTICK_FIRE) || key == 'Z' || (TDL_GetKey_Shift() & TDL_SHIFT_LR) ) {		/* Fire missile */
      if (missiley == 0) {
        crand += cframe;
        missiley = PLAYER_Y;
        missilex = playerx + 2;
      }
    } 
    player_draw ();
}

  /* Player hit, loose a life */
void player_loose_life ()
{ 
    BYTE x,y,ch;
    UINT pos;
    game_SoundOff ();
    nlifes --;
    score_update ();
    pos = game_xy2pos (playerx, PLAYER_Y);
    TDL_ScreenSet (pos,   CHR_BANG, COL_BANG); 
    TDL_ScreenSet (pos+1, CHR_BANG, COL_BANG); 
    TDL_Sleep (500);
}

#if ADD_BONUS 	/* Code for bonus target */

void bonus_hit ()
{
    if (bonusx == 0) return;
    if (missilex - bonusx > 7) return;
    alienhalt += 5;
    #if FULL_VERSION
     { 
      UINT pos;
      pos = game_xy2pos (bonusx, BONUS_Y);
      TDL_ScreenSet (pos,   CHR_BANG, COL_BANG); 
      TDL_ScreenSet (pos+1, CHR_BANG, COL_BANG); 
      TDL_Sleep (100);
     }
    #endif
    alien_clr (bonusx, BONUS_Y);
    bonusx = 0;
    score += 16 * level;
}

void bonus_move ()
{
    BYTE r;
    if (bonusx == 0) {		/* bonus alien not moving */
      if (cframe == 0 && alienhalt == 0) {
        r = (BYTE) rand () + crand;
        if (r < 33) {	/* Launch a bonus alien target? */
          if (r & 1) {		/* rand dir */
            bonusx = 1; bonusdir = 1;
          } else {
            bonusx = TDL_VDUX*4 - 10; bonusdir = 0xff;
          }
        }
      }
      return;
    }
    #if (TDL_VDUX < 30)
      if (cframe & 1) return;
    #endif
    alien_clr (bonusx, BONUS_Y);
    bonusx += bonusdir;
    if (bonusx > TDL_VDUX*4 - 10 || bonusx == 0) {
      bonusx = 0;
      return;
    }
    alien_draw (bonusx, BONUS_Y, TDL_COL_BLUE, CHR_ALIEN);

}
#endif

  /* Main game loop */
void game_Loop ()
{
    BYTE x;
    while (1) {
      game_help ();
      game_new ();
      score_update ();
      while (nlifes) {
	#if TDL_RAM > 64
          if (TDL_RequestQuit == TRUE) exit (0);  /* Request quit (window close) */
        #endif
        cframe++;
        //crand = TDL_Rand ();		/* Current rand # */
        missile_move ();
        if (naliens == 0) {
          bomb_move (1);		/* Clr old bombs */
          game_new_level ();
	}
        player_move ();
	if ((playmode & PLAY_FAST) == 0 || (cframe & 1)) {
	  TDL_FrameSync ();	/* Sync animation to frame */
	  TDL_SoundOff (VOX_ALIEN);
        }
        #if ADD_BONUS		/* Move mother ship target */
          bonus_move ();
        #endif
	alien_move ();
	if ((cframe & 1) == 0) {
	    bomb_move (0);
	    #ifdef PROG_DEBUG		/* Used to show FPS */
	      ntime = TDL_Clock () / TDL_CLOCKS_PER_SEC;
	      nframe ++;
	      TDL_GotoXY (1,2);
              TDL_PrintSI ((char *) "TIME:", ntime );  TDL_PrintSI ((char *) " FRAME:",cframe);
              if (ntime) TDL_PrintSI ((char *) " FPS:",cframe/ntime);
	    #endif
	}
      }
      if (score > hiscore) hiscore = score;
      game_SoundOff ();
      TDL_ScreenBackground (TDL_COL_BLACK, TDL_COL_RED);
      //TDL_GotoXY (1,2); TDL_Ink (TDL_COL_RED); TDL_PrintStr ((char *) " GAME OVER ");
      TDL_Sleep (2000);
      TDL_ScreenBackground (TDL_COL_BLACK, TDL_COL_BLACK);
    }
}

	/* Main program */
int main ()
{
    TDL_Initialise (0,NULL);
    TDL_UDG_Init (pPix, TDL_UDG_START, sizeof (pPix));
    TDL_SoundInit ();
    game_Loop ();	/* Main game loop */
    TDL_Finish ();
    return 0;
}
