/* ROCKBAL.C  -  RockBalloons, Avoid the crunch!
  (C) A.Millett 2016-2026 GPL/Freeware.
   Import some code from previous Trock101 & DynaJim106.
   (Imp dynamite, bonus-diamonds, flippers, freezers? SDL3+FullCol?)
 -> rocksp100, 15.6.2026
   Imp gfx for this game. (SAND, ROCKS, BRICKS, etc)
   Simple working version.
 -> rocksp101, 16.6.2026
   Add balloons
 -> rockbal102, 17.6.2026
   Small changes.
 -> rockbal103, 18.6.2026
   Imp 1/2 char anim. Imp Joystick
 -> rockbal104, 20.6.2026
 -> rockbal105, 21.6.2026

(AuntyGravity. Which way is up? Pills:LRUD.Balloons.)
*/

#define PROG_NAME "Rock-Balloons 1.05"

#define TDL_IO_DIRECT 1                /* Use direct screen poke for print */

#ifdef TDL_PATH                /* User sets TDL_PATH */
 #include TDL_PATH
#else
 #include "../tdl/tdl.c"
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//#define PROG_DEBUG   TRUE                /* Add some debug features (or: -D PROG_DEBUG=1) */
#define FULL_VERSION   TRUE                /* Add extra features */

#define USE_TITLE_SCREEN  TRUE

#if (TDL_UDG_MAX > 0)        /* Are UDGs available? If so, set them up.. */

 BYTE pPix[] = {
  //  "rockbal/rockbal.bmp" size 96 x 16, Bitdepth=1, #char: 12 x 2
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,  // chr:1
  0x00,0x00,0x00,0x00,0x38,0x7c,0x7c,0x7c,  // chr:2
  0x00,0x08,0x40,0x01,0x1c,0x36,0x7d,0x57,  // chr:3
  0xaa,0x00,0x55,0x00,0xaa,0x00,0x55,0x00,  // chr:4
  0x00,0x7e,0x7e,0x66,0x66,0x7e,0x7e,0x00,  // chr:5
  0x1c,0x26,0x7d,0x57,0x5b,0x36,0x1c,0x00,  // chr:6
  0x38,0x44,0x38,0x10,0x10,0x18,0x18,0x00,  // chr:7
  //0x00,0x36,0x7f,0x77,0x7f,0x36,0x1c,0x08,  // chr:7
  0x00,0x00,0xfd,0xfe,0xfc,0xfc,0x00,0x00,  // chr:8
  0x38,0x7c,0x7c,0x7c,0x38,0x10,0x08,0x04,  // chr:9
  0x00,0x55,0xaa,0xff,0xff,0x55,0xaa,0x00,  // chr:10
  0x5c,0x3a,0x5c,0x3a,0x5c,0x3a,0x5c,0x3a,  // chr:11
  0x00,0x3c,0x5a,0x66,0x66,0x5a,0x3c,0x00,  // chr:12
  0x77,0xf5,0xe7,0x00,0x76,0x5f,0x3b,0x00,  // chr:13
  0x38,0x10,0x08,0x04,0x00,0x00,0x00,0x00,  // chr:14
  0x7b,0x26,0x1c,0x00,0x00,0x00,0x00,0x00,  // chr:15
  0x18,0x18,0xe7,0x3c,0x3c,0x3c,0x24,0x66,  // chr:16
  0x99,0x5a,0x24,0x3c,0x3c,0x3c,0x24,0x66,  // chr:17
 0};


        /* UDG character constants */
 #define CHR_EMPTY    TDL_CHR_ASC32
 #define CHR_PLAYER   TDL_UDG_START + 15
 #define CHR_PLAYER2  TDL_UDG_START + 16
 #define CHR_SAND     TDL_UDG_START + 3
 #define CHR_BRICK    TDL_UDG_START + 4
 #define CHR_ROCK     TDL_UDG_START + 5
 #define CHR_ROCK2    TDL_UDG_START + 2
 #define CHR_KEY      TDL_UDG_START + 6
 #define CHR_DYNAMITE TDL_UDG_START + 7
 #define CHR_BALLOON  TDL_UDG_START + 8
 #define CHR_BALLOON2 TDL_UDG_START + 1
 #define CHR_EDGEV    TDL_UDG_START + 10
 #define CHR_EDGEH    TDL_UDG_START + 9
 #define CHR_EDGE     TDL_UDG_START + 11

#else         /* No UDGs, ASCII/PETSCII.. */

 #ifdef TDL_HAS_PETSCII

        /* PETCII Game char codes */
  #define CHR_EMPTY    TDL_ASC2CHR(' ')
  #define CHR_PLAYER   42
  #define CHR_PLAYER2  TDL_ASC2CHR(' ')
  #define CHR_SAND     102
  #define CHR_BRICK    79+128
  #define CHR_ROCK     81
  #define CHR_KEY      83
  #define CHR_DYNAMITE TDL_ASC2CHR('D')
  #define CHR_BALLOON  TDL_ASC2CHR('O')
  #define CHR_EDGEV    93
  #define CHR_EDGEH    64
  #define CHR_EDGE     43
#else

        /* ASCII Game char codes */
  #define CHR_EMPTY    TDL_CHR_ASC32
  #define CHR_PLAYER   TDL_ASC2CHR('*')
  #define CHR_PLAYER2  TDL_ASC2CHR(' ')
  #define CHR_SAND     TDL_ASC2CHR(':')
  #define CHR_BRICK    TDL_ASC2CHR('#')
  #define CHR_ROCK     TDL_ASC2CHR('+')
  #define CHR_KEY      TDL_ASC2CHR('$')
  #define CHR_DYNAMITE TDL_ASC2CHR('D')
  #define CHR_BALLOON  TDL_ASC2CHR('O')
  #define CHR_EDGEV    TDL_ASC2CHR('!')
  #define CHR_EDGEH    TDL_ASC2CHR('-')
  #define CHR_EDGE     TDL_ASC2CHR('+')

 #endif

#endif

  /* Game char colours */
#define COL_PLAYER   TDL_COL_WHITE
#define COL_SAND     TDL_COL_BLUE
#define COL_BRICK    TDL_COL_CYAN
#define COL_ROCK     TDL_COL_YELLOW
#define COL_KEY      TDL_COL_RED
#define COL_DYNAMITE TDL_COL_RED
#define COL_BALLOON  TDL_COL_PURPLE
#define COL_EDGE     TDL_COL_CYAN

  /* Various game constants */
#define NKEYS      3            /* #keys per level */
#define NKEYLEFT   1            /* #keys that can be left behind */
#define NDYNAMITE  1            /* #dynamite per level */
#define DENSITY_BRICK  4        /* % Density of hard bricks.. */
#define DENSITY_ROCK   5        /* % Start Density of rocks.. */

  /* Top of play area */
#define TOPX 1
#define TOPY 2
  /* Size of play area (excluding border) */
#define BRDX (TDL_VDUX - 2)
#define BRDY (TDL_VDUY - 3)
#define BRDSIZE (BRDX * BRDY)

  /* Game global vars */
UINT score;
UINT hiscore = 0;
BYTE playx,playy;
BYTE gameOver;
BYTE level;
BYTE nkeys; 
BYTE ndynamite;
BYTE joystick = 0;	/* Current joystick (0,1) */

void game_Help  ();
void game_DrawText ();
void game_Border (BYTE);

#if USE_TITLE_SCREEN

#if TDL_VDUX < 32	/* Minimal title screen */

char szHelp[] =
  " " PROG_NAME "\n\n"
  "\n\n(C)A.MILLETT 2026\n\n"
  "QAOP  - Move UDLR\n"
  "SPACE - Use Dynamite\n"
  "\n\nHit SPACE\n\n";


void game_Help ()
{
    BYTE helpkey;
    TDL_ScreenClr ();
    TDL_Ink ( TDL_COL_YELLOW);
    TDL_PrintStr (szHelp);
    TDL_Ink ( TDL_COL_PURPLE);
    TDL_PrintSI ( " HI:",   hiscore);  TDL_PrintChar ('0');
    do { 
      helpkey = TDL_GetKey ();
      #if TDL_RAM > 64
        if (helpkey == TDL_KEY_ESC || TDL_RequestQuit == TRUE) exit (0);  /* Request quit (window close) */
      #endif
    } while (helpkey != 32);
}

#else		/* >=32 cols, Full Help */

char szHelp[] =
	"\nAvoid the crunch!\n"
	"Use Joystick, or keys QAOP\n"
	//"or RCDF moves Up/Down/Left/R\n"
        "Hit SPACE to use Dynamite.\n"
	"Avoid falling rocks or\n"
        "rising balloons.\n"
	"Collect keys for next level.\n"
        "Hit J to swap Joystick.\n"
	"\n";

  
void game_Help ()
{
    BYTE helpkey;
    TDL_ScreenClr ();
help_loop:
    #if TDL_VDUX > 30		/* Center help text */
      TDL_SetLeftMargin ( (TDL_VDUX - 26) / 2);
    #endif
    
    TDL_GotoXY ((TDL_VDUX - 16)/2,3);
    TDL_Ink ( TDL_COL_WHITE);
    TDL_PrintStr ( PROG_NAME);
    TDL_Ink ( TDL_COL_BLUE);
    TDL_PrintStr ( "\n\n(C) A.MILLETT 2026,FREE/GPL3\n");
    TDL_Ink ( TDL_COL_YELLOW);
    TDL_PrintStr (szHelp);
    TDL_Ink ( TDL_COL_GREEN);
    TDL_PrintSI ( " High Score:",   hiscore);  TDL_PrintChar ('0');
    TDL_Ink ( TDL_COL_PURPLE);
    #if (TDL_MAX_JOYSTICK > 1)
      TDL_PrintSI ( "\n JOY (J):",joystick+1); 
    #endif
    TDL_Ink (TDL_COL_CYAN);
    TDL_PrintStr ( "\n\n  HIT SPACE");
    game_Border (0);
    while (TDL_GetKey ()) {};	/* Clr keyboard buffer */

    do { 
      TDL_Rand ();	/* Randomise */
      helpkey = TDL_GetKey ();
      helpkey = TDL_TOUPPER(helpkey);
      #if TDL_RAM > 64
        if (helpkey == TDL_KEY_ESC || TDL_RequestQuit == TRUE) exit (0);  /* Request quit (window close) */
      #endif
      #if (TDL_MAX_JOYSTICK > 1)
          if (helpkey == 'J') {
	    joystick ^= 1;	/* J=Flip joysticks */
	    goto help_loop;
	  }
      #endif
      TDL_Sleep (20);
    } while (helpkey != 32);
    TDL_SetLeftMargin (0);
}

#endif

#endif		/* USE_TITLE_SCREEN */

  /* Find random empty square */
UINT game_randpos ()
{
    UINT r;
    BYTE z;
    for (z=200; z; z++) {
      r = (TDL_Rand () % (TDL_ScreenPos (TDL_VDUX, TDL_VDUY-3))) + TDL_ScreenPos (0,2);
      if (TDL_ScreenGet (r) == CHR_SAND) return r;
    }
    return 0;
}

  /* Display score, free mvs, level */
void score_update ()
{
    UINT pos;
    TDL_GotoXY (1,1);
    TDL_PrintInt (score);
    TDL_PrintChar ('0');
    #if (TDL_UDG_MAX > 0)        /* Are UDGs available? */
      pos = TDL_ScreenPos (0,0);
      TDL_GotoXY (9,1);
      TDL_PrintInt (ndynamite);
      TDL_ScreenSet (pos+6, CHR_DYNAMITE, COL_DYNAMITE); 
      TDL_GotoXY (14,1);
      TDL_PrintInt (nkeys);
      TDL_ScreenSet (pos+11, CHR_KEY, COL_KEY); 
      TDL_GotoXY (TDL_VDUX-2,1);
      TDL_PrintInt (level);
      TDL_ScreenSet (TDL_VDUX-6, CHR_PLAYER2, TDL_COL_PURPLE); 
    #else
      TDL_PrintSI ((char *) " DY:",ndynamite);
      TDL_PrintSI ((char *) " LV:",level);
    #endif
}

void game_sound (BYTE n)
{
    UINT r;
    while (n) {
     r = TDL_Rand ();
     TDL_Sound (TDL_SOUND_LO + (r & 127)* TDL_SOUND_STEP, 1);
     n --;
     TDL_Sleep (20);
    }
    TDL_SoundOff (1);
}

void game_Border (BYTE topy)
{
    BYTE x,y;
	/* Draw border */
    for (x = 0; x < TDL_VDUX; x++) {
      TDL_ScreenSetXY (x,topy, CHR_EDGEH, COL_EDGE);
      TDL_ScreenSetXY (x,TDL_VDUY-1, CHR_EDGEH, COL_EDGE);
    }
    for (y = topy; y < TDL_VDUY; y++) {
      TDL_ScreenSetXY (0,y, CHR_EDGEV, COL_EDGE);
      TDL_ScreenSetXY (TDL_VDUX-1,y, CHR_EDGEV, COL_EDGE);
    }
    TDL_ScreenSetXY (0, topy, CHR_EDGE, COL_EDGE);
    TDL_ScreenSetXY (0, TDL_VDUY-1, CHR_EDGE, COL_EDGE);
    TDL_ScreenSetXY (TDL_VDUX-1, topy, CHR_EDGE, COL_EDGE);
    TDL_ScreenSetXY (TDL_VDUX-1, TDL_VDUY-1, CHR_EDGE, COL_EDGE);
}

  /* New game/level */
void game_NewLevel ()
{
    BYTE idx;
    BYTE x,y;
    UINT nitems;
    UINT pos;

    TDL_ScreenClr ();    
    game_sound (4);
    gameOver = FALSE;
    level ++;
    nkeys = NKEYS + level/2;

        /* Fill play area with sand */
    for (y=1; y< TDL_VDUY; y++) {
      for (x=1; x< TDL_VDUX-1; x++) {
        TDL_ScreenSetXY (x,y, CHR_SAND, COL_SAND); 
      }
    }
    game_Border (1);

        /* Place player & space in center */
    playx = TDL_VDUX / 2;
    playy = TDL_VDUY / 2;
    TDL_ScreenSetXY (playx, playy, CHR_PLAYER, COL_PLAYER);
		/* Draw rocks and balloons */
    nitems = level * (BRDSIZE/80) + (BRDSIZE * DENSITY_ROCK) / 100;
    for (; nitems; nitems --) {
      pos = game_randpos ();
      if (pos) TDL_ScreenSet (pos, CHR_ROCK, COL_ROCK); 
      pos = game_randpos ();
      if (pos) TDL_ScreenSet (pos, CHR_BALLOON, COL_BALLOON); 
    }
	/* Draw Bricks */
    idx = (BRDSIZE * DENSITY_BRICK) / 100;
    for (; idx; idx --) {
      pos = game_randpos ();
      if (pos) TDL_ScreenSet (pos, CHR_BRICK, COL_BRICK); 
    }
        /* Dynamite */
    for (idx = 0; idx < NDYNAMITE; idx++) {
      pos = game_randpos ();
      if (pos) TDL_ScreenSet (pos, CHR_DYNAMITE, COL_DYNAMITE); 
    }
        /* Keys */
    for (idx = 0; idx < nkeys; idx++) {
      pos = game_randpos ();
      if (pos) TDL_ScreenSet (pos, CHR_KEY, COL_KEY); 
    }
    score_update ();
}


void game_New ()
{
    level = 0;
    score = 0;
    ndynamite = 2;
    game_NewLevel ();
}

void game_MoveObject (BYTE xpos, BYTE ypos, BYTE diry, BYTE obj, BYTE objcol)
{
    BYTE cchr;
    BYTE ry;
    BYTE nfall;
}

  /* Drop rocks */
void game_DropRocks ()
{
    BYTE xpos,ypos;
    BYTE cchr;
    BYTE ry;
    BYTE nfall;
        /* Scan board for hanging rocks, drop them.. */
    for (xpos = TOPX; xpos < TOPX + BRDX; xpos ++) {
      for (ypos = TOPY + BRDY; ypos>=TOPY ; ypos --) {
        if (TDL_ScreenGetXY (xpos, ypos) == CHR_ROCK) {           /* Found rock, does it drop? */
          ry = ypos;
          nfall = 0;
          while (1) {            /* Drop until it comes to rest.. */
            cchr = TDL_ScreenGetXY (xpos, ry+1);        /* Next square */
            if (nfall && cchr == CHR_PLAYER) {        /* Rock hit player? */
              //TDL_ScreenSetXY (xpos, ry, CHR_EMPTY, TDL_COL_BLACK); 
              gameOver = TRUE;
              return ;
            }
            if (cchr != CHR_EMPTY) break;
            #if (TDL_UDG_MAX > 0)        /* Add 1/2 char anim */
              TDL_ScreenSetXY (xpos, ry, CHR_ROCK2, COL_ROCK); 
              TDL_ScreenSetXY (xpos, ry+1, CHR_ROCK2+12, COL_ROCK); 
              TDL_FrameSync ();   //  TDL_Sleep (50);
            #endif
            TDL_ScreenSetXY (xpos, ry, CHR_EMPTY, TDL_COL_BLACK); 
            ry ++;
            TDL_ScreenSetXY (xpos, ry, CHR_ROCK, COL_ROCK); 
            TDL_FrameSync ();   //  TDL_Sleep (50);
            nfall ++;
          }
        }
      }
      for (ypos = TOPY; ypos < TOPY +BRDY; ypos ++) {
        if (TDL_ScreenGetXY (xpos, ypos) == CHR_BALLOON) {           /* Found balloon, does it float? */
          ry = ypos;
          nfall = 0;
          while (1) {            /* Drop until it comes to rest.. */
            cchr = TDL_ScreenGetXY (xpos, ry-1);        /* Next square */
            if (nfall && cchr == CHR_PLAYER) {        /* Rock hit player? */
              //TDL_ScreenSetXY (xpos, ry, CHR_EMPTY, TDL_COL_BLACK); 
              gameOver = TRUE;
              return ;
            }
            if (cchr != CHR_EMPTY) break;
            #if (TDL_UDG_MAX > 0)        /* Add 1/2 char anim */
              TDL_ScreenSetXY (xpos, ry-1, CHR_BALLOON2, COL_BALLOON); 
              TDL_ScreenSetXY (xpos, ry, CHR_BALLOON2+12, COL_BALLOON); 
              TDL_FrameSync ();   //  TDL_Sleep (50);
            #endif

            TDL_ScreenSetXY (xpos, ry, CHR_EMPTY, TDL_COL_BLACK); 
            ry --;
            TDL_ScreenSetXY (xpos, ry, CHR_BALLOON, COL_BALLOON); 
            TDL_FrameSync ();   //  TDL_Sleep (50);
            nfall ++;
          }
        }
      }
    }
}



void player_Move ()
{
    BYTE px,py,dx,dy;
    BYTE x,y,z=0;
    UINT pos;
    BYTE ch;
    BYTE key;
    BYTE joy = 0;
    do {
      #if FULL_VERSION                /* Add player anmation */
        TDL_Sleep (20);
        z ++;
        if ((z & 15) == 0) {		/* Flash keys */
          TDL_ScreenSetXY (playx, playy, ((z & 16) ? CHR_PLAYER : CHR_PLAYER2), COL_PLAYER); 
          for (y = TOPY; y < TOPY + BRDY; y++) {
            for (x = TOPX; x < TOPX + BRDX; x++) {
              pos = TDL_ScreenPos (x,y);
              if (TDL_ScreenGet (pos) == CHR_KEY) {
                TDL_ScreenSet (pos, CHR_KEY, (z & 16) ? COL_KEY : TDL_COL_WHITE);
              }
            }
          }          
        }
      #endif
      #if (TDL_MAX_JOYSTICK > 0)
        joy = TDL_GetJoystick (joystick);
      #endif
      key = TDL_GetKey ();
      key = TDL_TOUPPER (key);
    } while (key ==  0 && (joy & TDL_JOYSTICK_HIT) == 0);

    if (ndynamite > 0) {                /* Detonate Dynamite? */
      if (key == ' ' || (joy & TDL_JOYSTICK_FIRE)) {               
        ndynamite --;
        for (y = playy-1; y <= playy+1; y++) {
          for (x = playx-1; x <= playx+1; x++) {
            pos = TDL_ScreenPos (x, y);
            ch = TDL_ScreenGet  (pos);
            if (ch == CHR_ROCK || ch == CHR_BALLOON) {     /* Wipe all hazards around player */
              TDL_ScreenSet (pos, TDL_ASC2CHR('*'), TDL_COL_RED);  
              game_sound (2);
              TDL_ScreenSetNC (pos, CHR_EMPTY); 
            }
          }
        }
        return ;
      }
    }
    #if TDL_RAM > 64
      if (key == 27) key = 'K';
    #endif
    if (key == 'K' || key == TDL_KEY_ESC) {
      gameOver = TRUE;
      return;
    }
    dx = dy = 0;
    if (key == 'O' || key == TDL_KEY_LEFT  || (joy & TDL_JOYSTICK_LEFT)) dx = (BYTE) -1;
    if (key == 'P' || key == TDL_KEY_RIGHT || (joy & TDL_JOYSTICK_RIGHT)) dx = 1;
    if (key == 'Q' || key == TDL_KEY_UP    || (joy & TDL_JOYSTICK_UP)) dy = (BYTE) -1;
    if (key == 'A' || key == TDL_KEY_DOWN  || (joy & TDL_JOYSTICK_DOWN)) dy = 1;
    if ((dx | dy) == 0) return ;
    TDL_ScreenSetNC (TDL_ScreenPos (playx, playy), CHR_EMPTY); 
    px = playx + dx;  
    py = playy + dy;
    pos = TDL_ScreenPos (px, py);
    ch = TDL_ScreenGet  (pos);
    switch (ch) {
      case CHR_SAND:
      case CHR_EMPTY:
        playx = px; playy = py;
        break;

      case CHR_KEY:
        game_sound (2);
        score += level;
        playx = px; playy = py;
        nkeys --;
        if (nkeys <= NKEYLEFT) {        /* Next level..  */
          TDL_Sleep (1000);
          game_NewLevel ();
        } 
        score_update ();
        break;

      case CHR_DYNAMITE:
        game_sound (2);
        score += level*2;
        ndynamite ++;
        playx = px; playy = py;
        score_update ();
        break;
                /* Rock/Brick/Edge, dont move */
      default:  ;
    }
    TDL_ScreenSetXY (playx, playy, CHR_PLAYER, COL_PLAYER); 
    
    score_update ();
}

void game_die ()
{
    BYTE x;
    for (x = 0; x < 10; x ++) {
      TDL_ScreenSetXY (playx, playy, CHR_EMPTY, TDL_COL_RED); 
      game_sound (2);
      TDL_ScreenSetXY (playx, playy, CHR_PLAYER, TDL_COL_RED); 
      game_sound (2);
    }
    TDL_Sleep (2000);
 }

  /* Main game loop */
void game_Loop ()
{
    while (1) {
      game_Help ();        /* Display title screen & help */
      game_New ();        /* Start a new game */
      do {
        player_Move ();
        game_DropRocks ();
      } while (gameOver == FALSE);
      game_die ();
      if (score > hiscore) hiscore = score;
    }
}


        /* Main program */
int main ()
{
    TDL_Initialise (0,NULL);
    #if (TDL_UDG_MAX > 0)        /* Are UDG gfx available? If so, set up.. */
      TDL_UDG_Init (pPix, TDL_UDG_START, sizeof (pPix));
    #endif
    TDL_SoundInit ();
    game_Loop ();        /* Main game loop */
    return 0;
}
