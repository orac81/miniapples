/* Owarix - Owari game, (C) A.Millett 2012-2026

 Simple shell..
-> OWARIX100 (30.5.2012)
 Imp new Brd layout, sch_New, sch_MakeMove..
 Working 2 player version..
-> OWARIX101 (30.9.2016)
 Imp nXX cmd set npits/nstart..
-> OWARIX102 (1.10.2016)
 Imp AlphaBeta, simple comp search..
 Simple working version..
-> OWARIX103 (1.10.2016)
 (Beats simple PET KALAH)
 Imp Further functions..
 Imp proper game-end eval: sch_IsGameOver, sch_EndEval, gam_Over..
-> OWARIX104 (1.10.2016)
 Note rule dif - null capture allowed in some versions. Imp allow_null_capt
-> OWARIX105 (1.10.2016)
-> OWARIX106 (4.10.2016)
-> OWARIX107 (20.10.2016)
 Changes for Oscar64 console ver
-> OWARIX108 (2.7.2026)
  Imp VTDL, Working version.
-> OWARIX110 (2.7.2026)
  Improve layout, make vic20 version work
-> OWARIX111 (3.7.2026)
  Imp better gfx. 
-> OWARIX112 (4.7.2026)
-> OWARIX113 (4.7.2026)
-> OWARIX114 (5.7.2026)

Build console version
  oscar64 -D IS_OSCAR -tm=c64 owarix.c -o=owarix-c64.prg -Os

BMP: m/util/bmp2c.elf owarix/owarix.bmp >tmp.c

*/

#define USE_C99     0
#define USE_LONG    0
#define DEBUG_CODE  0		/* Include debug aid code. */

#define PROG_NAME "OWARIX 1.14"

#if (USE_C99 == 0)

 #define TDL_IO_DIRECT 1		/* Use direct screen poke for print */

 #ifdef TDL_PATH		/* User sets TDL_PATH */
  #include TDL_PATH
 #else
  #include "../tdl/tdl.c"
 #endif
#endif

#define TRUE  1 
#define FALSE 0

  /* Forward declare (C99 version) */
void io_putint (int x);
void io_putsi (const char *ostr, int val);
void io_puts (const char *ostr) ;


/*-------------------------------------------------
 * sch_  Search Engine
 *------------------------------------------------- */

typedef unsigned char INTX;	/* Define small int, range 0-255, can be int or BYTE */

#ifdef TDL_VIC20		/* Limit for 5k Vic20 */
  #define MAX_PITS 7		/* Max Pits per side (inc Kalah) */
  #define MAX_PLY 12
  INTX *sch_saveboard = (INTX *) 828;   /* Use tape buffer */
  #define CELL_SIZEX 3
  #define CELL_SIZEY 5
#else
  #if defined(TDL_VDUX) && (TDL_VDUX < 40)
   #define MAX_PITS (TDL_VDUX/4 ) 	/* Fit screen width */
  #else
   #define MAX_PITS 10		/* Max Pits per side (inc Kalah) */
  #endif
  #define MAX_PLY 24
  INTX sch_saveboard [MAX_PITS * 2 * (MAX_PLY + 1) + 2];
  #define CELL_SIZEX 4
  #define CELL_SIZEY 5
#endif

#define DEF_NPITS 7		/* Default Pits per side (inc Kalah) */

INTX nstart = 4;		/* No of stones per pit at start */
INTX npits = DEF_NPITS;		/* No of pits per side (inc Kalah) */

INTX game_end;			/* Set when game has ended */
INTX allow_null_capt = 0; 	/* Allow null captures */

INTX KalahA = DEF_NPITS - 1;
INTX KalahB = DEF_NPITS*2-1;

INTX board [MAX_PITS * 2 + 2];

/*    12 11 10  9  8  7      (Board array mapping : SIDEA:0-6,B:7-13 - Wraps anticlockwise moves.)
   13                   6
       0  1  2  3  4  5      */

INTX side;		/* SIDEA=0,B=1 */

INTX sch_ply;	
int  sch_eval;
INTX sch_level = 3;	/* Search depth */
INTX sch_multimove;	/* Flag indicates multi-jump sqr to next ply */
INTX sch_best;

#define NO_MOVE 0

#if USE_LONG
 unsigned long sch_node;
 time_t sch_timeStart, sch_timeMove = 0;
#else
 unsigned int sch_node;
#endif

#define MAX_EVAL 11000
#define WIN_EVAL 10000

INTX flag_2play = 0;
INTX flag_display = 0;
INTX hisq ;		/* Hi lite sqr */
INTX autoplay = 0;

#if DEBUG_CODE		/* Debugging ASSERT macro .. */
  
  #define CASSERT(x) {if (!(x)) chk_assert (__LINE__); }

  void chk_assert(int bline) {
    io_putsi ("!",bline); 
    io_putsi (",",sch_ply); 
    gets ((char *) board);
    _exit(0); 
  }

#else
  #define CASSERT(x) ;
#endif

  /* Fwd declare */
void gam_analyShow (INTX cmove, int eval);
void gam_Anim (INTX cmove);

void sch_New ()
{
    INTX x;
    //if (npits < 2) npits = 2;
    //if (npits > MAX_PITS) npits = MAX_PITS;
    //if (nstart < 1) nstart = 1;
    hisq = 255;
    KalahA = npits-1;
    KalahB = npits*2-1;
    for (x = 0; x < npits * 2; x ++) {
      board [x] = nstart;
    }
    board [KalahA] = board [KalahB] = 0;
    side = 0;
    game_end = 0;
}


  /* Do a move (1..npits-1), return: 0=illegal, 1=normal move, 2=another go */
INTX sch_MakeMove (INTX mv, INTX callback)
{
    INTX nstone;
    INTX oppkal;
    INTX mykal;
    INTX opp;
    if (mv < 1 || mv >= npits) return 0;
    mv --;
    if (side) {
      mv += npits;
      oppkal = KalahA;
      mykal =  KalahB;
    } else {
      oppkal = KalahB;
      mykal =  KalahA;
    }
    nstone = board [mv]; 
    if (nstone < 1) return 0;
    hisq = mv;		/* Keep last move*/
	/* Pick up stones and drop 1 in each pit anti-clockwise */
    board [mv] = 0;
    if (callback) gam_Anim (mv);	/* Front end anim */
    do {
      mv ++;
      if (mv == oppkal) mv ++;		/* skip opponent kalah */
      if (mv >= npits*2) mv = 0;	/* Wrap back to start */
      board [mv] ++;
      nstone --;
      if (callback) gam_Anim (mv);	/* Front end anim */
    } while (nstone);
    if (mv == mykal) {		/* Last pit was my Kalah, play another turn */
      return 2;
    }
    if (board [mv] == 1) {		/* Was last pit empty? */
      if (mv < mykal && mv >= mykal - npits + 1) {	/* Same side pits? */
        opp = npits + npits - 2 - mv;
	if (allow_null_capt || board [opp]) {		/* Opponent pit occupied? */
	  board [mykal] += board [opp] + board [mv];	/* Capture stones to my kalah */
	  board [opp] = board [mv] = 0;
	}
      }
    }
    side = !side;
    return 1;
}

  /* Save board pos on stack */
void sch_SavePos ()
{
    INTX cpos;
    INTX *pBrd;
    int nbrd = npits + npits;
    pBrd = sch_saveboard + ((sch_ply-1) * nbrd);
    for (cpos = 0; cpos < nbrd; cpos ++) {
      pBrd [cpos] = board [cpos];
    }
}

  /* Restore board pos from stack */
void sch_RestorePos ()
{
    INTX cpos;
    INTX *pBrd;
    int nbrd = npits + npits;
    pBrd = sch_saveboard + ((sch_ply-1) * nbrd);
    for (cpos = 0; cpos < nbrd; cpos ++) {
      board [cpos] = pBrd [cpos];
    }
}

int numa,numb;

  /* End of game eval, count all stones */
int sch_EndEval ()
{
    INTX cpos;
    int eval;
    sch_node ++;
    numa = numb = 0;
    for (cpos = 0; cpos < npits; cpos ++) {
      numa += board[cpos];     
    }
    for (cpos = npits; cpos < npits + npits; cpos ++) {
      numb += board[cpos];     
    }
    eval = numa - numb;
    if (eval < 0) eval -= (WIN_EVAL);
    if (eval > 0) eval += (WIN_EVAL);
    if (side) eval = -eval;
    return eval;
}

int sch_IsGameOver (int side)
{
    INTX cpos,spos;
    spos = 0;
    if (side) spos = npits;
    for (cpos = 0; cpos < npits-1; cpos++) {
      if (board [cpos + spos]) return FALSE;
    }
    return TRUE;
}

  /* Terminal eval for midgame pos */
int sch_EvalPos ()
{
    int eval;
    sch_node ++;
    eval = board[KalahA] - board[KalahB];	/* Very simple! */
    if (side) eval =- eval;
    return eval;
}

  /* Recursively search game tree, return best move/eval.. */
int sch_AlphaBeta (INTX depth, int alpha, int beta)
{
    INTX cmove;
    INTX nmoves;
    int eval;
    INTX bestmove;
    INTX cret;

    bestmove = NO_MOVE;

	/* Some debugging asserts.. */   
    CASSERT (sch_ply > 0);
    //CASSERT (sch_ply < MAX_PLY-1);

		/* Terminal node? */
    if (depth <= 0 || sch_ply >= MAX_PLY) {
      return sch_EvalPos ();
    }
    sch_SavePos ();
    nmoves = 0;
    for (cmove = 1; cmove < npits; cmove ++) {
      cret = sch_MakeMove (cmove,0);
      if (cret) {
        nmoves ++;
        sch_multimove = cret - 1;	/* TRUE if multi-move */

	if (nmoves == 1) {	/* Game over? */
	  cret =sch_IsGameOver (!side);
	  if (cret) {
	    side = !side;
	    eval = sch_EndEval ();	/* End, count all stones, eval pos */
	    goto undoMove;
	  } 
	}
        sch_ply ++;
		/* Next ply.. */
        if (sch_multimove) {
          eval = sch_AlphaBeta (depth, alpha, beta);	/* Move again for same side */
        } else {
          eval = -sch_AlphaBeta (depth - 1, -beta, -alpha);  
	  side = !side;
        }
		/* UnMakemove*/
        sch_ply --;
undoMove:
        sch_RestorePos ();

        if (eval >= beta) {
          bestmove = cmove;
          return beta;
        } 
        if (eval > alpha) {
          bestmove = cmove;
          alpha = eval;
        }
		/* Ok, we have (eval) for (cmove) */
        if (sch_ply < 2) {	/* PLY 1: Tell front-end to show analysis */
          sch_best = bestmove;
          #if USE_LONG
            sch_timeMove = time (NULL) - sch_timeStart;
          #endif
          gam_analyShow (cmove,eval);	
        }
      }
    }
    if (nmoves == 0) {		/* Game over.. */
      return sch_EndEval ();	/* End, count all stones */
    }
    return alpha;
}

/* 
int AlphaBeta(int depth, int alpha, int beta)
{
    if (depth == 0)
        return Evaluate();
    GenerateLegalMoves();
    while (MovesLeft()) {
        MakeNextMove();
        val = -AlphaBeta(depth - 1, -beta, -alpha);
        UnmakeMove();
        if (val >= beta)
            return beta;
        if (val > alpha)
            alpha = val;
    }
    return alpha;
}
*/

  /* Initialise and start search.. */

void sch_CompMove ()
{
    sch_best = NO_MOVE;
    sch_ply = 1;
    sch_node = 0;
    #if USE_LONG
     sch_timeStart = time (NULL);
    #endif
    sch_eval = sch_AlphaBeta (sch_level, -MAX_EVAL, MAX_EVAL);
    CASSERT (sch_ply == 1);
}


/*-------------------------------------------------
 * VTDL code
 *------------------------------------------------- */

#if (USE_C99 == 0)

#if (TDL_RAM < 8)		// Limited RAM (Vic20)
 #define FULL_VERSION FALSE
#else 
 #define FULL_VERSION TRUE
#endif

#if (TDL_UDG_MAX > 0)	/* Are UDGs available? If so, set them up.. */

#define CHR_START (TDL_UDG_START)

BYTE pPix[] = {
  //  "owarix/owarix.bmp" size 96 x 16, Bitdepth=1, #char: 12 x 2
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,  // chr:1
  0xaa,0x55,0xaa,0x55,0xaa,0x55,0xaa,0x55,  // chr:2
  0x38,0x7c,0xbe,0xfe,0xbe,0x7c,0x38,0x00,  // chr:3
  0x00,0x06,0x0e,0x1c,0x98,0x63,0x1c,0x00,  // chr:4
  0x00,0x00,0x1e,0x21,0xd8,0x1c,0x0e,0x06,  // chr:5
  0x10,0x23,0x27,0x2e,0x2c,0x10,0x08,0x08,  // chr:6
  0x04,0x64,0x72,0x3a,0x1a,0x04,0x04,0x08,  // chr:7
  0xc3,0xe7,0x66,0x18,0x18,0x66,0xe7,0xc3,  // chr:8
  //0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
//  0x18,0x24,0x24,0x18,0x18,0x24,0x24,0x18,  // chr:9
//  0x00,0x00,0x66,0x99,0x99,0x66,0x00,0x00,  // chr:10
//  0x3c,0x42,0x99,0xa5,0xa5,0x99,0x42,0x3c,  // chr:11
//  0x08,0x1c,0x48,0xe2,0x47,0x12,0x38,0x10,  // chr:12
0};

  /* Game char codes */
 #define CHR_SPC      CHR_START 
 #define CHR_CURSOR   CHR_START + 1
 #define CHR_STONE    CHR_START + 2
 #define CHR_EDGEH    CHR_START + 3
 #define CHR_EDGEH2   CHR_START + 4
 #define CHR_EDGEV    CHR_START + 5
 #define CHR_EDGEV2   CHR_START + 6
 #define CHR_EDGE     CHR_START + 7

#else 	/* No UDGs.. */

	/* ASCII Game char codes */
  #define CHR_SPC      TDL_CHR_ASC32
  #define CHR_CURSOR   TDL_ASC2CHR('#')
  #define CHR_STONE    TDL_ASC2CHR('*')
  #define CHR_EDGEH    TDL_ASC2CHR('-')
  #define CHR_EDGEH2   TDL_ASC2CHR('-')
  #define CHR_EDGEV    TDL_ASC2CHR('!')
  #define CHR_EDGEV2   TDL_ASC2CHR('!')
  #define CHR_EDGE     TDL_ASC2CHR('+')

#endif

#define CHR_ZERO     TDL_ASC2CHR('0')

#define COL_EDGE     TDL_COL_GREEN
#define COL_EDGE2    TDL_COL_RED
#define COL_STONEA   TDL_COL_WHITE
#define COL_STONEB   TDL_COL_PURPLE
#define COL_NUMBER   TDL_COL_BLUE
#define COL_NUMBERHI TDL_COL_CYAN

	/* Board top pos */
#define TOPY  5
#define TOPX  2

BYTE cmdkey;

 /* Callback func to Show search analysis.. */
void gam_analyShow (INTX cmove, int eval)
{
    TDL_ScreenSetXY (8, 0, CHR_ZERO+cmove, TDL_COL_BLUE);       
    TDL_FrameSync ();	
}

int game_Over ()
{
    int eval = sch_EndEval ();
      /* Some stones left to play ? */
    if (numa != board[KalahA] && numb != board[KalahB]) { 
      game_end = FALSE;
      return FALSE;
    }
    game_end = TRUE;
}

  /* Draw a cell, calc position*/
void game_DrawCell (BYTE p)
{
    BYTE tx,ty,x,y,v,ch,ch2,col;
    v= board [p];
	/* Calc cell position */
    if (p < npits) {
      ty = TOPY + CELL_SIZEY*2;
      tx = TOPX + CELL_SIZEX * p;
      if (p == KalahA) {
        ty -= CELL_SIZEY;
        tx -= CELL_SIZEX;
      }
    } else {
      ty = TOPY ;
      tx = TOPX + CELL_SIZEX * (npits + npits - p - 2);
      if (p == KalahB) {
        ty += CELL_SIZEY;
        tx += CELL_SIZEX;
      }
    }
	/* Draw Frame */
    for (x=1; x<CELL_SIZEX; x++) {
      ch = (x & 1) ? CHR_EDGEH : CHR_EDGEH2;
      TDL_ScreenSetXY (tx+x, ty, ch, COL_EDGE);       
      TDL_ScreenSetXY (tx+x, ty+CELL_SIZEY, ch, COL_EDGE);       
    }
    for (y=1; y<CELL_SIZEY; y++) {
      ch = (y & 1) ? CHR_EDGEV : CHR_EDGEV2;
      TDL_ScreenSetXY (tx, ty+y, ch, COL_EDGE);       
      TDL_ScreenSetXY (tx+CELL_SIZEX, ty+y, ch, COL_EDGE);       
      for (x=1; x<CELL_SIZEX; x++) {
        TDL_ScreenSetXY (tx+x, ty+y, CHR_SPC, 0);       
      }
    }
    TDL_ScreenSetXY (tx, ty, CHR_EDGE, COL_EDGE2);       
    TDL_ScreenSetXY (tx, ty+CELL_SIZEY, CHR_EDGE, COL_EDGE2);       
    TDL_ScreenSetXY (tx+CELL_SIZEX, ty, CHR_EDGE, COL_EDGE2);       
    TDL_ScreenSetXY (tx+CELL_SIZEX, ty+CELL_SIZEY, CHR_EDGE, COL_EDGE2);       
	/* Draw Contents */
    col = (p <= KalahA) ? COL_STONEA : COL_STONEB;
    if (p == hisq) col = COL_NUMBERHI;

    #if 1 //FULL_VERSION // Show Stones
      if (flag_display == 0) {
        if (v < (CELL_SIZEX - 1) * (CELL_SIZEY -1) ) {
          for (y=CELL_SIZEY - 1; y; y--) {
            for (x=CELL_SIZEX - 1; x; x--) {
              if (v) {
                v--;
                TDL_ScreenSetXY (tx+x, ty+y, CHR_STONE, col);       
              }
            }
          }
          return;
        }
      }
    #endif

    #if 1	/* Avoid divide! */
      ch = CHR_SPC;
      if (v > 9) {
        ch = CHR_ZERO;
        while (v > 9) {
          ch ++; v -= 10;
        }
      }
      ch2 = CHR_ZERO + v; 
    #else
      ch = TDL_ASC2CHR(' ');  ch2 = CHR_ZERO + v; 
      if (v > 9) { ch = CHR_ZERO + v & 10; ch2 = CHR_ZERO + v % 10; }
    #endif
    TDL_ScreenSetXY (tx+1, ty+2, ch, col);       
    TDL_ScreenSetXY (tx+2, ty+2, ch2, col);       
}

  /* Clear text area */
void game_ClrText ()
{
    UINT p = TDL_ScreenPos (0,0);
    BYTE z;
    for (z=0; z<TDL_VDUX*4; z++) {
      TDL_ScreenSetNC (p+z,CHR_SPC);
    }
}

  /* Display game info */
void game_DrawText (BYTE mode)
{
    BYTE x,y,c;
    TDL_GotoXY (1,1); 
    TDL_Ink (TDL_COL_WHITE);
    if (game_end) {
      TDL_PrintSI ("Game over. A=",numa);
      TDL_PrintSI (", B=",numb);
      return;
    }
    #if TDL_VDUX > 30
      TDL_PrintStr ("SIDE ");
    #endif
    TDL_PrintChar ('A'+side);
    
    if (mode) {
      TDL_PrintStr ( ":   ");
    } else {
      #if TDL_VDUX < 32
       TDL_PrintStr ( ":Cmd (NGIYUT,1-9)?");
      #else
       TDL_PrintStr ( ":Cmd (NGIYUTA,1-9,H=Help)?");
      #endif
    }
    TDL_GotoXY (1,2); 
    TDL_Ink (TDL_COL_CYAN);
    TDL_PrintSI ( "IQ:", sch_level);
    if (flag_2play) {
      TDL_PrintStr ( " 2Play");
    }
    TDL_PrintStr ( (char *) "   ");

    #if FULL_VERSION
      c = side ? TDL_COL_WHITE : TDL_COL_BLUE;
      TDL_ScreenSetXY (0, TOPY + 1, TDL_ASC2CHR('B'), c);       
      c = side ? TDL_COL_BLUE : TDL_COL_WHITE;
      TDL_ScreenSetXY (0, TOPY + CELL_SIZEY*3-1, TDL_ASC2CHR('A'), c);       
	/* Show pit numbers */
      x= TOPX  + CELL_SIZEX/2;
      for (c=1; c < npits; c++) {
        TDL_ScreenSetXY (x, TOPY + 1 + CELL_SIZEY*3, c + CHR_ZERO, COL_NUMBER);       
        x += CELL_SIZEX;
      }
    #endif
    
}

void game_DrawBoard ()
{
    BYTE p;
    for (p = 0; p < npits * 2; p++) {
      game_DrawCell (p);
    }
    //game_DrawText (0);
}

  /* Show stones moving */
void gam_Anim (INTX cmove)
{
    if (flag_display) return;
    game_DrawCell (cmove);
    TDL_FrameSync ();	
    TDL_FrameSync ();	
}

void game_CompMove ()
{
    INTX cret;
    INTX p=1;
    game_ClrText ();
    //TDL_ScreenClr ();
    game_DrawText (1);
    TDL_GotoXY (1,3);
    TDL_Ink (TDL_COL_GREEN);
    do {
      game_DrawBoard ();
      sch_CompMove ();
      if (sch_best == NO_MOVE) {
        game_Over ();
        return;
      }
      #ifdef TDL_DOS      /* A hack for DOS ver */
        TDL_GotoXY (p,3); p+= 2;
        TDL_Ink (TDL_COL_GREEN);
      #endif
      TDL_PrintInt (sch_best);
      TDL_PrintStr (",");
      cret = sch_MakeMove (sch_best,1);
    } while (cret == 2);
    #ifdef TDL_DOS      /* A hack for DOS ver */
        TDL_GotoXY (p,3);
        TDL_Ink (TDL_COL_GREEN);
    #endif
    TDL_PrintStr ("Ev:");
    TDL_PrintSignedInt (sch_eval);
    TDL_PrintSI (",N:",sch_node);
    #if USE_LONG
      if (sch_timeMove) {
        TDL_PrintSI (",T",sch_timeMove);
      }
    #endif
}


#if FULL_VERSION	/* Help screens */

char szHelp[] =
 "\n"
 "1-9 - Choose pit to move\n"
 "N - Start a new game\n"
 "Y - Change no of pits\n"
 "U - Change no of stones\n"
 "G - Make computer move\n"
 "A - Auto play demo\n"
 "I - Change play IQ/Level\n"
 "T - Toggle 2 player mode\n" 
 "V - Toggle simple display\n"
 "H - Display help\n"
 "ESC - Quit to OS\n"
 "\n";

void game_Border ()
{
    BYTE x,y,ch;
    for (x=0; x<TDL_VDUX-1; x++) {
      ch = (x & 1) ? CHR_EDGEH : CHR_EDGEH2;
      TDL_ScreenSetXY (x, 0, ch, COL_EDGE);       
      TDL_ScreenSetXY (x, TDL_VDUY-1, ch, COL_EDGE);       
    }
    for (y=0; y<TDL_VDUY-1; y++) {
      ch = (y & 1) ? CHR_EDGEV : CHR_EDGEV2;
      TDL_ScreenSetXY (0, y, ch, COL_EDGE);       
      TDL_ScreenSetXY (TDL_VDUX-1, y, ch, COL_EDGE);       
    }
    TDL_ScreenSetXY (0, 0, CHR_EDGE, COL_EDGE2);       
    TDL_ScreenSetXY (0, TDL_VDUY-1, CHR_EDGE, COL_EDGE2);       
    TDL_ScreenSetXY (TDL_VDUX-1, 0, CHR_EDGE, COL_EDGE2);       
    TDL_ScreenSetXY (TDL_VDUX-1, TDL_VDUY-1, CHR_EDGE, COL_EDGE2);       
}
  
void game_Help ()
{
    BYTE helpkey;
    TDL_ScreenClr ();
help_loop:
    #if TDL_VDUX > 30		/* Center help text */
      TDL_SetLeftMargin ( (TDL_VDUX - 26) / 2);
    #endif
    
    TDL_GotoXY ((TDL_VDUX - 16)/2,3);
    TDL_Ink ( TDL_COL_WHITE);
    TDL_PrintStr ( PROG_NAME);
    TDL_Ink ( TDL_COL_BLUE);
    TDL_PrintStr ( "\n\n(C) A.MILLETT 2026,FREE/GPL3\n");
    TDL_Ink ( TDL_COL_YELLOW);
    TDL_PrintStr (szHelp);
    TDL_Ink (TDL_COL_CYAN);
    TDL_PrintStr ( "\n\n  HIT SPACE");
    game_Border ();

    do { 
      helpkey = TDL_GetKey ();
      helpkey = TDL_TOUPPER(helpkey);
      #if TDL_RAM > 64
        if (helpkey == TDL_KEY_ESC || TDL_RequestQuit == TRUE) exit (0);  /* Request quit (window close) */
      #endif
      TDL_Sleep (20);
    } while (helpkey != 32);
    TDL_SetLeftMargin (0);
    TDL_ScreenClr ();
}

#endif


void game_Loop ()
{
  BYTE fr = 0;
  BYTE cret;
  #if TDL_RAM > 64
    sch_level = 5;
  #endif
  #if FULL_VERSION
    game_Help ();
  #endif 		// FULL_VERSION
  
  sch_New ();
  TDL_ScreenClr ();
  while (1) { 
    game_Over ();	/* Test if game over */
    game_DrawBoard ();
    game_DrawText (0);
    do {
      cmdkey = TDL_GetKey ();
      #if FULL_VERSION
        if (game_end) autoplay = FALSE;
        if (autoplay) {
          if (cmdkey == 0) {
            cmdkey = 'G';
            //app_DrawCell (cxpos, cypos, 1);        /* Show cursor on last move */
            break;
          } else {
            autoplay = FALSE;
          }
        }
      #endif
      TDL_FrameSync ();        
    } while (cmdkey == 0);
    cmdkey = TDL_TOUPPER (cmdkey);
    if (game_end == FALSE) {
      if (cmdkey > '0' && cmdkey <= '9') {                /* Input human move */
        cret = sch_MakeMove (cmdkey & 15,1);
        if (cret == 1) {
          if (flag_2play == 0) {
            game_DrawBoard ();
            game_CompMove ();                /* Comp reply */
          }
        }
        continue;
      }
    }
    switch (cmdkey) {
      #if 0
      case 32:                        /* Select move */
        app_CursorMove (1);
        break;

      case 13:                        /* Enter move */
        app_ExecMove (cxpos, cypos);
        break;
     #endif
     #if FULL_VERSION
      case 'H':			/* Show Frame */
        game_Help ();
	break ;

      case 27:		/* Quit */
      case 3:
	return;

      case 'A':			/* AutoPlay (Comp vs Comp) */
        autoplay = TRUE;
	break ;

     #endif 		// FULL_VERSION

      case 13:			/* Enter move */
      case 'G':			/* Comp go */
        game_CompMove ();
	break;

      case 'V':			
	TDL_ScreenClr ();
	flag_display = !flag_display;
	break;

      case 'U':			/* Change # stone */
        nstart = 1 + (nstart & 7);
        npits --;
      case 'Y':			/* Change # pits */
        npits ++;
        if (npits > MAX_PITS) npits = 3;
      case 'N':			/* New game */
	sch_New ();
        TDL_ScreenClr ();
	break;

      case 'I':			/* IQ */
        sch_level ++;
        if (sch_level > 9 && flag_2play == 0) sch_level = 1;
	break;

      case 'T':		/* Toggle 2 player mode */
	TDL_ScreenClr ();
        flag_2play = ! flag_2play;
	break;
      
    }
  }
}


	/* Main program */
int main ()
{
    TDL_Initialise (0,NULL);
    #if (TDL_UDG_MAX > 0)	/* Are UDGs available? If so, set them up.. */
      TDL_UDG_Init (pPix, CHR_START, sizeof (pPix));
    #endif
    game_Loop ();	/* Main game loop */
    TDL_Finish ();
    return 0;
}


#endif		// (USE_C99 == 0)

/*-------------------------------------------------
 * C99 Console code
 *------------------------------------------------- */

#if USE_C99

typedef unsigned char BYTE;

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

#if USE_LONG
 #include <time.h>
#endif

#define IO_POKE(AD,BY) *((BYTE *) ((unsigned int) (AD)))=(BYTE) (BY);
#define IO_PEEK(AD) ((BYTE) *((BYTE *) ((int) (AD))))

#define io_gets gets

  /* Print a char */
void io_putch (int ch)
{ 
    if (ch == '\n') putchar ('\r');
    putchar (ch); 
}

  /* Print a string */
void io_puts (const char *ostr) 
{ 
    char ch;
    while (ch = *ostr) {
      io_putch (ch);
      ostr ++;
    }
}

  /* Print an int */
void io_putint (int x)
{
    if (x<0) {
      x = -x; 
      io_putch ('-');
    }
    if (x>9) {
      io_putint (x/10);
    }
    io_putch ('0' + x%10);
}

void io_putsi (const char *ostr, int val)
{
    io_puts (ostr);
    io_putint (val); 
}

/*-------------------------------------------------
 * gam_  Console Main game
 *------------------------------------------------- */

char szIn [128];


 /* Callback func to Show search analysis.. */
void gam_analyShow (INTX cmove, int eval)
{
    io_putsi (" ",cmove);
    io_putsi ("=",eval);
}

void gam_Anim (INTX cmove)
{
}

int gam_Over ()
{
    int eval = sch_EndEval ();
      /* Some stones left to play ? */
    if (numa != board[KalahA] && numb != board[KalahB]) { 
      game_end = FALSE;
      return FALSE;
    }
    game_end = TRUE;
    io_putsi (" Game Over. Score: A=",numa);
    io_putsi (", B=",numb);
    io_puts ("\n");
}

void gam_BrdDraw ()
{
    INTX x;
    int nstone;
    io_puts ("\n");
    io_puts (" (B)");
    for (x = 0; x < npits - 1; x++) {
      nstone = board[npits * 2 - 2 - x];
      if (nstone < 10) io_putch (' ');
      io_putsi (" ",nstone);
    }
    io_puts ("\n");
    if (flag_display) {
      io_puts (" ---+");
      for (x = 0; x < npits - 1; x++) {
        io_puts ("--+");
      }
      io_puts ("---\n");
    }
    io_putch (' ');
    if (board [KalahB] < 10) io_putch (' ');
    io_putint (board [KalahB]); 
    io_puts (" : ");
    for (x = 0; x < npits-2; x++) {
      io_puts ("   ");
    }
    io_putsi (" : ",board [KalahA]);
    if (board [KalahA] < 10) io_putch (' ');
    io_puts ("\n");
    if (flag_display) {
      io_puts (" ---+");
      for (x = 0; x < npits - 1; x++) {
        io_puts ("--+");
      }
      io_puts ("---\n"); 
    }
    io_puts ("    "); 
    for (x = 0; x < npits - 1; x++) {
      nstone = board[x];
      if (nstone < 10) io_putch (' ');
      io_putsi (" ",nstone);
    }
    io_puts (" (A)\n\n");
    gam_Over ();
    if (game_end == FALSE) {
      io_puts (" Side "); io_putch ('A'+side);
      io_puts (" to move.\n");
    }
}

void gam_compMove ()
{
    int cret;
    do {
      io_puts ("      (");
      sch_CompMove ();
      if (sch_best == NO_MOVE) {
        gam_Over ();
        return;
      }
      io_putsi (")\nMove:",sch_best);
      io_putsi (" Eval:",sch_eval);
      io_putsi (" Node:",sch_node);
      #if USE_LONG
        if (sch_timeMove) {
          io_putsi (" Time:",sch_timeMove);
        }
      #endif
      io_puts (" \n");
      cret = sch_MakeMove (sch_best,0);
    } while (cret == 2);
}

int main ()
{
    int cmd;
    int cret;
    #ifdef IS_OSCAR
	//#include <c64/memmap.h>
	//#include <conio.h>

     //iocharmap(IOCHM_PETSCII_2);
     io_putch (5); io_putch (147); io_putch (14);
     IO_POKE (53280,0); IO_POKE (53281,0);
     IO_POKE (36879,8);
    #endif
    io_puts (PROG_NAME "\n");
    sch_New ();
    while (1) {
      gam_BrdDraw ();
      io_puts ("Cmd (xngait,1-9):");
      io_gets (szIn);
      cmd = toupper (szIn [0]);
      if (cmd == 'X') return 0;
      if (cmd == 'N') {		/* n:## New game (Set # stones, # pits) */
        if (szIn[1]>'0') {
	  nstart = szIn[1] & 15;
          if (szIn[2]>'1') {
	    npits = szIn[2] & 15;
	  }
	}
        sch_New ();
	continue;
      }
      if (cmd == 'I') {		/* I#: Set search level      */
        sch_level = szIn[1] & 15;
	io_putsi ("IQ:",sch_level);
      }
      if (cmd == 'T') {
        flag_2play = !flag_2play;
	io_putsi ("2 Play mode:",flag_2play);
      }
      if (cmd == 'C') {		/* Flip sides */
        side = !side;
      }
      if (cmd == 'H') {		/* Help */
        puts (PROG_NAME);
	puts ("\n"
	  "1-9: Make a move. (1=Left..)\n"	
	  "i#:  Set IQ search level\n"
	  "n##: New game. (## = No stones, No pits)\n"
	  "g:   Comp go\n"
	  "t:   Two player mode\n"
	  "x:   Exit\n"
	  "\n");
      }
      if (cmd == '$') {
        flag_display = !flag_display;
	io_putsi ("Display:",flag_display);
      }
      if (cmd == '!') {
        allow_null_capt = !allow_null_capt;
	io_putsi ("Allow null capture:",allow_null_capt);
      }
      if (game_end == FALSE) {
        if (cmd > '0' && cmd <= '9') {		/* Input human move */
          cret = sch_MakeMove (cmd & 15,0);
	  if (cret == 1) {
	    if (flag_2play == 0) {
              gam_BrdDraw ();
              gam_compMove ();		/* Comp reply */
	    }
	  }
        }
        if (cmd == 'G' || cmd == 0) {		/* g: Comp move */
          gam_compMove ();
        }
        if (cmd == 'A') {		/* a:  Auto Comp move */
          for (cmd = 1; cmd <= 6; cmd ++) {
            gam_compMove ();
	    if (game_end) break;
	  }
	}
      }
    }
}

#endif      // (USE_C99)
