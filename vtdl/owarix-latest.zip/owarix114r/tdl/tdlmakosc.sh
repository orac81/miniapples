#!/bin/sh
# tdlmakosc.sh  - Build TDL app with OSCAR64
#  Syntax  ./tdlmakosc.sh progname [parms]   
#  ie: ./tdlmakosc.sh skattabugz/skattabugz -O2 -g
#  Note   -g add asm source
echo "Building C64..      ($1.c)"
oscar64 -D TDL_CBM -D TDL_C64=1 -D IS_OSCAR=1 -tm=c64 $2 $3 $4 $5 $1.c -o=$1-c64.prg
echo "Building C64-PETSCII..      ($1.c)"
oscar64 -D TDL_CBM -D TDL_C64=1 -D IS_OSCAR=1 -D TDL_REQ_TEXT=1 -tm=c64 $2 $3 $4 $5 $1.c -o=$1-c64-petscii.prg
echo "Building VIC20.."
oscar64 -D TDL_CBM -D TDL_VIC20=1 -D IS_OSCAR=1 -tm=vic20  $2 $3 $4 $5 $1.c -o=$1-v20.prg
echo "Building VIC20-PETSCII.."
oscar64 -D TDL_CBM -D TDL_VIC20=1 -D IS_OSCAR=1 -D TDL_REQ_TEXT=1 -tm=vic20  $2 $3 $4 $5 $1.c -o=$1-v20-petscii.prg
echo "Building C16.."
oscar64 -D TDL_CBM -D TDL_C16=1 -D IS_OSCAR=1 -tm=plus4 $2 $3 $4 $5 $1.c -o=$1-c16.prg
echo "Building PET.."
oscar64 -D TDL_CBM -D TDL_PET=1 -D IS_OSCAR=1 -tm=pet  $2 $3 $4 $5 $1.c -o=$1-pet.prg
#echo "Building PET32k.."
#oscar64 -D TDL_CBM -D TDL_PET=1 -D IS_OSCAR=1 -tm=pet32  $2 $3 $4 $5 $1.c -o=$1-pet32k.prg
echo "Building PET80.."
oscar64 -D TDL_CBM -D TDL_PET80=1 -D IS_OSCAR=1 -tm=pet32  $2 $3 $4 $5 $1.c -o=$1-pet80.prg
