/* GLIFE1D.C - Test GFXLIB hires graphics library.
 (C) A.Millett 2025. Released as free software under GNU GPL3 license.

  Build: vc +vic20x  gfxlib-vbcc.asm gfxlib.c glife1d.c -o glife1d.prg -O2

Use function gfx_init(
    gfx_init (BYTE ink, BYTE back, BYTE aux)	// Set default ink, background, aux. Add GFX_MULTICOL to ink for multicol mode.
And then 
    gfx_plot (int x, int y, BYTE col)		// Plot x,y, Colour (0,1 in hires, 0-3 in multicol mode)

 */

#include <stdio.h>
#include "gfxlib.h"

#define NSTATE 5	// Try 4 or 5 here
#define NRULE  (NSTATE * 4 + 4)
#define WIDE (GFX_VDUX/2)

BYTE life [WIDE*2 + 8];
BYTE rule [NRULE];

UINT lifeseed = 1;
UINT drawtime = 0;

void life1d()
{
    int x,y,c;
    BYTE c1,c2,c3;
    drawtime = io_ticks ();
    io_srand (lifeseed);
	// Random rules
    for (x=0; x<=NRULE; x++) {
      rule [x] = io_rand () % NSTATE;
    }
	// Seed first line
    for (x=0; x<=WIDE+1; x++) {
      life [x] = io_rand () % NSTATE;
    }
	//Pick some colours
    do {	
      c1 = (io_rand() & 7); 
      c2 = (io_rand() & 7);
      c3 = (io_rand() & 7);
    } while (c1<2 || c1==c2);

    gfx_init (GFX_MULTICOL+c3, 8 | c1,c2);
	// Draw screen
    for (y=0; y<GFX_VDUY; y++) {
      for (x=0; x<WIDE; x++) {
        c = life[x] + life[x+1] + life [x+2];
        c = rule [c];
        life [x+WIDE+1] = c;
	gfx_plot (x,y,c & 3);
      }
      for (x=0; x<WIDE; x++) {
        life [x] = life[WIDE+x];
      }
    }
    drawtime = io_ticks () - drawtime;
}

char help_screen ()
{
    char cmd;
    gfx_end ();
    io_prints (
	" *** gfx-life-1d ***\n\n"
	"\x9c(c)a.millett.freeware!\n\n"
	"\x1e" 
	"h = view help\n"
	"- = seed  -1\n"
	"> = seed +10\n"
	"< = seed -10\n"
	"r = rand seed\n"
        "enter = redraw\n"
        "space = next seed\n"
    );
    io_printsi ("\x9f\nseed:",lifeseed);
    io_printsi ("\ndraw time:",drawtime);
    //io_printsi ("\n ticks:",io_ticks ());
    io_prints ("\n\n\x05 hit space..");
    while ((cmd = io_getkey ()) == 0);
    return cmd;
}

int main ()
{
    char cmd;
    cmd = help_screen ();
    while (1) {
      life1d ();
      do {
        cmd = io_getkey ();
      } while (cmd == 0);
again:
      switch (cmd) {
	case 'q' : return 0;
	case 'r' : 	// Rand seed
	  lifeseed = io_ticks () & 32767;
	  break;
	case 'h' : 	// Help/info screen
	  cmd = help_screen ();
	  goto again;
	case '>' : 
          lifeseed += 10;
	  break;
	case '<' : 
          lifeseed -= 10;
	  break;
	case '-' : 
          lifeseed --;
	  break;
	case 13 : 
	case 'a':
	  break;
	default:
          lifeseed ++;
	  break;
      }
    }
    return 0;
}
