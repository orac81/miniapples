/* GFXTEST.C - Test GFXLIB hires graphics library.
 (C) A.Millett 2025. Released as free software under GNU GPL3 license.

  Build: vc +vic20x gfxlib-vbcc.asm gfxlib.c gfxtest.c -o gfxtest.prg -O2

Use function gfx_init(
    gfx_init (BYTE ink, BYTE back, BYTE aux)	// Set default ink, background, aux. Add GFX_MULTICOL to ink for multicol mode.
And then 
    gfx_plot (int x, int y, BYTE col)		// Plot x,y, Colour (0,1 in hires, 0-3 in multicol mode)

 */

#include <stdio.h>
#include "gfxlib.h"

#define USE_FLOAT 0


  // Plot curves hires 160x192
void test1 ()
{
    int x,y,i;
    gfx_init (1,8,3);
    for (i=4; i<100; i+=4) {
      for (x=-80; x<80; x++) {
        y = i+x*x/i;
	if ((UINT) y<GFX_VDUY) gfx_plot (x+80, y,1);
      }
    }
}

  // Plot curves MULTICOL (80x192)
void test2 ()
{
    int x,y,i,c;
    gfx_init (GFX_MULTICOL+1,0x0c,3);
    // for (x=0; x<80; x++) {gfx_plot (x,x,3); } while (1); // Simple test
    for (c=1; c<4; c++) {
      //gfx_init (GFX_MULTICOL+1,0x48,3);
      for (i=4; i<200; i+=6) {
        for (x=-40; x<40; x++) {
	  y = i+c+c+x*x/i;
	  if ((UINT) y<GFX_VDUY) gfx_plot (x+40,y,c);
        }
      }
    }
}

  // kalidescope fx
void test3 ()
{
    int t,x,y,c,x1,y1,n;
    c = 2 + (io_rand () % 6);
    n = io_rand () & 511;
    gfx_init (GFX_MULTICOL+1, 8 | c,3);
    for (t=0; t<n; t++) {
      for (c=0; c<4; c++) {
        x = io_rand () % (GFX_VDUX/2);
        y = io_rand () % GFX_VDUY;
        x1 = GFX_VDUX/2-x; y1 = GFX_VDUY-y;
	gfx_plot (x,  y,  c);
	gfx_plot (x1, y,  c);
	gfx_plot (x,  y1, c);
	gfx_plot (x1, y1, c);
      }
    }
}

void delay (BYTE d)
{
    UINT p;
    p = io_ticks () + (d * IO_TICKS_PER_SEC);
    while (io_ticks() != p);
}

int main ()
{
    gfx_end ();		// Back to Text mode
    io_prints ("\x05\x93   \x9f*** gfxlib ***\x05\n\n\n"
		"gfxtest, a simple demo\n");
      // gfx_plot_asm (1,2,3); while (io_getkey ()==0);
    delay (2);
    while (1) {
      test1 ();
      delay (2);
      test2 ();
      delay (2);
      test3 ();
      delay (3);
      //while (io_getkey ()==0);
    }
}
