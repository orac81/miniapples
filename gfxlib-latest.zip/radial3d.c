/* RADIAL3D.C - Classic Radial 3D plot, test GFXLIB hires graphics library.
 (C) A.Millett 2025. Released as free software under GNU GPL3 license.

  Build: vc +vic20x  vicfill2k.asm gfxlib.c radial3d.c -o radial3d.prg -lm

 */

#include <stdio.h>
#include "gfxlib.h"


#include <math.h>

 // Quick, approx cosine. Accurate to 3.2 digits, range (0,pi/2)
 // cos(x)= c1 + c2*x**2 + c3*x**4..
float cos32s(float x)
{
  const float c1=0.99940307;
  const float c2=-0.49558072;
  const float c3=0.03679168;
  float x2;
  x2=x*x;
  return (c1 + x2*(c2+c3*x2));  
}

float cos32(float x)
{
  int qu;
  const float pi=3.1415926;
  float z;
  qu = (int) ((float) (x+x)/pi);
  z = pi*((int) (qu & 0xfffc)/2);
  if (x<0) x=-x;
  x=x-z;
  switch (qu & 3) {
    case 0: return  cos32s (x);
    case 1: return -cos32s (pi-x);
    case 2: return -cos32s (x-pi);
    case 3: return  cos32s (pi+pi-x);
  }
  return 0;
}

  // int square root
UINT isqr(UINT x) 
{
    int k=1;
    while (k*k <= x) k++;
    return (k--);
}

  // float square root (approx)
float fsqr(float x) 
{
    float g,g2;
    int n=6;
    if (x<=0) return 0;
    g = (float) isqr((UINT) x);
    do {
      g2 = g;
      g = (g + x/g)/2.0;
      n --;
    } while (n && g2 != g);
    return g;
}

void testcos ()
{
    float f;
    int x,y,n;
    gfx_init (1,8,3);
    for (n=2; n<17; n++) {
     for (x=0; x< GFX_VDUX; x++) {
      f = (cos32 ((float) x/(32-n)) + 1) * (GFX_VDUY/2-16);
      y = (int) f + n + n;
      gfx_plot (x, y, 1);
      // y = fsqr(x); gfx_plot (x/2, y, 1);
     }
    }
}

 // Radial 3d plot
void test3d()
{
  int x1,x2,y1,y2;
  int x4,m,x,y;
  float a,r,f,i,r2;
  const int vstep = 24;

  gfx_init (1,8,3);
  x1 = GFX_VDUX / 2; x2 = x1 * x1;
  y1 = GFX_VDUY / 2; y2 = y1 / 2;
  for (x = 0; x<=x1; x++) {
    x4 = x * x;
    m = -y1;
    a = fsqr ((float) (x2 - x4));
    for (i = -a; i<= a; i+= GFX_VDUY / vstep) {
      r = fsqr ((float) x4 + i * i ) / (float) x1;
      f = (r - 1) * cos32(r * 12);
      // f = ( (1 - r) ** 4) +  (1-r)*((r) ** 2) - 1; 
      // r2 = 1-r ; f = (2*r2*r2)-(r*r*r)-(r*r*r*r) ; 
      y = (int) ((float) i / 5 + f * y1);
      if (y > m) {
        m = y;
        y = y1 - y;
	gfx_plot (x1 - x, y, 1);
	gfx_plot (x1 + x, y, 1);
      }
    }
  }
}

int main ()
{
	UINT p;
	
    test3d();
    for (p=1; p; p++) ;
    // testcos (); for (p=1; p; p++) ;
    while (1) {};
}
