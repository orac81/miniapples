/* GFXLIB.C - Hires graphics Library for VIC20.
 (C) A.Millett 2025. Released as free software under GNU GPL3 license.

 Build with VBCC for VIC20, example build "gfxtext.c":   
     vc +vic20x gfxlib-vbcc.asm gfxlib.c gfxtest.c -o gfxtest.prg -O2
       (Also See: gfxmake.bat)

Use these functions:
    gfx_init (BYTE ink, BYTE back, BYTE aux)	// Set ink, background, aux. Add GFX_MULTICOL to ink for multicol mode.
And then 
    gfx_plot (int x, int y, BYTE col)	// Plot x,y, Colour (0,1 in hires, 0-3 in multicol mode)

See examples (GFXTEST.C, GLIFE1D.C) for how to use..

So we will have both screen and char set at $1000. VDU set to 8x16 chr mode.
Screen will be 256 bytes $1000-10ff, Hires $1100-1fff, 160x192 (20x192=$0f00)
Fill screen with index codes 0..239. 
Screen chars ordered vertically for easy decoding in columns 0,1,..10,11, 
then next col 12..23, etc.
or going across 0,12,24,36,48.. Next chr line 1,13,25,37,49..
* 
-> GFXLIB101.ZIP (26.7.2025)
-> GFXLIB102.ZIP (27.7.2025)
-> GFXLIB103.ZIP (28.7.2025)
 */

#define USE_ASM 1		// Use  ASM routines

#include <stdio.h>
#include "gfxlib.h"

BYTE *pVdu   = (BYTE *) ((UINT) V20_VDULOC);		/* Ptr to screen */
BYTE *pCol   = (BYTE *) ((UINT) V20_COLRAM);		/* Ptr to colour ram */
BYTE *pHires = (BYTE *) ((UINT) V20_HIRES);		/* Ptr to hires data  */

/*------------------------------------------------------------------------------------
   io_..  Minimal C I/O lib
--------------------------------------------------------------------------------------*/

void io_printc (char c)
{
    io_raw_putchar (c);
}

//void io_printc (char c) ;		// Fwd declare

	/* Print a null-term string */
void io_prints (char *istr)	
{
	int cchr;
        for (cchr = 0; istr [cchr]; cchr ++) {
	  io_printc ( istr [cchr]);
	  if (istr [cchr] == 10) io_printc (13);
	}
}

  /* Print a signed int */
void io_printi (int x)		
{
	if (x<0) {
	 x = -x; io_printc ('-');
	}
        if (x>9) {
	  io_printi (x/10);
	}
        io_printc ('0' + x%10);
}

		/* Composite short cut */
void io_printsi (char *istr, int iint)
{
	io_prints (istr);
	io_printi (iint);
}

char io_getkey ()
{
    return io_raw_getkey ();
}

  // Very simple (not very) random num gen.
int io_randseed = 1;

void io_srand (int seed)
{
    io_randseed = seed;
}

int io_rand ()
{
    io_randseed = (io_randseed * 37) + 1;
    return ((io_randseed>>8)+(io_randseed<<8)) & 0x7fff;
}

  // Ret jiffy count UINT wrapping time var
UINT io_ticks ()
{
    return (IO_PEEK (ZP_JIFFY+2) + IO_PEEK (ZP_JIFFY+1)*256);
}

/*------------------------------------------------------------------------------------
   GFX_ lib functions.
--------------------------------------------------------------------------------------*/

BYTE *pDest;
UINT ptr;


  /* Initialise VIC20 hires mode 160x192, or 80x192 multicol 
     ADD GFX_MULTICOL to ink for 4 color mode */

BYTE gfx_mode=0;

void gfx_init (BYTE ink, BYTE back, BYTE aux)
{
    BYTE x,y,xx,yy;
    gfx_mode = ink & GFX_MULTICOL;
    IO_POKE (V20_BACKCOL, back);
    IO_POKE (V20_VOL, aux<<4);	// Aux colour
    IO_POKE (V20_VIDADD,0xcc);		// Set VDU=$1000,CHRSET=$1000 (Normally $c0 (v20+8k) for Default VDU=$1000,CHRSET=$8000)
    IO_POKE (V20_HSIZE, GFX_VDUCHX);		// Set #cols
    IO_POKE (V20_VSIZE, GFX_VDUCHY*2+129);	// Set #rows*2, bit0 set for 8x16chr.
	// Init colour ram
    pDest = (BYTE *) V20_COLRAM;
    for (ptr = 0; ptr < (UINT) 0x0400; ptr ++) {
      pDest [ ptr] = ink;
    }
	// Fill char screen with index codes for hires
    yy = 0;
    for (y=0; y<GFX_VDUCHY; y++) {
      pDest = (BYTE *) ((UINT) V20_VDULOC+yy);
      xx=0;
      for (x=0; x<GFX_VDUCHX; x++) {
        pDest[x] = 16+y+xx;
        xx += GFX_VDUCHY;
      }
      yy+=GFX_VDUCHX;
    }
    //pDest = (BYTE *) V20_HIRES;
    for (ptr = V20_HIRES; ptr < V20_HIRES_END; ptr++) {
      IO_POKE (ptr,0);
    }
}

  // Plot X,Y, Colour (0,1 in hires, 0-3 in multicol mode)
void gfx_plot (BYTE xpos, BYTE ypos, BYTE col)
{
    #if USE_ASM
      gfx_plot_asm (xpos, ypos, col);
    #else
      BYTE b;
      if (gfx_mode & GFX_MULTICOL) { 			// 4 color mode?
        ptr = (UINT) (xpos>>2) * 192 + ypos;
        if (xpos>=GFX_VDUX/2 || ypos>= GFX_VDUY || (UINT) ptr > 0x0f00) return;
        xpos= 6-((xpos&3)<<1); 		// bitshift is 0,2,4,6
        pHires [ptr] &= ~(3<<xpos);	// mask bits to change
        pHires [ptr] |= (col<<xpos);
        return;
      }
			// Hires 2 col mode.
      ptr = (UINT) (xpos >> 3) * 192 + ypos;	// Calc byte pos in hires mem.
      if (xpos >= GFX_VDUX || ypos >= GFX_VDUY || (UINT) ptr > 0x0f00) return;	// Out of range
      b = 128>>(xpos&7);
      if (col) {
        pHires [ptr] |= b;		// Plot pixel
      } else {
        pHires [ptr] &= ~b;		// Unplot pixel
      }
    #endif
}

  /* Back to text mode */
void gfx_end ()
{
    IO_POKE (V20_BACKCOL, 8);
    IO_POKE (V20_VIDADD,0xc0);	
    IO_POKE (V20_HSIZE, 22);		// Set #cols
    IO_POKE (V20_VSIZE, 23*2+128);	// Set #rows*2, bit0 set for 8x16chr.
    io_printc (5); io_printc (147);	// Clr vdu
}
