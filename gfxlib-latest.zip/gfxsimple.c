/* GFXSIMPLE.C - Simple demo GFXLIB hires graphics library. (VIC20)

  Build: vc +vic20x gfxlib-vbcc.asm gfxlib.c gfxsimple.c -o gfxsimple.prg -O2

 */

#include <stdio.h>
#include "gfxlib.h"

  // Plot curves hires 160x192
void test1 ()
{
    int x,y,i;
    gfx_init (1,8,3);
    for (i=4; i<100; i+=4) {
      for (x=-80; x<80; x++) {
        y = i+x*x/i;
	if ((UINT) y<GFX_VDUY) gfx_plot (x+80, y,1);
      }
    }
}

int main ()
{
    test1 ();
    while (1);
}
