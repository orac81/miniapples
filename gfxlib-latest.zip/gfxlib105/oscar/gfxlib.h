
/* VIC-HIRES.C - Test Vic20 hires graphics for VBCC.
 (C) A.Millett 2025. Released as free software under GNU GPL3 license.

  Build example: vc +vic20x gfxlib-vbcc.asm gfxlib.c gfxtest.c -o gfxtest.prg 

Use function gfx_init(
    gfx_init (BYTE ink, BYTE back, BYTE aux)	// Set ink, background, aux. Add GFX_MULTICOL to ink for multicol mode.
And then 
    gfx_plot (int x, int y, BYTE col)	// Plot x,y, Colour (0,1 in hires, 0-3 in multicol mode)
See samples at end.

So we will have both screen and char set at $1000. VDU set to 8x16 chr mode.
Screen will be 256 bytes $1000-10ff, Hires $1100-1fff, 160x192 (20x192=$0f00)
Fill screen with index codes 0..239. 
Screen chars ordered vertically for easy decoding in columns 0,1,..10,11, 
then next col 12..23, etc.
or going across 0,12,24,36,48.. Next chr line 1,13,25,37,49..
 */


#define GFX_VERSION 104

typedef unsigned char BYTE;
typedef unsigned int UINT;

#define ZP_JIFFY 0x00a0		// CBM system clock, 3 bytes hi,med,low. in jiffys (1/60 sec)

	// VIC regs
#define V20_HPOS    0x9000		// bits 0-6 horizontal pos/centering, bit 7 sets interlace scan (36864) [PAL:12,NTSC:5]
#define V20_VPOS    0x9001		// vert position [PAL:38,NTSC:25]
#define V20_HSIZE   0x9002		// bits 0-6 set # of columns, bit 7 part video matrix address
#define V20_VSIZE   0x9003		// bits 1-6 set # of rows, bit 0 for 8x8 or 8x16 chars
#define V20_RASTER  0x9004		// current video raster line
#define V20_VIDADD  0x9005		// Vid/chrset address: bits 0-3 charset address, bits 4-7 screen address.  (36869)
#define V20_PENH    0x9006		// Light pen horiz
#define V20_PENV    0x9007		// Light pen vert
#define V20_PADX    0x9008		// Paddle X
#define V20_PADY    0x9009		// Paddle Y
#define V20_VOICE1  0x900a		// Voice osc 1 (128-255) bit 7 on/off (36874)
#define V20_VOICE2  0x900b		// Voice osc 2 (128-255) bit 7 on/off
#define V20_VOICE3  0x900c		// Voice osc 3 (128-255) bit 7 on/off
#define V20_NOISE   0x900d		// Voice noise (128-255) bit 7 on/off
#define V20_VOL     0x900e		// bit 0-3 overall volume, bits 4-7 aux color in multicolor mode.
#define V20_BACKCOL 0x900f		// Screen/border color, bits 4-7 screen background, bits 0-2 border, bit 3 for inverted/normal mode (36879)
	// Other VIC regs
#define V20_VIA1    0x9110		// VIC20 6522 VIA1
#define V20_VIA2    0x9120		// VIC20 6522 VIA2
#define V20_COLRAM  0x9400		// VIC20 colour ram if vdu $1000 (9600 for vdu $1e00)  
#define V20_CHARROM 0x8000		// VIC20 ROM char set.
	// VIC mem locs
#define V20_VDULOC  0x1000		// VDU text chrs
#define V20_HIRES   0x1100		// VDU hires data
#define V20_HIRES_END 0x2000		// VDU hires end

#define GFX_VDUX 160			// VDU width/height in pixels
#define GFX_VDUY 192		
#define GFX_VDUCHX 20			// VDU width/height in chars (8x16)
#define GFX_VDUCHY 12		

extern BYTE *pVdu;		/* Ptr to screen */
extern BYTE *pCol;		/* Ptr to colour ram */
extern BYTE *pHires;		/* Ptr to hires data  */

#define GFX_MULTICOL 8

void gfx_init (BYTE ink, BYTE back, BYTE aux);
  // Plot X,Y, Colour (0,1 in hires, 0-3 in multicol mode)
void gfx_plot (BYTE xpos, BYTE ypos, BYTE col);
void gfx_end ();
void gfx_plot_asm (BYTE xpos, BYTE ypos, BYTE col);

extern char io_hires_mem[];		// Unused: Static ptr to hires/charset mem.

BYTE io_raw_getkey ();
void io_raw_putchar (BYTE c);
		// Simple I/O lib functions
void io_printc (char );
void io_prints (const char *);
void io_printi (int );
void io_printsi (const char *, int);
int  io_rand ();			// Simple random number gen, ret 0-32767
void io_srand (int);	
char io_getkey ();
UINT io_ticks ();
#define IO_TICKS_PER_SEC 60		// Jiffys per sec

  // Simple peek/poke macros
#define IO_POKE(AD,BY) *((BYTE *) ((UINT) AD))=(BYTE) (BY);
#define IO_PEEK(AD) ((BYTE) *((BYTE *) ((UINT) AD)))
#define IO_DOKE(AD,BY) *((UINT *) ((UINT) AD))=(UINT) (BY);
#define IO_DEEK(AD) ((UINT) *((UINT *) ((UINT) AD)))

//#pragma compile("gfxlib.c")

