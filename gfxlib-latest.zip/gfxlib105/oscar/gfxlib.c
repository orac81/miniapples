/* GFXLIB.C - Hires graphics Library for VIC20.
 (C) A.Millett 2025. Released as free software under GNU GPL3 license.

To build with OSCAR64:
oscar64 -O2 -tm=vic20+16 gfxlib.c gfxsimple.c -o=gfxsimple.prg

Use these functions:
    gfx_init (BYTE ink, BYTE back, BYTE aux)	// Set ink, background, aux. Add GFX_MULTICOL to ink for multicol mode.
And then 
    gfx_plot (int x, int y, BYTE col)	// Plot x,y, Colour (0,1 in hires, 0-3 in multicol mode)

See examples (GFXTEST.C, GLIFE1D.C) for how to use..

So we will have both screen and char set at $1000. VDU set to 8x16 chr mode.
Screen will be 256 bytes $1000-10ff, Hires $1100-1fff, 160x192 (20x192=$0f00)
Fill screen with index codes 0..239. 
Screen chars ordered vertically for easy decoding in columns 0,1,..10,11, 
then next col 12..23, etc.
or going across 0,12,24,36,48.. Next chr line 1,13,25,37,49..
 
-> GFXLIB101.ZIP (26.7.2025)
-> GFXLIB102.ZIP (27.7.2025)
-> GFXLIB103.ZIP (28.7.2025)
  Imp changes for OSCAR
-> GFXLIB104.ZIP (10.8.2025)
-> GFXLIB105.ZIP (10.8.2025)
*/


  // VIC20: Force code up to $2000, leave $1000-!FFF for hires gfx.
#include <c64/memmap.h>
#pragma region( main, 0x2020, 0x6000, , , {code, data, bss, heap, stack} )

#define USE_ASM 1		// Use  ASM routines

#include <stdio.h>
#include <conio.h>
#include "gfxlib.h"

BYTE *pVdu   = (BYTE *) ((UINT) V20_VDULOC);		/* Ptr to screen */
BYTE *pCol   = (BYTE *) ((UINT) V20_COLRAM);		/* Ptr to colour ram */
BYTE *pHires = (BYTE *) ((UINT) V20_HIRES);		/* Ptr to hires data  */

/*------------------------------------------------------------------------------------
   io_..  Minimal C I/O lib
--------------------------------------------------------------------------------------*/

void io_printc (char c)
{
    putch (c);
}

	/* Print a null-term string */
void io_prints (const char *istr)	
{
	int cchr;
        for (cchr = 0; istr [cchr]; cchr ++) {
	  io_printc ( istr [cchr]);
	  // if (istr [cchr] == 10) io_printc (13);
	}
}

  /* Print a signed int */
void io_printi (int x)		
{
	if (x<0) {
	 x = -x; io_printc ('-');
	}
        if (x>9) {
	  io_printi (x/10);
	}
        io_printc ('0' + x%10);
}

		/* Composite short cut */
void io_printsi (const char *istr, int iint)
{
	io_prints (istr);
	io_printi (iint);
}

char io_getkey ()
{
    if (kbhit () ==0) return 0;
    return getch ();
}

  // Very simple (not very) random num gen.
int io_randseed = 1;

void io_srand (int seed)
{
    io_randseed = seed;
}

int io_rand ()
{
    io_randseed = (io_randseed * 37) + 1;
    return ((io_randseed>>8)+(io_randseed<<8)) & 0x7fff;
}

  // Ret jiffy count as UINT wrapping time var (avoids LONG, but wraps after 18 mins.)
UINT io_ticks ()
{
return  __asm 		// (Using asm here stops it being optimized out)
    {
	lda $a2		//CBM_JIFFY+2
	sta accu
	lda $a1		// CBM_JIFFY+1
	sta accu+1
	rts
    };
}

/*------------------------------------------------------------------------------------
   GFX_ lib functions.
--------------------------------------------------------------------------------------*/

BYTE *pDest;
UINT ptr;


  /* Initialise VIC20 hires mode 160x192, or 80x192 multicol 
     ADD GFX_MULTICOL to ink for 4 color mode */

BYTE gfx_mode=0;

void gfx_init (BYTE ink, BYTE back, BYTE aux)
{
    BYTE x,y,xx,yy;
    gfx_mode = ink & GFX_MULTICOL;
    IO_POKE (V20_BACKCOL, back);
    IO_POKE (V20_VOL, aux<<4);	// Aux colour
    IO_POKE (V20_VIDADD,0xcc);		// Set VDU=$1000,CHRSET=$1000 (Normally $c0 (v20+8k) for Default VDU=$1000,CHRSET=$8000)
    IO_POKE (V20_HSIZE, GFX_VDUCHX);		// Set #cols
    IO_POKE (V20_VSIZE, GFX_VDUCHY*2+129);	// Set #rows*2, bit0 set for 8x16chr.
	// Init colour ram
    pDest = (BYTE *) V20_COLRAM;
    for (ptr = 0; ptr < (UINT) 0x0400; ptr ++) {
      pDest [ ptr] = ink;
    }
	// Fill char screen with index codes for hires
    yy = 0;
    for (y=0; y<GFX_VDUCHY; y++) {
      pDest = (BYTE *) ((UINT) V20_VDULOC+yy);
      xx=0;
      for (x=0; x<GFX_VDUCHX; x++) {
        pDest[x] = 16+y+xx;
        xx += GFX_VDUCHY;
      }
      yy+=GFX_VDUCHX;
    }
    //pDest = (BYTE *) V20_HIRES;
    for (ptr = V20_HIRES; ptr < V20_HIRES_END; ptr++) {
      IO_POKE (ptr,0);
    }
}

#if USE_ASM

// zptr = $fe	; zero page byte general pointer (2 bytes)

BYTE tab_pow2[8] = {128,64,32,16,8,4,2,1};
BYTE tab_vdu_lo[] = {0,192,128,64,0,192,128,64,0,192,128,64,0,192,128,64,0,192,128,64};   // VDU loc mul by 192
BYTE tab_vdu_hi[] = {17,17,18,19,20,20,21,22,23,23,24,25,26,26,27,28,29,29,30,31};
BYTE tab_colpos_mask_xor[] ={0x3f,0xcf,0xf3,0xfc};	// %00111111,%11001111,%11110011,%11111100 ; turn multicol xpos (0-3) to bit position mask
BYTE tab_colpos_mask[] ={0xc0,0x30,0x0c,0x03};		// %11000000,%00110000,%00001100,%00000011 ; turn multicol xpos (0-3) to bit position
BYTE tab_color_mask[] = {0,0x55,0xaa,0xff};		// byte %00000000,%01010101,%10101010,%11111111	; and with above for color
BYTE tempmask;

// ; void gfx_plot_asm (BYTE xpos, BYTE ypos, BYTE col)    // Parms: xpos=x,ypos=y,r4=col
// ; Plot to 160x192 hires screen at $1100-$1fff
// ; NOTE VBCC param locations can change, build with -O2, check code before use..

  // Plot X,Y, Colour (0,1 in hires, 0-3 in multicol mode)
void gfx_plot (BYTE xpos, BYTE ypos, BYTE col)
{
 __asm {
    lda gfx_mode
    bne gfxmultiplot	// 4-color plot
    lda xpos		// x pos
    cmp #GFX_VDUX	// X out of range?
    bcs gfx_bye
		// $fe = (UINT) (x >> 3) * 192 //	// Calc byte pos in hires mem.
    lsr
    lsr 
    lsr
    tax
    lda tab_vdu_lo,x	// VDUPOS start of each column (step by 192) look up tab
    sta $fe
    lda tab_vdu_hi,x
    sta $fe+1
      //b = (128>>(x&7));  // Calc bit mask
    lda xpos		// xpos
    and #7
    tax
    lda tab_pow2,x
    tax			// save mask in x

    ldy ypos		// y = y pos
    cpy #GFX_VDUY	// Y out of range?
    bcs gfx_bye
 
    lda col		// a=colour
    bne gfxplot1	// plot a point
	//  pHires [ptr] &= ~b;		// Unplot pixel
    txa
    eor #$ff
    and ($fe),y
    sta ($fe),y
    clc
    bcc gfx_bye
	//  pHires [ptr+] |= b;	// Plot pixel
gfxplot1:     
    txa
    ora ($fe),y
    sta ($fe),y
gfx_bye:
    rts

gfxmultiplot:		// Plot multicol pixel
    lda xpos		// x pos
    cmp #GFX_VDUX/2	// X out of range?
    bcs gfx_bye
	//$fe = VDUPOS + (UINT) (x >> 2) * 192 ;	// Calc byte pos in hires mem.
    lsr 
    lsr
    tax
    lda tab_vdu_lo,x	// VDUPOS start of each column (step by 192) look up tab
    sta $fe
    lda tab_vdu_hi,x
    sta $fe+1
			// y = y pos
    ldy ypos	
    cpy #GFX_VDUY	// Y out of range?
    bcs gfx_bye
	// Now we mask out the old bits at ($fe),y and put the new colour in.
			// Calc mask index
    lda xpos		// xpos
    and #3
    tax
    lda tab_colpos_mask_xor,x	// Inverse Bitwise plot pos mask
    and ($fe),y	// Mask with existing screen bitmap data
    sta tempmask	// Save..
    lda tab_colpos_mask,x  // Bit wise plot pos in byte
    pha
    lda col		// a=colour
    and #3
    tax 
    pla 
    and tab_color_mask,x
    ora tempmask
    sta ($fe),y
    rts
  };
} 

#else


  // Plot X,Y, Colour (0,1 in hires, 0-3 in multicol mode)
void gfx_plot (BYTE xpos, BYTE ypos, BYTE col)
{
      BYTE b;
      if (gfx_mode & GFX_MULTICOL) { 			// 4 color mode?
        ptr = (UINT) (xpos>>2) * 192 + ypos;
        if (xpos>=GFX_VDUX/2 || ypos>= GFX_VDUY || (UINT) ptr > 0x0f00) return;
        xpos= 6-((xpos&3)<<1); 		// bitshift is 0,2,4,6
        pHires [ptr] &= ~(3<<xpos);	// mask bits to change
        pHires [ptr] |= (col<<xpos);
        return;
      }
			// Hires 2 col mode.
      ptr = (UINT) (xpos >> 3) * 192 + ypos;	// Calc byte pos in hires mem.
      if (xpos >= GFX_VDUX || ypos >= GFX_VDUY || (UINT) ptr > 0x0f00) return;	// Out of range
      b = 128>>(xpos&7);
      if (col) {
        pHires [ptr] |= b;		// Plot pixel
      } else {
        pHires [ptr] &= ~b;		// Unplot pixel
      }
}
#endif

  /* Back to text mode */
void gfx_end ()
{
    iocharmap(IOCHM_PETSCII_2); 
    IO_POKE (V20_BACKCOL, 8);
    IO_POKE (V20_VIDADD,0xc0);	
    IO_POKE (V20_HSIZE, 22);		// Set #cols
    IO_POKE (V20_VSIZE, 23*2+128);	// Set #rows*2, bit0 set for 8x16chr.
    io_printc (5); io_printc (147);	// Clr vdu
}
