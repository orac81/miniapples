#!/bin/sh
# makgfxosc.sh  - Build gfxlib app using OSCAR64. Ensure $PATH includes OSCAR dir.
oscar64 -O2 -tm=vic20+16 gfxlib.c $1.c $2 $3 $4 -o=$1.prg 
