/* GFXSIMPLE.C - Simple demo GFXLIB hires graphics library. (VIC20)

  Build: vc +vic20x gfxlib-vbcc.asm gfxlib.c gfxsimple.c -o gfxsimple.prg -O2
  Build: oscar64 -O2 -tm=vic20+16 gfxlib.c gfxsimple.c -o=gfxsimple.prg
 */

	// Force VIC20 start up high for hires gfx 

#include <stdio.h>
#include <conio.h>
#include "gfxlib.h"

  // Plot curves hires 160x192
void test1 ()
{
    int x,y,i;
    gfx_init (1,8,3);
    for (i=4; i<100; i+=4) {
      for (x=-(GFX_VDUX/2); x<(GFX_VDUX/2); x++) {
        y = i+x*x/i;
	if ((UINT) y<GFX_VDUY) gfx_plot (x+(GFX_VDUX/2), y,1);
      }
    }
}

int main ()
{
    test1 ();
    while ( io_getkey()==0);
}
