/*  RACERxx.C, Car racing game, for MSDOS. 
  Copyright A.Millett, PC Solutions 1993-2024. 
  Released as free software under GNU GPL3 license, see GNU website:    www.gnu.org/licenses/gpl-3.0.html 

  History:- Take TANX20, Adapt..
  Imp simple scrolling demo using org TANX graphics.
  -> RACE10, 18.5.93
  Design some graphics (imp full col palettes on SAF23)
  Imp simple scrolling road. Imp ISHADOW, XMAP.
  -> RACE11, 20.5.93
  Redo PUTSPR, imp moving car.
  -> RACE12, 25.5.93
  Imp RACECH charset, RPUTOBJECT, PRINTSTRAT etc.
  -> RACE14, 27.5.93
  Imp CGA/EGA mode using 40col txt (CGAGAME etc)
  -> RACE15, 6.6.93
  Tidy up bits - inp CGASTRAT. Imp SOUNDCMD. Tidy TITLESCREEN.
  -> RACE16, 10-15.6.93
  Scroll Bug - doesnt work with modern VGA cards!
  Experiment with VESA calls - no help.
  -> RACE16b.c
  Imp MODEX graphics.
  Re-write VGA addressing for planar graphics.
  -> RACE17.C, 20.6.94
  Imp new adscreen from BLITZ
  Imp Spike & Bonus.
  Imp Road narrow/widen..
  Imp Oppcar..
  -> RACE18, 19.7.94
  Tidy up bits, slower on-coming cars, Slow speed implemeted..
  -> RACE19, 28.8.94
  Remove Adverts/shareware texts. Add GPL texts.
  -> RACER20, 14.9.2024
  
*/

#define PROG_VER "2.0"

#include <stdio.h>
#include <dos.h>	/* Defines union REGS, INT86 */
#include <alloc.h>	/* FARCORELEFT,FARMALLOC */

typedef unsigned char BYTE;     /* A convenient new data type */

#define CHEAT_MODE 1
#define Noload 1		/* Built in .SPR data? */
#define Debug 0

void syncfly ();
void pause (int ticks);

int loaderror = 0;
int kcmd;		/* Command key hit */
int inkey;
int pxpos,pypos; 	/* Player posn */
int xpos,ypos;		/* General pos */
int txpos,typos;	/* General pos */
int axpos,aypos,axdir,aydir;
int gxpos,gypos;
int thit;
int bxpos,bypos;	/* Bullet pos */
int bxdir,bydir;
int nflying;		/* No bullets active */
int cbullet;
int delaybul;
int txdir,tydir;
int xdir,ydir;
int onto;		/* Contents dest sqr */
int score,hiscore;
int maxscore;		/* Max possible score */

int cscreen;
int temp;

int nports;		/* Teles on screen */
int cport;

int kguns;
int cgun,xgun;
int gunchr;		/* Char of bullet */
int gunfreq;
int nbullets;		/* No of Bullets */

int realtime = 0;
long xtime;
long lasttime;

int cmap = 0;
int cobj;
int cspeed = 1,gamespeed = 1;
int spcount = 0;
int ccount;
int cxpos, cypos;
int ninv;		/* Invader-zombies */
int calien;		/* Current alien-type */
int tline;
int cheatmode= 0;
int demomode = 0;
int nlifes = 3;

char far *Vdu;		/* Pointer to CGA screen */
char far *Vdux;
int far *Vdui;
int far *Vdu2;
int far *Vducar;
#define Mboard 4000
char board [Mboard + 5];	/* Virtual Playing area */

#define Mobj 40
#define Msprite 11000
#define Maxx 19
#define Maxy 11
#define Mbul 30

int bulxpos [Mbul+1],bulypos [Mbul+1];	/* Bullet pos/dir.. */
int bulxdir [Mbul+1],bulydir [Mbul+1];
int bulspeed [Mbul + 1];
int null [10];

int charx = 16;
int chary = 16;
int halfy = 8;
int sprsize = 256;
int tanxfx = 0;
int countdown = 1;
int looptick = 0;
int virtx = 60,virty = 36;	/* Virtual screen (x,y) size */
int mapx = 0,mapy = 0;		/* Offset for real screen in board */
int zloc;
int soundcmd = 0;

long freeram;		/* Free Memory in FAR heap */
char far *pshadow;	/* Pointer to FAR VDU shadow ram */
char far *pshadow2;
char far *cpShadow;
int far *ishadow;
int huge *hshadow;
char far *shiftkey;
int huge *xshadow;
int huge *Vdup;
unsigned long ltemp;
int botline = 30;

#define regv _DX

  unsigned char sprites [] =	/* Sprite data */
  #include "racedat.c"

  unsigned char chrset [] =	/* Sprite data */
  #include "raceda2.c"

unsigned char minisprites [] =	/* 3x10x4 (CGA) 3x18x4 (EGA:X,Y,#) */
#include "pipedat.c"

int setx = 8, sety = 10;

int *iobj;
char *cpObj;
char *carptr;
char *oppcarptr;
int cpl;

int keydown [128];	/* Keys down.. */

int hxdir [] =
	{ 0, -1, 0, 1, -1, 0, 1, -1, 0, 1, 0, 0};
int hydir [] =
	{ 0, 1, 1, 1, 0, 0, 0, -1, -1, -1, 0, 0};


char gin [100];		/* General input */

char palz [1024] =	/* RGB for DAC regs */
 {0,0,0, 0,0,42, 0,42,0, 0,42,42, 42,0,0, 42,0,42, 42,42,0, 42,42,42,
 21,21,21, 21,21,63, 21,63,21, 21,63,63, 63,21,21, 63,21,63, 63,63,21,
 63,63,63};

unsigned int xvdu;
int linebuf [80];
int xmap [2000];
int mapoff;
unsigned int nextline,xoff;
unsigned int xline;

int rwide = 7;
int targwide = 7;
int rleft = 7;
int rdir = 0;
int ndir = 4;
int trnd;
int skiddir = -1;

int colr,colg,colb;

#define Empty 0
#define Back2 1
#define Back 2
#define Road 3
#define Tarmac 4
#define Lroad 6
#define Rroad 10
#define Lines 14
#define Car 18
#define Oppcar 19
#define Oppcar2 30
#define Oil 20
#define Mine 21
#define Gold 22
#define Fence 23
#define Pipeline 24
#define Skid 25
#define Poster 26
#define Poster2 31
#define Bonus 28
#define Spike 29
#define Crash 33

#define Edge 0
#define Guns 0
#define Accel keydown[29]

#define Mcars 20

int bonusmode = 0;
int skidmode = 0;
int croadchar = Tarmac;
int oppx, oppy, oppdx, oppdy;	/* Curr opp car pos, dir..*/
int nopp = 0;
int lastcargen = 0;
int copp;
int oppcarx [Mcars+4], oppcary [Mcars+4];
int oppdirx [Mcars+4], oppdiry [Mcars+4];
int crashflag = 0;
int scoremode = 1;
char message [100];

int typeof [Mobj+5] = {	/* Object type:- 0=Back,1=shootable,2=hard */
  1,1,1,1,0,1,1,0,0,1,
  1,0,0,1,1,1,1,1,1,1,
  1,1,1,1,1,1,1,1,1,1};

/* #define Nguns numof [Guns] */
/* #define Naliens numof [Alien] */
/* #define Nkeys numof [Key] */
int nguns,naliens,nkeys;

union REGS inr,outr;	/* Define register access */
struct SREGS sregs;

char prbuffer [10];	/* Buffer for int-print */
int xgamode = 3;	/* Graphic adapter 0 = CGA, 1 = EGA, 2 = VGA.. */
long far *timeptr;

void gotoxy (int xloc, int yloc)	/* Goto to loc X,Y on VDU */
{
	inr.h.bh = 0;
	inr.h.dl = xloc - 1;
	inr.h.dh = yloc - 1;
	inr.h.ah = 0x02;
	int86 (0x10,&inr,&outr);	/* INT 10, function 02 */
}

long readtime ()		/* Read 32 bit system clock in 1/18 secs */
{
	timeptr = (long far *) 0x0000046c;
	return ( *timeptr);
}

long Vseed;
void vsrand (unsigned int seed)
{
	Vseed = seed;
}

int vrand (void)
{
	Vseed = 0x015a4e35L * Vseed + 1;
	return ((int) (Vseed >> 16) & 0x7fff);
}

int nrand (int range)
{
	int temp;
	Vseed = 0x015a4e35L * Vseed + 1;
	return ((int) ((Vseed >> 17) & 0x7fff) % range);
}

void printc (char ichr)		/* Print a Char */
{
	inr.h.ah = 0x0e;
	inr.h.al = ichr;
	int86 (0x10,&inr,&outr);	/* INT 10, function 0e */
}

void prints (char *istr)	/* Print a null-term string */
{
	int cchr;
        for (cchr = 0; istr [cchr]; cchr ++) {
	  printc ( istr [cchr]);
	  if (istr [cchr] == 10) printc (13);
	}
}

void printk (unsigned char *istr)	/* Print string with color-codes */
{
	int cchr;
	static int temp, cgprn;
	cgprn = 1;
	for (cchr = 0; istr [cchr]; cchr ++) {
	  temp = istr [cchr];
	  if (temp == 128) {
	    cchr ++; temp = istr [cchr];
	    if (temp == '+') {
	      if (xgamode < 2) cgprn = 1 - cgprn;	/* CGA print */
	    } else {
	      getpal (temp & 15);
	    }
	  } else {
	    if (cgprn) printc (temp);
	  }
	  if (istr [cchr] == 10) printc (13);
	}
}

void printi (int iint)		/* Print a signed int */
{
	int cchr;
	if (iint == 0) {
	  printc ('0');
	  return;
	}
	if (iint < 0) {
	  printc ('-');
	  iint = -iint;
	}
	for (cchr = 0; iint; cchr ++) {
	  prbuffer [cchr] = 48 + (iint % 10);
	  iint /= 10;
	}
	prbuffer [cchr] = 0;
	while (cchr) {
	  cchr --;
	  printc ( prbuffer [cchr]);
	}
}

void printsi (char *istr, int iint)		/* Composite short cut */
{
	prints (istr);
	printi (iint);
}

int getkey ()
{
	int temp;
	inr.h.ah = 0x06;
	inr.h.dl = 0xff;
	int86 (0x21,&inr,&outr);	/* INT 21, function 6 */
	temp = outr.h.al;
	if (temp == 0 && (outr.x.flags & 64) == 0) /* Zero flag set? (bit6) */
	  temp --;
	return (temp);
}

void graphmode(int mode)	/* Set Screen Graphics mode */
				/* 0=40x25BW,1=40COL,2=80BW,3=80COL */
				/* 4=320x200COL,5=320BW,6=640BW */
{
	inr.x.ax = mode;
	int86 (0x10,&inr,&outr);	/* INT 10, function 0 */
}

#define SEQU_ADDR 0x3c4
#define CRTC_ADDR 0x3d4
#define GRAC_ADDR 0x3ce

set320x200x256_X()
{

        union REGS r;

        /* Set VGA BIOS mode 13h: */

        r.x.ax = 0x0013;
        int86(0x10, &r, &r);

        /* Turn off the Chain-4 bit (bit 3 at index 4, port 0x3c4): */

        outport(SEQU_ADDR, 0x0604);

        /* Turn off word mode, by setting the Mode Control register
           of the CRT Controller (index 0x17, port 0x3d4): */

        outport(CRTC_ADDR, 0xE317);

        /* Turn off doubleword mode, by setting the Underline Location
           register (index 0x14, port 0x3d4): */

        outport(CRTC_ADDR, 0x0014);

        /* Clear entire video memory, by selecting all four planes, then
           writing 0 to the entire segment. */

        outport(SEQU_ADDR, 0x0F02);
        /*memset(vga+1, 0, 0xffff); /* stupid size_t exactly 1 too small */
	/* vga[0] = 0; */

}

set320x240x256_X()
{

        /* Set the unchained version of mode 13h: */

        set320x200x256_X();

        /* Modify the vertical sync polarity bits in the Misc. Output
           Register to achieve square aspect ratio: */

        outportb(0x3C2, 0xE3);

        /* Modify the vertical timing registers to reflect the increased
           vertical resolution, and to center the image as good as
           possible: */

        outport(0x3D4, 0x2C11);         /* turn off write protect */
        outport(0x3D4, 0x0D06);         /* vertical total */
        outport(0x3D4, 0x3E07);         /* overflow register */
        outport(0x3D4, 0xEA10);         /* vertical retrace start */
        outport(0x3D4, 0xAC11);         /* vertical retrace end AND wr.prot */
        outport(0x3D4, 0xDF12);         /* vertical display enable end */
        outport(0x3D4, 0xE715);         /* start vertical blanking */
        outport(0x3D4, 0x0616);         /* end vertical blanking */

}

#define Setmode(Cmode) outport (0x03ce,Cmode);

void setmode (int cmode)	/* lo = register, hi = data */
{
	Setmode (cmode)
}

#define Setplanes(Cplane) 	/* Specify write planes */\
	outport (0x03c4,Cplane);

	/* Setplanes (0x0302);  Set reg 2 = 3 */

int getpal (int pal)
{
	if (xgamode == 0) return (1);	/* CGA.. */
	inr.h.ah = 16;
	inr.h.al = 7;
	inr.h.bl = pal;
	int86 (0x10,&inr,&outr);	/* INT 10, function 16 */
	return (outr.h.bh);
}

void loadvgapal (int nreg)
{
	if (xgamode < 1) return ;	/* not VGA.. */
	inr.h.ah = 16;
	inr.h.al = 18;
	inr.x.bx = 0;		/* Start reg */
	inr.x.cx = nreg;
	inr.x.dx = FP_OFF (palz);	/* Pallete regs */
	sregs.es = _DS;
	int86x (0x10,&inr,&outr,&sregs);	/* INT 10, function 16 */
}

#define palr(Cpal) palz[(Cpal) * 3]
#define palg(Cpal) palz[1 + (Cpal) * 3]
#define palb(Cpal) palz[2 + (Cpal) * 3]

#define WritePlane(Cplane) \
	outport (0x03c4,(256 << (Cplane)) + 2);

unsigned int xend,temp8,yoff;
char *tobj;
void putobject (int xtop, int ytop, int xlen, int ylen, register char *objarray)
{
	register unsigned int xpos;
	unsigned int ypos;
	yoff = ytop * 320;
	for (ypos = ytop; ypos < ytop + ylen; ypos ++) {
	  xend = xtop + xlen + yoff;
	  xpos = xtop + yoff;
	  do {
	    pshadow [xpos] = Vdu [xpos] = *objarray;
	    objarray ++;
	    xpos ++;
	    pshadow [xpos] = Vdu [xpos] = *objarray;
	    objarray ++;
	    xpos ++;
	  } while (xpos != xend);
	  yoff += 320;
	}
	return;
}

int zpl;
int frompl = 0,topl = 3;
void rputobject (int xtop, int ytop, int xlen, int ylen, char *objarray)
{
	register unsigned int xpos;
	static unsigned int ypos;
	static int xoff;
	xoff = xtop & 3;
	xtop = xtop >> 2;
	for (cpl = frompl; cpl <= topl; cpl ++) {
	  zpl = (cpl + xoff) & 3;
	  Vdux = Vdu + nextline;
	  cpObj = objarray + cpl;
	  WritePlane (zpl)
	  if (zpl & 2) {
	    cpShadow = pshadow;
	  } else {
	    cpShadow = pshadow2;
	  }
	  if (zpl & 1) cpShadow += 0x8000;
	  yoff = ytop * 80;
	  if (cpl + xoff == 4) {	/* VDU byte boundary */
	    xtop ++;
	  }
          for (ypos = 0; ypos < ylen; ypos ++) {
 	    xend = xtop + (xlen >> 2) + yoff + nextline;
	    xpos = xtop + yoff + nextline;
	    do {
	      cpShadow [xpos & 0x7fff] = Vdu [xpos] = cpObj [0];
	      cpObj += 4;
	      xpos ++;
	    } while (xpos != xend);
	    yoff += 80;
	  }
	}
}

void object80 (int xtop, int ytop, int xlen, int ylen, char *objarray)
{
	int xpos,ypos;
	int cobj = 0;
	int yoff;
	int ploff,cplane,xpl;
	int ssize;
	ssize = xlen * ylen;
	  ploff = 0; xpl = 256;
	  for (cplane = 0; cplane < 4; cplane ++) {
	    Setplanes (xpl + 2)	/* Reg 2 = plane */
	    xpl = (xpl << 1);
	    for (ypos = ytop; ypos < ytop + ylen; ypos ++) {
	      yoff = ypos * 80;
	      for (xpos = xtop; xpos < xtop + xlen; xpos ++) {
	        Vdu [yoff + xpos] = objarray [cobj];
	        cobj ++;
	      }
	    }
	    ploff += ssize;
	  }
	  return ;
}

void putat80 (int xpos, int ypos, int cpiece)
{
	xpos = xpos * 3 - 2;
	ypos = ypos * 18 - 2;
	object80 ( xpos, ypos, 3, 18, minisprites + cpiece * 216);
}

int xlen = 16,ylen = 16;
int backg;		/* backg color is transparent */

void putsprite (int xtop, int ytop, char *objarray)
{
	register unsigned int xpos;
	static unsigned int ypos;
	static int xoff;
	xoff = xtop & 3;
	xtop = xtop >> 2;
	for (cpl = 0; cpl < 4; cpl ++) {
	  zpl = (cpl + xoff) & 3;
	  Vdux = Vdu + nextline;
	  cpObj = objarray + cpl;
	  WritePlane (zpl)
	  if (zpl & 2) {
	    cpShadow = pshadow;
	  } else {
	    cpShadow = pshadow2;
	  }
	  if (zpl & 1) cpShadow += 0x8000;
	  yoff = ytop * 80;
	  if (cpl + xoff == 4) {	/* VDU byte boundary */
	    xtop ++;
	  }
          for (ypos = 0; ypos < ylen; ypos ++) {
 	    xend = xtop + (xlen >> 2) + yoff + nextline;
	    xpos = xtop + yoff + nextline;
	    do {
	      if ((regv = cpObj [0]) != backg ) {
	        Vdu [xpos] = regv;
	      } else {
	        Vdu [xpos] = cpShadow [xpos & 0x7fff];
	      }
	      cpObj += 4;
	      xpos ++;
	    } while (xpos != xend);
	    yoff += 80;
	  }
	}
}

void clrsprite (int xtop, int ytop, int xlen, int ylen)
{
	register unsigned int xpos;
	unsigned int ypos;
	yoff = ytop * 320;
	for (ypos = ytop; ypos < ytop + ylen; ypos ++) {
	  xend = xtop + xlen + yoff;
	  xpos = xtop + yoff;
	  do {
	    Vdu [xpos] = pshadow [xpos];
	    xpos ++;
	    Vdu [xpos] = pshadow [xpos];
	    xpos ++;
	  } while (xpos < xend);
	  yoff += 320;
	}
	return;
}

void outlinesprite (int xtop, int ytop, int xlen, int ylen)
{
	register unsigned int xpos;
	unsigned int ypos;
	for (ypos = ytop; ypos < ytop + ylen; ypos += ylen - 1) {
	  yoff = ypos * 320;
	  xend = xtop + xlen + yoff;
	  xpos = xtop + yoff;
	  do {
	    Vdu [xpos] = pshadow [xpos];
	    xpos ++;
	    Vdu [xpos] = pshadow [xpos];
	    xpos ++;
	  } while (xpos < xend);
	}
	yoff = ytop * 320;
	for (ypos = ytop; ypos < ytop + ylen; ypos ++) {
	  xpos = xtop + yoff;
	  Vdu [xpos] = pshadow [xpos];
	  xpos += xlen - 1;
	  Vdu [xpos] = pshadow [xpos];
	  yoff += 320;
	}
	return;
}

void putbullet (int xtop, int ytop)
{
	register unsigned int xpos;
	xpos = ytop * 320 + xtop;
	Vdu [xpos] = Vdu [xpos + 1] = Vdu [xpos + 320] = Vdu [xpos + 321] = 15;
}

void clrbullet (int xtop, int ytop)
{
	register unsigned int xpos;
	xpos = ytop * 320 + xtop;
	Vdu [xpos] = pshadow [xpos];
	Vdu [xpos + 1] = pshadow [xpos + 1];
	Vdu [xpos + 320] = pshadow [xpos + 320];
	Vdu [xpos + 321] = pshadow [xpos + 321];
}

void pause (int ticks)
{
	long temp = readtime () + ticks;
	while ( readtime () < temp);
}

int anyfly = 1;
void testfly ()		/* Test for hardware flyback */
{
	long temp = readtime () + 3;
	int test = inport (0x3da) & 8;
	while ( readtime () < temp) {
	  if (test != ( inport (0x3da) & 8)) return;
	}
	anyfly = 0;
}

void syncfly ()		/* 03da bit 3 set during flyback - bot to top bdr */
{
	if (anyfly) {
	  while (inport (0x3da) & 8);
	  while ((inport (0x3da) & 8) == 0);
	}
}

int soundflag = 1;
int savesound;
void soundon ()
{
	savesound = inportb (0x61) & 252;		/* Keep setting */
	if (soundflag) {
	  outportb (0x61, savesound | 3);	/* Speaker on */
	}
}

void setfreq (int hertz)
{
	int outfreq = 1331000/hertz;	/* Calc port val */
        outportb (0x43, 0xb6);		/* Set mode */
	outportb (0x42, outfreq & 0xff);	/* Write lo */
	outportb (0x42, outfreq >> 8);		/* Write hi */
}

void soundoff ()
{
	outportb (0x61,savesound);	/* restore setting */
}

void soundit (int hertz)
{
	setfreq (hertz);
	soundon ();
	syncfly ();
	soundoff ();
}

void soundrand ()
{
	soundit (100 + (rand () % 2000));
}

void click ()
{
	int cloop;
	soundit (1000);
	syncfly ();
	soundit (250);
}

void glide (int cstep)
{
	int cfreq;
	if (anyfly == 0) {
	  click ();
	  return ;
	}
	soundon ();
	for (cfreq = 50; cfreq < 1500; cfreq += cstep) {
	  setfreq (cfreq);
	  syncfly ();
	}
	soundoff ();
}

#if (Noload == 0)
void floaddata (char *filename,char *brddata,int datasize)
{						/* Load data from disk */
	int chandle;
	loaderror = 0;
	inr.x.dx = (int) filename;
	inr.h.ah = 0x3d;
	inr.h.al = 0;		/* 0=read,1=write,2=rnd */
	int86 (0x21,&inr,&outr);	/* INT 21, 3d OPEN */
	chandle = outr.x.ax;
	if (outr.x.flags & 1) { 	/* Carry set ? */
	  prints ("Unable to load graphics!\n");
	  loaderror ++;
	  return ;
	}

	inr.x.bx = chandle;
	inr.x.dx = (int) brddata;
	inr.x.cx = datasize;
	inr.h.ah = 0x3f;
	int86 (0x21,&inr,&outr);	/* INT 21, 3f READ */

	inr.x.bx = chandle;
	inr.h.ah = 0x3e;
	int86 (0x21,&inr,&outr);	/* INT 21, 3e CLOSE */
}
#endif

void beep ()
{
	printc (7);
}

int inchr (char *bigstr, char fchr)	/* Find char in BIGSTR (-1 fail) */
{
	int scount;
	for (scount = 0; bigstr [scount] != 0; scount ++)
	  if (bigstr [scount] == fchr)
	    return (scount);
	return (-1);
}

void qputat (int xpos, int ypos, int cpiece)
{
	putobject ( xpos * charx, ypos * chary + 8, charx, chary, sprites + cpiece * sprsize);
}

void putchat (int xpos, int ypos, int cchr)
{
        rputobject (xpos, ypos, setx, sety, chrset + cchr * 80);
}

void printnumat (int cnum, int xpos, int ypos)
{
	putchat (xpos,ypos,48 + (cnum % 10));
	cnum = cnum / 10; xpos -= setx;
	putchat (xpos,ypos,48 + (cnum % 10));
	cnum = cnum / 10; xpos -= setx;
	putchat (xpos,ypos,48 + (cnum % 10));
	cnum = cnum / 10; xpos -= setx;
	putchat (xpos,ypos,48 + (cnum % 10));
}

void printstrat (char *istr, int xpos, int ypos)
{
	int cstr = 0;
	while (istr [cstr]) {
	  temp = istr [cstr];
	  temp = temp & 63;
	  putchat (xpos, ypos, temp);
	  xpos += setx;
	  cstr ++;
	}
}

void clrvdu ()		/* Wipe hires screen/board */
{
	int cbrd;
	Vdu = (BYTE far *) 0xa0000000;	/* Ptr to EGA/VGA screen */
	if (xgamode > 1) {
	  graphmode (13);
	  set320x240x256_X();	/* MODE-X graphics */
	  charx = 16; chary = 16; halfy = 8; sprsize = 256;
	  loadvgapal (256);
	  getpal (15);		/* Wht ink */
	} else {
	  Vdu = (BYTE far *) 0xb8000000;	/* Pointer to CGA screen */
	  graphmode (6);
	  charx= 2; chary = 10; halfy = 5; sprsize = 20;
	}
	Vdui = Vdu;
	for (cbrd = 0; cbrd < Mboard; cbrd ++) {	/* Wipe brd */
	  board [cbrd] = Back;
	}
}

void clr80vdu ()	/* Clr into 80 col mode */
{
	int cbrd;
	Vdu = (BYTE far *) 0xa0000000;	/* Ptr to EGA/VGA screen */
	if (xgamode > 1) {
	  graphmode (18);
	  getpal (15);		/* Wht ink */
	} else {
	  Vdu = (BYTE far *) 0xb8000000;	/* Pointer to CGA screen */
	  graphmode (6);
	}
}

void clrcol (int col, int cline)	/* Set text scr colors,0=whole scr */
{
	int xpos;
	Vdu = (BYTE far *) 0xb8000000;	/* Pointer to CGA screen */
	if (cline) {
	  cline = cline * 160 - 159;
	  for (xpos = cline; xpos < cline + 160; xpos += 2) {
	    Vdu [xpos] = col;
	  }
	} else {
	  graphmode (3);
	  for (xpos = 1; xpos < 4000; xpos += 2) {
	    Vdu [xpos] = col;
	  }
	}
}

int sgn (int tval)
{
	if (tval > 0) return (1);
	if (tval < 0) return (-1);
	return (0);
}


void newgame ()
{
	maxscore = score = 0;
	nlifes = 3;
	cscreen = 0;
}

void newscreen ()
{
        int ccount;
	for (ccount = 1; ccount < Mbul; ccount ++) {
	  bulxpos [ccount] = -1;
	}
	if (cmap) {
	  vsrand (cmap);
	} else {
	  vsrand (readtime ());
	}
	countdown = 270;
	gamespeed = cspeed;
	ndir = 20; rdir = 0; rleft = 9;
	targwide = 11; rwide = 1;
	bonusmode = 0; skidmode = 0;
	crashflag = 0;
	looptick = 0;
	lastcargen = 500;
	croadchar = Tarmac;
	for (copp = 0; copp <= Mcars; copp ++) {
	  oppcarx [copp] = 0;
	}
	nopp = 0;
	pxpos = 160; pypos = 190;
	nflying = 0;
	cscreen ++;
	soundcmd = 0;
	clrvdu ();			/* Clr brd/vdu */
}

long far *tempptr;
long vectsave,vectnew;

void interrupt keycatch ()
{
	register unsigned int temp;
	temp = inportb (0x60);
	if (temp & 128) {
	  keydown [temp & 127] = 0;
	} else {
	  keydown [temp & 127] = 1;
	}
	tempptr [0] = vectsave;
	__int__(0x09);		/* INT 9, Old keyboard int.. */
	tempptr [0] = vectnew;
}

void install (void interrupt  (*faddr) (),int inum)
{
	setvect (inum, faddr);
}

	/* Set up to install key interrupt to catch key up/down for steering, not just characters.. */
void keyinstall ()
{
	register int temp;
	for (temp = 0; temp < 128; temp ++) {
	  keydown [temp] = 0;
	}
	tempptr = (long far *) 0x00000024;	/* INT 9h =keyboard */
	vectsave = tempptr [0];
	install (keycatch,9);
	vectnew = tempptr [0];
}

void uninstall ()
{
	tempptr [0] = vectsave;
}

int tloc,chrat;

int peekat (int txpos, int typos)
{
	tloc = (mapoff - 20 - ((typos + xline) >> 4) * 20 + (txpos >> 4)) & 1023;
	return (chrat = xmap [tloc]);
}

void redoloc (int cloc)
{
	int temp = xmap [cloc];
	cloc = (mapoff - cloc ) & 1023;
	txpos = ((2000 - cloc) % 20) << 4;
	typos = ((cloc / 20) << 4) - xline - 1;
	/* getpal (15);gotoxy (1,1); printi (txpos); printsi (",",typos);printsi (",",cloc); */
	rputobject (txpos, typos, 16,16, sprites + temp * sprsize);
}

int x2pos,y2pos;
int anyhit ( int hxpos, int hypos)	/* Collide Background? */
{
	register int x1pos = hxpos + 7;
	register int y1pos = hypos + 7;
	x2pos = hxpos + 8;
	y2pos = hypos + 7;
	/* gotoxy (1,1); printi (x1pos); printsi (",",y1pos); */

	if (typeof [peekat (x1pos,y2pos)]) {
	  txpos = x1pos; typos = y2pos; return (1);
	}
	if (typeof [peekat (x2pos,y2pos)]) {
	  txpos = x2pos; typos = y2pos; return (1);
	}
	if (typeof [peekat (x1pos,y1pos)]) {
	  txpos = x1pos; typos = y1pos; return (1);
	}
	if (typeof [peekat (x2pos,y1pos)]) {
	  txpos = x2pos; typos = y1pos; return (1);
	}
	return (0);
}

void writestart (int startaddr)
{
	outport (0x03d4,12 + (startaddr & 0xff00)); /* Reg 12=hi */
	outport (0x03d4,13 + (startaddr << 8));	    /* Reg 13=lo */
}

void gennextroad ()	/* Gen next bit of road in LINEBUF */
{
	int trnd,xpos;
	trnd = vrand ();
	if ((trnd & 63) == 3) {
	  for (xpos = 0; xpos < 20; xpos ++) {
	    linebuf [xpos] = Fence;
	  }
	} else {
	  for (xpos = 0; xpos < 20; xpos ++) {
	    linebuf [xpos] = 2 - ((trnd & 3) == 0);
	    trnd = (trnd >> 1) + (trnd << 15);
	  }
	  trnd = vrand ();
	  if ((trnd & 31) == 9) {
	    temp = Poster;
	    if (trnd & 128) temp = Poster2;
	    if (rleft < 5) {
	      linebuf [18] = temp; linebuf [19] = temp + 1;
	    } else {
	      linebuf [0] = temp; linebuf [1] = temp + 1;
	    }
	  }
	}

	  if (rleft < 0 || rleft > 20) return;
	  if (rdir == 0 ) {	/* STRAIGHT */
	    linebuf [rleft] = Road; linebuf [rleft + rwide + 1] = Road + 2;
	    for (xpos = 1; xpos <= rwide; xpos ++) {
	      linebuf [rleft + xpos] = croadchar;
	    }
	    if (targwide != rwide) {
	      if (rwide > targwide) {	/* Narrow.. */
	        linebuf [rleft] = Rroad; linebuf [rleft + 1] = Rroad + 1;
	        linebuf [rleft + rwide] = Lroad + 2;
	        linebuf [rleft + rwide + 1] = Lroad + 3;
		rleft ++;
		rwide -= 2;
	      } else {		/* Widen rd */
		if (rleft >= 2 && rleft + rwide <= 16) {
		  rleft --; rwide += 2;
	          linebuf [rleft] = Lroad; linebuf [rleft + 1] = Lroad + 1;
	          linebuf [rleft + rwide + 0] = Rroad + 2;
	          linebuf [rleft + rwide + 1] = Rroad + 3;
		}
	      }
	    }
	    /* linebuf [rleft + (rwide >> 1) ] = Lines; */
	  } else if (rdir > 0 ) {	/* RIGHT */
	    linebuf [rleft] = Rroad; linebuf [rleft + 1] = Rroad + 1;
	    linebuf [rleft + rwide + 1] = Rroad + 2;
	    linebuf [rleft + rwide + 2] = Rroad + 3;
	    for (xpos = 2; xpos <= rwide; xpos ++) {
	      linebuf [rleft + xpos] = croadchar;
	    }
	    /* linebuf [rleft + (rwide >> 1) + 1] = Lines + 2; */
	    rleft += rdir;
	  } else {		/* LEFT */
	    rleft += rdir;
	    linebuf [rleft] = Lroad; linebuf [rleft + 1] = Lroad + 1;
	    linebuf [rleft + rwide + 1] = Lroad + 2;
	    linebuf [rleft + rwide + 2] = Lroad + 3;
	    for (xpos = 2; xpos <= rwide; xpos ++) {
	      linebuf [rleft + xpos] = croadchar;
	    }
	    /* linebuf [rleft + (rwide >> 1) + 1] = Lines + 1; */
	  }
		/* Put a rnd obstacle */
	  trnd = vrand ();
	  if (bonusmode) {
	    if (bonusmode > 0) {
	      bonusmode --;
	      temp = Gold;
	    } else {
	      bonusmode ++;
	      temp = Mine;
	      if (trnd & 2048) temp = Oil;
	    }
	    if (trnd > 26000 - maxscore - maxscore && countdown == 0) {
	      if (temp == Gold) maxscore += 5;
	      linebuf [rleft + 2 + (trnd % (rwide - 2))] = temp;
	    }
	  } else {
	    if (trnd > 27500 - maxscore - maxscore && countdown == 0) {
	      if (trnd > 32000 - maxscore && maxscore > 20) {
		temp = Bonus + 1 - ((trnd % 6) == 1);
	      } else {
	        temp = Oil + (nrand (3));
	        if (maxscore < 120 && temp == Mine) temp = Oil;
	      }
	      if (temp == Bonus) maxscore += 50;
	      if (temp == Gold) maxscore += 5;
	      linebuf [rleft + 2 + (trnd % (rwide - 2))] = temp;
	    }
	  }
	  xline = 15;
	  if (rleft + rdir < 1 || rleft + rdir + rwide > 17) rdir = -rdir;
	  ndir --;
	  if (ndir < 0) {	/* Gen next bit road */
	    croadchar = Tarmac;
	    if ((trnd & 31) == 5 && maxscore > 400) {
	      croadchar = Oil;
	    }
	    ndir = 2 + nrand (8);
	    rdir = nrand (4) - 1;
	    if (rdir > 0) rdir --;
	    if (bonusmode == 0) {
	      if (rdir == 0 && maxscore > 100 && (trnd & 240) == 0) {
	        targwide = 7 + (nrand (3) << 1);
	      }
	      if (targwide == 7 && rdir == 0 && nrand (8) == 0) targwide += 2;
	    }
	    if (rleft < 2) rdir = 1;
	    if (rleft + rwide > 15) rdir = -1;
	  }
	  for (xpos = 0; xpos < 20; xpos ++) {	/* Save map data.. */
	    xmap [(xpos + mapoff) & 1023] = linebuf [xpos];
	  }
	  mapoff += 20;
}

void playgame ()
{
      shiftkey = (char far *) 0x00000417;
      delaybul = 0;
      xgamode = 3;
      newgame ();
      newscreen ();
      xdir = ydir = 0;
      xvdu = 16384; xline = 999;
      do {		/* Main playing loop */
	looptick ++;
	if (countdown > 0) countdown --;
reloop:
	inkey = 0;
	lasttime = readtime ();
	inkey = getkey ();
	if (inkey == 27 || inkey == 3) return;
	if (inkey == ';' || inkey == ' ') {	/* F1 - pause */
	  printstrat (" PAUSED, SPACE = CONT, ESC = END ",5,229);
	  printnumat (score,310,229);
	  click ();
	  do {
	    inkey = getkey ();
	    if (inkey == 27 || inkey == 3) return;
	  } while (inkey != ' ');
	  getkey ();
	}
	if (inkey == 9) {
	  scoremode = 1 - scoremode;
	}
	#if CHEAT_MODE
	  if (inkey == 'c') cheatmode = 1 - cheatmode;		/* Hit C to to cheat, infinite lifes */
	  if (inkey == 15) score += 1000;
	#endif
      #if Debug
	if (inkey == '!') {
	  for (cpl = 0; cpl < 4; cpl ++) {
	    Vdux = Vdu + nextline;
	    if (cpl & 2) {
	      cpShadow = pshadow;
	    } else {
	      cpShadow = pshadow2;
	    }
	    if (cpl & 1) cpShadow += 0x8000;
	    WritePlane (cpl)
	    for (xpos = 0; xpos < 0x4000; xpos ++) {
	      Vdux [xpos] = cpShadow [(xpos + nextline) & 0x7fff];
	     /*cpShadow = pshadow + (0x3fff & nextline) + (cpl << 14); */
	    }
	  }
	  while (getkey () != ' ');
	  return;
	}
	if (inkey == '$') {
	 clrvdu ();
	 do {
          for (xpos = 1; xpos < 128; xpos ++) {
	    if (keydown [xpos]) printsi (",",xpos);
	  }
	 } while (getkey () != 3);
	 return;
	}
      #endif	/* Debug */
	kcmd = 0;
	if (keydown [75]) kcmd = 4;
	if (keydown [77]) kcmd = 6;
		/* CTRL = 29, ALT = 56 */
	xdir = hxdir [kcmd];	/* Get dir moved */
	/* ydir = hydir [kcmd]; */
	#if Debug
	if (shiftkey [0] == 1) {
	  pxpos += xdir; pypos += ydir;
          zloc = nextline + pxpos + pypos * 320;
	  Vdu [zloc] = 15;
	  temp = peekat (pxpos,pypos); backg = 1;
	  redoloc (tloc);
	  putsprite (1,183,sprites + sprsize * temp);
	  syncfly ();
	  Vdu [zloc] = pshadow [zloc];
	  goto reloop;
	}
	#endif
	trnd = vrand ();
	if (xline > 16) {	/* GEN NEW LINE of road.. */
	  gennextroad ();
		/* Gen an opp car? */
	  if (trnd > 31800 - maxscore && nopp < 5 && bonusmode + countdown == 0) {
	   temp =  260 - (maxscore >> 3);
           if (temp < 90) temp = 90;
           if (looptick - lastcargen > temp) {
	    for (copp = 1; copp <= nopp; copp ++) {	/* Find empty slot */
	      if (oppcarx [copp] == 0) {
		nopp --;
		break;
	      }
	    }
	    nopp ++;
	    oppcarx [copp] = (rleft + 1 + (rwide >> 1) + (trnd % 3)) * charx;
	    oppcary [copp] = 1;
	    if (maxscore & 128) {
	      oppdiry [copp] = 2;
	    } else {
	      oppdiry [copp] = 1;
	    }
	    oppdirx [copp] = 1 - (trnd & 2);
	    lastcargen = looptick;
	   }
	  }
	}
		/* Scroll a pixel line */
	xvdu -= 80;
	nextline = xvdu;
		/* Ok, now turn chr data (linebuf []) into pixels */
	for (cpl = 0; cpl < 4; cpl ++) {
	  Vdux = Vdu + nextline;
	  WritePlane (cpl)
	  if (cpl & 2) {
	    cpShadow = pshadow;
	  } else {
	    cpShadow = pshadow2;
	  }
	  if (cpl & 1) cpShadow += 0x8000;
	  cpShadow = cpShadow + (0x7fff & nextline);
	  for (xpos = 0; xpos < 20; xpos ++) {
	    cpObj = sprites + linebuf [xpos] * sprsize + (xline << 4) + cpl;
	    for (xoff = 0; xoff < 4; xoff ++) {
	      cpShadow [0] = Vdux [0] = cpObj [0];
	      Vdux ++; cpObj += 4; cpShadow ++;
	    }
	  }
	}
	xline --;	/* Dec buffer pixel count..*/

		/* Service opposition cars.. */
	for (copp = 1; copp <= nopp; copp ++) {
	  oppx = oppcarx [copp];
	  if (oppx) {	/* Found an active car.. */
	    oppy = oppcary [copp];
	    oppdx = oppdirx [copp];
	    oppdy = oppdiry [copp];
            if (anyhit (oppx + (oppdx << 4), oppy + oppdy)) {
	      if (chrat < Oppcar) {	/* Road edge hit.. */
	        oppdx = -oppdx;
	      }
	    }
	    oppx += oppdx;
	    if (oppdy > 1) {	/* On-coming car.. */
	      if (maxscore > 1100 || (xline & 1)) {
		oppy += oppdy;
	      } else {
		oppy += (oppdy >> 1);
	      }
	      oppcarptr = sprites + Oppcar * sprsize;
	    } else {		/* Same dir as you.. */
	      if (xline & 1) oppy += oppdy;
	      oppcarptr = sprites + Oppcar2 * sprsize;
	    }
	    backg = oppcarptr [0];
	    ylen = 16;
	    putsprite (oppx,oppy,oppcarptr);
	    if (oppx > pxpos - 8 && oppy > pypos - 10) {	/* Crashh? */
	      if (oppx < pxpos + 8 && oppy < pypos + 10) {
		if (cheatmode == 0) {
		  crashflag = 1;
		} else {
		  soundcmd = 5000;
		}
	      }
	    }
	    if (oppy < 240) {
	      oppcary [copp] = oppy; oppcarx [copp] = oppx;
	      oppdirx [copp] = oppdx;
	    } else {
	      oppcarx [copp] = 0;
	      if (copp == nopp) nopp --;
	    }
	  }
	}
	if (crashflag) {	/* Crash in progress.. */
	  if (crashflag & 4) {
	    oppcarptr = sprites + Crash * sprsize;
	  } else {
	    oppcarptr = sprites + (Crash + 1) * sprsize;
	  }
	  if (crashflag > 10) gamespeed = 0;
	  backg = oppcarptr [0];
	  setfreq ((rand () % 1000) + 100);
	  soundon ();
	  putsprite (pxpos,pypos,oppcarptr);
	  soundoff ();
	  crashflag ++;
	  if (crashflag > 200) {
	      printstrat (" GAME OVER - HIT SPACE ",80,229);
	      printstrat ("SCORE       FROM A POSSIBLE   ",30,5);
	      printnumat (score,102,5);
	      printnumat (maxscore,278,5);
	      glide (700);  glide (100);  glide (130);  glide (200);
	      /* backg = 1; putsprite (1,183,sprites + sprsize * chrat); */
	      while (getkey () != ' ');
	      return;
	  }
	} else if (countdown < 1) {		/* Draw & service CAR.. */
	  ydir = 0;
	  if (Accel) {
	    if (pypos > 50) ydir = -1;
	  } else {
	    if ((xline & 1) && pypos < 200) ydir = 1;
	  }
	  pxpos += xdir; pypos += ydir; backg = carptr [0];
	  ylen = 17;
	  putsprite (pxpos,pypos,carptr);
	  ylen = 16;
	  if (anyhit (pxpos, pypos)) {	/* Hit obstacle ? */
	    if (chrat == Oil || chrat == Skid) {
	      pxpos += skiddir;
	      if ((xline & 3)== 0) skiddir = (rand () % 3) - 1;
	    } else if (chrat == Gold) {
	      score += 5;
	      xmap [tloc] = Tarmac;
	      redoloc (tloc);
	      soundcmd = 300 + pxpos * 4;
	    } else if (chrat == Bonus) {
	      score += 50;
	      xmap [tloc] = Tarmac;
	      redoloc (tloc);
	      soundcmd = 5000;
	      bonusmode += 90;
	      strcpy (message,"+50!");
	      if (rwide < 9) targwide = 9;
	    } else if (chrat == Spike) {
	      xmap [tloc] = Tarmac;
	      redoloc (tloc);
	      soundcmd = 100;
	      bonusmode -= 80;
	      if (rwide > 7) targwide = 7;
	    } else if (cheatmode == 0) {		/* Crash */
	      crashflag = 1;
	    } else {
	      soundcmd = 5000;
	    }
	  }
	}
	if (scoremode) {
	  printnumat (score,310,229);
	}
	if (message [0]) {
	  if (rleft > 6) {
	    printstrat (message,1,1);
	  } else {
	    printstrat (message,319 - strlen (message) * setx,1);
	  }
	  message [0] = 0;
	}
	writestart (xvdu);
	spcount --;
	if (spcount < 0) {
	  spcount = gamespeed;
	  if (bonusmode) spcount ++;
	  if (soundcmd) {
	    soundit (soundcmd);
	    soundcmd = 0;
	  } else {
	    syncfly ();
	  }
	}
      } while (1);
}

int cgahit;
#define Ctarmac 0x03db
#define Ctarg 0x3e03

void cganumat (int cnum, int cpos)
{
	Vdui [cpos] = 0x1f30 + (cnum % 10);
	cnum = cnum / 10; cpos --;
	Vdui [cpos] = 0x1f30 + (cnum % 10);
	cnum = cnum / 10; cpos --;
	Vdui [cpos] = 0x1f30 + (cnum % 10);
	cnum = cnum / 10; cpos --;
	Vdui [cpos] = 0x1f30 + (cnum % 10);
}

void cgastrat (char *istr, int cpos, int cink)
{
	int cstr = 0;
	while (istr [cstr]) {
	  Vdui [cpos] = cink | istr [cstr];
	  cstr ++; cpos ++;
	}
}

void showcgamodes ()
{
	gotoxy (30,15); printsi ("High score:",hiscore);
	printsi ("  Speed:",cspeed); prints (" (F1)  ");
}

void cgagame ()
{
      int temp;
cgaloop:
      if (cspeed < 1) cspeed = 3;
      graphmode (3);
      clrcol (10,0); clrcol (14,1); clrcol (15,25); clrcol (11,23);
      prints (
 "                          RACER - (C) PC Solutions\n\n"
 "    This is the CGA/EGA version of RACER - to move your car left/right\n"
 "    with the 4 & 6 keys on the keypad. Try to avoid on coming cars (\x0f),\n"
 "    and OIL slicks, but try to collect yellow targets (\x03) for points.\n"
 "    When you hit an on-coming car, or run off the road, the game is over.\n"
 "      NOTE:- you may want to adjust the speed to suit your PC - use F1 NOW\n"
 "    to do this - the larger the speed value, the faster it runs.\n"
	"");
	gotoxy (25,25); prints ("Hit SPACE to play, ESC to exit.");
	showcgamodes ();
      do {
	inkey = getkey ();
	if (inkey == 27 || inkey == 3) return;
	if (inkey == ';') {
	  cspeed = (cspeed % 7) + 1;
	  showcgamodes ();
	}
      } while (inkey != 32);
      graphmode (1);	/* 40x25 color txt */
      Vdui = Vdu = (BYTE far *) 0xb8000000;	/* Pointer to CGA screen */
	/* 7=blink,654=back,3=intense,210=fore.map=chr,attrib,chr,.. */
      ndir = 25; rdir = 0; rleft = 14; rwide = 14;
      pxpos = 20; pypos = 20;
      countdown = 25; score = 0;
      do {		/* Main playing loop */
	looptick ++;
	if (countdown > 0) countdown --;
	inkey = 0;
	lasttime = readtime ();
	inkey = getkey ();
	if (inkey == 3) return;
	if (inkey == 27) goto cgaloop;
	inkey = getkey ();
	if (inkey == 3) return;
	if (inkey == 27) goto cgaloop;
	kcmd = 0;
	if (keydown [79]) kcmd = 1;
	if (keydown [80]) kcmd = 2;
	if (keydown [81]) kcmd = 3;
	if (keydown [75]) kcmd = 4;
	if (keydown [77]) kcmd = 6;
	if (keydown [71]) kcmd = 7;
	if (keydown [72]) kcmd = 8;
	if (keydown [73]) kcmd = 9;
	xdir = hxdir [kcmd];	/* Get dir moved */
	ydir = hydir [kcmd];
	Vdui = Vdu;
	for (xpos = 0; xpos < 40; xpos ++) {
	  Vdui [xpos] = 0x02b0;
	}
	if (rleft < 0 || rleft > 40) return;
	if (rdir < 0) rleft --;
	Vdui [rleft] = 0x07de; Vdui [rleft + rwide + 1] = 0x07dd;
	for (xpos = 1; xpos <= rwide; xpos ++) {
	  Vdui [rleft + xpos] = Ctarmac; 	/*06db*/
	}
	if (rand () > 30000 - (score << 4) && countdown == 0) {
	  temp = rand () % 3; trnd = rleft + 2 + (rand () % (rwide - 2));
	  if (temp == 2) {	/* Targ */
	    Vdui [trnd] = Ctarg;
	  } else if (temp) {	/* Car */
	    Vdui [trnd] = 0x9c0f;
	  } else {		/* Oil */
	    Vdui [trnd - 1] = 0x034f; Vdui [trnd] = 0x0349;
	    Vdui [trnd + 1] = 0x034c;
	  }
	}
	if (rdir > 0) rleft ++;
	if (rleft + rdir < 2) rdir = 1;
	if (rleft + rdir + rwide > 38) rdir = -1;
	ndir --;
	if (ndir < 0) {	/* Gen next bit road */
	  ndir = 4 + (rand () & 7);
	  rdir = (rand () % 3) - 1;
	  if (rleft < 2) rdir = 1;
	  if (rleft + rwide > 35) rdir = -1;
	}
	cganumat (score,999);
	if (countdown < 1) {		/* CAR.. */
	  pxpos += xdir;
	  Vducar = Vdu + (pxpos << 1) + pypos * 80;
	  cgahit = Vducar [0];
	  Vducar [0] = 0x3f18;
	  temp = cgahit & 255;
	  if (cgahit != Ctarmac) {
	    if (cgahit == Ctarg) {
	      score += 10;
	      cgahit = Ctarmac;
	    } else if (temp== 'O' || temp == 'I' || temp == 'L') {
	      pxpos += (rand () % 3) - 1;
	    } else {
	      getpal (15);
	      cgastrat (" Hit SPACE. ",974,0xe000);
	      glide (30);
	      while (getkey () != ' ');
	      return;
	    }
	  }
	}
	for (ccount = cspeed; ccount < 8; ccount ++) {
	  syncfly ();
	}
	if (countdown < 1) {
	  Vducar [0] = cgahit;
	}
	Vdui = Vdu + 1920; Vdu2 = Vdu + 2000;
	for (temp = 0; temp <= 240; temp ++) {
	  Vdu2 [0] = Vdui [0];
	  Vdui --; Vdu2 --;
	  Vdu2 [0] = Vdui [0];
	  Vdui --; Vdu2 --;
	  Vdu2 [0] = Vdui [0];
	  Vdui --; Vdu2 --;
	  Vdu2 [0] = Vdui [0];
	  Vdui --; Vdu2 --;
	}
	Vdui = Vdu;
      } while (1);
}

void hitspace ()
{
	click ();
	prints ("                    Hit SPACE to Continue.");
	while (getkey () != ' ');
}

#define Dept "RA"


void frontscreen (int mode)
{
	clrcol (14,0);
	clrcol (15,25);
	prints (
  "\n\t\t\t   *  RACER  " PROG_VER "  *\n"
  "\t\t\t  ------------------\n\n"
  "\t\t\t(C) A.Millett 1993-2024.\n\n\n"
  "    Racer is an open source car racing game for MSDOS computers.\n\n"
  "    Released as free software under GNU GPL3 license.\n\n"
  "       see: www.gnu.org/licenses/gpl-3.0.html\n\n"
#if CHEAT_MODE  
  " NOTE: - Cheatmode on this version - Press C during play for infinite lifes!\n"
#endif
	);
	if (mode == 0) {
	  hitspace ();
	  return;
	}
	gotoxy (1,22);
	prints (" (You can now hit SPACE for default VGA, or select CGA,EGA,VGA modes)\n\n");
	prints ("        Hit SPACE to continue...    (or hit c,e,v)");
	click ();
	do {
	  inkey = getkey ();
	  if (inkey == 27) {
	    xgamode = 99; return;
	  }
	  if (inkey > 96) inkey -= 32;
	  xgamode = inchr ("CEV ",inkey);
	} while (xgamode < 0);
	if (xgamode == 3) xgamode = 2;
}

#define Boty 25

void showborder ()
{
	for (xpos = 1; xpos <= 26; xpos ++) {		/* Edges... */
	  putat80 ( xpos, 1, rand () % 3);
	  putat80 ( xpos, Boty, rand () % 3);
	}
	for (ypos = 1; ypos <= Boty; ypos ++) {
	  putat80 (  1, ypos, rand () % 3);
	  putat80 ( 26, ypos, rand () % 3);
	}
	putat80 (1,1,3); putat80 (1,Boty,3); putat80 (26,1,3); putat80 (26,Boty,3);
}

void fillscr ()
{
	for (xpos = 1; xpos <= 26; xpos ++) {		/* Edges... */
	  for (ypos = 1; ypos <= Boty; ypos ++) {
	    putat80 ( xpos, ypos, rand () % 4);
	  }
	}
}

void show1border ()
{
	xpos = (rand () % 24) + 2;
	ypos = (rand () % (Boty - 2)) + 2;
	temp = rand () % 3;
	syncfly ();
	if (rand () & 1) {
	  putat80 ( xpos, 1, temp);
	  putat80 ( xpos,Boty, temp);
	} else {
	  putat80 (  1, ypos, temp);
	  putat80 ( 26, ypos, temp);
	}
}

void showtitles ()
{
	clr80vdu ();
	tline = 16;
	getpal (12);
	if (hiscore) {
	  gotoxy (24,1);
	  printsi ("Score : ",score);
	  printsi ("   High Score : ",hiscore);
	}
	getpal (15);
	gotoxy (23,4);
	prints ("+          R  A  C  E  R        +\n\n");
	getpal (11);
	prints ("\t\t   Copyright A.Millett 1993-2024. Freeware!\n");
}

void showmodes ()
{
	getpal (11);
	  gotoxy (24,27);
	  if (cmap) {
	    printsi ("Map:",cmap);
	    prints ("     ");
	  } else {
	    prints ("Map:Random ");
	  }
	  gotoxy (42,27);
	if (cspeed > 1) {
	  prints ("Fast speed    (F1) ");
	} else if (cspeed == 1) {
	  prints ("Normal speed  (F1) ");
	} else {
	  prints ("Slow speed    (F1) ");
	}
}

void titlescreen ()
{
	showtitles ();
	if (xgamode) printc (10);
	getpal (10);
	prints (
"         Welcome to RACER " PROG_VER ", a neat car-racing game with smooth\n"
"       scrolling graphics. Steer your car along the road, using the 4\n"
"       and 6 keys on the keypad, or the cursor left/right keys. Hit the\n"
"       CTRL key to Accelerate - when released, you drop back again.\n"
"       Try to avoid on coming CARS, MINES (white), and OIL slicks, but\n"
"       try to collect yellow GOLD BARS for points. When you hit an\n"
"       on-coming car, mine, or run off the road, the game is over - when\n"
"       you hit OIL, you skid. Try to collect green BONUS ARROWS, for\n"
"       points, and a fast 'GOLD-RUN', but avoid red POISON PILLS, which\n"
"       narrow the road and give you a fast 'MINE-RUN'!\n"
"       During the GOLD-RUN, you do not have to face other cars, or mines.\n"
"       Hit F1 now for a different speed now, or F9 to toggle sound..\n"
"       You can select a different map by typing '+' or '-'.\n"
"       Hit SPACE during play for PAUSE, or TAB to switch off score.\n"
"\n");
	getpal (15);
	prints (
"                         Hit SPACE to play, ESC to Exit.");
	showborder ();
	showmodes ();
	glide (60);
	lasttime = readtime () - 17;
	do {

	  xtime = readtime ();
	  if ( xtime != lasttime) {
	    lasttime = xtime;
	    show1border ();
	  }
	  inkey = getkey ();
	  if (inkey == 3) return;
	  if (inkey == ';') {
	    cspeed = ((cspeed + 1) % 3) ;
	  }
	  #if (Shareware == 0)
	  if (inkey == '+') {
	    cmap = (cmap + 1) % 1000;
	  }
	  if (inkey == '-') {
	    cmap = (cmap + 999) % 1000;
	  }
	  #else
	  if (inkey == '+') {
	    cmap = 1 - cmap;
	    click ();
	  }
	  #endif
	  if (inkey == 'C') {
	    soundflag = 1 - soundflag;
	    click ();
	  }
	  if (inkey) showmodes ();
	} while (inkey != ' ' && inkey != 27);
}

void main ()
{
	testfly ();
        srand ( (int) readtime () );
	#if (Noload == 0)
	  floaddata ("race.vga", sprites, Msprite);
	  if (loaderror)
	    return;
	  floaddata ("racech.vga", chrset, 5200);
	  if (loaderror)
	    return;
	#endif
	carptr = sprites + Car * sprsize;
	oppcarptr = sprites + Oppcar * sprsize;
	for (colr = 0; colr < 6; colr ++) {
	  for (colg = 0; colg < 6; colg ++) {
	    for (colb = 0; colb < 6; colb ++) {
	      xpos = colr + colg * 6 + colb * 36 + 16;
	      palr (xpos) = colr * 12;
	      palg (xpos) = colg * 12;
	      palb (xpos) = colb * 12;
	    }
	  }
	}
	for (xpos = 0; xpos < 8; xpos ++) {
	  temp = (232 + xpos) * 3;
	  palz [temp] = palz [temp + 1] = palz [temp + 2] = xpos * 8 + 7;
	  temp = (240 + xpos) * 3;
	  palz [temp] = palz [temp + 1] = xpos * 3 + 7; palz [temp + 2] = xpos * 8 + 7;
	  temp = (248 + xpos) * 3;
	  palz [temp] = xpos * 8 + 7; palz [temp + 1] = xpos * 4 + 7; palz [temp + 2] = 7;
	}
	freeram = farcoreleft ();
	printi (freeram/1024); prints ("K Bytes free."); pause (10);
	if (freeram < 71000) {
	  prints ("Out of memory!\n");
	  pause (20);
	  return;
	}
	ltemp = (long) farmalloc (freeram - 3900);
	ltemp =((ltemp >> 4) << 4) + 512;
	hshadow = ishadow = pshadow = ltemp;
	pshadow2 = (ltemp + 0x10000000);
	/*printf ("\n %Fp pshad, %Fp pshad2 %lu ltmp\n",pshadow,pshadow2,ltemp);*/
	frontscreen (1);
	botline = 30; if (xgamode < 2) botline = 25;
	clr80vdu ();
	hiscore = 0;
	do {
	  if (xgamode < 2) {
	    keyinstall ();
	    cgagame ();
	    uninstall ();
	    if (inkey == 27) break;
	    if (inkey == 3) {
	      graphmode (3); return;
	    }
	  } else {
	    titlescreen ();
	    if (inkey == 3) {
	      graphmode (3); return;
	    }
	    if (inkey == 27) {
	      fillscr ();
	      pause (10);
	      break;
	    }
	    keyinstall ();
	    playgame ();
	    uninstall ();
	    if (inkey == 3) {
	      graphmode (3); return;
	    }
	  }
	  if (score > hiscore)
	    hiscore = score;
	} while (inkey != 3);
	graphmode (3);
}

