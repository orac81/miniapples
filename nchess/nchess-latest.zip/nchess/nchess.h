/*   NCHESS.H - Header for New Chess engine
 Copyright  Adrian Millett 2008-2015, All rights reserved, Duplication Prohibited
*/

/*
typedef unsigned long  UINT32;
typedef unsigned short UINT16;
typedef unsigned char  UINT8;
typedef long  INT32;
typedef short INT16;
typedef char  INT8;
*/

typedef uint32_t  UINT32;
typedef uint16_t UINT16;
typedef uint8_t  UINT8;
typedef int32_t  INT32;
typedef int16_t INT16;
typedef int8_t  INT8;

#ifndef BYTE		/* Define BYTE/UINT/TRUE/FALSE.. */
 typedef unsigned char BYTE;
 typedef unsigned int UINT;
 #define TRUE 1
 #define FALSE 0
#endif

#ifndef min		/* Define min/max.. */
 #define min(a,b)            (((a) < (b)) ? (a) : (b))
 #define max(a,b)            (((a) > (b)) ? (a) : (b))
#endif

#ifdef _WIN32
 #define _CUR_LINE __LINE__
#else
 #define _CUR_LINE 0
#endif

/*------------------------------------------------------------------------------------------- 
   MV_ mvgen/search support defines and structs.. 
-------------------------------------------------------------------------------------------*/

#define MV_MAXX     12		/* Max brd size */
#define MV_MAXY     10
#define MV_DEFSIZE  8		/* Default brd size */
#define MV_MAXBRD   256		/*  Abs Max board size */
#define MV_MAXGAME  1000	/*  Abs Max game length */

#ifdef IS_8BIT			/* Save a bit of memory for 8bit.. */
 #define MV_MAXLIST  1000	/* Max MV_LIST size */
 #define MV_MAXPLY   30		/* Max search depth */
#else 
 #define MV_MAXLIST  2000	/* Max MV_LIST size */
 #define MV_MAXPLY   50		/* Max search depth */
#endif
#define MV_MAXEVAL  15000	/* Absolute maximum eval (king capture) -ve = minimum */
#define MV_DRAWEVAL 0		/* Eval for a draw */
#define MV_MAXPIECE (MV_MAXX * 2)

		/*  Piece type values (ORed with MV_WHITE/MV_BLACK) */
#define MV_NPIECES  6
#define MV_EMPTY    0

#define MV_PAWN	    1		
#define MV_KNIGHT   2
#define MV_BISHOP   3
#define MV_ROOK     4
#define MV_QUEEN    5
#define MV_KING     6

#define MV_BLACK  8		/* Bit to set indicating black piece.. */
#define MV_WHITE  16		/* Bit to set indicating white piece.. */
#define MV_UNUSED 32		/* Bit indicates unused sqr */
#define MV_MASK   15		/* Mask both Black/White piece bits */
#define MV_PIECEMASK 7		/* Mask piece type bits */

#define MV_WPAWN   (MV_WHITE | MV_PAWN)
#define MV_WKNIGHT (MV_WHITE | MV_KNIGHT)
#define MV_WBISHOP (MV_WHITE | MV_BISHOP)
#define MV_WROOK   (MV_WHITE | MV_ROOK)
#define MV_WQUEEN  (MV_WHITE | MV_QUEEN)
#define MV_WKING   (MV_WHITE | MV_KING)

#define MV_BPAWN   (MV_BLACK | MV_PAWN)
#define MV_BKNIGHT (MV_BLACK | MV_KNIGHT)
#define MV_BBISHOP (MV_BLACK | MV_BISHOP)
#define MV_BROOK   (MV_BLACK | MV_ROOK)
#define MV_BQUEEN  (MV_BLACK | MV_QUEEN)
#define MV_BKING   (MV_BLACK | MV_KING)

#define MV_VALOF_PAWN    100
#define MV_VALOF_KNIGHT  390
#define MV_VALOF_BISHOP  400
#define MV_VALOF_ROOK    600
#define MV_VALOF_QUEEN  1200
#define MV_VALOF_KING  10000

	/* Eval Simple "most valuable victim - least valuable attacker" */
#define MV_MVV_LVA(src,dest)  (sch_valof[dest] - (sch_valof[src] / 16))
#define MV_MVV_LVA_CAPT(src,dest)  (sch_valof[dest] - (sch_valof[src] / 2))
#define MV_WEIGHT_VAL(src,dest) (sch_weight[dest] - sch_weight[src])
	/* Evaluation granularity */
#define MV_EVAL_GRAIN (~3)	

	/* Position x/y <-> board pos decoding macros */
#define MV_POS(xp,yp)   (((yp)<< 4) + (xp)) 
#define MV_SQR2X(sqr) ((sqr) & 15)
#define MV_SQR2Y(sqr) ((sqr) >> 4)
#define MV_DISTX(sqr1,sqr2) (abs(MV_SQR2X(sqr1) - MV_SQR2X(sqr2)))
#define MV_DISTY(sqr1,sqr2) (abs(MV_SQR2Y(sqr1) - MV_SQR2Y(sqr2)))
#define MV_CBOARD(xp,yp) (mgam.cur.board[MV_POS(xp,yp)])
#define MV_DIR_DOWN  16		/* Dir down 1 row */
#define MV_DIR_DOWN2 32

typedef struct {
  BYTE board [MV_MAXBRD];
  short int ep;		/*  En passant status */
  BYTE wcastled;	/*  Castling rights.. */
  BYTE bcastled;	
  short int side;		/*  Side to move (0=Wht,1=Blk) */
  short int spare;
} MV_BOARD;

typedef struct {	/*  Moves  */
  BYTE fr,to;
} MV_MOVE;

typedef struct {	/*  Moves used in movelist (with score etc) */
  MV_MOVE m;
  short int eval;
} MV_LIST;

typedef struct {
  int brdx,brdy;
  int dimx,dimy;		/*  "Real" board dimesions, including border */
  int offset;			/*  Start of board */
  int iniWK,iniWR1,iniWR2;	/*  Initial pos of K/R, for castling */
  int iniBK,iniBR1,iniBR2;
} MV_RULES;

typedef struct {
  short int id;
  MV_RULES rules;
  /* MV_BOARD start; */
  short int isSetup;
  MV_BOARD cur;		/*  Current board position & game status */
} MV_GAME;

typedef struct {
  BYTE pos;		/* Piece pos*/
  BYTE type;		/* Piece type (1=pawn etc, 0=none) */
} MV_PIECE;

typedef struct {
  MV_MOVE move;		/* Move made.. */
  BYTE capt;		/* Piece captured */
  BYTE idx_capt;	/* Index of captured piece */
  BYTE piece;		/* Piece moved (before promo) */
  short int nmoves;
  short int bestmove;
  MV_MOVE killmv;	/* Killer move */
} MV_TREE;

