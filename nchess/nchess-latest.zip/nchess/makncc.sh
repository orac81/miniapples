#!/bin/sh
# Build nchess with GNU C
#oscar64 -O2 -D ENG_8BIT=1 nchess.c -o=nchess.prg
cc -O2 nchess.c -o nchess.elf
strip nchess.elf
