#!/bin/sh
# Build NCHESS with OSCAR64 for C64.
echo C64..
oscar64 -O2 -tm=c64      -D ENG_8BIT=1 nchess.c -o=nchess-c64.prg
echo C128..
oscar64 -O2 -tm=c128     -D ENG_8BIT=1 nchess.c -o=nchess-c128.prg
echo Vic20..
oscar64 -O2 -tm=vic20+24 -D ENG_8BIT=1 nchess.c -o=nchess-v20.prg
echo +4..
oscar64 -O2 -tm=plus4    -D ENG_8BIT=1 nchess.c -o=nchess-p4.prg
#echo Atari..
#oscar64 -O2 -tm=atari    -D ENG_8BIT=1 nchess.c -o=nchess-atari.prg
rm nc*.int
rm nc*.lbl
rm nc*.map
rm nc*.asm
