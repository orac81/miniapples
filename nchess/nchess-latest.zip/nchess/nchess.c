/*   NCHESS.C - A simple experimental Chess engine.
 Copyright  Adrian Millett 2008-2025, Release as free software under GNU GPL3 license

 This is an experimental very simple demonstration Chess Engine.
 It can compile/run in small 8 bit targets. 
 It has variable board size, from 6x6-10x10.

 Start new code. Objective - write brand new, "clean code" chess program, playing normal or variant chess..
 Improve ideas/structures/mvgen/eval over protochess.
 Imp MV_GAME & related defines
 Imp mv_GameNew newgame function
 Imp cmd_DrawBoard  simple display function..
->nchess100,  20.8.2015
 Imp MV_LIST, MV_TREE, ..
 Start attack map gen - att_wht, MV_PIECE, gen_attack_maps()..
->nchess101,  21.8.2015
 Small changes..
->nchess102,  25.8.2015
 Imp gen_move_white (+gen_move..) gen moves using piece list scan.
 Imp cmd_DoMoveAsc - simple move entry.
->nchess103,  26.8.2015
 Correct mvgen capture..
 Imp gen_move_black() - gen black move lists..
 Rough implement sch_AlphaBeta, sch_MakeMove etc. not working yet..
->nchess104,  27.8.2015
 Imp sch_2idx[] to track piece-index when making/undoing moves in search. not working yet..
->nchess105,  28.8.2015
 Debug unMakeMove. 
 Imp mv_DoMove, cmd_CompMove..
 Very Simple working ver.. (ie:no quiescent sch, material only)
->nchess106,  29.8.2015
 Imp eng_call for use as engine. 
 Working with tchess front end.
->nchess107,  30.8.2015
 Imp pawn promotion
->nchess108,  30.8.2015
 Imp pawn promotion
->nchess109,  31.8.2015
 Imp SCH_ATTACK_TAB, tidy up some io_ bits
->nchess110,  1.9.2015
 Imp sch_rand - random flag.
->nchess111,  2.9.2015

->nchess112,  3.9.2015
 Imp rand opt.
 Imp black attack maps.
->nchess114,  9.9.2015
 Start imp  see_eval - SEE evaluation using attack tables..
 Simple cmd_test_see partly works..
->nchess115, 14.9.2015
 Add TO_BYTE() to some att_wht/blk[] entries..
->nchess116, 14.9.2015
 Imp gen_captures () using attack bitmaps
 Imp MV_MVV_LVA..
 Imp sch_Captures
 Imp SCH_QUIESCENCE, crudely working..
->nchess117, 15.9.2015
 Imp SCH_WEIGHT, simple center bias.
 Imp Weight/MVV/LVA evals in mvgen.
 Imp faster sch_Evaluate() using piece lists
->nchess118, 17.9.2015
 Imp SCH_SORT, sch_PickNextMove..
->nchess119, 17.9.2015
 Imp gen_captures  without Attack tables.. (SCH_ATTACK_TAB == 0)
 Imp sch_flags..
 Imp SCH_QUDEPTH, cut unpromising captures..
->nchess120, 18.9.2015
 Imp Load/Save test positions in "Console" version.
 Bug in sch_PickNextMove.. (sort not working!)
 Imp SCH_KILLER (= 40 seems about best.)
->nchess121, 19.9.2015
 Adjust to better handle mate scores.
->nchess122, 20.9.2015
 Imp SCH_TIME
->nchess123, 20.9.2015
 Imp timepermove, iterative deepening.
->nchess124, 21.9.2015
 Bad bug, sch_timeOut can cause v bad moves.. Dont genmove on 1st ply (allow iter to reorder..)
 Imp SCH_SHORTLOOK - short look ahead..
 Bug in sch_PickNextMove..  
 Bug "sch_pList[cmove].eval = eval;"   in wrong place.
->nchess125, 22.9.2015
 Imp sch_flags[27], /T for SSET_TIME, etc..
->nchess126, 22.9.2015
  Imp new resize cmd: n#,#
  Make piece order same as front end.
-> nchess127, 22.9.2015
  Alter to compile with OSCAR64, it works ok (same nodes etc), but slow.
  add stdint.h, for UINT32 etc.
  Imp clock() if (SCH_TIME) set, instead of time()
  Imp SCH_QSAMESQR if set, only look at same sqr exchanges beyond a certain depth.
-> nchess128, 14.8.2025
  2do: sch explosion on quiesence is still a very big problem (watch games on /D=2ply). Try some alternatives.
  SCH_SEE not yet working
  Imp Target node count for time. 
  Imp detect checkmate for game end.
  -D FLAG defs dont propogate to inc headers?
  INT32 for nodes, printi..

*/

#define PROG_VERSION "1.28"

#define ENG_CODE	0	/* Imp as included engine code for front end */
#define ENG_DEBUG       0	/* Include debug code */
/* #define ENG_8BIT	0 	/* Set for 8 BIT compiler */

#define SCH_GEN_MVLIST	1	/* Use sorted move list */
#define SCH_ATTACK_TAB	0	/* Gen moves & SEE by scanning attack table (Alt from piece list) */
#define SCH_SEE		0	/* Use SEE */
#define SCH_WEIGHT      1	/* Use weight tables */
#define SCH_SORT        1	/* Sort move list */
#define SCH_QUIESCENCE	1	/* Quiescence search enable */
#define SCH_QUDEPTH	2	/* Beyond-quiescence depth to cut "loosing" captures */
#define SCH_QSAMESQR	0	/* Search only same-square exchanges beyond this depth past quiescence (0=off)  */
#define SCH_KILLER	40	/* Enable killer move. */
#define SCH_TIME	1	/* Use time */
#define SCH_SHORTLOOK   1	/* Use internal short look ahead to sort lower ply moves */

#define ENG_EXTRAS	1	/* Pos load/save/set */

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

#include "nchess.h"

MV_GAME mgam;			/* Game store */

MV_LIST sch_list[MV_MAXLIST];	/* Move list storage */
MV_TREE sch_tree[MV_MAXPLY];	/* Search Tree store */
MV_LIST *sch_pList;		/* Current top of list */

MV_BOARD sch_brd;		/* Work board for search */
BYTE sch_2idx[MV_MAXBRD];	/* Index of each board piece */

int sch_nmoves;			/* #moves */
int sch_bx,sch_by;		/* Board size */
int sch_side;			/* Side to play */
int sch_ply;			/* Cur depth */
long sch_timeStart;
long sch_time;
int sch_timeOut;
int sch_doingShort;		/* Set when doing short look ahead */

int sch_flags [27];		/* Search settings/flags (/A-/Z)*/

#define SSET_DEPTH sch_flags[4]		/* D:Search depth */
#define SSET_DEBUG sch_flags[5]		/* E:Debug mode  */
#define SSET_FLAGS sch_flags[6]		/* F:Misc flag bits  */
#define SSET_QUIET sch_flags[17]	/* Q:Quiet mode  */
#define SSET_RAND  sch_flags[18]	/* R:Randomisation  */
#define SSET_TIME  sch_flags[20]	/* T:Time per move (0=use depth) */

long sch_nodes;			/* Node count */
int sch_lastbest;		/* Index of best move */
MV_LIST sch_best;		/* Best move found by search */

int sch_nWht, sch_nBlk;			/* # pieces in lists */
MV_PIECE sch_wpiece[MV_MAXPIECE];	/* List of pieces */
MV_PIECE sch_bpiece[MV_MAXPIECE];	/* List of pieces */
#define SCH_KING_POS 0		/* King is first entry */
				
#if SCH_ATTACK_TAB		/* Use Attack bitmaps */
 UINT32 att_wht[MV_MAXBRD];	/* Attack bitmap - bit set for each piece attacks this sqr */
 UINT32 att_blk[MV_MAXBRD];	/* Attack bitmap */
#endif

#if SCH_WEIGHT
 BYTE sch_weight[MV_MAXBRD];		/* Simple center weight table */
#endif

BYTE sch_wpawnrow,sch_bpawnrow;		/* End of pawn rows (2,7) */
BYTE sch_whtPromote;		/* Promotion sqrs for pawns */
BYTE sch_blkPromote;

  /* Value of pieces.. */
short int sch_valof[] = {
  0, MV_VALOF_PAWN, MV_VALOF_KNIGHT, MV_VALOF_BISHOP, MV_VALOF_ROOK, MV_VALOF_QUEEN, MV_VALOF_KING, 0, 
  0,-MV_VALOF_PAWN,-MV_VALOF_KNIGHT,-MV_VALOF_BISHOP,-MV_VALOF_ROOK,-MV_VALOF_QUEEN,-MV_VALOF_KING, 0};

  /* Ascii for each piece */
char sch_szPieceAsc[] = ".PNBRQK??pnbrqk?";

#if ENG_DEBUG		/* Debugging CASSERT macro .. */
  
  #define CASSERT(x) {if (!(x)) app_assert (_CUR_LINE); }

  void io_putsi (const char *pStr, int x);
  void io_puts (const char *pStr);
  void io_gets (char *pStr);
  void cmd_dumpboard (BYTE *);
  int cmd_AscFromMove (char *, MV_MOVE *);
  void cmd_dumplist ();

  char szDebug[64];

  void app_assert (int curline) {
    io_putsi ("Error: Line:",curline); 
    io_putsi (" Ply:",sch_ply); 
    io_puts ("\n:"); 
    io_gets (szDebug);
    exit(0); 
  }

#else
  #define CASSERT(x) ;
#endif

void sch_analyShow (int depth, int cmove, int eval);
int sch_AlphaBeta (int depth, int alpha, int beta);

/*---------------------------------------------------------------------------- 
  io_ .. Misc IO functions
----------------------------------------------------------------------------*/

#if ENG_CODE == 0

#define io_putchar putchar

  /* Write a string */
void io_puts (const char *pOut) 
{
    char ch;
    while (  (ch = *pOut)  ) {
      io_putchar(ch);
      pOut ++;
    }
}

  /* Write an int */
void io_putint (int x)
{
    if (x<0) {
      x = -x; io_putchar ('-');
    }
    if (x>9) {
      io_putint (x/10);
    }
    io_putchar ('0' + x%10);
}

  /* Print a string then an integer */
void io_putsi (const char *pStr, int x)
{
   io_puts (pStr); io_putint (x);
}

  /* Print string, int, string, int.. */
void io_putsisi (const char *pStr, int x, const char *pStr2, int x2)
{
   io_puts (pStr); io_putint (x);
   io_puts (pStr2); io_putint (x2);
}

  /* Input a string */
void io_gets (char *pStr)
{
    /* pDat = fgets (szIn, sizeof (szIn)-1, stdin); // This is better */
    gets (pStr);
}

#define io_toupper(ch) (((ch)<'a'||(ch)>'z')?(ch):(ch)-'a'+'A')
#define io_isdigit(ch) ((ch) >= '0' && (ch) <= '9')

int io_isalpha (char ch) 
{
    ch = io_toupper(ch);
    return (ch >= 'A' && ch <= 'Z');
}

#endif		/* ENG_CODE == 0 */


#ifdef ENG_8BIT 		/* Some special stuff for 8 bit compilers */

#define TO_BYTE(x) ((BYTE) ((x) & 255))		/* Hack needed for cc65 */

void io_memcpy (void *pDest, void *pSrc, unsigned int count)
{
    unsigned int x;
    for (x = 0; x<count; x++) {
      ((BYTE *) pDest) [x] = ((BYTE *) pSrc) [x];
    }
}

void io_memset(void *pDest, int c, unsigned int count)
{
    unsigned int x;
    for (x = 0; x<count; x++) {
      ((BYTE *) pDest) [x] = c;
    }
}

#include <conio.h>

  // Simple peek/poke macros
#define IO_POKE(AD,BY) *((BYTE *) ((UINT) AD))=(BYTE) (BY);
#define IO_PEEK(AD) ((BYTE) *((BYTE *) ((UINT) AD)))

	/* target specific init */ 
void app_init ()
{
   iocharmap(IOCHM_PETSCII_2); 
   if (IO_PEEK(65500) == 228) {		/* C64.. */
      IO_POKE (53280,0);
      IO_POKE (53281,0);
      io_putchar (5);
      io_putchar (147);
      return;
   }
   if (IO_PEEK(65500) == 103) {		/* VIC20 */
      IO_POKE (36879,8);
      io_putchar (5);
      io_putchar (147);
      return;
   }
}

#else		/* Normal C compiler.. */

  #define TO_BYTE(x) ((BYTE) (x))

  #include <memory.h>

  #define io_memcpy memcpy
  #define io_memset memset

 void app_init ()
 {}

#endif		/* ENG_8BIT */

long io_rand_seed = 0;

void io_srand (unsigned int seed)
{ 
    io_rand_seed = seed;
}

int io_rand ()
{
    io_rand_seed = 0x015a4e35L * io_rand_seed + 1;
    return ((short) (io_rand_seed >> 16) & 0x7fff);
}


#if ENG_CODE == 0

  /*  Write block of data (pData) of size (nbytes) to file (szFile) */
  /*    ret FALSE if error */
int io_FileSave (char *szFile, void *pData, int nbytes)
{
    FILE *hFile;
    int cret;
    if (szFile == NULL || *szFile == 0) return FALSE;
    hFile = fopen (szFile, "w+b");
    if (hFile == NULL) return FALSE;
    cret = fwrite (pData, 1, nbytes, hFile);
    fclose (hFile);
    if (cret < nbytes) return FALSE;
    return TRUE;
}

  /*  Read block of data (pData) of size (nbytes) from file (szFile) */
  /*    ret FALSE if error */
int io_FileLoad (char *szFile, void *pData, int nbytes)
{
    FILE *hFile;
    int cret;
    if (szFile == NULL || *szFile == 0) return FALSE;
    hFile = fopen (szFile, "rb");
    if (hFile == NULL) return FALSE;
    cret = fread (pData, 1, nbytes, hFile);
    fclose (hFile);
    if (cret < nbytes) return FALSE;
    return TRUE;
}

#endif

#if SCH_TIME

#include <time.h>

  /* Get elapsed time in seconds */
long io_GetTime ()
{
    /* return time(NULL); */
    return (long) ((clock_t) clock() / CLOCKS_PER_SEC);
}

#endif

/*---------------------------------------------------------------------------- 
  Initialisation..
----------------------------------------------------------------------------*/

  /* One-time common initialisation */
void prg_Initialise ()
{
    io_memset (sch_flags, 0, sizeof (sch_flags));
    SSET_TIME = 2;
    SSET_DEPTH = 4;
    app_init ();	/* target specific init */ 
}


  /* Pieces in descending order of strength */
BYTE gen_piece_order[] = {MV_KING, MV_QUEEN, MV_ROOK, MV_BISHOP, MV_KNIGHT, MV_PAWN};

  /* Init vars for mvgen/search, build piece lists, weight tables, etc */
int sch_Init()
{
    int cpos,mx;
    BYTE ch,cpiece;
    int idx;
    BYTE x,y,hx,hy,wgt;
    
    #if SCH_ATTACK_TAB		/* Use Attack bitmaps */
     io_memset (att_wht, 0, sizeof(att_wht));
     io_memset (att_blk, 0, sizeof(att_blk));
    #endif
    io_memset (sch_tree, 0, sizeof(sch_tree));
    
    io_memcpy (&sch_brd, &mgam.cur, sizeof (MV_BOARD));
    mx = mgam.rules.brdy << 4;

	/* Init search parms */
    sch_pList = sch_list;
    sch_ply  = 1;
    sch_nodes = 0;
    sch_lastbest = -1;
    sch_side = mgam.cur.side;
    sch_bx   = mgam.rules.brdx;
    sch_by   = mgam.rules.brdy;
    sch_bpawnrow = MV_POS(0,2);			/* End of pawn rows, used for double step 1st pawn moves */
    sch_wpawnrow = MV_POS(0,mgam.rules.brdy-2)-1;
    sch_whtPromote = MV_POS(0,1);		/* Calc promo sqrs */
    sch_blkPromote = MV_POS(0,mgam.rules.brdy-1)-1;

    sch_timeOut = FALSE;
    sch_time = 0;
    sch_doingShort = FALSE;

	/* Build piece lists */
    sch_nWht = 0;
    sch_nBlk = 0;

	/* Scan board for each piece, build piece lists in descending K..P val order */
    for (idx = 0; idx < MV_NPIECES; idx++) {
      cpiece = gen_piece_order[idx];
      for (cpos = 0; cpos < mx; cpos ++) {
        ch = sch_brd.board[cpos];
        if ((ch & MV_PIECEMASK) == cpiece) {
	  if (ch & MV_WHITE) {
	    if (sch_nWht >= MV_MAXPIECE) return FALSE;		/* Too many! */
	    sch_wpiece[sch_nWht].type = ch & MV_PIECEMASK;	/* Add pos to list */
	    sch_wpiece[sch_nWht].pos  = cpos;
	    sch_2idx[cpos] = sch_nWht;			/* Save index crossref for each sqr */
	    sch_nWht ++;
          } else {
	    if (sch_nBlk >= MV_MAXPIECE) return FALSE;
	    sch_bpiece[sch_nBlk].type = ch & MV_PIECEMASK;	/* Add pos to list */
	    sch_bpiece[sch_nBlk].pos  = cpos;
	    sch_2idx[cpos] = sch_nBlk;		/* Save index crossref for each sqr */
	    sch_nBlk ++;
	  }
        }
      }
    }

    #if SCH_WEIGHT		/* Compute center weight table */

      hx = (mgam.rules.brdx+1) / 2;
      hy = (mgam.rules.brdy+1) / 2;
      for (y = 0; y < hy; y++) {
        for (x = 0; x < hx; x++) {
	  wgt = (min (x,y) << 1) + 2;
          sch_weight [MV_POS (x,y)] = wgt;
          sch_weight [MV_POS (sch_bx-1-x, y)] = wgt;
          sch_weight [MV_POS (x, sch_by-1-y)] = wgt;
          sch_weight [MV_POS (sch_bx-1-x, sch_by-1-y)] = wgt;
        }
      }
    #endif		/* SCH_WEIGHT */

    return TRUE;
}

/*---------------------------------------------------------------------------- 
  gen_attack .. gen attack bitmap tables
----------------------------------------------------------------------------*/

#if SCH_ATTACK_TAB		/* Use Attack bitmaps */

UINT32 mxbit;

void gen_attack_wking (BYTE cpos)
{
    att_wht [TO_BYTE(cpos-MV_DIR_DOWN-1)] |= 1;
    att_wht [TO_BYTE(cpos-MV_DIR_DOWN)]   |= 1;
    att_wht [TO_BYTE(cpos-MV_DIR_DOWN+1)] |= 1;
    att_wht [TO_BYTE(cpos-1)]		  |= 1;
    att_wht [cpos+1]		 |= 1;
    att_wht [cpos+MV_DIR_DOWN-1] |= 1;
    att_wht [cpos+MV_DIR_DOWN]   |= 1;
    att_wht [cpos+MV_DIR_DOWN+1] |= 1;
}

void gen_attack_wpawn (BYTE cpos)
{
    att_wht [TO_BYTE(cpos-MV_DIR_DOWN-1)] |= mxbit;
    att_wht [TO_BYTE(cpos-MV_DIR_DOWN+1)] |= mxbit;
}

void gen_attack_wknight (BYTE cpos)
{
    att_wht [TO_BYTE(cpos-MV_DIR_DOWN-2)]  |= mxbit;
    att_wht [TO_BYTE(cpos-MV_DIR_DOWN+2)]  |= mxbit;
    att_wht [TO_BYTE(cpos-MV_DIR_DOWN2-1)] |= mxbit;
    att_wht [TO_BYTE(cpos-MV_DIR_DOWN2+1)] |= mxbit;
    att_wht [cpos+MV_DIR_DOWN-2]  |= mxbit;
    att_wht [cpos+MV_DIR_DOWN+2]  |= mxbit;
    att_wht [cpos+MV_DIR_DOWN2-1] |= mxbit;
    att_wht [cpos+MV_DIR_DOWN2+1] |= mxbit;
}

  /* Gen attacks for bishop */
void gen_attack_wbishop (BYTE spos)
{
    BYTE xpos;
    xpos = spos;
    do {
      xpos += (MV_DIR_DOWN+1);
      att_wht [xpos] |= mxbit;
    } while (sch_brd.board[xpos] == MV_EMPTY);
    xpos = spos;
    do {
      xpos += (MV_DIR_DOWN-1);
      att_wht [xpos] |= mxbit;
    } while (sch_brd.board[xpos] == MV_EMPTY);
    xpos = spos;
    do {
      xpos -= (MV_DIR_DOWN+1);
      att_wht [xpos] |= mxbit;
    } while (sch_brd.board[xpos] == MV_EMPTY);
    xpos = spos;
    do {
      xpos -= (MV_DIR_DOWN-1);
      att_wht [xpos] |= mxbit;
    } while (sch_brd.board[xpos] == MV_EMPTY);
}

  /* Gen attacks for rook */
void gen_attack_wrook (BYTE spos)
{
    BYTE xpos;
    xpos = spos;
    do {
      xpos ++;
      att_wht [xpos] |= mxbit;
    } while (sch_brd.board[xpos] == MV_EMPTY);
    xpos = spos;
    do {
      xpos --;
      att_wht [xpos] |= mxbit;
    } while (sch_brd.board[xpos] == MV_EMPTY);
    xpos = spos;
    do {
      xpos += MV_DIR_DOWN;
      att_wht [xpos] |= mxbit;
    } while (sch_brd.board[xpos] == MV_EMPTY);
    xpos = spos;
    do {
      xpos -= MV_DIR_DOWN;
      att_wht [xpos] |= mxbit;
    } while (sch_brd.board[xpos] == MV_EMPTY);
}

  /* Generate white attack bitmap table (att_wht) */
void gen_attack_white()
{
    int idx;
    BYTE cpos,ctype;
    
    io_memset (att_wht, 0, sizeof(att_wht));	/* Clr white attack table */
	/* Generate king attacks */
    cpos = sch_wpiece[SCH_KING_POS].pos;
    gen_attack_wking (cpos);
    mxbit = 2;
    for (idx = 1; idx < sch_nWht; idx ++) {
      cpos  = sch_wpiece[idx].pos;
      ctype = sch_wpiece[idx].type;
      switch (ctype) {
        case MV_PAWN:
          /* gen_attack_wpawn(cpos); */
          att_wht [TO_BYTE(cpos-MV_DIR_DOWN-1)] |= mxbit;
          att_wht [TO_BYTE(cpos-MV_DIR_DOWN+1)] |= mxbit;
	  break;
        case MV_KNIGHT:
          gen_attack_wknight(cpos);
	  break;
	case MV_BISHOP:
	  gen_attack_wbishop(cpos); 
	  break;
	case MV_QUEEN:
	  gen_attack_wbishop(cpos); 
	case MV_ROOK:
	  gen_attack_wrook(cpos); 
	  break;
      }
      mxbit = mxbit << 1;
    }
}


/*---------------------------------------------------------------------------- 
  gen_attack_b .. gen Black attack bitmap tables
----------------------------------------------------------------------------*/


void gen_attack_bking (BYTE cpos)
{
    att_blk [TO_BYTE(cpos-MV_DIR_DOWN-1)] |= 1;
    att_blk [TO_BYTE(cpos-MV_DIR_DOWN)]   |= 1;
    att_blk [TO_BYTE(cpos-MV_DIR_DOWN+1)] |= 1;
    att_blk [TO_BYTE(cpos-1)]		  |= 1;
    att_blk [cpos+1]		  |= 1;
    att_blk [cpos+MV_DIR_DOWN-1] |= 1;
    att_blk [cpos+MV_DIR_DOWN]   |= 1;
    att_blk [cpos+MV_DIR_DOWN+1] |= 1;
}

void gen_attack_bpawn (BYTE cpos)
{
    att_blk [cpos+MV_DIR_DOWN-1] |= mxbit;
    att_blk [cpos+MV_DIR_DOWN+1] |= mxbit;
}

void gen_attack_bknight (BYTE cpos)
{
    att_blk [TO_BYTE(cpos-MV_DIR_DOWN-2)]  |= mxbit;
    att_blk [TO_BYTE(cpos-MV_DIR_DOWN+2)]  |= mxbit;
    att_blk [TO_BYTE(cpos-MV_DIR_DOWN2-1)] |= mxbit;
    att_blk [TO_BYTE(cpos-MV_DIR_DOWN2+1)] |= mxbit;
    att_blk [cpos+MV_DIR_DOWN-2]  |= mxbit;
    att_blk [cpos+MV_DIR_DOWN+2]  |= mxbit;
    att_blk [cpos+MV_DIR_DOWN2-1] |= mxbit;
    att_blk [cpos+MV_DIR_DOWN2+1] |= mxbit;
}

  /* Gen attacks for bishop */
void gen_attack_bbishop (BYTE spos)
{
    BYTE xpos;
    xpos = spos;
    do {
      xpos += (MV_DIR_DOWN+1);
      att_blk [xpos] |= mxbit;
    } while (sch_brd.board[xpos] == MV_EMPTY);
    xpos = spos;
    do {
      xpos += (MV_DIR_DOWN-1);
      att_blk [xpos] |= mxbit;
    } while (sch_brd.board[xpos] == MV_EMPTY);
    xpos = spos;
    do {
      xpos -= (MV_DIR_DOWN+1);
      att_blk [xpos] |= mxbit;
    } while (sch_brd.board[xpos] == MV_EMPTY);
    xpos = spos;
    do {
      xpos -= (MV_DIR_DOWN-1);
      att_blk [xpos] |= mxbit;
    } while (sch_brd.board[xpos] == MV_EMPTY);
}

  /* Gen attacks for rook */
void gen_attack_brook (BYTE spos)
{
    BYTE xpos;
    xpos = spos;
    do {
      xpos ++;
      att_blk [xpos] |= mxbit;
    } while (sch_brd.board[xpos] == MV_EMPTY);
    xpos = spos;
    do {
      xpos --;
      att_blk [xpos] |= mxbit;
    } while (sch_brd.board[xpos] == MV_EMPTY);
    xpos = spos;
    do {
      xpos += MV_DIR_DOWN;
      att_blk [xpos] |= mxbit;
    } while (sch_brd.board[xpos] == MV_EMPTY);
    xpos = spos;
    do {
      xpos -= MV_DIR_DOWN;
      att_blk [xpos] |= mxbit;
    } while (sch_brd.board[xpos] == MV_EMPTY);
}

  /* Generate Black attack bitmap table (att_blk) */
void gen_attack_black()
{
    int idx;
    BYTE cpos,ctype;

    io_memset (att_blk, 0, sizeof(att_blk));	/* Clr black attack table */
	/* Generate king attacks */
    cpos = sch_bpiece[SCH_KING_POS].pos;
    gen_attack_bking (cpos);
    mxbit = 2;
    for (idx = 1; idx < sch_nBlk; idx ++) {
      cpos  = sch_bpiece[idx].pos;
      ctype = sch_bpiece[idx].type;
      switch (ctype) {
        case MV_PAWN:
          /* gen_attack_bpawn(cpos); */
          att_blk [cpos+MV_DIR_DOWN-1] |= mxbit;
          att_blk [cpos+MV_DIR_DOWN+1] |= mxbit;
	  break;
        case MV_KNIGHT:
          gen_attack_bknight(cpos);
	  break;
	case MV_BISHOP:
	  gen_attack_bbishop(cpos); 
	  break;
	case MV_QUEEN:
	  gen_attack_bbishop(cpos); 
	case MV_ROOK:
	  gen_attack_brook(cpos); 
	  break;
      }
      mxbit = mxbit << 1;
    }
}

#endif		/* SCH_ATTACK_TAB */

/*---------------------------------------------------------------------------- 
  see_ .. evaluate see exchange vals using attack maps
----------------------------------------------------------------------------*/

#if SCH_SEE		/* Use SEE */

UINT32 see_wht; 
UINT32 see_blk; 
int see_idxw;		/* Current piece indexs */
int see_idxb;
int see_pos;

#define SEE_HIBIT ((UINT32) 0x80000000UL)

  /* Calculate see eval for a sqr */
int see_sch (int pieceval, int sside)
{
    int ceval;
    BYTE xtype;

    if (sside) {		/* Black move */
				/* Find next black attacker.. */
      while (1) {
        if (see_blk == 0) return 0;	/* No more */
        while (!(see_blk & SEE_HIBIT)) {
	  CASSERT (see_idxb >= 0);
          see_blk = see_blk << 1;
	  see_idxb --;
        }
        xtype = sch_bpiece[see_idxb].type;
        see_blk = see_blk << 1;
	see_idxb --;
	if (xtype) break;	/* Found piece */
      }
    } else {			/* White move */
				/* Find next white attacker.. */
      while (1) {
        if (see_wht == 0) return 0;	/* No more */
        while (!(see_wht & SEE_HIBIT)) {
	  CASSERT (see_idxw >= 0);
          see_wht = see_wht << 1;
          see_idxw --;
        }
        xtype = sch_wpiece[see_idxw].type;
        see_wht = see_wht << 1;
        see_idxw --;
        if (xtype) break;	/* Found piece */
      }
    }
    ceval = pieceval;
	/* if (ceval == VAL_KING) return ceval; */
    pieceval = sch_valof [xtype];		/* Val of attacking piece */
	/* ISPROMOTE... */   /* FindHiddenAttackers... */

    ceval -= see_sch (pieceval, !sside);	/* Recursively exchange pieces */
    if (ceval < 0) ceval = 0;			/* If exchange was loosing, stand-pat and dont exchange */
    return ceval;
}

  /* Calculate see eval for a sqr */
int see_eval (int spos, int sside)
{
    int pieceval,ctype;
    see_idxw = sch_nWht - 1;
    see_idxb = sch_nBlk - 1;
    see_wht = att_wht[spos] << (32 - sch_nWht);		/* Put last pawn bit in highest bit */
    see_blk = att_blk[spos] << (32 - sch_nBlk);
    see_pos = spos;

    ctype = sch_brd.board[spos] & MV_MASK;
    pieceval = sch_valof [ctype];		/* Val of piece */
    if (sside == 0) pieceval = -pieceval;

    if (see_wht && see_blk) {
      spos ++;
    }
    return see_sch (pieceval, sside);
}

#endif		/* Use SEE */

/*---------------------------------------------------------------------------- 
  gen_...   gen move lists
----------------------------------------------------------------------------*/

MV_LIST  *pList;		/* local ptr to cur move list */

		  /* Gen moves by scanning from piece list */

  /* Add move/eval to list */
void gen_add_wht_move(BYTE csrc, BYTE cdest, short int ceval)
{
    pList->m.fr = csrc;
    pList->m.to = cdest;
    pList->eval = ceval;
    pList ++; 
}

  /* Add move/capt to list */
void gen_add_wht_move_capt(BYTE csrc, BYTE cdest, BYTE srcPiece, BYTE destPiece)
{
    pList->m.fr = csrc;
    pList->m.to = cdest;
    if (destPiece) {
      pList->eval = MV_MVV_LVA(srcPiece, destPiece & MV_PIECEMASK);
    } else {
     #if SCH_WEIGHT
      pList->eval = MV_WEIGHT_VAL(csrc,cdest);
     #else
      pList->eval = 0;
     #endif
    }
    pList ++; 
}


  /* Add move/eval to list, eval simple center weight */
void gen_add_wht_move_wgt(BYTE csrc, BYTE cdest)
{
    pList->m.fr = csrc;
    pList->m.to = cdest;
    #if SCH_WEIGHT
     pList->eval = MV_WEIGHT_VAL(csrc,cdest);
    #else
     pList->eval = 0;
    #endif
    pList ++; 
}

#define gen_move_wht(cpos,cdest,srcPiece) if(!((destPiece = sch_brd.board[TO_BYTE(cdest)]) & (MV_WHITE | MV_UNUSED))) gen_add_wht_move_capt(cpos, TO_BYTE(cdest), srcPiece, destPiece);
  

  /* Gen white pawn moves */
void gen_move_wht_pawn (BYTE cpos)
{
    BYTE cdest;
    if (sch_brd.board[TO_BYTE(cpos - MV_DIR_DOWN)] == MV_EMPTY) {
      gen_add_wht_move_wgt (cpos, TO_BYTE(cpos - MV_DIR_DOWN));
      if (cpos > sch_wpawnrow) {
        if (sch_brd.board[TO_BYTE(cpos - MV_DIR_DOWN2)] == MV_EMPTY) {
          gen_add_wht_move_wgt (cpos, TO_BYTE(cpos - MV_DIR_DOWN2));
	}
      }
    }
    if ((cdest = sch_brd.board[TO_BYTE(cpos - MV_DIR_DOWN - 1)]) & MV_BLACK) {
      gen_add_wht_move (cpos,  TO_BYTE(cpos - MV_DIR_DOWN - 1), (short) MV_MVV_LVA (MV_PAWN, cdest & MV_PIECEMASK));
    }
    if ((cdest = sch_brd.board[TO_BYTE(cpos - MV_DIR_DOWN + 1)]) & MV_BLACK) {
      gen_add_wht_move (cpos,  TO_BYTE(cpos - MV_DIR_DOWN + 1), (short) MV_MVV_LVA (MV_PAWN, cdest & MV_PIECEMASK));
    }
}

  /* Gen white rook/queen orthagonal moves */
void gen_move_wht_rook(BYTE cpos, BYTE srcPiece)
{
    BYTE cdest;
    BYTE destPiece;

    cdest = cpos + 1;
    while (sch_brd.board[TO_BYTE(cdest)] == MV_EMPTY) {		/* Move to empty sqrs? */
      gen_add_wht_move_wgt (cpos, cdest);
      cdest ++;
    } 
    if ((destPiece = sch_brd.board[TO_BYTE(cdest)]) & MV_BLACK) {	/* Capture? */
      gen_add_wht_move (cpos, cdest, (short) MV_MVV_LVA(srcPiece, destPiece & MV_PIECEMASK));
    }

    cdest = cpos - 1;
    while (sch_brd.board[TO_BYTE(cdest)] == MV_EMPTY) {		/* Move to empty sqrs? */
      gen_add_wht_move_wgt (cpos, cdest);
      cdest --;
    } 
    if ((destPiece = sch_brd.board[TO_BYTE(cdest)]) & MV_BLACK) {	/* Capture? */
      gen_add_wht_move (cpos, cdest, (short) MV_MVV_LVA(srcPiece, destPiece & MV_PIECEMASK));
    }

    cdest = cpos - MV_DIR_DOWN;
    while (sch_brd.board[TO_BYTE(cdest)] == MV_EMPTY) {		/* Move to empty sqrs? */
      gen_add_wht_move_wgt (cpos, cdest);
      cdest -= MV_DIR_DOWN;
    } 
    if ((destPiece = sch_brd.board[TO_BYTE(cdest)]) & MV_BLACK) {	/* Capture? */
      gen_add_wht_move (cpos, cdest, (short) MV_MVV_LVA(srcPiece, destPiece & MV_PIECEMASK));
    }

    cdest = cpos + MV_DIR_DOWN;
    while (sch_brd.board[TO_BYTE(cdest)] == MV_EMPTY) {		/* Move to empty sqrs? */
      gen_add_wht_move_wgt (cpos, cdest);
      cdest += MV_DIR_DOWN;
    } 
    if ((destPiece = sch_brd.board[TO_BYTE(cdest)]) & MV_BLACK) {	/* Capture? */
      gen_add_wht_move (cpos, cdest, (short) MV_MVV_LVA(srcPiece, destPiece & MV_PIECEMASK));
    }
}

  /* Gen white bishop/queen diagonal moves */
void gen_move_wht_bishop(BYTE cpos, BYTE srcPiece)
{
    BYTE cdest;
    BYTE destPiece;

    cdest = cpos + (MV_DIR_DOWN + 1);
    while (sch_brd.board[TO_BYTE(cdest)] == MV_EMPTY) {		/* Move to empty sqrs? */
      gen_add_wht_move_wgt (cpos, cdest);
      cdest += (MV_DIR_DOWN + 1);
    } 
    if ((destPiece = sch_brd.board[TO_BYTE(cdest)]) & MV_BLACK) {	/* Capture? */
      gen_add_wht_move (cpos, cdest, (short) MV_MVV_LVA(srcPiece, destPiece & MV_PIECEMASK));
    }

    cdest = cpos + (MV_DIR_DOWN - 1);
    while (sch_brd.board[TO_BYTE(cdest)] == MV_EMPTY) {		/* Move to empty sqrs? */
      gen_add_wht_move_wgt (cpos, cdest);
      cdest += (MV_DIR_DOWN - 1);
    } 
    if ((destPiece = sch_brd.board[TO_BYTE(cdest)]) & MV_BLACK) {	/* Capture? */
      gen_add_wht_move (cpos, cdest, (short) MV_MVV_LVA(srcPiece, destPiece & MV_PIECEMASK));
    }

    cdest = cpos - (MV_DIR_DOWN + 1);
    while (sch_brd.board[TO_BYTE(cdest)] == MV_EMPTY) {		/* Move to empty sqrs? */
      gen_add_wht_move_wgt (cpos, cdest);
      cdest -= (MV_DIR_DOWN + 1);
    } 
    if ((destPiece = sch_brd.board[TO_BYTE(cdest)]) & MV_BLACK) {	/* Capture? */
      gen_add_wht_move (cpos, cdest, (short) MV_MVV_LVA(srcPiece, destPiece & MV_PIECEMASK));
    }

    cdest = cpos - (MV_DIR_DOWN - 1);
    while (sch_brd.board[TO_BYTE(cdest)] == MV_EMPTY) {		/* Move to empty sqrs? */
      gen_add_wht_move_wgt (cpos, cdest);
      cdest -= (MV_DIR_DOWN - 1);
    } 
    if ((destPiece = sch_brd.board[TO_BYTE(cdest)]) & MV_BLACK) {	/* Capture? */
      gen_add_wht_move (cpos, cdest, (short) MV_MVV_LVA(srcPiece, destPiece & MV_PIECEMASK));
    }
}

  /* Generate a move list (sch_pList, sch_nmoves..) using piece list */
void gen_move_white ()
{
    BYTE clist;
    BYTE ctype,cpos;
    BYTE destPiece;

    pList = sch_pList;
    sch_nmoves = 0;
    if (sch_wpiece[0].type == 0) return;	/* No king, no moves.. */

    for (clist = 0; clist < sch_nWht; clist ++) {
      cpos  = sch_wpiece[clist].pos;
      ctype = sch_wpiece[clist].type;
      CASSERT (ctype ? ctype == (sch_brd.board[cpos] & MV_PIECEMASK) : 1);
      switch (ctype) {

        case MV_PAWN:
	  gen_move_wht_pawn (cpos);
	  break;

        case MV_KNIGHT:
	  gen_move_wht(cpos,cpos+MV_DIR_DOWN-2, MV_KNIGHT);
	  gen_move_wht(cpos,cpos+MV_DIR_DOWN+2, MV_KNIGHT);
	  gen_move_wht(cpos,cpos+MV_DIR_DOWN2-1,MV_KNIGHT);
	  gen_move_wht(cpos,cpos+MV_DIR_DOWN2+1,MV_KNIGHT);
	  gen_move_wht(cpos,cpos-MV_DIR_DOWN-2, MV_KNIGHT);
	  gen_move_wht(cpos,cpos-MV_DIR_DOWN+2, MV_KNIGHT);
	  gen_move_wht(cpos,cpos-MV_DIR_DOWN2-1,MV_KNIGHT);
	  gen_move_wht(cpos,cpos-MV_DIR_DOWN2+1,MV_KNIGHT);
	  break;

        case MV_KING:
	  gen_move_wht(cpos,cpos+MV_DIR_DOWN-1,MV_KING);
	  gen_move_wht(cpos,cpos+MV_DIR_DOWN,  MV_KING);
	  gen_move_wht(cpos,cpos+MV_DIR_DOWN+1,MV_KING);
	  gen_move_wht(cpos,cpos+1, MV_KING);
	  gen_move_wht(cpos,cpos-1, MV_KING);
	  gen_move_wht(cpos,cpos-MV_DIR_DOWN-1,MV_KING);
	  gen_move_wht(cpos,cpos-MV_DIR_DOWN,  MV_KING);
	  gen_move_wht(cpos,cpos-MV_DIR_DOWN+1,MV_KING);
	  break;

        case MV_BISHOP:
	  gen_move_wht_bishop (cpos,ctype);
	  break;

        case MV_QUEEN:
	  gen_move_wht_bishop (cpos,ctype);

        case MV_ROOK:
	  gen_move_wht_rook (cpos,ctype);
	  break;
      }
    }
    sch_nmoves = (pList - sch_pList);
}


	  /* Gen moves by scanning from piece list */

  /* Add move/eval to list */
void gen_add_blk_move(BYTE csrc, BYTE cdest, short int ceval)
{
    pList->m.fr = csrc;
    pList->m.to = cdest;
    pList->eval = ceval;
    pList ++; 
}

  /* Add move/capt to list */
void gen_add_blk_move_capt(BYTE csrc, BYTE cdest, BYTE srcPiece, BYTE destPiece)
{
    pList->m.fr = csrc;
    pList->m.to = cdest;
    if (destPiece) {
      pList->eval = MV_MVV_LVA(srcPiece, destPiece & MV_PIECEMASK);
    } else {
     #if SCH_WEIGHT
      pList->eval = MV_WEIGHT_VAL(csrc,cdest);
     #else
      pList->eval = 0;
     #endif
    }
    pList ++; 
}


  /* Add move/eval to list, eval simple center weight */
void gen_add_blk_move_wgt(BYTE csrc, BYTE cdest)
{
    pList->m.fr = csrc;
    pList->m.to = cdest;
    #if SCH_WEIGHT
     pList->eval = MV_WEIGHT_VAL(csrc,cdest);
    #else
     pList->eval = 0;
    #endif
    pList ++; 
}

#define gen_move_blk(cpos,cdest,srcPiece) if(!((destPiece = sch_brd.board[TO_BYTE(cdest)]) & (MV_BLACK | MV_UNUSED))) gen_add_blk_move_capt(cpos, TO_BYTE(cdest), srcPiece, destPiece);
  

  /* Gen white pawn moves */
void gen_move_blk_pawn (BYTE cpos)
{
    BYTE cdest;
    if (sch_brd.board[TO_BYTE(cpos + MV_DIR_DOWN)] == MV_EMPTY) {
      gen_add_blk_move_wgt (cpos, TO_BYTE(cpos + MV_DIR_DOWN));
      if (cpos < sch_bpawnrow) {
        if (sch_brd.board[TO_BYTE(cpos + MV_DIR_DOWN2)] == MV_EMPTY) {
          gen_add_blk_move_wgt (cpos, TO_BYTE(cpos + MV_DIR_DOWN2));
	}
      }
    }
    if ((cdest = sch_brd.board[TO_BYTE(cpos + MV_DIR_DOWN - 1)]) & MV_WHITE) {
      gen_add_blk_move (cpos,  TO_BYTE(cpos + MV_DIR_DOWN - 1), (short) MV_MVV_LVA (MV_PAWN, cdest & MV_PIECEMASK));
    }
    if ((cdest = sch_brd.board[TO_BYTE(cpos + MV_DIR_DOWN + 1)]) & MV_WHITE) {
      gen_add_blk_move (cpos,  TO_BYTE(cpos + MV_DIR_DOWN + 1), (short) MV_MVV_LVA (MV_PAWN, cdest & MV_PIECEMASK));
    }
}

  /* Gen white rook/queen orthagonal moves */
void gen_move_blk_rook(BYTE cpos, BYTE srcPiece)
{
    BYTE cdest;
    BYTE destPiece;

    cdest = cpos + 1;
    while (sch_brd.board[TO_BYTE(cdest)] == MV_EMPTY) {		/* Move to empty sqrs? */
      gen_add_blk_move_wgt (cpos, cdest);
      cdest ++;
    } 
    if ((destPiece = sch_brd.board[TO_BYTE(cdest)]) & MV_WHITE) {	/* Capture? */
      gen_add_blk_move (cpos, cdest, (short) MV_MVV_LVA(srcPiece, destPiece & MV_PIECEMASK));
    }

    cdest = cpos - 1;
    while (sch_brd.board[TO_BYTE(cdest)] == MV_EMPTY) {		/* Move to empty sqrs? */
      gen_add_blk_move_wgt (cpos, cdest);
      cdest --;
    } 
    if ((destPiece = sch_brd.board[TO_BYTE(cdest)]) & MV_WHITE) {	/* Capture? */
      gen_add_blk_move (cpos, cdest, (short) MV_MVV_LVA(srcPiece, destPiece & MV_PIECEMASK));
    }

    cdest = cpos - MV_DIR_DOWN;
    while (sch_brd.board[TO_BYTE(cdest)] == MV_EMPTY) {		/* Move to empty sqrs? */
      gen_add_blk_move_wgt (cpos, cdest);
      cdest -= MV_DIR_DOWN;
    } 
    if ((destPiece = sch_brd.board[TO_BYTE(cdest)]) & MV_WHITE) {	/* Capture? */
      gen_add_blk_move (cpos, cdest, (short) MV_MVV_LVA(srcPiece, destPiece & MV_PIECEMASK));
    }

    cdest = cpos + MV_DIR_DOWN;
    while (sch_brd.board[TO_BYTE(cdest)] == MV_EMPTY) {		/* Move to empty sqrs? */
      gen_add_blk_move_wgt (cpos, cdest);
      cdest += MV_DIR_DOWN;
    } 
    if ((destPiece = sch_brd.board[TO_BYTE(cdest)]) & MV_WHITE) {	/* Capture? */
      gen_add_blk_move (cpos, cdest, (short) MV_MVV_LVA(srcPiece, destPiece & MV_PIECEMASK));
    }
}

  /* Gen white bishop/queen diagonal moves */
void gen_move_blk_bishop(BYTE cpos, BYTE srcPiece)
{
    BYTE cdest;
    BYTE destPiece;

    cdest = cpos + (MV_DIR_DOWN + 1);
    while (sch_brd.board[TO_BYTE(cdest)] == MV_EMPTY) {		/* Move to empty sqrs? */
      gen_add_blk_move_wgt (cpos, cdest);
      cdest += (MV_DIR_DOWN + 1);
    } 
    if ((destPiece = sch_brd.board[TO_BYTE(cdest)]) & MV_WHITE) {	/* Capture? */
      gen_add_blk_move (cpos, cdest, (short) MV_MVV_LVA(srcPiece, destPiece & MV_PIECEMASK));
    }

    cdest = cpos + (MV_DIR_DOWN - 1);
    while (sch_brd.board[TO_BYTE(cdest)] == MV_EMPTY) {		/* Move to empty sqrs? */
      gen_add_blk_move_wgt (cpos, cdest);
      cdest += (MV_DIR_DOWN - 1);
    } 
    if ((destPiece = sch_brd.board[TO_BYTE(cdest)]) & MV_WHITE) {	/* Capture? */
      gen_add_blk_move (cpos, cdest, (short) MV_MVV_LVA(srcPiece, destPiece & MV_PIECEMASK));
    }

    cdest = cpos - (MV_DIR_DOWN + 1);
    while (sch_brd.board[TO_BYTE(cdest)] == MV_EMPTY) {		/* Move to empty sqrs? */
      gen_add_blk_move_wgt (cpos, cdest);
      cdest -= (MV_DIR_DOWN + 1);
    } 
    if ((destPiece = sch_brd.board[TO_BYTE(cdest)]) & MV_WHITE) {	/* Capture? */
      gen_add_blk_move (cpos, cdest, (short) MV_MVV_LVA(srcPiece, destPiece & MV_PIECEMASK));
    }

    cdest = cpos - (MV_DIR_DOWN - 1);
    while (sch_brd.board[TO_BYTE(cdest)] == MV_EMPTY) {		/* Move to empty sqrs? */
      gen_add_blk_move_wgt (cpos, cdest);
      cdest -= (MV_DIR_DOWN - 1);
    } 
    if ((destPiece = sch_brd.board[TO_BYTE(cdest)]) & MV_WHITE) {	/* Capture? */
      gen_add_blk_move (cpos, cdest, (short) MV_MVV_LVA(srcPiece, destPiece & MV_PIECEMASK));
    }
}

  /* Generate a move list (sch_pList, sch_nmoves..) using piece list */
void gen_move_black ()
{
    BYTE clist;
    BYTE ctype,cpos;
    BYTE destPiece;

    pList = sch_pList;
    sch_nmoves = 0;
    if (sch_bpiece[0].type == 0) return;	/* No king, no moves.. */

    for (clist = 0; clist < sch_nBlk; clist ++) {
      cpos  = sch_bpiece[clist].pos;
      ctype = sch_bpiece[clist].type;
      CASSERT (ctype ? ctype == (sch_brd.board[cpos] & MV_PIECEMASK) : 1);
      switch (ctype) {

        case MV_PAWN:
	  gen_move_blk_pawn (cpos);
	  break;

        case MV_KNIGHT:
	  gen_move_blk (cpos, cpos+MV_DIR_DOWN-2, MV_KNIGHT);
	  gen_move_blk (cpos, cpos+MV_DIR_DOWN+2, MV_KNIGHT);
	  gen_move_blk (cpos, cpos+MV_DIR_DOWN2-1,MV_KNIGHT);
	  gen_move_blk (cpos, cpos+MV_DIR_DOWN2+1,MV_KNIGHT);
	  gen_move_blk (cpos, cpos-MV_DIR_DOWN-2, MV_KNIGHT);
	  gen_move_blk (cpos, cpos-MV_DIR_DOWN+2, MV_KNIGHT);
	  gen_move_blk (cpos, cpos-MV_DIR_DOWN2-1,MV_KNIGHT);
	  gen_move_blk (cpos, cpos-MV_DIR_DOWN2+1,MV_KNIGHT);
	  break;

        case MV_KING:
	  gen_move_blk (cpos, cpos+MV_DIR_DOWN-1,MV_KING);
	  gen_move_blk (cpos, cpos+MV_DIR_DOWN,  MV_KING);
	  gen_move_blk (cpos, cpos+MV_DIR_DOWN+1,MV_KING);
	  gen_move_blk (cpos, cpos+1, MV_KING);
	  gen_move_blk (cpos, cpos-1, MV_KING);
	  gen_move_blk (cpos, cpos-MV_DIR_DOWN-1,MV_KING);
	  gen_move_blk (cpos, cpos-MV_DIR_DOWN,  MV_KING);
	  gen_move_blk (cpos, cpos-MV_DIR_DOWN+1,MV_KING);
	  break;

        case MV_BISHOP:
	  gen_move_blk_bishop (cpos,ctype);
	  break;

        case MV_QUEEN:
	  gen_move_blk_bishop (cpos,ctype);

        case MV_ROOK:
	  gen_move_blk_rook (cpos,ctype);
	  break;
      }
    }
    sch_nmoves = (pList - sch_pList);
}


  /* Generate move list */
void gen_moves ()
{
    if (sch_side) {		/* Black moves.. */
      gen_move_black ();
    } else {
      gen_move_white ();
    }
}

	/* Search cur list for move, ret (1..n), 0=bad  */
int gen_isLegal (MV_MOVE *pMove)
{
    int cmv;
    for (cmv = 0; cmv < sch_nmoves; cmv ++) {
      if (pMove->fr == sch_pList[cmv].m.fr && pMove->to == sch_pList[cmv].m.to) {
        return cmv+1;	/* Found it! */
      }
    }
    return 0;		/* Move not legal */

}


/*---------------------------------------------------------------------------- 
  gen_capt .. Gen captures without attack bitmaps..
----------------------------------------------------------------------------*/


#if (SCH_ATTACK_TAB == 0)		/* Dont use Attack bitmaps */

  /* Gen captures by scanning from piece list */

  /* Add move/eval to list */
void gen_add_wht_capt(BYTE csrc, BYTE cdest, short int ceval)
{
    pList->m.fr = csrc;
    pList->m.to = cdest;
    pList->eval = ceval;
    pList ++; 
}

/* #define gen_capt_wht(cpos,cdest,src_Piece) if(((destPiece = sch_brd.board[TO_BYTE(cdest)]) & MV_BLACK)) gen_add_wht_capt(cpos, TO_BYTE(cdest), (short) MV_MVV_LVA_CAPT(src_Piece, destPiece & MV_PIECEMASK)); */

void gen_capt_wht (BYTE cpos, BYTE cdest, BYTE src_Piece) 
{
  BYTE destPiece;
  destPiece = sch_brd.board[TO_BYTE(cdest)];
  if (destPiece & MV_BLACK) {
    pList->m.fr = cpos;
    pList->m.to = cdest;
    pList->eval = (short) MV_MVV_LVA_CAPT(src_Piece, destPiece & MV_PIECEMASK);
    pList ++; 
  }
} 

  /* Gen white pawn moves */
void gen_capt_wht_pawn (BYTE cpos)
{
    BYTE cdest;
    if ((cdest = sch_brd.board[TO_BYTE(cpos - MV_DIR_DOWN - 1)]) & MV_BLACK) {
      gen_add_wht_capt (cpos,  TO_BYTE(cpos - MV_DIR_DOWN - 1), (short) MV_MVV_LVA_CAPT (MV_PAWN, cdest & MV_PIECEMASK));
    }
    if ((cdest = sch_brd.board[TO_BYTE(cpos - MV_DIR_DOWN + 1)]) & MV_BLACK) {
      gen_add_wht_capt (cpos,  TO_BYTE(cpos - MV_DIR_DOWN + 1), (short) MV_MVV_LVA_CAPT (MV_PAWN, cdest & MV_PIECEMASK));
    }
}

  /* Gen white rook/queen orthagonal moves */
void gen_capt_wht_rook(BYTE cpos, BYTE srcPiece)
{
    BYTE cdest;
    BYTE destPiece;

    cdest = cpos + 1;
    while (sch_brd.board[TO_BYTE(cdest)] == MV_EMPTY) {		/* Move to empty sqrs? */
      cdest ++;
    } 
    if ((destPiece = sch_brd.board[TO_BYTE(cdest)]) & MV_BLACK) {	/* Capture? */
      gen_add_wht_capt (cpos, cdest, (short) MV_MVV_LVA_CAPT(srcPiece, destPiece & MV_PIECEMASK));
    }

    cdest = cpos - 1;
    while (sch_brd.board[TO_BYTE(cdest)] == MV_EMPTY) {		/* Move to empty sqrs? */
      cdest --;
    } 
    if ((destPiece = sch_brd.board[TO_BYTE(cdest)]) & MV_BLACK) {	/* Capture? */
      gen_add_wht_capt (cpos, cdest, (short) MV_MVV_LVA_CAPT(srcPiece, destPiece & MV_PIECEMASK));
    }

    cdest = cpos - MV_DIR_DOWN;
    while (sch_brd.board[TO_BYTE(cdest)] == MV_EMPTY) {		/* Move to empty sqrs? */
      cdest -= MV_DIR_DOWN;
    } 
    if ((destPiece = sch_brd.board[TO_BYTE(cdest)]) & MV_BLACK) {	/* Capture? */
      gen_add_wht_capt (cpos, cdest, (short) MV_MVV_LVA_CAPT(srcPiece, destPiece & MV_PIECEMASK));
    }

    cdest = cpos + MV_DIR_DOWN;
    while (sch_brd.board[TO_BYTE(cdest)] == MV_EMPTY) {		/* Move to empty sqrs? */
      cdest += MV_DIR_DOWN;
    } 
    if ((destPiece = sch_brd.board[TO_BYTE(cdest)]) & MV_BLACK) {	/* Capture? */
      gen_add_wht_capt (cpos, cdest, (short) MV_MVV_LVA_CAPT(srcPiece, destPiece & MV_PIECEMASK));
    }
}

  /* Gen white bishop/queen diagonal moves */
void gen_capt_wht_bishop(BYTE cpos, BYTE srcPiece)
{
    BYTE cdest;
    BYTE destPiece;

    cdest = cpos + (MV_DIR_DOWN + 1);
    while (sch_brd.board[TO_BYTE(cdest)] == MV_EMPTY) {		/* Move to empty sqrs? */
      cdest += (MV_DIR_DOWN + 1);
    } 
    if ((destPiece = sch_brd.board[TO_BYTE(cdest)]) & MV_BLACK) {	/* Capture? */
      gen_add_wht_capt (cpos, cdest, (short) MV_MVV_LVA_CAPT(srcPiece, destPiece & MV_PIECEMASK));
    }

    cdest = cpos + (MV_DIR_DOWN - 1);
    while (sch_brd.board[TO_BYTE(cdest)] == MV_EMPTY) {		/* Move to empty sqrs? */
      cdest += (MV_DIR_DOWN - 1);
    } 
    if ((destPiece = sch_brd.board[TO_BYTE(cdest)]) & MV_BLACK) {	/* Capture? */
      gen_add_wht_capt (cpos, cdest, (short) MV_MVV_LVA_CAPT(srcPiece, destPiece & MV_PIECEMASK));
    }

    cdest = cpos - (MV_DIR_DOWN + 1);
    while (sch_brd.board[TO_BYTE(cdest)] == MV_EMPTY) {		/* Move to empty sqrs? */
      cdest -= (MV_DIR_DOWN + 1);
    } 
    if ((destPiece = sch_brd.board[TO_BYTE(cdest)]) & MV_BLACK) {	/* Capture? */
      gen_add_wht_capt (cpos, cdest, (short) MV_MVV_LVA_CAPT(srcPiece, destPiece & MV_PIECEMASK));
    }

    cdest = cpos - (MV_DIR_DOWN - 1);
    while (sch_brd.board[TO_BYTE(cdest)] == MV_EMPTY) {		/* Move to empty sqrs? */
      cdest -= (MV_DIR_DOWN - 1);
    } 
    if ((destPiece = sch_brd.board[TO_BYTE(cdest)]) & MV_BLACK) {	/* Capture? */
      gen_add_wht_capt (cpos, cdest, (short) MV_MVV_LVA_CAPT(srcPiece, destPiece & MV_PIECEMASK));
    }
}

  /* Generate a move list (sch_pList, sch_nmoves..) using piece list */
void gen_white_captures ()
{
    BYTE clist;
    BYTE ctype,cpos;

    pList = sch_pList;
    sch_nmoves = 0;
    for (clist = 0; clist < sch_nWht; clist ++) {
      cpos  = sch_wpiece[clist].pos;
      ctype = sch_wpiece[clist].type;
      CASSERT (ctype ? ctype == (sch_brd.board[cpos] & MV_PIECEMASK) : 1);
      /* io_putsisi (" ty:",ctype,"@",cpos); */
      switch (ctype) {

        case MV_PAWN:
	  gen_capt_wht_pawn (cpos);
	  break;

        case MV_KNIGHT:
	  gen_capt_wht(cpos, TO_BYTE(cpos+MV_DIR_DOWN-2), MV_KNIGHT);
	  gen_capt_wht(cpos, TO_BYTE(cpos+MV_DIR_DOWN+2), MV_KNIGHT);
	  gen_capt_wht(cpos, TO_BYTE(cpos+MV_DIR_DOWN2-1),MV_KNIGHT);
	  gen_capt_wht(cpos, TO_BYTE(cpos+MV_DIR_DOWN2+1),MV_KNIGHT);
	  gen_capt_wht(cpos, TO_BYTE(cpos-MV_DIR_DOWN-2), MV_KNIGHT);
	  gen_capt_wht(cpos, TO_BYTE(cpos-MV_DIR_DOWN+2), MV_KNIGHT);
	  gen_capt_wht(cpos, TO_BYTE(cpos-MV_DIR_DOWN2-1),MV_KNIGHT);
	  gen_capt_wht(cpos, TO_BYTE(cpos-MV_DIR_DOWN2+1),MV_KNIGHT);
	  break;

        case MV_KING:
	  gen_capt_wht(cpos, TO_BYTE(cpos+MV_DIR_DOWN-1),MV_KING);
	  gen_capt_wht(cpos, TO_BYTE(cpos+MV_DIR_DOWN),  MV_KING);
	  gen_capt_wht(cpos, TO_BYTE(cpos+MV_DIR_DOWN+1),MV_KING);
	  gen_capt_wht(cpos, TO_BYTE(cpos+1), MV_KING);
	  gen_capt_wht(cpos, TO_BYTE(cpos-1), MV_KING);
	  gen_capt_wht(cpos, TO_BYTE(cpos-MV_DIR_DOWN-1),MV_KING);
	  gen_capt_wht(cpos, TO_BYTE(cpos-MV_DIR_DOWN),  MV_KING);
	  gen_capt_wht(cpos, TO_BYTE(cpos-MV_DIR_DOWN+1),MV_KING);
	  break;

        case MV_BISHOP:
	  gen_capt_wht_bishop (cpos,ctype);
	  break;

        case MV_QUEEN:
	  gen_capt_wht_bishop (cpos,ctype);

        case MV_ROOK:
	  gen_capt_wht_rook (cpos,ctype);
	  break;
      }
    }
    sch_nmoves = (pList - sch_pList);
}

/*---------------------------------------------------------------------------- 
  gen_capt_blk .. Gen black captures..
----------------------------------------------------------------------------*/

  /* Gen captures by scanning from piece list */

  /* Add move/eval to list */
void gen_add_blk_capt(BYTE csrc, BYTE cdest, short int ceval)
{
    pList->m.fr = csrc;
    pList->m.to = cdest;
    pList->eval = ceval;
    pList ++; 
}

/* #define gen_capt_blk(cpos,cdest,srcPiece) if( ((destPiece = sch_brd.board[TO_BYTE(cdest)]) & MV_WHITE)) gen_add_blk_capt(cpos, TO_BYTE(cdest), (short) MV_MVV_LVA_CAPT(srcPiece, destPiece & MV_PIECEMASK)); */

void gen_capt_blk (BYTE cpos, BYTE cdest, BYTE src_Piece) 
{
  BYTE destPiece;
  destPiece = sch_brd.board[cdest];
  if (destPiece & MV_WHITE) {
    pList->m.fr = cpos;
    pList->m.to = cdest;
    pList->eval = (short) MV_MVV_LVA_CAPT(src_Piece, destPiece & MV_PIECEMASK);
    pList ++; 
  }
} 



  /* Gen white pawn moves */
void gen_capt_blk_pawn (BYTE cpos)
{
    BYTE cdest;
    if ((cdest = sch_brd.board[TO_BYTE(cpos + MV_DIR_DOWN - 1)]) & MV_WHITE) {
      gen_add_blk_capt (cpos,  TO_BYTE(cpos + MV_DIR_DOWN - 1), (short) MV_MVV_LVA_CAPT (MV_PAWN, cdest & MV_PIECEMASK));
    }
    if ((cdest = sch_brd.board[TO_BYTE(cpos + MV_DIR_DOWN + 1)]) & MV_WHITE) {
      gen_add_blk_capt (cpos,  TO_BYTE(cpos + MV_DIR_DOWN + 1), (short) MV_MVV_LVA_CAPT (MV_PAWN, cdest & MV_PIECEMASK));
    }
}

  /* Gen white rook/queen orthagonal moves */
void gen_capt_blk_rook(BYTE cpos, BYTE srcPiece)
{
    BYTE cdest;
    BYTE destPiece;

    cdest = cpos + 1;
    while (sch_brd.board[TO_BYTE(cdest)] == MV_EMPTY) {		/* Move to empty sqrs? */
      cdest ++;
    } 
    if ((destPiece = sch_brd.board[TO_BYTE(cdest)]) & MV_WHITE) {	/* Capture? */
      gen_add_blk_capt (cpos, cdest, (short) MV_MVV_LVA_CAPT(srcPiece, destPiece & MV_PIECEMASK));
    }

    cdest = cpos - 1;
    while (sch_brd.board[TO_BYTE(cdest)] == MV_EMPTY) {		/* Move to empty sqrs? */
      cdest --;
    } 
    if ((destPiece = sch_brd.board[TO_BYTE(cdest)]) & MV_WHITE) {	/* Capture? */
      gen_add_blk_capt (cpos, cdest, (short) MV_MVV_LVA_CAPT(srcPiece, destPiece & MV_PIECEMASK));
    }

    cdest = cpos - MV_DIR_DOWN;
    while (sch_brd.board[TO_BYTE(cdest)] == MV_EMPTY) {		/* Move to empty sqrs? */
      cdest -= MV_DIR_DOWN;
    } 
    if ((destPiece = sch_brd.board[TO_BYTE(cdest)]) & MV_WHITE) {	/* Capture? */
      gen_add_blk_capt (cpos, cdest, (short) MV_MVV_LVA_CAPT(srcPiece, destPiece & MV_PIECEMASK));
    }

    cdest = cpos + MV_DIR_DOWN;
    while (sch_brd.board[TO_BYTE(cdest)] == MV_EMPTY) {		/* Move to empty sqrs? */
      cdest += MV_DIR_DOWN;
    } 
    if ((destPiece = sch_brd.board[TO_BYTE(cdest)]) & MV_WHITE) {	/* Capture? */
      gen_add_blk_capt (cpos, cdest, (short) MV_MVV_LVA_CAPT(srcPiece, destPiece & MV_PIECEMASK));
    }
}

  /* Gen white bishop/queen diagonal moves */
void gen_capt_blk_bishop(BYTE cpos, BYTE srcPiece)
{
    BYTE cdest;
    BYTE destPiece;

    cdest = cpos + (MV_DIR_DOWN + 1);
    while (sch_brd.board[TO_BYTE(cdest)] == MV_EMPTY) {		/* Move to empty sqrs? */
      cdest += (MV_DIR_DOWN + 1);
    } 
    if ((destPiece = sch_brd.board[TO_BYTE(cdest)]) & MV_WHITE) {	/* Capture? */
      gen_add_blk_capt (cpos, cdest, (short) MV_MVV_LVA_CAPT(srcPiece, destPiece & MV_PIECEMASK));
    }

    cdest = cpos + (MV_DIR_DOWN - 1);
    while (sch_brd.board[TO_BYTE(cdest)] == MV_EMPTY) {		/* Move to empty sqrs? */
      cdest += (MV_DIR_DOWN - 1);
    } 
    if ((destPiece = sch_brd.board[TO_BYTE(cdest)]) & MV_WHITE) {	/* Capture? */
      gen_add_blk_capt (cpos, cdest, (short) MV_MVV_LVA_CAPT(srcPiece, destPiece & MV_PIECEMASK));
    }

    cdest = cpos - (MV_DIR_DOWN + 1);
    while (sch_brd.board[TO_BYTE(cdest)] == MV_EMPTY) {		/* Move to empty sqrs? */
      cdest -= (MV_DIR_DOWN + 1);
    } 
    if ((destPiece = sch_brd.board[TO_BYTE(cdest)]) & MV_WHITE) {	/* Capture? */
      gen_add_blk_capt (cpos, cdest, (short) MV_MVV_LVA_CAPT(srcPiece, destPiece & MV_PIECEMASK));
    }

    cdest = cpos - (MV_DIR_DOWN - 1);
    while (sch_brd.board[TO_BYTE(cdest)] == MV_EMPTY) {		/* Move to empty sqrs? */
      cdest -= (MV_DIR_DOWN - 1);
    } 
    if ((destPiece = sch_brd.board[TO_BYTE(cdest)]) & MV_WHITE) {	/* Capture? */
      gen_add_blk_capt (cpos, cdest, (short) MV_MVV_LVA_CAPT(srcPiece, destPiece & MV_PIECEMASK));
    }
}

  /* Generate a move list (sch_pList, sch_nmoves..) using piece list */
void gen_black_captures ()
{
    BYTE clist;
    BYTE ctype,cpos;

    pList = sch_pList;
    sch_nmoves = 0;
    for (clist = 0; clist < sch_nBlk; clist ++) {
      cpos  = sch_bpiece[clist].pos;
      ctype = sch_bpiece[clist].type;
      CASSERT (ctype ? ctype == (sch_brd.board[cpos] & MV_PIECEMASK) : 1);
      switch (ctype) {

        case MV_PAWN:
	  gen_capt_blk_pawn (cpos);
	  break;

        case MV_KNIGHT:
	  gen_capt_blk(cpos, TO_BYTE(cpos+MV_DIR_DOWN-2), MV_KNIGHT);
	  gen_capt_blk(cpos, TO_BYTE(cpos+MV_DIR_DOWN+2), MV_KNIGHT);
	  gen_capt_blk(cpos, TO_BYTE(cpos+MV_DIR_DOWN2-1),MV_KNIGHT);
	  gen_capt_blk(cpos, TO_BYTE(cpos+MV_DIR_DOWN2+1),MV_KNIGHT);
	  gen_capt_blk(cpos, TO_BYTE(cpos-MV_DIR_DOWN-2), MV_KNIGHT);
	  gen_capt_blk(cpos, TO_BYTE(cpos-MV_DIR_DOWN+2), MV_KNIGHT);
	  gen_capt_blk(cpos, TO_BYTE(cpos-MV_DIR_DOWN2-1),MV_KNIGHT);
	  gen_capt_blk(cpos, TO_BYTE(cpos-MV_DIR_DOWN2+1),MV_KNIGHT);
	  break;

        case MV_KING:
	  gen_capt_blk(cpos, TO_BYTE(cpos+MV_DIR_DOWN-1),MV_KING);
	  gen_capt_blk(cpos, TO_BYTE(cpos+MV_DIR_DOWN),  MV_KING);
	  gen_capt_blk(cpos, TO_BYTE(cpos+MV_DIR_DOWN+1),MV_KING);
	  gen_capt_blk(cpos, TO_BYTE(cpos+1), MV_KING);
	  gen_capt_blk(cpos, TO_BYTE(cpos-1), MV_KING);
	  gen_capt_blk(cpos, TO_BYTE(cpos-MV_DIR_DOWN-1),MV_KING);
	  gen_capt_blk(cpos, TO_BYTE(cpos-MV_DIR_DOWN),  MV_KING);
	  gen_capt_blk(cpos, TO_BYTE(cpos-MV_DIR_DOWN+1),MV_KING);
	  break;

        case MV_BISHOP:
	  gen_capt_blk_bishop (cpos,ctype);
	  break;

        case MV_QUEEN:
	  gen_capt_blk_bishop (cpos,ctype);

        case MV_ROOK:
	  gen_capt_blk_rook (cpos,ctype);
	  break;
      }
    }
    sch_nmoves = (pList - sch_pList);
}

void gen_captures ()
{
    if (sch_side) {		/* Black captures.. */
      gen_black_captures ();
    } else {
      gen_white_captures ();
    }
}

#endif


/*---------------------------------------------------------------------------- 
  gen_capt .. Gen captures by scanning opponents using attack tabs/SEE..
----------------------------------------------------------------------------*/

#if SCH_ATTACK_TAB		/* Use Attack bitmaps */


void gen_white_captures ()
{
    BYTE stype,spos;		/* Source piece type, pos */		
    int slist;
    BYTE dtype,dpos;		/* Dest (captured) piece type, pos */
    int dlist;
    UINT32 attx;		/* Attack bitmap for captured piece */

    pList = sch_pList;
    sch_nmoves = 0;
    for (dlist = 0; dlist < sch_nBlk; dlist ++) {
      dtype = sch_bpiece[dlist].type;		/* Get type/pos of opp piece we might capture.. */
      dpos  = sch_bpiece[dlist].pos;
      if (dtype) {
        CASSERT ((dtype | MV_BLACK) == sch_brd.board[dpos]);	/* Debug: Check piece is really on board */
        attx = att_wht [dpos];
        if (attx) {		/* Any white pieces attack dest? */
          slist = 0;
          while (1) {		/* Scan for set bits.. */
            if (attx == 0) break;	/* No more */
            while (!(attx & 1)) {
              attx = attx >> 1;
	      slist ++;
            }
	    CASSERT (slist < sch_nWht);
            stype = sch_wpiece[slist].type;
            spos  = sch_wpiece[slist].pos;
            attx = attx >> 1;
            slist ++;
  	    if (stype) {	/* Found capturing piece */
              CASSERT ((stype | MV_WHITE) == sch_brd.board[spos]);	/* Debug: Check piece is really on board */
              gen_add_wht_move (spos, dpos, (short) MV_MVV_LVA_CAPT (stype, dtype));
	    }
          }
	}
      }
    }
    sch_nmoves = (pList - sch_pList);
}

void gen_black_captures ()
{
    BYTE stype,spos;		/* Source piece type, pos */		
    int slist;
    BYTE dtype,dpos;		/* Dest (captured) piece type, pos */
    int dlist;
    UINT32 attx;		/* Attack bitmap for captured piece */

    pList = sch_pList;
    sch_nmoves = 0;
    for (dlist = 0; dlist < sch_nWht; dlist ++) {
      dtype = sch_wpiece[dlist].type;		/* Get type/pos of opp piece we might capture.. */
      dpos  = sch_wpiece[dlist].pos;
      if (dtype) {
        CASSERT ((dtype | MV_WHITE) == sch_brd.board[dpos]);	/* Debug: Check piece is really on board */
        attx = att_blk [dpos];
        if (attx) {		/* Any pieces attack dest? */
          slist = 0;
          while (1) {		/* Scan for set bits.. */
            if (attx == 0) break;	/* No more */
            while (!(attx & 1)) {
              attx = attx >> 1;
	      slist ++;
            }
	    CASSERT (slist < sch_nBlk);
            stype = sch_bpiece[slist].type;
            spos  = sch_bpiece[slist].pos;
            attx = attx >> 1;
            slist ++;
  	    if (stype) {	/* Found capturing piece */
              CASSERT ((stype | MV_BLACK) == sch_brd.board[spos]);	/* Debug: Check piece is really on board */
              gen_add_blk_move (spos, dpos, (short) MV_MVV_LVA_CAPT (stype, dtype));
	    }
          }
	}
      }
    }
    sch_nmoves = (pList - sch_pList);
}

void gen_captures ()
{
    if (sch_side) {		/* Black moves.. */
      gen_black_captures ();
    } else {
      gen_white_captures ();
    }
}

#endif		/* SCH_ATTACK_TAB */

/*---------------------------------------------------------------------------- 
  sch_ .. Tree Search code
----------------------------------------------------------------------------*/

  /* Evaluate position for (sch_side) */
int sch_Evaluate ()
{
    BYTE clist;
    BYTE ctype,cpos;
    int eval;

    eval = 0;
    for (clist = 0; clist < sch_nWht; clist ++) {
      cpos  = sch_wpiece[clist].pos;
      ctype = sch_wpiece[clist].type;
      if (ctype) {
	eval += sch_valof [ctype];
        #if SCH_WEIGHT
	  eval += sch_weight [cpos];
	#endif
      }
    }
    for (clist = 0; clist < sch_nBlk; clist ++) {
      cpos  = sch_bpiece[clist].pos;
      ctype = sch_bpiece[clist].type;
      if (ctype) {
	eval -= sch_valof [ctype];
        #if SCH_WEIGHT
 	  eval -= sch_weight [cpos];
	#endif
      }
    }

    if (sch_ply > 2) {		/* Simple Mobility.. */
      eval -= (sch_tree[sch_ply-1].nmoves-sch_tree[sch_ply-2].nmoves)/2;
    }
    if (SSET_RAND) eval += (SSET_RAND & io_rand());
    if (sch_side) eval =-eval;
    if (eval == MV_DRAWEVAL) eval ++;	/* Zero val reserved for draw */
    sch_nodes ++;
    return (eval & MV_EVAL_GRAIN);
}

#if SCH_KILLER

  /* Find killer move */
void sch_KillerMove ()
{
    int cmove;
    MV_MOVE kill;

    io_memcpy (&kill, &sch_tree[sch_ply].killmv, sizeof (MV_MOVE));

	/* See if previous killer move is in current list */
    for (cmove = 0; cmove < sch_nmoves; cmove++) {
      if (sch_pList[cmove].m.to == kill.to) {
        if (sch_pList[cmove].m.fr == kill.fr) {
          sch_pList[cmove].eval += SCH_KILLER;		/* Promote killer eval */
	}
      }
    }
}

#endif		/* SCH_KILLER */

#if SCH_SORT

MV_LIST sch_listswap;

  /* Pick best eval from remaining move list */

void sch_PickNextMove (int cmove)
{
    int smove;
    int seval;
    int pickmove;
    int pickeval;

    if (cmove >= sch_nmoves-1) return;
    pickeval = -MV_MAXEVAL-1;
    pickmove = -1;

    for (smove = cmove; smove < sch_nmoves; smove++) {
      seval = sch_pList[smove].eval;
      if (seval > pickeval) {
        pickeval = seval; pickmove = smove;
      }
    }

    CASSERT (pickmove >= 0);

    if (pickmove > cmove) {	/* Swap best move to top */
      io_memcpy (&sch_listswap,        &sch_pList[cmove],    sizeof (MV_LIST));
      io_memcpy (&sch_pList[cmove],    &sch_pList[pickmove], sizeof (MV_LIST));
      io_memcpy (&sch_pList[pickmove], &sch_listswap,        sizeof (MV_LIST));
    }
}

#endif		/* SCH_SORT */

void sch_MakeMove (MV_MOVE *pMov)
{
    BYTE pc,cap;
    BYTE idx,idcap;

    CASSERT (sch_ply >= 0);
    pc = sch_brd.board [pMov->fr];
    CASSERT (pc > 0);
    cap = sch_brd.board [pMov->to];
    idx = sch_2idx[pMov->fr];
    sch_tree[sch_ply].piece = pc;
    sch_tree[sch_ply].capt = cap;
    sch_tree[sch_ply].idx_capt = 0;
    sch_brd.board [pMov->fr] = 0;
    sch_brd.board [pMov->to] = pc;
    if (sch_side) {			/* Update indexes */
      CASSERT (idx < (BYTE) sch_nBlk);
      CASSERT (sch_bpiece[idx].pos == pMov->fr);
      if (cap) {
        CASSERT (cap & MV_WHITE);
        idcap = sch_2idx[pMov->to];
        sch_tree[sch_ply].idx_capt = idcap;
        CASSERT (sch_wpiece[idcap].pos == pMov->to);
        sch_wpiece[idcap].type = 0;		/* Mark piece as captured */
      }
      sch_bpiece[idx].pos = pMov->to;		/* Update piece list pos */
      if (pc == MV_BPAWN && pMov->to > sch_blkPromote) {	/* Promote a pawn? */
        sch_bpiece[idx].type = MV_QUEEN;
        sch_brd.board [pMov->to] = MV_BQUEEN;
      }
    } else {
      CASSERT (idx < (BYTE) sch_nWht);
      CASSERT (sch_wpiece[idx].pos == pMov->fr);
      if (cap) {
        CASSERT (cap & MV_BLACK);
        idcap = sch_2idx[pMov->to];
        sch_tree[sch_ply].idx_capt = idcap;
        CASSERT (sch_bpiece[idcap].pos == pMov->to);
        sch_bpiece[idcap].type = 0;		/* Mark piece as captured */
      }
      sch_wpiece[idx].pos = pMov->to;		/* Update piece list pos */
      if (pc == MV_WPAWN && pMov->to < sch_whtPromote) {	/* Promote a pawn? */
        sch_wpiece[idx].type = MV_QUEEN;
        sch_brd.board [pMov->to] = MV_WQUEEN;
      }
    }
    sch_2idx[pMov->to] = idx;
    sch_side = !sch_side;
}

void sch_unMakeMove (MV_MOVE *pMov)
{
    BYTE pc,cap;
    BYTE idx,idcap;

    CASSERT (sch_ply >= 0);
    CASSERT (sch_brd.board [pMov->fr] == 0);
    CASSERT (sch_brd.board [pMov->to]);

    sch_side = !sch_side;
    pc  = sch_tree[sch_ply].piece;
    cap = sch_tree[sch_ply].capt;
    idx = sch_2idx[pMov->to];
    sch_brd.board [pMov->fr] = pc;	/* Restore orig pieces */
    sch_brd.board [pMov->to] = cap;
    if (sch_side) {			/* Update indexes */
      CASSERT (idx < (BYTE) sch_nBlk);
      CASSERT (sch_bpiece[idx].pos == pMov->to);
      sch_bpiece[idx].pos = pMov->fr;
      if (cap) {	/* Restore captured piece in list */
        CASSERT (cap & MV_WHITE);
        idcap = sch_tree[sch_ply].idx_capt;
        CASSERT (sch_wpiece[idcap].type == 0);
        sch_wpiece[idcap].type = cap & MV_PIECEMASK;
        sch_wpiece[idcap].pos = pMov->to;
        sch_2idx[pMov->to] = idcap;
      }
      sch_bpiece[idx].type = pc & MV_PIECEMASK;
    } else {
      CASSERT (idx < (BYTE) sch_nWht);
      CASSERT (sch_wpiece[idx].pos == pMov->to);
      sch_wpiece[idx].pos = pMov->fr;
      if (cap) {	/* Restore captured piece in list */
        CASSERT (cap & MV_BLACK);
        idcap = sch_tree[sch_ply].idx_capt;
        CASSERT (sch_bpiece[idcap].type == 0);
        sch_bpiece[idcap].type = cap & MV_PIECEMASK;
        sch_bpiece[idcap].pos = pMov->to;
        sch_2idx[pMov->to] = idcap;
      }
      sch_wpiece[idx].type = pc & MV_PIECEMASK;
    }
    sch_2idx[pMov->fr] = idx;
}


#if  SCH_QUIESCENCE

  /*  Try to play out captures.. */
int sch_Captures (int depth, int alpha, int beta)
{
    int cmove,eval;
    CASSERT (sch_ply > 0);
    CASSERT (sch_ply < MV_MAXPLY-1);
    CASSERT (sch_pList >= sch_list);
    CASSERT (sch_pList < &sch_list[MV_MAXLIST-50]);

    eval = sch_Evaluate ();
    if (sch_ply > MV_MAXPLY - 2) {
      return eval;
    }
    if (eval >= beta) return beta;		/*  "Standing pat" eval.. */
    /* if (pTree->incheck == FALSE && ceval >= beta) return beta; */
    if (eval > alpha) alpha = eval;

		/* King lost? */
    if (eval < -(MV_VALOF_KING-3000) ) {
      return -(MV_MAXEVAL - sch_ply); 
      /* return eval; */
    }

    #if SCH_ATTACK_TAB		/* Gen/update attack bitmaps */
      gen_attack_white();	/* Hack - for now just regen everything (slow) */
      gen_attack_black();
    #endif

    /* sch_tree[sch_ply].bestmove = -1; */
    gen_captures ();
    if (sch_nmoves == 0) {	/* No captures, ret eval */
      return eval;
    }
	/* Save MvGen info on stack */
    sch_tree[sch_ply].nmoves = sch_nmoves;
    /* eval = -MV_MAXEVAL; */
    for (cmove = 0; cmove < sch_nmoves; cmove++) {
      #if SCH_QUDEPTH		/* If beyond this depth past Quiescence, chop MVA/LVV loosing captures.. */
        if (depth < 1-SCH_QUDEPTH && !(SSET_FLAGS & 2) && sch_pList[cmove].eval < -(MV_VALOF_PAWN/2) && cmove) {
          continue;
        }
      #endif
      #if SCH_QSAMESQR		/* If beyond this depth past Quiescence, only captures on same sqr.. */
        if (depth < 1-SCH_QSAMESQR && !(SSET_FLAGS & 2) && sch_ply > 1 && sch_pList[cmove].m.to != sch_tree[sch_ply].move.to) {
          continue;
        }
      #endif
      sch_MakeMove (&sch_pList[cmove].m);
      sch_pList += sch_nmoves;
      sch_ply ++;
      eval = -sch_Captures (depth-1, -beta, -alpha);  

		/* UnMakemove*/
      sch_ply --;
      sch_nmoves = sch_tree[sch_ply].nmoves;
      sch_pList -= sch_nmoves;
      sch_unMakeMove (&sch_pList[cmove].m);

      if (eval >= beta) {
        /* sch_tree[sch_ply].bestmove = cmove; */
        return beta;
      }
      if (eval > alpha) {
        /* sch_tree[sch_ply].bestmove = cmove; */
        alpha = eval;
      }
    }
    return alpha;
}

#endif			/* SCH_QUIESCENCE */


  /* Perform short look ahead to order moves? */

#if SCH_SHORTLOOK

void sch_ShortLook (int depth)
{
    int cmove;
    int eval;

    if (sch_ply == 1 && SSET_TIME) return;
    if (SSET_FLAGS & 4) return;
    if (sch_doingShort) return;

    sch_doingShort = sch_ply;
    sch_tree[sch_ply].nmoves = sch_nmoves;
    eval = -MV_MAXEVAL;

    for (cmove = 0; cmove < sch_nmoves; cmove++) {
      /* if (sch_brd.board[sch_pList[cmove].m.to]) continue; */
      sch_MakeMove (&sch_pList[cmove].m);

      sch_pList += sch_nmoves;
      sch_ply ++;
      eval = -sch_AlphaBeta ((depth >> 1)-2, -MV_MAXEVAL, MV_MAXEVAL); 
      /* eval = -sch_Captures (0, -MV_MAXEVAL, MV_MAXEVAL);  */
		/* UnMakemove*/
      sch_ply --;
      sch_nmoves = sch_tree[sch_ply].nmoves;
      sch_pList -= sch_nmoves;
      sch_unMakeMove (&sch_pList[cmove].m);

      sch_pList[cmove].eval = eval;	/* Save short-look eval for each move */
    }
    sch_doingShort = FALSE;
}

#endif		/* SCH_SHORTLOOK */


int sch_AlphaBeta (int depth, int alpha, int beta)
{
    int cmove,eval;

		/* Some ENG_DEBUG asserts.. */
    CASSERT (sch_ply > 0);
    CASSERT (sch_ply < MV_MAXPLY-1);
    CASSERT (sch_pList >= sch_list);
    CASSERT (sch_pList < &sch_list[MV_MAXLIST-50]);
    
    /* if (alpha >= beta) return alpha; */

    #if SCH_QUIESCENCE		/* Perform quiecence search? */
      if (depth < 1 && !(SSET_FLAGS & 1)) {	
        return sch_Captures (depth, alpha, beta);
      }
    #endif

    eval = sch_Evaluate ();

    #if ENG_DEBUG	
      if (SSET_DEBUG) {
        io_putsisi ("Eval:",eval," Side:",sch_side);
        io_putsisi (" Ply:",sch_ply," A:",alpha);
        io_putsi (" B:",beta);
        io_puts ("\n");
        cmd_dumpboard (sch_brd.board);
      }
    #endif

		/* King lost? */
    if (eval < -(MV_VALOF_KING-3000) ) {
      return -(MV_MAXEVAL - sch_ply);
    }
		/* Terminal node? */
    if (depth <= 0) {
      return eval;
    }

    #if SCH_ATTACK_TAB		/* Gen/update attack bitmaps */
      gen_attack_white();	/* Hack - just regen all (slow) */
      gen_attack_black();
    #endif
    
    if (sch_ply > 1) {
      gen_moves ();
    }

    #if ENG_DEBUG	
      if (SSET_DEBUG) {
        io_putsisi (" #Mv:",sch_nmoves," #Stk:",(int) (sch_pList - sch_list)); io_puts ("\n");
	cmd_dumplist ();
      }
    #endif

    if (sch_nmoves == 0) {	/* No moves, draw score */
      return MV_DRAWEVAL; 
    }

    #if SCH_SHORTLOOK		/* Perform short look ahead to order moves? */
      if (depth > 5 && sch_nmoves > 1) {
	sch_ShortLook (depth);
      }
    #endif	/* SCH_SHORTLOOK */

    #if SCH_KILLER
      if (sch_ply > 1) {
        sch_KillerMove ();	/* Find any killer move(s).. */
      }
    #endif 

	/* Save MvGen info on stack */
    sch_tree[sch_ply].nmoves = sch_nmoves;
    eval = -MV_MAXEVAL;

    sch_tree[sch_ply].bestmove = -1;

    for (cmove = 0; cmove < sch_nmoves; cmove++) {
      #if SCH_SORT
        sch_PickNextMove (cmove);
      #endif

      sch_MakeMove (&sch_pList[cmove].m);
      sch_pList += sch_nmoves;
      sch_ply ++;
      eval = -sch_AlphaBeta (depth - 1, -beta, -alpha);  

		/* UnMakemove*/
      sch_ply --;
      sch_nmoves = sch_tree[sch_ply].nmoves;
      sch_pList -= sch_nmoves;

      sch_pList[cmove].eval = eval;	/* Save new eval for move */
      sch_unMakeMove (&sch_pList[cmove].m);

      #if ENG_DEBUG	
        if (SSET_DEBUG) {
          cmd_AscFromMove (szDebug, &sch_pList[cmove].m);
          io_puts ("%"); io_puts (szDebug);
          io_putsi ("=",eval); io_puts ("\n");	  
	}
      #endif
		/* Ok, we have (eval) for (cmove) */
      if (eval >= beta) {
        sch_tree[sch_ply].bestmove = cmove;
	#if SCH_KILLER
	  if (!sch_doingShort) io_memcpy (&sch_tree[sch_ply].killmv, &sch_pList[cmove].m, sizeof (MV_MOVE));
	#endif
        /* return eval; */
        return beta;
      }
      if (eval > alpha) {
        sch_tree[sch_ply].bestmove = cmove;
	#if SCH_KILLER
	  if (!sch_doingShort) io_memcpy (&sch_tree[sch_ply].killmv, &sch_pList[cmove].m, sizeof (MV_MOVE));
	#endif
        alpha = eval;
      }
      if (sch_ply < 2 && sch_doingShort == 0) {		/* Ply 1: Tell front-end to show analysis. Time out? */
        #if SCH_TIME
          sch_time = io_GetTime() - sch_timeStart;
	  if (SSET_TIME) {
	    if (sch_time >= SSET_TIME) {
              sch_analyShow (depth,cmove,eval);
	      sch_timeOut = TRUE;
	      break;
	    }
	  }
	#endif
        sch_analyShow (depth,cmove,eval);
      }
    }
    return alpha;
}

  /* Init & do a search */

int sch_Start ()
{
    int sdepth,bestm;

    sdepth = SSET_DEPTH;

    sch_Init ();
    gen_moves ();
    if (sch_nmoves == 0) return FALSE;

    #if (SCH_TIME == 0)
      sch_best.eval = sch_AlphaBeta (SSET_DEPTH, -MV_MAXEVAL, MV_MAXEVAL);
      sch_lastbest = sch_tree[1].bestmove;
    #else
     sch_timeStart = io_GetTime ();
     if (SSET_TIME) {		/* Iterative deepening? */
       sdepth = 0; 
       while (sch_timeOut == FALSE) {
	 sdepth ++;
         sch_best.eval = sch_AlphaBeta (sdepth, -MV_MAXEVAL, MV_MAXEVAL);
         bestm = sch_tree[1].bestmove;
	 if (bestm >= 0) sch_lastbest = bestm;

	 #if ENG_DEBUG	
          CASSERT (sch_ply == 1);
          CASSERT (sch_side == mgam.cur.side);
          CASSERT (sch_pList == sch_list);
	  {
	   int clist,cpos,ctype;
	   for (clist = 0; clist < sch_nBlk; clist ++) {
	     cpos  = sch_bpiece[clist].pos;
             ctype = sch_bpiece[clist].type;
             CASSERT (ctype == (sch_brd.board[cpos] & MV_PIECEMASK));
	   }
	   for (clist = 0; clist < sch_nWht; clist ++) {
	     cpos  = sch_wpiece[clist].pos;
             ctype = sch_wpiece[clist].type;
             CASSERT (ctype == (sch_brd.board[cpos] & MV_PIECEMASK));
	   }
	  }
          if (SSET_FLAGS & 8) {
	   io_puts ("\n");
           cmd_dumplist ();
	  }
	 #endif

         if (sch_nmoves == 1) break;
	 if (sch_best.eval > MV_MAXEVAL - 100) break;
	 if (sch_best.eval < -MV_MAXEVAL + 100) break;
       }
     } else {
       #if ENG_DEBUG	
        if (SSET_FLAGS & 8) {
         cmd_dumplist ();
         sch_best.eval = sch_AlphaBeta (SSET_DEPTH-1, -MV_MAXEVAL, MV_MAXEVAL);
         cmd_dumplist ();
         sch_best.eval = sch_AlphaBeta (SSET_DEPTH, -MV_MAXEVAL, MV_MAXEVAL);
         cmd_dumplist ();
        }
       #endif
       sch_best.eval = sch_AlphaBeta (SSET_DEPTH, -MV_MAXEVAL, MV_MAXEVAL);
       sch_lastbest = sch_tree[1].bestmove;
     }
    #endif

    CASSERT (sch_ply == 1);
    CASSERT (sch_side == mgam.cur.side);
    CASSERT (sch_pList == sch_list);

    sch_best.m.fr = sch_list[sch_lastbest].m.fr;
    sch_best.m.to = sch_list[sch_lastbest].m.to;
    sch_analyShow (sdepth,-1,sch_best.eval);
    return TRUE;
}

/*---------------------------------------------------------------------------- 
  mv_ .. Game code
----------------------------------------------------------------------------*/

void mv_GameNew (short int clrGame)
{
    int xp,yp,cpc;
    int mx,my;
    MV_RULES nrules;

    io_memcpy (&nrules, &mgam.rules, sizeof (MV_RULES));
    io_memset (&mgam,0,sizeof (mgam));
    io_memcpy (&mgam.rules, &nrules, sizeof (MV_RULES));

    if (mgam.rules.brdx == 0) {
      mgam.rules.brdy = mgam.rules.brdx = MV_DEFSIZE;
    }
    mx = mgam.rules.brdx;
    my = mgam.rules.brdy;

	/* Fill unused sqrs */
    io_memset (mgam.cur.board, MV_UNUSED, sizeof (mgam.cur.board));
	/* Clear board */
    for (xp = 0; xp < mx; xp++) {
      for (yp = 0; yp < my; yp++) {
        MV_CBOARD(xp,yp) = MV_EMPTY;
      }
    }
    if (clrGame) return;

	/* Setup any size brd with std new chess pos layout */
    for (xp = 0; xp < mx; xp++) {
	/* Pawns on Rows 2,7.. */
      MV_CBOARD(xp,1)    = MV_BPAWN;
      MV_CBOARD(xp,my-2) = MV_WPAWN;
	/* Alternate Bishops/knights */
      if (xp < mx / 2) {
        cpc = MV_BISHOP;
	if (xp & 1) cpc = MV_KNIGHT;
        MV_CBOARD(xp,0)    = cpc | MV_BLACK;
        MV_CBOARD(xp,my-1) = cpc | MV_WHITE;
        MV_CBOARD(mx-1-xp,0)    = cpc | MV_BLACK;
        MV_CBOARD(mx-1-xp,my-1) = cpc | MV_WHITE;
      }
    }
	/* Rooks in corners */
    MV_CBOARD(0,   0)    = MV_BROOK;
    MV_CBOARD(mx-1,0)    = MV_BROOK;
    MV_CBOARD(0,   my-1) = MV_WROOK;
    MV_CBOARD(mx-1,my-1) = MV_WROOK;
	/* Q/K in center */
    MV_CBOARD(mx/2-1, 0)    = MV_BQUEEN;
    MV_CBOARD(mx/2,   0)    = MV_BKING;
    MV_CBOARD(mx/2-1, my-1) = MV_WQUEEN;
    MV_CBOARD(mx/2,   my-1) = MV_WKING;
    sch_Init ();
}

int mv_DoMove (MV_MOVE *pMov) 
{
    BYTE pc;
	/* Exec move without checking legality */
    pc = mgam.cur.board[pMov->fr];
    if (pc == 0) return FALSE;
    mgam.cur.board[pMov->fr] = 0;
    if (pc == MV_WPAWN && pMov->to < sch_whtPromote) {		/* Promote a pawn? */
      pc = MV_WQUEEN;
    }
    if (pc == MV_BPAWN && pMov->to > sch_blkPromote) {
      pc = MV_BQUEEN;
    }
    mgam.cur.board[pMov->to] = pc;
    mgam.cur.side = !mgam.cur.side;
    return TRUE;
}

/*---------------------------------------------------------------------------- 
  cmd_ .. Front end code
----------------------------------------------------------------------------*/

#if ENG_CODE == 0

char app_szTitle[]  = "NCHESS " PROG_VERSION ", A simple Chess Engine.\n\0VHDGGZOO";
char app_szAuthor[] = "(C) A.Millett 2008-2025.Freeware/GPL3\n";

char cmd_szIn [256];

void cmd_DrawBoard ()
{
    int xp,yp;
    BYTE cp;
    io_puts ("\n");
    for (yp = 0; yp < mgam.rules.brdy; yp ++) {
      for (xp = 0; xp < mgam.rules.brdx; xp ++) {
        cp = MV_CBOARD (xp,yp) & MV_MASK;
        io_putchar (' ');
        io_putchar (sch_szPieceAsc[cp]);
      }
      io_puts ("\n");
    }
    io_puts (mgam.cur.side ? "Black.\n" : "White.\n");
}

  /* Convert ascii to sqr pos. Ret pos, +256 if 3 byte string (ie E10) */

int cmd_Asc2Sqr (char *pStr)
{
    BYTE xp,yp;
    int cpos;
    char ch;
    ch = *pStr;
    if (io_isalpha(ch) == FALSE) return -1;
    xp = (ch & 31)-1;
    if (xp >= mgam.rules.brdx) return -1;
    ch = pStr[1];
    if (io_isdigit(ch) == FALSE) return -1;
    yp = ch & 15;
    ch = pStr[2];
    if (yp == 1 && io_isdigit(ch)) {
      yp = 10 + (ch & 15); 
    }
    if (yp > mgam.rules.brdy) return -1;
    cpos = MV_POS (xp,mgam.rules.brdy - yp);
    if (yp > 9) cpos += 256;
    return cpos;
}

    /* Convert sqr to asc (A1..H8..) ret len (2,3) or 0=err */
int cmd_AscFromSqr (char *pStr, BYTE sq)
{
    BYTE xp,yp;

    xp = MV_SQR2X (sq);
    yp = MV_SQR2Y (sq);
    if (xp >= mgam.rules.brdx) return 0;
    if (yp >= mgam.rules.brdy) return 0;
    pStr[0] = 'A'+ xp;
    yp = mgam.rules.brdy - yp;
    if (yp > 9) {
      pStr[1] = '1';
      pStr[2] = '0' + yp - 10;
      pStr[3] = 0;
      return 3;
    }
    pStr[1] = '0'+ yp;
    pStr[2] = 0;
    return 2;
}


  /* Convert ascii move to MV_MOVE, ret len (0=error) */

int cmd_Asc2Move (char *pStr, MV_MOVE *pMov)
{
    int cpos;
    int clen;
    cpos = cmd_Asc2Sqr (pStr);
    if (cpos == -1) return 0;
    pMov->fr = (BYTE) cpos;
    clen = 2;
    if (cpos & 256) clen ++;
    if (pStr[clen] == '-') clen ++;
    cpos = cmd_Asc2Sqr (pStr+clen);
    if (cpos == -1) return 0;
    pMov->to = (BYTE) cpos;
    if (cpos & 256) clen ++;
    return clen;
}

 /*  Convert move to simple ascii (ret len, 0=err) */
int cmd_AscFromMove (char *pStr, MV_MOVE *pMov)
{
    int clen;
    int cret;
    *pStr = 0;
    clen = cmd_AscFromSqr(pStr, pMov->fr);
    if (clen == 0) return 0;
    cret = cmd_AscFromSqr(pStr+clen, pMov->to);
    if (cret == 0) return 0;
    clen += cret;
    return clen;
}

#if ENG_EXTRAS

  /*  Convert ascii piece letter to piece type code (ret FALSE if none) */
BYTE mv_Asc2Piece (char casc)
{
    BYTE cpos;
    cpos = 0;
    do {
      if (casc == sch_szPieceAsc[cpos]) {
        if (cpos < MV_BLACK) return cpos + MV_WHITE;
        return cpos;
      }
      cpos ++;
    } while (sch_szPieceAsc[cpos]);
    return FALSE;
}

  /*  Decode a FEN string into a board position */
  /*  ret FALSE if err, or pos of end.. */
int mv_GameDecodeFEN (char *szFen)
{
    int xp,yp;
    int cstr;
    char cchr;
    int mx,my;
    BYTE cpiece;
    
    mv_GameNew (TRUE);
    mx = mgam.rules.brdx;
    my = mgam.rules.brdy;
    xp = 0; yp = 0;
    cstr = 0;
    while (1) {
      cchr = szFen [cstr];
      cstr ++;
      if (io_isdigit (cchr)) {
        xp += (cchr & 15);
        if (xp > mx) return FALSE;
	continue;
      }
      if (io_isalpha (cchr)) {
        cpiece = mv_Asc2Piece ((char) cchr);
	if (cpiece == FALSE) return FALSE;
        if (xp >= mx) return FALSE;
	mgam.cur.board[MV_POS(xp,yp)] = cpiece;
	xp ++;
	continue;
      }
      if (cchr == '/') {
        if (xp != mx) return FALSE;
        xp = 0; yp ++;
        if (yp >= my) return FALSE;
	continue;
      }
      if (cchr == 32) {    /*  Must end exactly on lastsqr+1 */
        if (yp != my-1) return FALSE;
        if (xp != mx)   return FALSE;
        break;	
      }
      return FALSE;	/*  Illegal char.. */
    }
    while (szFen[cstr] == ' ') cstr ++;
    if (szFen[cstr] == 'w') {
      mgam.cur.side = 0;
    } else if (szFen[cstr] == 'b') {
      mgam.cur.side = 1;
    } else {
      return FALSE;
    }
    return cstr;
}

#endif		/* ENG_EXTRAS */


#if ENG_DEBUG		/* Add Debug/Test code */

void cmd_dumppieces ()
{
    int cp;
    io_puts ("White piece list\n");
    for (cp = 0; cp < sch_nWht; cp ++) {
      io_putsi (" ",sch_wpiece[cp].type);
      io_putsi ("@",sch_wpiece[cp].pos);
    }
    io_puts ("\nBlack piece list\n");
    for (cp = 0; cp < sch_nBlk; cp ++) {
      io_putsi (" ",sch_bpiece[cp].type);
      io_putsi ("@",sch_bpiece[cp].pos);
    }
    io_puts ("\n");
}

void cmd_dumpattack (UINT32 *pAtt)
{
    int xp,yp;
    UINT32 att;
    for (yp = 0; yp < mgam.rules.brdy; yp ++) {
      for (xp = 0; xp < mgam.rules.brdx; xp ++) {
        att = pAtt[MV_POS(xp,yp)];
	io_putsi (" ",att);
      }
      io_puts ("\n");
    }
}

#if SCH_SEE

  /* Compute + print SEE for whole board */

void cmd_dump_see (int sside)
{
    int xp,yp;
    int ceval;
    for (yp = 0; yp < mgam.rules.brdy; yp ++) {
      for (xp = 0; xp < mgam.rules.brdx; xp ++) {
	ceval = see_eval (MV_POS(xp,yp), sside);
	io_putsi (" ",ceval);
      }
      io_puts ("\n");
    }
}
#endif

void cmd_dumpboard (BYTE *pBrd)
{
    int xp,yp;
    BYTE cp;
    for (yp = 0; yp < mgam.rules.brdy; yp ++) {
      for (xp = 0; xp < mgam.rules.brdx; xp ++) {
        cp = pBrd[MV_POS(xp,yp)];
	io_putsi(" ",cp);
      }
      io_puts ("\n");
    }
    io_puts ("\n");
}

void cmd_dumplist()
{
    int cmove;
    char szTxt [8];

    for (cmove = 0; cmove < sch_nmoves; cmove ++) {
      cmd_AscFromMove (szTxt, &sch_pList[cmove].m);
      io_puts (szTxt);
      io_putsi ("=",sch_pList[cmove].eval);
      io_puts (" ");
    }
    io_putsi ("\n # moves:",sch_nmoves);
    io_puts ("\n");
}

void cmd_dump()
{
    int ceval;
    sch_Init();
    gen_move_white();
    cmd_dumplist ();
    gen_move_black();
    cmd_dumplist ();
    ceval = sch_Evaluate ();
    io_putsi ("Eval:",ceval);
}

void cmd_test()
{
    sch_Init();
    cmd_dumpboard (mgam.cur.board);
    cmd_dumppieces ();
    #if SCH_ATTACK_TAB		/* Use Attack bitmaps */
     gen_attack_white();
     gen_attack_black();
     io_puts ("White attacks\n");
     cmd_dumpattack (att_wht);
     io_puts ("Black attacks\n");
     cmd_dumpattack (att_blk);
    #endif
}

void cmd_test_capt()
{
    sch_Init();
    cmd_dumppieces ();
    io_puts ("\nWeights\n");
    #if SCH_WEIGHT
     cmd_dumpboard (sch_weight);
    #endif
    #if SCH_ATTACK_TAB		/* Use Attack bitmaps */
     gen_attack_white();
     gen_attack_black();
    #endif
     gen_white_captures();
     io_puts ("White captures\n");
     cmd_dumplist ();
     gen_black_captures();
     io_puts ("Black captures\n");
     cmd_dumplist ();
}

#if SCH_SEE

void cmd_test_see()
{
     sch_Init();
     gen_attack_white();
     gen_attack_black();
     io_puts ("\nWhite SEE\n");
     cmd_dump_see (0);
     io_puts ("\nBlack SEE\n");
     cmd_dump_see (1);
}
#endif

#endif		/* ENG_DEBUG */


  /* Show engine thinking */
void sch_analyShow (int depth, int cmove, int eval)
{
    char szTxt [8];
    int best = sch_tree[1].bestmove;

    if (sch_lastbest == best && cmove >= 0 && (SSET_FLAGS & 8)==0) {
      /* cmd_AscFromMove (szTxt, &sch_pList[cmove].m); io_puts (szTxt); io_puts ("/"); */
      io_puts (".");
      return;
    }
    io_puts ("\n");
    cmd_AscFromMove (szTxt, &sch_pList[best].m);
    io_puts (szTxt);
    io_putsi ("=",eval);
    io_putsi (" ",sch_nodes);
    io_putsi ("n ",depth);
    io_puts ("p ");
    #if SCH_TIME
      io_putint (sch_time);
      io_puts ("s ");
    #endif
    sch_lastbest = best;
}

  /* Search for & do comp move */  
int cmd_CompMove ()
{
    int cret;
    cret = sch_Start ();
    if (cret == FALSE) return FALSE;
    cret = mv_DoMove (&sch_best.m);
    return cret;
}

int cmd_DoMoveAsc (char *pStr)
{
    MV_MOVE cmov;
    int cret;
    cret = cmd_Asc2Move (pStr, &cmov);
    if (cret == 0) return FALSE;
    cret = mv_DoMove (&cmov);
    return cret;
}

void cmd_Parms (char *szIn)
{
    int cflag;
    if (io_isalpha (szIn [1])) {
      cflag = szIn[1] & 31;
      sch_flags[cflag] = atoi (szIn + 2);
    }
    if (SSET_QUIET == 0) {	/*  Not in quiet mode.. */
      for (cflag = 1; cflag <= 26; cflag ++) {
        io_puts (" /");
        io_putchar ('A'+cflag-1);
	io_putsi ("=",sch_flags [cflag]);
      }
    }
    io_puts ("\n");
}


void cmd_main ()
{
    int cret,m;

    prg_Initialise ();
    mv_GameNew (FALSE);
    io_puts (app_szTitle);
    io_puts (app_szAuthor);
    io_puts ("\n\n");
    while (1) {
      io_puts ("\n");
      if (SSET_QUIET == 0) {
        cmd_DrawBoard ();
        io_puts ("\nCmd:");
      }
      io_gets (cmd_szIn);
      cret = cmd_DoMoveAsc (cmd_szIn);	/* Move? (ie. E2E4) */
      if (cret) {
        continue;
      }
      switch (cmd_szIn[0]) {
        case 'x':
	  return ;

	case 'n':		/* New game */
	  if (io_isdigit(cmd_szIn[1])) {	/*  n#,# for chess variant board size (x,y) */
	    int cp = 1;
	    int bx = 0;
	    int by = 0;
	    bx = atoi (cmd_szIn + cp);
	    while (io_isdigit(cmd_szIn[cp])) cp ++;
	    if (cmd_szIn[cp] == ',') {
	      by = atoi (cmd_szIn + cp + 1);
	    }
	    if (bx > 2 && by > 2 && bx <= MV_MAXX && by <= MV_MAXY) {
	      mgam.rules.brdx = bx;
	      mgam.rules.brdy = by;
	    }
	  }
          mv_GameNew (FALSE);
	  break;

	case 'g':		/* Make Comp go*/
	case 0:
	  cmd_CompMove ();
	  break;

	case 'a':			/* Auto play */
	  for (m=0; m<10; m++) {
	    cret = cmd_CompMove ();
	    if (cret == FALSE) break;
	    io_puts ("\n----  ");
	  }
	  break;

	case '/':
	  cmd_Parms (cmd_szIn);
	  break;

	case ';':
	  io_puts (cmd_szIn);
	  io_puts ("\n");
	  break;

      #if ENG_EXTRAS		/* Inc load/save code.. */

	case 's':
	  cret = io_FileSave (cmd_szIn+1, &mgam, sizeof (MV_GAME));
	  if (cret == FALSE) break;
  	  io_puts (cmd_szIn+1);
	  io_puts (" Saved.\n");
	  break;

	case 'l':
	  cret = io_FileLoad (cmd_szIn+1, &mgam, sizeof (MV_GAME));
	  if (cret == FALSE) break;
  	  io_puts (cmd_szIn+1);
	  io_puts (" Loaded.\n");
	  break;

	case '=':
	  cret = mv_GameDecodeFEN (cmd_szIn+1);
	  if (cret == FALSE) break;
	  io_puts (cmd_szIn);
	  io_puts ("\n");
	  break;

      #endif		/* ENG_SETUP */

      #if ENG_DEBUG		/* Add Debug code */

	case '$':
	  switch (cmd_szIn[1] & 15) {
	    case 0:  
	      cmd_test(); break;
	    case 1:
	      cmd_test_capt(); break;
	    case 2:
	      cmd_dump(); break;
	    #if SCH_SEE
	    case 3:
	      cmd_test_see(); break;
	    #endif
	  }
	  break;
	  
      #endif

      }
    }
}

int main ()
{
    cmd_main ();
}

#endif		/* ENG_CODE == 0 */


/*------------------------------------------------------------------------------------------- 
    eng_ .. Communicate with front end with eng_.. calls.. 
------------------------------------------------------------------------------------------- */

#if ENG_CODE

#include "tchess.h"

/* BYTE enc_pieces [] = {0,1,2,6,0,3,4,5,0,9,10,14,0,11,12,13}; */

/* BYTE decode_pieces [] = 
 {0, MV_WPAWN, MV_WKNIGHT, MV_WBISHOP, MV_WROOK, MV_WQUEEN, MV_WKING, 0, 
  0, MV_BPAWN, MV_BKNIGHT, MV_BBISHOP, MV_BROOK, MV_BQUEEN, MV_BKING, 0}; */

ENG_SEARCH eng_search;

  /* Convert from front-end to NCHESS pos */
BYTE enc_ConvPosFromFront (BYTE sq)
{
    BYTE xp,yp;
    yp = ENG_SQR2Y(sq);
    xp = ENG_SQR2X(sq);
    return MV_POS (xp, yp);
}

  /* Convert from NCHESS pos to front-end */
BYTE enc_ConvToFront (BYTE sq)
{
    BYTE xp,yp;
    xp =  MV_SQR2X (sq);
    yp =  MV_SQR2Y (sq);
    return (ENG_POS(xp, yp));
}



  /* Called by front end to start searches, etc.. */
int eng_call (int mode, ENG_GAME *pGame)
{
    int cret;
    int xp,yp;
    BYTE cp;
    MV_MOVE mov;
    int cmv;

    switch (mode) {

      case ENG_INIT:
        prg_Initialise ();
	sch_Init();
	return TRUE;

      case ENG_NEW:
        mgam.rules.brdx = pGame->rules.boardx;
        mgam.rules.brdy = pGame->rules.boardy;
        mv_GameNew (FALSE);
        return TRUE;

      case ENG_MAKEMOVE:
        mov.fr = enc_ConvPosFromFront (pGame->cmov.fr);
        mov.to = enc_ConvPosFromFront (pGame->cmov.to);
        cret = mv_DoMove (&mov);
        return cret;

      case ENG_READPOS:
        pGame->cur.side = mgam.cur.side;
        for (yp = 0; yp < mgam.rules.brdy; yp ++) {
          for (xp = 0; xp < mgam.rules.brdx; xp ++) {
	    cp = mgam.cur.board [MV_POS(xp,yp)] & 15;
	    pGame->cur.board [ENG_POS(xp,yp)] = cp; 
	  }
        }
        return TRUE;

      case ENG_SETPOS:
        mgam.cur.side = pGame->cur.side ;
        for (yp = 0; yp < mgam.rules.brdy; yp ++) {
          for (xp = 0; xp < mgam.rules.brdx; xp ++) {
	    cp = pGame->cur.board [ENG_POS(xp,yp)];
	    if (cp >= ENG_PAWN && cp <= ENG_KING) cp = cp | MV_WHITE;
	    mgam.cur.board [MV_POS(xp,yp)] = cp;
	  }
        }
	mgam.isSetup = TRUE;
        return TRUE;

		/* Search for best move, return (pGame->cmov)*/
      case ENG_COMPUTE:
        SSET_TIME = pGame->level;		/*  Set search time */
	if (pGame->level < 1) {
          SSET_TIME = 0;		
	  SSET_DEPTH = 1 - pGame->level;		/*  Set search depth */
	}
	pGame->cmov.fr = pGame->cmov.to = 0;
	SSET_RAND = pGame->rand;

	cret = sch_Start ();
	if (cret == FALSE) return FALSE;	/* No legal move, game over.. */
	pGame->cmov.fr = enc_ConvToFront (sch_best.m.fr);
	pGame->cmov.to = enc_ConvToFront (sch_best.m.to);
        return TRUE;

			/* See if move (pGame->cmov) is legal, ret TRUE/FALSE */
      case ENG_IS_LEGAL:
        mov.fr = enc_ConvPosFromFront (pGame->cmov.fr);
        mov.to = enc_ConvPosFromFront (pGame->cmov.to);
		/* Gen list for current pos */
	sch_Init ();
        gen_moves ();
	return (gen_isLegal(&mov) > 0);		/* Search list for move */

    }
    return FALSE;
}


  /* Post ENG_SEARCH data back to front end */

void sch_analyShow (int depth, int cmove, int eval)
{
    int bestm = sch_tree[1].bestmove;
    memset (&eng_search, 0, sizeof (ENG_SEARCH));
    eng_search.best[0].fr = sch_pList[bestm].m.fr;
    eng_search.best[0].to = sch_pList[bestm].m.to;
    eng_search.nbest = 1;
    eng_search.eval = eval;
    eng_search.nodes = sch_nodes;
    eng_search.depth = depth;
    #if SCH_TIME
      eng_search.stime = sch_time;
    #endif
    eng_callback (0, &eng_search);		/* Post search data to front end */
}

#endif  		/* ENG_CODE */


