/*   SDLTXT.C  - SDL bitmap font rendering lib, print text strings to sdl renderer.
  (C) A.Millett 2025, Released as free software under GNU GPL3 license.
  Provides a set of functions in form: SDLTXT_func (..) 
 ->
To build: ./sdlmak progname sdltxt.c -Os

->sdltxt103 12.2.2025
->sdltxt104 14.2.2025
 Add simple toolbar functions.
->sdlwio105 26.2.2025
*/

#include <SDL.h>
#include "sdlwio.h"	/* Header for font lib */

/*-------------------------------------------------------------------
   SDLTXT - SDL bitmap font rendering lib
---------------------------------------------------------------------*/

SDLTXT_FONT * pCFont = NULL;		/* Current font obj to use */

SDL_Renderer * pOutRenderer = NULL;	/* Current Output Renderer */

unsigned char pDefaultFont [] = {	/* Default 8x8 font, chr 32-127 */
 #include "sdlwio_font8x8.c"
0};

SDLTXT_FONT defaultFont = {0,pDefaultFont, 8,8,8,8,96,32,100,NULL};		/* Default font object to use */

/*   // SDLTXT_FONT is a structure with data for the bitmap font
typedef struct  {
  int is_user_font;	// Set to 1 for user font, otherwise default
  unsigned char *pFontData;	// Raw data for each char.
  int fontx,fonty;	// Size of source font 
  int outx,outy;	// Scaled output font size
  int nchar;		// No of chars in set 
  int startchar;	// Ascii start char in set 
  int scale;		// % Size to rescale when printing (100=default, same size as source)
  SDL_Texture  *fontTexture;	// Texture to hold bmp ready to render to screen 
} SDLTXT_FONT;
*/


int cursorx = 0;	/* Current print pos */
int cursory = 0;

  /* Initialise font, defined in (SDLTXT_FONT) */
int SDLTXT_CreateFont (SDL_Renderer * pRenderer, SDLTXT_FONT *pFont)
{
    SDL_Surface * pSurface = NULL;
    int sSize;
    int cpos,cx,cy;
    int cbyte, cbit;
    Uint32 fontcol [2];
    Uint32 *pPixels;

    if (pRenderer == NULL) return FALSE;
    if (pFont == NULL) return FALSE;
    if (pFont->is_user_font != TRUE || pFont->pFontData == NULL) {	/* Empty struct, alloc default font */
      memcpy (pFont, &defaultFont, sizeof (SDLTXT_FONT));
    }
    pCFont = pFont;		/* Set this as current font to use */
    pOutRenderer = pRenderer;	/* Save output renderer */
    #if SDL_BYTEORDER == SDL_BIG_ENDIAN
      pSurface = SDL_CreateRGBSurface (0, pCFont->fontx * pCFont->nchar, pCFont->fonty, 32, 0xff000000, 0x00ff0000, 0x0000ff00, 0x000000ff);
    #else
      pSurface = SDL_CreateRGBSurface (0, pCFont->fontx * pCFont->nchar, pCFont->fonty, 32, 0x000000ff, 0x0000ff00, 0x00ff0000, 0xff000000);
    #endif
    if (pSurface == NULL) return FALSE;

    pPixels = (Uint32 *) pSurface->pixels;
    sSize = (pSurface->h * pSurface->w) >> 3;
    if (sSize != pCFont->fonty * pCFont->nchar) return FALSE;
    // printf (" sSize:%d\n",sSize);
    fontcol [1] = SDL_MapRGBA (pSurface->format, 0xFF, 0xFF, 0xFF, 0xFF);
    fontcol [0] = SDL_MapRGBA (pSurface->format, 0x00, 0x00, 0x00, 0x00);

	/* Render font data to new surface */
    for (cy = 0; cy < pCFont->fonty; cy++) {    
      for (cx = 0; cx < pCFont->nchar; cx++) {    
        cbyte = pCFont->pFontData [cx*pCFont->fonty+cy];
	cpos = (cx + cy * pCFont->nchar) * pCFont->fontx + 7;
        for (cbit = 0; cbit < 8; cbit ++) {
          pPixels [cpos - cbit] = fontcol [cbyte & 1];
          cbyte = cbyte >> 1;
        }
      }
    }
	/* Create a texture with font image data */
    pCFont->fontTexture = SDL_CreateTextureFromSurface (pOutRenderer, pSurface);
    if (pCFont->fontTexture == NULL) { 
      return FALSE;
    }
    SDL_FreeSurface (pSurface);
    return TRUE;
}

	/* Release/free objects */
void SDLTXT_DestroyFont (SDLTXT_FONT *pFont) 
{ 
    SDL_DestroyTexture (pFont->fontTexture); 
    pFont->fontTexture = NULL; 
}

void SDLTXT_SetOutputRenderer (SDL_Renderer * pRenderer)
{
    pOutRenderer = pRenderer;
}

  /* Set printing color */
void SDLTXT_SetColor (Uint8 r, Uint8 g, Uint8 b)
{
	SDL_SetTextureColorMod (pCFont->fontTexture, r, g, b);
}

  /* Set printing scale %, 100=same as src */
void SDLTXT_SetScale (int scale)
{
    pCFont->scale = scale;
    pCFont->outx = (pCFont->fontx * pCFont->scale) / 100;
    pCFont->outy = (pCFont->fonty * pCFont->scale) / 100;
    
}

  /* Set printing pos +ve in pixels, -ve in chars, (-1,-1) = top left */
void SDLTXT_SetCursorPos (int xpos, int ypos)
{
    if (xpos < 0) xpos = -(xpos+1) * pCFont->outx;
    if (ypos < 0) ypos = -(ypos+1) * pCFont->outy;
    cursorx = xpos;
    cursory = ypos;
}

  /* Output a character */
int SDLTXT_PrintChar (unsigned char cchr)
{
    SDL_Rect src, dest;
    if (pCFont == NULL) return FALSE;
    if (pCFont->fontTexture == NULL) return FALSE;
    if (cchr == 10) {	/* '\n' new line */
      cursory += pCFont->outy;
      cursorx = 0;
    }
    cchr = cchr - pCFont->startchar;
    if (cchr >= pCFont->nchar) return TRUE;	/* Out of range for set */
    src.x = cchr * pCFont->fontx;
    src.y = 0;
    src.w = pCFont->fontx;
    src.h = pCFont->fonty;
    dest.x = cursorx;
    dest.y = cursory;
    dest.w = pCFont->outx;
    dest.h = pCFont->outy;
    SDL_RenderCopy (pOutRenderer, pCFont->fontTexture, &src, &dest);
    cursorx += pCFont->outx;
    return TRUE;
}

  /* Output a string */
int SDLTXT_PrintStr (char *pStr)
{
    int cret;
    while (*pStr) {
      cret = SDLTXT_PrintChar ((unsigned char) *pStr );
      if (cret == FALSE) return FALSE;
      pStr ++;
    }
    return TRUE;
}

  /* Output a signed int */
int SDLTXT_PrintInt (long xint)
{
    if (xint<0) {
     xint = -xint; SDLTXT_PrintChar ('-');
    }
    if (xint>9) {
      SDLTXT_PrintInt (xint/10);
    }
    SDLTXT_PrintChar ('0' + xint%10);
}

  /* Output a string and int */
int SDLTXT_PrintStrInt (char *pStr, long xint)
{
    SDLTXT_PrintStr (pStr);
    SDLTXT_PrintInt (xint);
}

  /* test routine, dumps chrset */
int SDLTXT_ShowSet ()
{
    SDL_Rect src;
    src.x = 0;
    src.y = 0;
    src.w = pCFont->nchar * pCFont->fontx;
    src.h = pCFont->fonty;
    if (SDL_RenderCopy (pOutRenderer, pCFont->fontTexture, &src, &src)) {
      return FALSE;
    }
    return TRUE;
}

/*-------------------------------------------------------------------
   SDLTOOL - Simple bmp toolbar..
---------------------------------------------------------------------*/

 /* Very simple toolbar mini API */
/*
typedef struct {
  int sizex,sizey;		// Size of buttons
  int nbuttons;			// no of buttons
  int topx,topy;		// pos to render them
  SDL_Texture  *pTTexture;	// Texture to hold bmp ready to render to screen 
} SDLTOOL_DATA;
*/

	/* Create a user toolbar, load bmp..  */
int SDLTOOL_Create (SDLTOOL_DATA *pTool, SDL_Renderer * pRender, char *pName)
{
    int cret;
    SDL_Surface * pSurfaceBmp = NULL;		/* bmps for pieces */

    if (pRender == NULL) return FALSE;

	/* Load toolbar bmps */
    pSurfaceBmp = SDL_LoadBMP (pName);
    if (pSurfaceBmp == NULL) {
      return FALSE;
    }
	/* Transfer bmp to texture for rendering.. */
    pTool->pTTexture = SDL_CreateTextureFromSurface (pRender, pSurfaceBmp);
    if (pTool->pTTexture == NULL) {
      return FALSE;
    }
    SDL_FreeSurface (pSurfaceBmp);
    return TRUE;
}

void SDLTOOL_Draw (SDLTOOL_DATA *pTool, SDL_Renderer * pRender)
{
    SDL_Rect src, dest;
    src.x = 0;
    src.y = 0;
    src.w = pTool->sizex * pTool->nbuttons;
    src.h = pTool->sizey;
    dest.x = pTool->topx;
    dest.y = pTool->topy;
    dest.w = src.w;
    dest.h = src.h;
    SDL_RenderCopy (pRender, pTool->pTTexture, &src, &dest);
}

	/* Process a button hit, return button# 1-N, or 0 if none */
int SDLTOOL_Service (SDLTOOL_DATA *pTool, int hitx, int hity)
{
    // printsi (" hit:",hitx); printsi (",",hity); printsi (" top:",pTool->topx); printsi (",",pTool->topy);
    hitx -= pTool->topx;
    hity -= pTool->topy;
    if (hity < 0 || hity > pTool->sizey) return 0;
    if (hitx < 0) return 0;
    hitx = hitx / pTool->sizex;
    if (hitx >= pTool->nbuttons) return 0;
    return hitx + 1;
}

void SDLTOOL_Destroy (SDLTOOL_DATA *pTool)
{
    SDL_DestroyTexture (pTool->pTTexture); 
    pTool->pTTexture = NULL; 
}


/*  	// This is a "Hello World" minimal example program:
// STESTMIN.C.  Simplest minimal program to demo SDLTXT bitmap font library. (C) A.Millett 2025. Released as free software under GPL3.
// To build: ./sdlmak stestmin sdltxt.c -Os
#include <SDL.h>
#include <stdio.h>
#include "sdltxt.h"	// Header for font lib 
SDL_Window *pWin ; SDL_Renderer *pRender; 
SDLTXT_FONT SDLTXT_font; int x;
void main ()  {
    SDL_Init (SDL_INIT_VIDEO); 
    SDL_CreateWindowAndRenderer (600, 400, SDL_WINDOW_SHOWN, &pWin, &pRender) ;
    SDLTXT_font.is_user_font = 0;	// Use default font 
    SDLTXT_CreateFont (pRender, &SDLTXT_font);	// Init font
    SDL_SetRenderDrawColor (pRender, 0, 32, 64, 255);	// Background color
    SDL_RenderClear (pRender); 		// Clear background
    SDLTXT_SetOutputRenderer (pRender);	
    SDLTXT_SetColor (255, 255, 128);  SDLTXT_SetCursorPos (0,10);  // Set text params
    for (x=32; x<128; x++) SDLTXT_PrintChar (x);	// Print chrset
    SDLTXT_SetScale (200); SDLTXT_PrintStr ("\n\n Hello World, using a bitmap font!\n");
    SDL_RenderPresent (pRender); SDL_Delay(4000);		// Show result
    SDLTXT_DestroyFont (&SDLTXT_font);  SDL_DestroyWindow (pWin); 
    SDL_Quit ();		// Clean up
}
*/

