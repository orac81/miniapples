# Convert files to upper case
util/toupper.elf ubl.bas ublup.bas
util/toupper.elf example/ugomoku10.bas qbasic/gomok10q.bas
