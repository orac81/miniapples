/*	TOUPPER.C - simple file i/o example. C99 ver. 
  (C) A.Millett, Freeware/GPL3.

Utility to convert files to upper/lower case.
Syntax: toupper source.txt dest.txt [U/L/S]

ie: toupper  file.txt dest.txt U      # Convert file.txt to upper case
ie: toupper  file.txt dest.txt L      # Convert file.txt to lower case
ie: toupper  file.txt dest.txt S      # Strip file of CR (asc 13)
Linux: ./toupper.elf  file.txt dest.txt U      # Convert file.txt to upper case (etc)

To build: cc -Os -o toupper.elf toupper.c

*/
 
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

char szBuffer[1030];

void main(int argc, char *argv[])
{
    FILE *hFile;
    FILE *hOut;
    char *pTxt;
    int mode = 0;
    
    if (argc < 2) {
      puts ("Syntax: TOUPPER FILE.TXT DEST.TXT [U][L][S]\n");
      return;
    }

    if (argv[3]) mode = toupper(*argv[3]);

    hFile = fopen(argv[1],"r");
    if (hFile == NULL) {
         fprintf(stderr,"Unable to open file.");
         exit(0);
    }
    hOut = fopen(argv[2],"wb");
    if (hOut == NULL) {
         fprintf(stderr,"Unable to open file.");
         exit(0);
    }
     
    do {
      pTxt = fgets (szBuffer, sizeof(szBuffer)-4, hFile);
      if (pTxt) {
        int slen,x;
	int ch;
	slen = strlen (pTxt);
	for (x=0; x<slen; x++) {
          ch = pTxt[x];
	  if (mode == 'L') {
            ch = tolower(ch);
	  } else if (mode == 'S') {	/* Strip CR */
	    if (ch == 13) continue;
	  } else {
            ch = toupper(ch);
	  }
	  fputc (ch, hOut);
	}
        /* puts(pTxt); */
      }
    } while(pTxt);
    fclose (hOut);
    fclose (hFile);
}
     
