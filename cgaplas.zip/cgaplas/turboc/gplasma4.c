/* 
  GPLASMAx.C   -  Plasma effects, using int maths. 
    A Freeware demo. (C) A.Millett 2014.

 Released as free/open software under the terms of the GNU GPL3 license.  
       See:  www.gnu.org/licenses/gpl-3.0.html 

  ->GPLASMA4.C  (31.10.2014)

*/

#define PALETTE_CHANGES 1	/* Palette rotates every few seconds */
#define FLYBACK_SYNC    0	/* Lock to hardware flyback */
#define ALT_SCANLINES   0	/* Alt scanlines per frame for faster rendering */

typedef unsigned char BYTE;  
typedef unsigned int WORD;
#define TRUE  1 
#define FALSE 0

	/* Macro wrappers for in-line asm routines */

#define IO_GETKEY(x) { _DL = 0xff; _AH = 6; asm int 21h; x = (char) _AX; };
#define IO_VIDEOMODE(x) { _AX = (x); asm int 10h;}
#define IO_TIMER ((int) *((int far *) 0x0000046c))
#define IO_TIMER_SECOND 18
/*#define IO_RAND  (io_rand = (io_rand * 14293) + 0x1113)			/* Cheap random func */
#define IO_RANDTIME  (io_rand = ((io_rand^IO_TIMER) * 24251) + 0x5173)		/* Cheap random func */
#define IO_RAND  (io_rand = (io_rand * 24251) + 0x5173)		/* Cheap random func */
#define IO_SRAND(s) {io_rand = s;}
#define IO_PUTS(str) { _DX = (int) (str); _AH = 9; asm int 21h; }
#define IO_WAITKEY(x) do { _DL = 0xff; _AH = 6; asm int 21h; x = (char) _AX; } while ((x)==0);
#define IO_OUTPORT(port,val) { _AL = val; _DX = port; asm out dx,al ; }
#define IO_INPORT(val,port) { _DX = port; asm in al,dx; val = _AL; }

#define VDUX 320	/* 320x200 in VGA mode 0x13 */
#define VDUY 200
#define VDUMAX (VDUX * VDUY)
#define VDUPOS(x,y) ((y)*VDUX+(x))

int io_rand=0;
BYTE far *pVdu;	

	/* Sine lookup table range -127..127.. */
BYTE sintab [64] = {
  128,131,134,137,140,143,146,149,152,155,159,162,165,168,171,173,
  176,179,182,185,188,190,193,196,198,201,204,206,209,211,213,216,
  218,220,222,224,226,228,230,232,234,235,237,239,240,242,243,244,
  245,247,248,249,250,251,251,252,253,253,254,254,255,255,255,255};


BYTE bufx[VDUX+4];
BYTE bufy[VDUY+4];

BYTE px1start=0;		/* Start index offset for sine tables */
BYTE px2start=0;
BYTE py1start=0;
BYTE py2start=0;

int qsine (int x)
{
    int r=sintab[x & 127];
    if (x & 64) {
      r = sintab[63-(x & 63)];
    }
    if (x & 128) {
      return (256-r);
    }
    return (r);
}

void main ()
{
    int x,y;
    int tim,ypre;
    int ch;
    BYTE px1,px2,py1,py2;	
    BYTE ti1;
    IO_VIDEOMODE (0x13);	/* Set VGA video mode 13h 320x200x256 */
    tim = 0;
    do {

     #if PALETTE_CHANGES
      if ((tim & 1023) == 0) {
        int d1,d2,d3;
	d1=(IO_RANDTIME & 7) + 1;
	d2=((io_rand/4) & 7) + 1;
	d3=((io_rand/16) & 7) + 1;
	/* Generate a simple 256 color palette  */
        IO_OUTPORT(0x3c8,0);
        for (x =0; x < 256; x ++) {
          IO_OUTPORT (0x3c9, x/d1);        
          IO_OUTPORT (0x3c9, x/d2);        
          IO_OUTPORT (0x3c9, x/d3);        
        }
      }
     #endif /* PALETTE_CHANGES */

     #if FLYBACK_SYNC
       do {
         IO_INPORT (x,0x3da);
       } while (x & 8);
       do {
         IO_INPORT (x,0x3da);
       } while ((x & 8) == 0);
     #endif

      ti1=qsine(tim)/64;
		/* Gen precalc X sin pattern table bufx[] */
      px1start += 2; px2start += ti1; 
      /* px1start += 2; px2start -= 3;  */
      px1 = px1start; px2 = px2start;
      for (x=0; x<VDUX; x++) {
        bufx[x] = qsine(px1) + qsine(px2);
	  px1+= 1; px2 += 2;
      }
		/* Gen precalc Y sin pattern table bufy[] */
      py1start ++; py2start -= 2;
      /* py1start ++; py2start -= 2; */
      py1 = py1start; py2 = py2start;
      for (y=0; y<VDUY; y++) {
        bufy[y] = qsine(py1) + qsine(py2);
	  py1+= 2; py2 -= 1;
      }
		/* Fill screen using precalc tables */
      pVdu = (BYTE far *) ((long) 0xa0000000);		/* Top of VDU */
      #if ALT_SCANLINES
        for (y=(tim & 1); y<VDUY; y += 2) {
	  pVdu = (BYTE far *) ((long) 0xa0000000) + y*VDUX;
      #else
        for (y=0; y<VDUY; y ++) {
      #endif
        ypre = bufy[y];
        for (x=0; x<VDUX; x++) {
          *pVdu = (ypre + bufx[x]);
	  pVdu ++; x++; 
	  *pVdu = (ypre + bufx[x]);
	  pVdu ++;
	}
      }
      tim++;
      IO_GETKEY(ch);
    } while (!ch);
}
