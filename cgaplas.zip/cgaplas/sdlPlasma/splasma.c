/* SPLASMA. Demo of SDL
   (C) A.Millett 2025. Released as free software under GPL3.
  Classic "Plasma" effect.
*/

char szProg [] = "SDL-PLASMA. (ESC to exit, SPC=size, D=speed)  (C) A.Millett 2025, Freeware/GPL3.";

#include <unistd.h>
#include <SDL.h>
#include <SDL_scancode.h>

#define NUM_CELLS 300

typedef unsigned char BYTE;

SDL_Window  * hWin = NULL;		/* Main program window */
SDL_Renderer * sRender = NULL;		/* Used for drawing comands */

SDL_DisplayMode dispMode;	/* Used to find screen size */
SDL_Event sEvent;		/* Used for event loop (kbd/mouse etc */
SDL_Rect rect;

#define MAXVDUX 1024	/* Abs max vdu size */
#define MAXVDUY 1024

int vdux = 0;
int vduy = 0;
int finished = 0;

  /* SDL function error, show msg, abort. */
void sdl_error (char *pMsg)
{ 
     printf ("%s error: %s\n", pMsg, SDL_GetError ());
     sleep (1);
     exit (1);
}

int px,py;	/* Pos of cells */
int lx,ly;	/* Size*/
int nx = NUM_CELLS;
int ny = NUM_CELLS;	/* no of cells */

	/* Sine lookup table range -127..127.. */
BYTE sintab [64] = {
  128,131,134,137,140,143,146,149,152,155,159,162,165,168,171,173,
  176,179,182,185,188,190,193,196,198,201,204,206,209,211,213,216,
  218,220,222,224,226,228,230,232,234,235,237,239,240,242,243,244,
  245,247,248,249,250,251,251,252,253,253,254,254,255,255,255,255};


BYTE bufx[MAXVDUX+4];
BYTE bufy[MAXVDUY+4];

BYTE px1start=0;		/* Start index offset for sine tables */
BYTE px2start=0;
BYTE py1start=0;
BYTE py2start=0;

SDL_Color tabColor [256];		/* Pixel color lookup table */

int delay = 2;
int tim = 0;

  /* Quick INT sine - input 0-255 (eq 0-360 deg) ret 0-255 (eq -1.0 to 1.0) */

int qsine (int x)
{
    int r=sintab[x & 127];
    if (x & 64) {
      r = sintab[63-(x & 63)];
    }
    if (x & 128) {
      return (256-r);
    }
    return (r);
}

  /* Create a new rnd color gradient table */
void app_NewColors ()
{
    int x;
    int r,g,b;
    r = rand () & 7;
    g = rand () & 7;
    b = rand () & 7;
    for (x = 0; x < 256; x++) {
      tabColor[x].r = (x * r / 2) & 255;
      tabColor[x].g = (x * g / 2) & 255;
      tabColor[x].b = (x * b / 2) & 255;
    }
}

  /* Render a frame to (sRender) */
void app_Draw ()
{
    int x,y;
    int ypre;
    int ch;
    BYTE px1,px2,py1,py2;	
    BYTE ti1;
    BYTE res;
    
    lx = 1 + (vdux / nx);
    ly = 1 + (vduy / ny);
    if ((tim & 0x1ff) == 0) {
      app_NewColors ();
    }
    ti1 = qsine(tim)/64;
		/* Gen precalc X sin pattern table bufx[] */
    px1start += 2; px2start += ti1; 
      /* px1start += 2; px2start -= 3;  */
    px1 = px1start; px2 = px2start;
    for (x=0; x<nx; x++) {
      bufx[x] = qsine(px1) + qsine(px2);
      px1+= 1; px2 += 2;
    }
		/* Gen precalc Y sin pattern table bufy[] */
    py1start ++; py2start -= 2;
      /* py1start ++; py2start -= 2; */
    py1 = py1start; py2 = py2start;
    for (y=0; y<ny; y++) {
      bufy[y] = qsine(py1) + qsine(py2);
      py1+= 2; py2 -= 1;
    }
		/* Fill screen using precalc tables */
    rect.y = 0;
    for (y=0; y<ny; y ++) {
      ypre = bufy[y];
      rect.x = 0;
      rect.w = lx; 
      rect.h = ly;
      for (x=0; x<nx; x++) {
	res = (ypre + bufx[x]) & 255;
        SDL_SetRenderDrawColor (sRender, tabColor[res].r, tabColor[res].g, tabColor[res].b, 255);
        SDL_RenderFillRect (sRender, &rect);      
	// SDL_RenderDrawPoint (sRender, x, y);
        rect.x += lx;
	if (rect.x > vdux) break;
      }
      rect.y += ly;
      if (rect.y > vduy) break;
    }
    tim++;
}

  /* Main program loop. */
void progloop ()
{
    tim = 0;
    app_NewColors ();
	/* Main program loop */
    do {
      SDL_SetRenderDrawColor (sRender, 0, 16, 32, 255);
      SDL_RenderClear (sRender); 

	/* Sys/Mouse/Keyboard event managment */
      while (SDL_PollEvent (&sEvent)) {
	switch (sEvent.type) {
	  case SDL_QUIT:
	    return ;

          case SDL_MOUSEBUTTONDOWN:
	    nx = NUM_CELLS + NUM_CELLS/2 - nx; ny = nx;
	    break;

	  case SDL_KEYDOWN:

	    switch (sEvent.key.keysym.scancode) {
	      case SDL_SCANCODE_ESCAPE:
		return;

	      case SDL_SCANCODE_SPACE:
	        nx = NUM_CELLS + NUM_CELLS/2 - nx; ny = nx;
                app_NewColors ();
		tim = 1;
		break;

	      case SDL_SCANCODE_D:	/* Change speed */
                delay = (delay-1)&3;
		break;

	    }
	}
      }
		/* Ok redraw and render screen */
      app_Draw ();
      if (delay) SDL_Delay (delay*8);		/* Delay X millisec */
      SDL_RenderPresent (sRender); 
		/* can be: while (GetCmd ()); */
    } while (1);	/* until key/mouse hit */
}


void proginit ()
{
    int cret;
    cret = SDL_Init (SDL_INIT_VIDEO);
    if (cret != 0) {
      sdl_error ("SDL_Init");
    }

	/* Get desktop size */
    cret = SDL_GetCurrentDisplayMode (0, &dispMode);    
    if (cret != 0) {
      sdl_error ("SDL_GetCurrentDisplayMode");
    }
    vdux = dispMode.w - 10;
    vduy = dispMode.h - 60; 
    
    if (SDL_CreateWindowAndRenderer (vdux, vduy, SDL_WINDOW_MAXIMIZED, &hWin, &sRender) < 0) {
      sdl_error ("SDL_CreateWindowAndRenderer");
    }
    if (sRender == NULL) {
      sdl_error ("sRender is NULL");
    }
    SDL_SetWindowTitle (hWin, szProg);
    SDL_GetWindowSize (hWin, &vdux, &vduy);
}


	/* Tidy up, quit. */
void progend ()
{
    SDL_DestroyWindow (hWin);
    SDL_Quit ();
}

	/* Main program */
void main ()
{
    proginit ();
    progloop ();
    progend ();
}

