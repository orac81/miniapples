rem zombie island (c) a.millett 1980-2012 
rem take orig "zombie ii" from "work-pet.d64" adapt to ascii..
rem ->zombie02.txt (28.10.12)
rem  start linking to UBL11.TXT, version that works on c64..
rem ->zombie03.txt (28.10.12)
rem  convert to use UBL libs
rem ->zombie04.txt (28.10.12)     (Use with UBL11L.TXT)
rem  cont convertion to use UBL libs
rem  can run in b/w on most systems.
rem ->zombie05.txt (28.10.12)     (Use with UBL12L.TXT)
rem  imp color calls
rem ->zombie06.txt (28.10.12)     (Use with UBL12L.TXT)
rem  imp freezer/bonuses ($) imp title screen.
rem ->zombie07.txt (28.10.12)     (Use with UBL12L.TXT)

rem -----1---------2---------3---------4---------5---------6---------7---------8

100 rem *    munchy island   *
110 rem * (c)a.millett may80 *
120 dim z(30):mz=30
125 sc=0:hi=0
130 gosub 9500
200 gosub 9000
220 gosub 9100
250 gosub 8000
300 gosub 7000
320 if e then 500
340 gosub 6000
350 if e=1 then 500
360 if g=0 then gosub 7950:goto 250
370 goto 300

500 rem game over
510 for x=1 to 2000:next
530 goto 200

6000 rem * zombie move *
6010 e=0:g=0
6020 if fz then fz=fz-1:g=1:return
6050 hx=hu-ux:hy=int(hx/ux)
6060 hx=hx-hy*ux
6100 for l=1 to nz
6120  i=z(l)-ux:if i<1 then 6230
6130  g=g+1:j=int(i/ux):i=i-j*ux
6140  ii=sgn(hx-i):jj=sgn(hy-j)
6150  u=z(l):u1=ks:gosub 4
6160  u=z(l)+ii+jj*ux:gosub 8
6170  if u1=ks then z(l)=u:u1=kz:u2=cz:gosub 3:goto 6230
6180  if u1=ky then e=1:f=u:gosub 7900:f2=kz:goto 6900
6190  if u1<>kh then jj=ii:gosub 9600:ii=int(u*3)-1:goto 6160
6200  g=g-1:sc=sc+sr:z(l)=0
6230 next
6240 gosub 7600
6290 return
     
6900 rem flash char at (f)
6905 nn=10
6909 u=f:gosub 8:f1=u1
6910 for x=1 to nn
6920  u=f:u1=kb:gosub 4:for y=1 to 10:next
6930  u=f:u1=f2:gosub 4:for y=1 to 10:next:next
6990 return

7000 rem human move
7020 e=0
7030 gosub 9570:if u>96 then u=u-32
7040 if u=75 then stop
7050 if u=84 then gosub 7800:goto 7030
7060 gosub 7500
7070 if d=2 then 7030
7100 u=hu:u1=ks:gosub 4
7110 hu=hu+d:u=hu:gosub 8
7120 if u1=kf then sc=sc+sr*5:fz=fz+3:gosub 7600:jm=jm+1:goto 7150
7140 if u1<>ks then 7200
7150 u=hu:u1=ky:u2=cy:gosub 3
7190 return
7200 rem game end
7210 e=1:u=hu:gosub 8
7220 if u1=kz then gosub 7900
7230 if u1<>kz then gosub 7910
7240 f2=ky:f=hu:gosub 6900
7290 return

7500 rem get dir (d) for u
7510 d=2
7520 if u=81 then d=-ux-1
7530 if u=87 then d=-ux
7540 if u=69 then d=-ux+1
7550 if u=65 then d=-1
7555 if u=83 then d=0
7560 if u=68 then d=1
7570 if u=90 then d=ux-1
7580 if u=88 then d=ux
7585 if u=67 then d=ux+1
7590 return

7600 rem status line
7610 u2=ch
7620 u$="":u$="score:"+str$(sc)+"  jumps:"+str$(jm)
7640 ui=0:uj=0:goto 9610

7800 if jm<=0 then 7850
7805 u=hu:u1=ks:gosub 4
7810 gosub 8900
7820 hu=u:u1=ky:u2=cy:gosub 3:jm=jm-1
7830 fz=1
7850 if jm<0 then jm=0
7852 gosub 7600
7860 return

7900 u$="munched!  ":ui=0:uj=0:goto 9610
7910 u$="splash!   ":ui=0:uj=0:goto 9610
7950 u$="you win! hit space. ":ui=0:uj=0:gosub 9610
7960 gosub 9570:if u=75 then stop
7970 if u<>32 then 7960
7990 return

8000 rem next screen
8010 u=0:gosub 9680:gosub 9670
8020 sr=sr+1:nz=nz+1:if nz>=mz then nz=mz-1
8025 nh=nh+1:fz=1
8030 u1=kb:u2=cb:vm=ux*(uy-2):w=ux-1
8050 for x=ux to ux+w
8060  u=x:gosub 3:u=x+vm:gosub 3
8070 next
8080 for x=ux to vm+ux step ux
8090  u=x:gosub 3:u=x+w:gosub 3
8100 next
      rem display rnd holes (#), RGBI color(3)
8110 u2=ch
8120 for x=1 to nh
8130  gosub 8900:u1=kh:gosub 3
8135  if x<4 then gosub 8900:u1=kb:gosub 3
8140 next
      rem display zombies
8200 u2=cz
8205 for x=1 to nz
8210  gosub 8900:u1=kz:gosub 3:z(x)=u
8240 next
      rem display freezers ($)
8250 u2=cf
8260 for x=1 to nf
8270  gosub 8900:u1=kf:gosub 3
8280 next
      rem display player, RGBI color(14)
8300 gosub 8900:hu=u:u1=ky:u2=cy:gosub 3
8320 u=14:gosub 9630:u2=u:u1=ks:for u=0 to ux-1:gosub 3:next
8330 gosub 7600
8490 return

8899 rem gen rnd pos
8900 gosub 9600:u=ux+int(u*vm):gosub 8
8910 if u1<>ks then 8900
8920 return

9000 rem init
9040 u=32:gosub 9590:ks=u
9050 kf=u+4:u=15:gosub 9630:cf=u
    rem convert poke codes, set colours (RGBI)
9055 u=4:gosub 9580:ky=u:u=15:gosub 9630:cy=u
9060 u=1:gosub 9580:kb=u:u=1:gosub 9630:cb=u
9065 u=2:gosub 9580:kz=u:u=5:gosub 9630:cz=u:
9070 u=3:gosub 9580:kh=u:u=6:gosub 9630:ch=u
9080 jm=3:nz=4:nh=6:nf=2:sr=1
9090 return

9100 rem title screen
9120 if sc>hi then hi=sc
9140 u=1:gosub 9680:u=15:gosub 9640:gosub 9670
9160 print"  zombie island":print" ---------------"
9180 u=10:gosub 9640
9200 print:print"a freeware game":print"(c) a.millett"
9220 u=14:gosub 9640
9240 print:print "lure the zombies"
9260 print"into holes."
9270 print"bonuses ($) freeze"
9275 print"them!"
9280 print"use keys about (s)"
9300 print"to move. t=teleport!"
9320 u=11:gosub 9640
9340 print:print "score:";sc;" hi:";hi
9360 print:print "hit space or k=exit";
9400 gosub 9570:if u=75 then end
9420 if u<>32 then 9400
9440 nm=4:sc=0
9490 return

rem -----1---------2---------3---------4---------5---------6---------7---------8

rem ASCII                  ref: !"#$%&'()*+,-./0123456789:;<=>?@abcdefghijklmno
