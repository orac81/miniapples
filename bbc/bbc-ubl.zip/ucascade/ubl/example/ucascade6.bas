 rem cascade - a simple game (C) a.millett 1980-2025. freeware/gpl3
 rem -> cascade-u1 (10.11.09)
 rem  further improvements
 rem -> cascade-u2 (11.11.09)
 rem  +4:add 62105 poke 65500,255   
 rem -> cascade-u2b (10.9.2024) (ver cascade2.zip ->github etc)
 rem  convert to UBL
 rem -> ucascade4 (10.12.2025)
 
 100 rem * cascade (c) a.millett 1980-2025. freeware/gpl3.
 120 dim bl(80),al(25),na(25)
 140 gosub 9500
 150 gosub 9000
 170 gosub 20000
 200 gosub 8000
 210 gosub 7000:if e then 170
 220 if nb<0 then 15000
 230 gosub 6000
 240 if nb<0 then 15000
 250 goto 210
 990 end

 6000 rem * comp.move
 6005 pl=1-pl
 6006 a$="hmm..":gosub 7700
 6010 for x=0 to 25:al(x)=0:next
 rem 6020 for cb=0 to nb:z=bl(cb):y=1.5+(peek(z+40)=bl)
 rem 6030 for d=39 to 41:a=peek(z+d)-1:if a<26 then al(a)=al(a)+y
 6020 for cb=0 to nb:z=bl(cb)+ux
 6030 for u=z-1 to z+1:gosub 8:a=u1-ka:if a>=0 and a<26 then al(a)=al(a)+1
 6040 next u:next cb
 6050 be=-1:bm=-1
 6060 for x=0 to 25
 6070 if al(x)>be then be=al(x):bm=x
 6080 next
 6090 if be<=0 then stop
 6100 a=bm+1
 6110 a$="i take "+chr$(a+64):gosub 7700
 6120 gosub 7900
 6130 gosub 6500
 6490 return

 6500 rem * drop balls down->pl(0/1)
 6530 for cb=0 to nb
 6550 z=bl(cb):if z<=0 then stop
 6560 d=ux:u=z+d:gosub 8:if u1=32 then 6610
 6570 d=ux+1-int(rnd(1)*2)*2
 6580 u=z+d:gosub 8:if u1=32 then 6610
 6590 d=ux+ux-d:u=z+d:gosub 8:if u1<>32 then 6690
 6610 u2=cw:u=z:u1=32:gosub 3:z=z+d:u=z:u1=kb:gosub 3:
 6620 u=z+ux:gosub 8:if u1<>ke then 6560:rem hit bottom?
 6630 u1=kb:u2=cw:d=pl*2-1:
 6635 for u=z to (uy-2)*ux+(ux-5)*pl step d
 6640  u1=kb:gosub 3:for x=1 to 5:next:u1=32:gosub 3
 6650 next
 6660 if pl then cs=cs+1:gosub 8400
 6670 if pl=0 then hs=hs+1:gosub 8400
 6680 z=0:rem nb=nb-1
 6690 bl(cb)=z
 6700 next cb
 6710 a$="ok..":gosub 7700:gosub 6900
 rem 6720 for nb=nb to 0 step-1:if bl(nb)=0 then next
 6790 return

 6900 rem bubble sort bl(0-nb)
 6910 for x=nb to 0 step-1:z=1
 6920  for y=0 to x-1
 6940   if bl(y)<bl(y+1)-5 then a=bl(y):bl(y)=bl(y+1):bl(y+1)=a:z=0
 6950  next y
 6960  if z then x=0
 6970 next x
 6980 if nb>=0 then if bl(nb)=0 then nb=nb-1:goto 6980
 6990 return

 rem 6900 rem quicksort bl(0..nb-1)
 rem 6905 if nb<2 then return
 rem 6910 sg%=nb/2
 rem 6920  x%=0
 rem 6930   sw%=0
 rem 6940   for y=x% to nb-sg%-1 step sg%
 rem 6950    if bl(y)<bl(y+sg%) then a=bl(y):bl(y)=bl(y+sg%):bl(y+sg%)=a:sw%=1
 rem 6960   next y
 rem 6970  if sw% then 6930
 rem 6980  x%=x%+1:if x%<sg% then 6930
 rem 6985 sg%=sg%/2:if sg% then 6920
 rem 6990 return

 7000 rem * human move
 7010 pl=1-pl
 7020 e=0:a$="move (a-z)? ":gosub 7700
 7030 gosub 9570:a=u-64:if u>96 then a=u-96
 7040 if u=33 then e=1:return
 7050 if a<1 or a>size then 7030
 7060 if na(a-1)=0 then print" used.":goto 7020
 7070 print u$;"..";:gosub 7900
 7080 gosub 6500
 7490 return
 
 7700 rem show text (a$) @top line
 7720 u1=32:u2=0:u3=0:u4=ux-1:u5=1:gosub 9690
 7740 u=6:gosub 9640:ui=1:uj=1:gosub 9650:print a$;
 7790 return
 
 7900 rem * remove letters=a
 7910 na(a-1)=0:a=a+ka-1
 7920 k=ux*3+ma:u2=cw
 7930 for z=k to ux*(uy-2) step ux
 7940  for u=z to z+ux-ma-ma-1:gosub 8:if u1=a then u1=32:gosub 4
 7960  next u
 7970 next z
 7990 return
 
 8000 rem new game
 8010 hs=0:cs=0:pl=1
 8020 gosub 8700
 8030 gosub 8500
 8040 gosub 8750
 8050 gosub 8400
 8060 gosub 8800
 8090 return

 8400 rem show scores
 8410 a=hs:x=0:gosub 8450
 8420 a=cs:x=ux-2
 8450 u2=cw:u=ux*(uy-2)+x:u1=int(a/10)+48:gosub 3
 8460 u=u+1:u1=a-int(a/10)*10+48:gosub 3
 8490 return

 8500 rem draw screen 
 8510 u=0:gosub 9680:u=2:gosub 9640:gosub 9670:u5=1
 8530 u1=ke:u2=c2:u3=ux+ma-1:u4=ux*(uy-3):u5=ux:gosub 9690:rem draw sides
 8550 u3=ux+ux-ma:gosub 9690
 8560 u3=ux*(uy-3):u4=u3+ux-1:u5=1:gosub 9690
 8570 u3=ux*(uy-1):u4=u3+ux-1:u5=1:gosub 9690
 8690 return

 8700 rem init ball array
 8710 nb=0
 8720 for x=ux*2+ma to ux*3-ma-1:bl(nb)=x:nb=nb+1:next
 8730 for x=ux+ma to ux*2-ma-1:bl(nb)=x:nb=nb+1:next:nb=nb-1
 8735 gosub 6900
 8740 return
 
 8750 rem draw balls
 8760 u2=cw
 8770 u1=kb
 8780 for x=0 to nb:u=bl(x):gosub 3:next
 8790 return
 
 8800 rem draw char maze
 8810 for x=0 to 25:na(x)=1:next
 8820 k=ux*3+ma:u2=c1
 8830 for z=k to ux*(uy-2) step ux
 8840  for u=z to z+ux-ma-ma-1:u1=int(rnd(1)*size)+ka:gosub 3:next u
 8850 next z
 8890 return

 9000 rem * init.
 9010 size=12
 9040 x=rnd(0):y=x:z=x:a=x:b=x
 9060 u=2:gosub 9580:kb=u:rem ball (81)
 9070 u=1:gosub 9580:ke=u:rem edge (102)
 9080 u=65:gosub 9590:ka=u
 9100 ma=int(ux/10):rem margin l/r
 9120 u=15:gosub 9630:cw=u:rem white
 9130 u=5:gosub 9630:c1=u
 9140 u=9:gosub 9630:c2=u
 9490 return

 15000 rem * new game
 15020 if cs>hs then a$="i win!"
 15030 if hs=cs then a$="drawn!"
 15040 if hs>cs then a$="you win!"
 15100 a$=a$+" again(y,n)?":gosub 7700
 15110 gosub 9570:if u=89 then 170
 15120 if u<>78 then 15110
 15130 end

 20000 rem instruct
 20010 u=0:gosub 9680:gosub 9670:u5=1
 20020 t=int((ux-22)/2):if t<1 then t=0
 20030 u1=ke:u2=c1
 20040 u3=ux*uy-ux:u4=u3+ux-1:u5=1:gosub 9690
 20050 u3=0:u4=ux-1:u5=1:gosub 9690
 20060 u=15:gosub 9640:ui=1:uj=3:gosub 9650:
 20065 print tab(t);"   + cascade +":print:u=9:gosub 9640
 20070 print tab(t);"(c)a.millett 1980-25"
 20080 print tab(t);"a freeware game.":print:u=10:gosub 9640
 20090 print tab(t);"remove letters and"
 20100 print tab(t);"the balls will fall"
 20105 print tab(t);"down the gaps into"
 20110 print tab(t);"your hopper."
 20120 print tab(t);"i will do the same!"
 20130 print tab(t);"when no balls left"
 20140 print tab(t);"high score wins.":print:u=9:gosub 9640
 20150 print tab(t);" # letters:";size;"(n) ":print:u=15:gosub 9640
 20190 print tab(t);"hit space (or n)"
 20200 gosub 9570:if u=88 then end
 20210 if u=78 then size=38-size:goto 20000
 20230 if u<>32 then 20200
 20490 return
 
 