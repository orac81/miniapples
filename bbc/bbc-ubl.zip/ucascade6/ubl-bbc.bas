
    rem bbc version using print.. (hires mode 5 20x28,4col(blk,Red,Yel,wht)
  2 dim u%(960):goto 100
    rem color(u)=u2:screen(u)=u1 (see:gcol 0,col)
  3 colour u2 and 3
    rem screenPoke(u,u1)
  4 u%(u)=u1:vdu 31,u mod ux,u div ux,u1:return
    rem screenDoke(u,u1,u2)
  6 u%(u)=u1:vdu 31,u mod ux,u div ux,u1,u2:return
    rem u1=screenPeek(u)
  8 u1=u%(u):return
    rem initialise library      
    rem 9500 mode 1:u=0:ux=40:uy=32 :rem 320x256,40x32ch,4col(Blk,R,Y,W), only 5K free!
    rem use mode 5, 160x256,20x32ch,4 colour (Blk,Red,Yel,Wht)
 9500 mode 5:u=0:ux=20:uy=28
 9510 vdu 23,1,0,0,0,0,0,0,0,0:vdu 19,1,4,0,0,0
    rem 8x8 udg for extended set 
 9520 vdu 23,128, 170,85,170,85,170,85,170,85
 9521 vdu 23,129, 0,60,126,126,126,126,60,0
 9522 vdu 23,130, 0,60,66,66,66,66,60,0
 9523 vdu 23,131, 54,127,127,127,62,28,8,0
 9524 vdu 23,132, 8,28,62,127,62,28,8,0
 9525 vdu 23,133, 8,28,62,127,127,28,62,0
 9526 vdu 23,134, 8,28,42,119,42,8,8,0
 9527 vdu 23,135, 255,255,255,255,255,255,255,255
 9528 vdu 23,136, 0,0,0,0,255,255,255,255
 9529 vdu 23,137, 255,255,255,255,0,0,0,0
 9530 vdu 23,138, 240,240,240,240,240,240,240,240
 9531 vdu 23,139, 15,15,15,15,15,15,15,15
 9532 vdu 23,140, 8,8,8,8,255,8,8,8
 9533 vdu 23,141, 0,0,0,0,255,0,0,0
 9534 vdu 23,142, 8,8,8,8,8,8,8,8
 9550 goto 9670
      rem u=getkey()  (ret if null)
 9560 u=asc(inkey$(0)+chr$(0)):return
      rem u=getkey()
 9570 u$=inkey$(0):if u$="" then 9570
 9572 u=asc(u$):return
      rem get "special" poke-char(u),printable(u1) (typical asc "%*OHDSC#_^)(+-!") 
      rem u=asc(mid$("%*OHDSC#_^)(+-!",u,1)):u1=u:return 
 9580 u=u+127:u1=u:return 
      rem asc to peek/poke code
 9590 return
       rem u=random()  0..1
 9600 u=rnd(1):return
      rem poke output (u$) at vdu(ui,uj) (top 0,0)
 9610 colour u2 and 3:print tab(ui,uj);u$;
      rem convert cga-type rgbi (0-15 bits:irgb) to local color poke val (u).
 9630 return
      rem set ink for print (u)
 9640 colour u and 3:return
      rem set print cursor pos(ui,uj) (1..n)
 9650 print tab(ui-1,uj-1);:return
      rem get print cursor pos(ui,uj)
 9660 ui=pos:uj=vpos:return
      rem cls
 9670 u9%=32:for u=0 to 959:u%(u)=u9%:next:cls:return
      rem set screen colour (u) (rem vdu 17,u)
 9680 return
      rem fast fill (u3..u4 step u5) with u1
 9690 colour u2 and 3:for u=u3 to u4 step u5:gosub 3:next:return
      rem u2=colorPeek(u)
 9700 return
      rem time in secs (uf=float var)
 9710 uf=time/100:return
rem -----1---------2---------3---------4---------5---------6---------7---------8
