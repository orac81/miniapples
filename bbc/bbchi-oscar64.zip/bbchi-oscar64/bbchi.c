/* Test Hires for OSCAR64 compiler for BBC code gen 

oscar64 -O2 -tm=vic20+16 bbchi.c -o=bbchi.prg
 (generates code at $1900. BBC start $1900 [PAGE])
To strip orginal start code:
 dd if=bbchi.prg of=bbchi.bin bs=1 skip=1793 

Use MAKIM.BAT  & MKIMG to create disk. Then run Emulator, attach disk:
 *LOAD "BBCHI" 1900
 MODE 5:CALL 6400

Set USE_PRINT for print version: 
    oscar64 -O2 -D USE_PRINT -tm=vic20+16 bbchi.c -o=bbchi.prg

(Linux test: cc -O2 -D IS_C99 -o bbcosc.elf bbcosc.c)

*/

#define FALSE 0
#define TRUE  1

typedef unsigned char BYTE;
typedef unsigned int UINT;	

#ifdef IS_C99		/* Use C compilers stdio */

#include <stdio.h>

#define io_flag_add_cr FALSE	/* Add CR to LF */

void io_printc (BYTE ch)
{
    putchar (ch);
}

#else
	/* BBC/OSCAR64 version, call OS direct */

#define io_flag_add_cr TRUE	/* Add CR to LF */

#include <c64/memmap.h>
#pragma region( main, 0x1900, 0x5800, , , {code, data, bss, heap, stack} )

void io_printc (BYTE ch)
{
      __asm {		
	lda ch
	jsr $ffe3
      }
}

#endif

	/* Print a null-term string */
void io_prints (const char *pStr)	
{
	char ch;
	while (ch = *pStr) {
	  if (ch == 10 && io_flag_add_cr) {
	    io_printc (13);
	  } else {
	    io_printc (ch);
          }
	  ++ pStr;
	}
}

char num[16];

  /* Print an int */
void io_printi (int x)		
{
    BYTE c,i;
    i=0;
    while (x) {
      c = x % 10; if (c>9) c=c+7;
      num[i] = 48+c;
      i ++;
      x= x/10;
    }
    while (i) {
      i--;
      io_printc (num[i]);
    }
}

	/* Composite short cut */
void io_printsi (char *istr, int iint)
{
	io_prints (istr);
	io_printi (iint);
}

#define io_isdigit(x) ((x)>='0' && (x)<='9')

  /* Simple 16 bit rnd gen */
unsigned short rndseed = 0;
unsigned short io_rand ()
{
    rndseed = (unsigned short) (4737 * rndseed) + 1231;
    return (rndseed >> 8) ^ rndseed;
}

/*-----------------------------------------------------------------------
   GFX Demo code - Output to MODE 5 gfx..
-------------------------------------------------------------------------*/

#define VDUX 20
#define VDUY 28

#ifdef USE_PRINT	/* Use OS print to set mode, UDG, etc */

BYTE game_setup[]={
 12, 22,5,  19,1,4,0,0,0,
 23,128,0x00,0x03,0x0f,0x1c,0x3b,0x37,0x6e,0x6d,
 23,129,0x6d,0x6e,0x37,0x3b,0x1c,0x0f,0x03,0x00,
 23,130,0x00,0xc0,0xf0,0x38,0xdc,0xec,0x76,0xb6,
 23,131,0xb6,0x76,0xec,0xdc,0x38,0xf0,0xc0,0x00,
0};

  /* Use OS print char to setup gfx */
void gfx_init () 
{
    BYTE x;
    for (x=0; x<sizeof (game_setup); x++) {
      io_printc (game_setup[x]);
    }
}

  /* Draw (2x2) piece (col) at (xpos,ypos)  */
void gfx_draw_piece (int x, int y, BYTE c)
{
    io_printc(17); io_printc(c); 
    io_printc(31); io_printc(x+x); io_printc(y+y);   io_printc(128); io_printc(130); 
    io_printc(31); io_printc(x+x); io_printc(y+y+1); io_printc(129); io_printc(131);
}

#else	
	/* Use direct access to hires screen */


BYTE game_hires[]= {
	// White piece 
  0x00,0x03,0x0f,0x1c,0x3b,0x37,0x6e,0x6d,
  0x6d,0x6e,0x37,0x3b,0x1c,0x0f,0x03,0x00,
  0x00,0xc0,0xf0,0x38,0xdc,0xec,0x76,0xb6,
  0xb6,0x76,0xec,0xdc,0x38,0xf0,0xc0,0x00,
0};

  /* Colour mask lookup */
BYTE tcol[] = {0,0x0f, 0xf0, 0xff};

BYTE *pVdu = (BYTE *) 0x5800;	/* Mode 5 gfx starts $5800 */

void gfx_init () 
{
    io_printc (12);
}

  /* Draw a char.. (colmask = 0xf0, 15, 255) */
void gfx_draw_char (int xpos, int ypos, BYTE *pChr, BYTE colmask)
{
    BYTE x;
    BYTE c;
    BYTE *pOut = pVdu + (xpos * 16 + ypos * VDUX * 16);
    for (x=0; x <8; x++) {
      c = *pChr;
      pOut[8] = ((c & 0x0f) | (c<<4)) & colmask;	// Draw left 4 dots 
      pOut[0] = ((c & 0xf0) | (c>>4)) & colmask;	// Draw right 4 dots
      pChr ++; pOut ++;
    }
}


  /* Draw a piece.. */
void gfx_draw_piece (int x, int y, BYTE c)
{
    x += x; y += y;
    c = tcol [c & 3];
    gfx_draw_char (x,  y,  game_hires,   c);
    gfx_draw_char (x+1,y,  game_hires+16,c);
    gfx_draw_char (x,  y+1,game_hires+8, c);
    gfx_draw_char (x+1,y+1,game_hires+24,c);
}

#endif		/* USE_PRINT */


void gfx_draw_screen ()
{
    int x,y;
    for (y=0; y<12; y++) {
     for (x=0; x<10; x++) {
       gfx_draw_piece (x,y,io_rand ());
     }
    }
}


int main ()
{
    int x,y;
    BYTE c;
    gfx_init ();
    while (1) {
      x = io_rand () % 10;
      y = io_rand () % 14;
      c = io_rand () % 3;
      gfx_draw_piece (x,y,c+1);
    }
    return 0;
}
