/* VICTEST.C - Test vic20 hires 
  Build: vc +vic20x  vicfill.asm victest.c -o victest.prg 
 */

#include <stdio.h>

typedef unsigned char BYTE;
typedef unsigned int UINT;

	// VIC regs
#define V20_HPOS    0x9000		// bits 0-6 horizontal pos/centering, bit 7 sets interlace scan (36864) [PAL:12,NTSC:5]
#define V20_VPOS    0x9001		// vert position [PAL:38,NTSC:25]
#define V20_HSIZE   0x9002		// bits 0-6 set # of columns, bit 7 part video matrix address
#define V20_VSIZE   0x9003		// bits 1-6 set # of rows, bit 0 for 8x8 or 8x16 chars
#define V20_RASTER  0x9004		// current video raster line
#define V20_VIDADD  0x9005		// Vid/chrset address: bits 0-3 charset address, bits 4-7 screen address.  (36869)
#define V20_PENH    0x9006		// Light pen horiz
#define V20_PENV    0x9007		// Light pen vert
#define V20_PADX    0x9008		// Paddle X
#define V20_PADY    0x9009		// Paddle Y
#define V20_VOICE1  0x900a		// Voice osc 1 (128-255) bit 7 on/off (36874)
#define V20_VOICE2  0x900b		// Voice osc 2 (128-255) bit 7 on/off
#define V20_VOICE3  0x900c		// Voice osc 3 (128-255) bit 7 on/off
#define V20_NOISE   0x900d		// Voice noise (128-255) bit 7 on/off
#define V20_VOL     0x900e		// bit 0-3 overall volume, bits 4-7 aux color in multicolor mode.
#define V20_BACKCOL 0x900f		// Screen/border color, bits 4-7 screen background, bits 0-2 border, bit 3 for inverted/normal mode (36879)
	// Other regs
#define V20_VIA1    0x9110		// VIC20 6522 VIA1
#define V20_VIA2    0x9120		// VIC20 6522 VIA2
#define V20_COLRAM  0x9400		// VIC20 colour ram if vdu $1000 (9600 for vdu $1e00)  
#define V20_CHARROM 0x8000		// VIC20 ROM char set.

#define V20_VDULOC  0x1000
#define V20_CHARRAM 0x1400

#define CUSTOM_CHR 0xc0			// Offset for first custom char in chrset..
#define CUSTOM_NO 4			// # Custom chrs 

#define VDUX 22
#define VDUY 23
#define VDUPOS(X,Y) ((X)+((Y)*VDUX))

BYTE *pVdu = (BYTE *) ((UINT) V20_VDULOC);	/* Ptr to screen */
BYTE *pCol = (BYTE *) ((UINT) V20_COLRAM);	/* Ptr to colour ram */

extern char io_hires_mem[];		// Static ptr to hires/charset mem.

void io_fill_out_low_mem ();

/*------------------------------------------------------------------------------------
   io_..  Minimal C I/O lib
--------------------------------------------------------------------------------------*/

#define io_printc putchar
//void io_printc (char c) ;		// Fwd declare

	/* Print a null-term string */
void io_prints (char *istr)	
{
	int cchr;
        for (cchr = 0; istr [cchr]; cchr ++) {
	  io_printc ( istr [cchr]);
	  if (istr [cchr] == 10) io_printc (13);
	}
}

  /* Print a signed int */
void io_printi (int x)		
{
	if (x<0) {
	 x = -x; io_printc ('-');
	}
        if (x>9) {
	  io_printi (x/10);
	}
        io_printc ('0' + x%10);
}

		/* Composite short cut */
void io_printsi (char *istr, int iint)
{
	io_prints (istr);
	io_printi (iint);
}

  // Very simple (not very) random num gen.
int io_randseed = 1;
int io_rand ()
{
    io_randseed = (io_randseed * 37) + 1;
    return ((io_randseed>>8)+(io_randseed<<8)) & 0x7fff;
}

  // Simple peek/poke macros
#define IO_POKE(AD,BY) *((BYTE *) ((UINT) AD))=(BY);
#define IO_PEEK(AD) ((BYTE) *((BYTE *) ((UINT) AD)))

/*------------------------------------------------------------------------------------
   Main program
--------------------------------------------------------------------------------------*/

BYTE game_hires[]= {
	// White piece
  0x00,0x03,0x0f,0x1c,0x3b,0x37,0x6e,0x6d,
  0x6d,0x6e,0x37,0x3b,0x1c,0x0f,0x03,0x00,
  0x00,0xc0,0xf0,0x38,0xdc,0xec,0x76,0xb6,
  0xb6,0x76,0xec,0xdc,0x38,0xf0,0xc0,0x00,
0};

void init_vic_hires()
{
    BYTE *pSrc  = (BYTE *) V20_CHARROM ;
    BYTE *pDest = (BYTE *) V20_CHARRAM;
    UINT p;
    //io_printc (5); io_printc (147);	// Clr vdu
    IO_POKE (V20_BACKCOL, 8);
    IO_POKE (V20_VIDADD,0xcd);		// Set VDU=$1000,CHRSET=$1200 (Normally $c0 (v20+8k) for Default VDU=$1200,CHRSET=$8000)
    for (p=0; p<2048; p++) {		// Copy orig ROM set to RAM
      pDest [p] = pSrc [p];
    }
    for (p = 0; p < CUSTOM_NO*8; p++) {	// Add custom chars
      pDest [CUSTOM_CHR*8 + p] = game_hires [p];
    }
}

char szTxt[] = 	"  this is just a simple gfx demo, using hires gfx on a vic within c."
		" lets wrap, wrap, wrap, wrap.......                                 ";

int main ()
{
    int x,y,c,t,n;
    BYTE *pDest;
    init_vic_hires ();
    //io_fill_out_low_mem ();
    // x = (int) io_hires_mem; io_printsi ("char mem is at:",chrmem);  // Should be st 4843/$12eb
    //io_printc (5); io_printc (147);	// Clr vdu
    for (x=0; x<512; x++) {
      pVdu[x] = 32; pCol[x] = 1;
    }
    for (y=0; y<VDUY-1; y+= 2) {
      for (x=0; x<VDUX; x+= 2) {
        pDest = pVdu + VDUPOS(x,y);
	pDest [0] = CUSTOM_CHR;
	pDest [1] = CUSTOM_CHR+2;
	pDest [VDUX] = CUSTOM_CHR+1 ;
	pDest [VDUX+1] = CUSTOM_CHR+3;
      }
    }
    //for (x=0; x<256; x++) {  pVdu[x+256] = x; }    
    t=0;
    while (1) {
      t++;
      // for (x=0; x<256; x++) { pVdu [io_rand() & 511] = x; }
      c = ((t>>((t>>7)&3)) % 7)+1;
      for (n=0; n<32; n++) {
        x = (io_rand () % VDUX) & 0xfe;
        y = (io_rand () % (VDUY-1)) & 0xfe;
        pDest = pCol + VDUPOS(x,y);
	pDest [0] = c;
	pDest [1] = c;
	pDest [VDUX] = c ;
	pDest [VDUX+1] = c;
      }
      for (x=0; x<VDUX; x++) {
        pVdu [VDUPOS(x,VDUY-1)] = szTxt[(x + t) & 127] & 63;
      }
    }
}
