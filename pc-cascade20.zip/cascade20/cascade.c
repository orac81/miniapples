  /*  CASCADE.C, Stategy game for MSDOS.
    Copyright A.Millett,  1981-2024.
  Released as free software under GNU GPL3 license, see GNU website:    www.gnu.org/licenses/gpl-3.0.html 
    
  Design basic CASC.EGA. Take CONTAX22.C, Convert to new structure.
  Imp screen layout, simple drawboard.
  -> CASC10.C, 30.3.93
  Imp MAKELIST,DROPBALLS,EXECCOMP & others. Simple playable version.
  -> CASC11.C, 31.3.93
  Imp NEGATORS/DOUBLERS/BONUSES. Imp GAMEOVER detect. Imp EDITMODE.
  -> CASC12.C, 3.4.93
  Imp LOAD/SAVE board prompts. Imp Gelegnite & Regenerators.
  -> CASC14.C, 4.4.93
  Imp Title/Helpscreens.
  -> CASC15.C, 5.4.93
  Imp BLOWUP for gelignite. Smooth-drop balls.
  -> CASC16.C, 15.4.93
  Imp HARDSCROLL, and Hidescreen/Showscreen macros to use.
  Imp Big-set (CBIG.EGA,CASCDA2.C).
  -> CASC17.C, 20-21.4.93
  Redesign CBIG - use new SAF editor (SAF22)
  Imp CALCWGT.
  -> CASC18.C, 22-23.4.93
  Imp SHOWFLAG for true comp search. Imp IQ. Debug CGA.
  -> CASC19.C, 29.4.93
  Remove Adverts/shareware texts. Update texts, add GPL texts.
  -> cascade20.c, 15.9.2024
  */

#define PROG_VER "2.0"

#include <stdio.h>
#include <dos.h>	/* Defines union REGS, INT86,  */

#define Advert 0
#define Shareware 0
#define Noload 1
#define Debug 0

void frontscreen (int mode);
void adscreen (int mode);
void adscreen2 (int mode);
int regscreen ();
void helpscreen ();
void showscores ();
void initsprites (int cset);

int Maxx = 40;
int Maxy = 25;

int begx = 5, begy = 1;
int endx = 36, endy = 24;
int endbrd,begbrd;
int rtmp;
int charx = 2;
int chary = 14;
int chrsize;
int topy = 0;		/* Top of board */
int topx = 0;
int bmult = 40;		/* Multiplier */
int diskerror = 0;
int iqcutoff = 2;
int kcmd;		/* Command key hit */
int inkey,cmdkey;
int pxpos,pypos; 	/* Player posn */
int cxpos,cypos;	/* Computer posn */
int rxpos,rypos;
int txpos,typos;
int xpos,ypos;		/* General pos */
int xdir,ydir;
int yoff;
int ccolor;		/* Left = 1, Right = 2 */
int cpiece;
int temp;
int vert;
unsigned int cptr;
int bigflag = 1;
int showflag = 1;
int debugflag = 0;

int mouseflag = 1;
int mousex,mousey,mbutton;

int cursorflag = 1;
int bxpos,bypos;	/* Best xy pos */
int beval;		/* Best score */
int xeval;		/* Comp term eval score */
int ceval;		/* Temp eval score */
int automode = 0;
int twoplaymode = 0;

long tloc;		/* Temp used in time access */
long xtime;

int cball,nballs;
int scoreleft,scoreright;
int layout = 15;
int doubler = 0;
int negate = 0;
int tneg,tdoub,tleft,tright;
int editmode = 0;
int alphasize = 26;
int usefeatures = 1;
int fastmode = 0;

#define Mball 300
char far *Vdu;		/* Pointer to CGA screen */
int far *Vdui;

int board [2010];	/* Playing area */
int bstack [6000];
int bwgt [2010];	/* Weight on balls */
int ballx [Mball+4],bally [Mball+4];	/* X/Y pos of balls. */

char *sprites ;	/* Sprites in use */
char gin [100];
#define Left 1
#define Right 2

#define Empty 0
#define Letters 1
#define Blank 27
#define Ball 29
#define Neg 30
#define Bonus 31
#define Doubler 32
#define Slope 33
#define Edge 38
#define Gcur 39
#define Regen 40
#define Xchar 41
#define Gel 43


unsigned char disksprites [] =
#include "cascdat.c"

unsigned char bigsprites [] =
#include "cascda2.c"

unsigned char minisprites [] =	/* 3x10x4 (CGA) 3x18x4 (EGA:X,Y,#) */
#include "pipedat.c"

int hxdir [20] =
	{ -1, 0, 1, -1, 1, -1, 0, 1};
int hydir [20] =
	{ 1, 1, 1, 0, 0, -1, -1, -1};

#define Msprite 4900
int Ssize = 912;	/* Sprite size */

#define Setboard(Xpos,Ypos,Cpiece) \
	board [Xpos + (Ypos) * bmult] = Cpiece;

#define Getboard(Xpos,Ypos) \
	board [Xpos + (Ypos) * bmult]

#define Beep click();

#define Setink(Cink) getpal (Cink)

  /* GRAPHxx.C Graphics function module for PC's */

#define Wht 0
#define Yel 1
#define Pur 10
union REGS inr,outr;	/* Define register access */
char prbuffer [10];	/* Buffer for int-print */
long far *timeptr;

typedef unsigned char BYTE;     /* A convenient new data type */
	/* Color usage is complex - lo = planes to effect, hi= SET/RESET pattern */
	/* for col on black use lo = not (ink), hi = 0 */

int xgamode = 0;	/* Graphic adapter 0 = CGA, 1 = EGA, 2 = VGA.. */

long readtime ()		/* Read 32 bit system clock in 1/18 secs */
{
	timeptr = (long far *) 0x0000046c;
	return ( *timeptr);
}

void pause (int ticks)
{
	long temp = readtime () + ticks;
	while ( readtime () < temp);
}

void graphmode(int mode)	/* Set Screen Graphics mode */
{
	inr.x.ax = mode;
	int86 (0x10,&inr,&outr);	/* INT 10, function 0 */
}

#define Setmode(Cmode) outport (0x03ce,Cmode);

void setmode (int cmode)	/* lo = register, hi = data */
{
	Setmode (cmode)
}

#define Setplanes(Cplane) 	/* Specify write planes */\
	outport (0x03c4,Cplane);

	/* Setplanes (0x0302);  Set reg 2 = 3 */

int getpal (int pal)
{
	if (xgamode == 0) return (1);	/* CGA.. */
	inr.h.ah = 16;
	inr.h.al = 7;
	inr.h.bl = pal;
	int86 (0x10,&inr,&outr);	/* INT 10, function 16 */
	return (outr.h.bh);
}

void writestart (int startaddr)
{
	outport (0x03d4,12 + (startaddr & 0xff00)); /* Reg 12=hi */
	outport (0x03d4,13 + (startaddr << 8));	    /* Reg 13=lo */
}

void writevert (int vert)
{
	int tmp;
	outport (0x03d4,18 + (vert << 8));	    /* Reg 18=vert(lo) */
	outportb (0x03d4,7);	/* Sel reg 7 - overflow reg hi bits */
	tmp = inportb (0x03d5) & 0xdd;	/* bit 9 is bit 1, bit 10 is bit 5 */
	/* gotoxy (10,1); printi (tmp); prints ("  "); */
	if (vert & 256) tmp = tmp | 2;
	if (vert & 512) tmp = tmp | 32;
	outport (0x03d4,7 + (tmp << 8));	    /* Reg 7=vert(hi) */
}

int readvert ()
{
	int tmp,hi;
	outportb (0x03d4,7);	/* Sel reg 7 - overflow reg */
	tmp = inportb (0x03d5);	/* bit 9 from bit 1, bit 10 from bit 5 */
	hi = 0; if (tmp & 2) hi = 256;
	if (tmp & 32) hi += 512;
	outportb (0x03d4,18);	/* Sel reg 18 */
	return (hi + inportb (0x03d5));
}


void object (int xtop, int ytop, int xlen, int ylen, char *objarray)
{
	int xpos,ypos;
	int cobj = 0;
	int yoff;
	int ploff,cplane,xpl;
	if (xgamode) {		/* EGA/VGA... */
	  ploff = 0; xpl = 256;
	  for (cplane = 0; cplane < 4; cplane ++) {
	    Setplanes (xpl + 2)	/* Reg 2 = plane */
	    xpl = (xpl << 1);
	    for (ypos = ytop; ypos < ytop + ylen; ypos ++) {
	      yoff = ypos * 80;
	      for (xpos = xtop; xpos < xtop + xlen; xpos ++) {
	        Vdu [yoff + xpos] = objarray [cobj];
	        cobj ++;
	      }
	    }
	    ploff += (Ssize >> 2);
	  }
	  return ;
	}
	for (ypos = ytop; ypos < ytop + ylen; ypos ++) {
	  yoff = (ypos >> 1) * 80 + ((ypos & 1) << 13);
	  for (xpos = xtop; xpos < xtop + xlen; xpos ++) {
	    Vdu [yoff + xpos] = objarray [cobj];
	    cobj ++;
	  }
	}
}

void fillobject (int xtop, int ytop, int xlen, int ylen, int pattern, int color)
		/* Fill an object on screen with char pattern */
{
	int xpos,ypos;
	int yoff;
	if (xgamode) {		/* EGA/VGA... */
	  Setplanes (0x0f02)	/* Enable ALL planes - Reg 2 = 15 */
	  Setmode (color & 0xff00)	/* RESET/SET fix pattern - reg 0 */
	  Setmode ((color << 8) | 1)	/* Bit planes to effect - reg 1 */
	  for (ypos = ytop; ypos < ytop + ylen; ypos ++) {
	    yoff = ypos * 80;
	    for (xpos = xtop; xpos < xtop + xlen; xpos ++) {
	      Vdu [yoff + xpos] = pattern;
	    }
	  }
	  Setmode (0)		/* RESET/SET fix pattern - WHT (ALL) */
	  Setmode (1)		/* Bit planes to effect - reg 1 */
	  return ;
	}
	for (ypos = ytop; ypos < ytop + ylen; ypos ++) {
	  yoff = (ypos >> 1) * 80 + ((ypos & 1) << 13);
	  for (xpos = xtop; xpos < xtop + xlen; xpos ++) {
	    Vdu [yoff + xpos] = pattern;
	  }
	}
}

int anyfly = 1;
void testfly ()		/* Test for hardware flyback */
{
	long temp = readtime () + 3;
	int test = inport (0x3da) & 8;
	while ( readtime () < temp) {
	  if (test != ( inport (0x3da) & 8)) return;
	}
	anyfly = 0;
}

void syncfly ()		/* 03da bit 3 set during flyback - bot to top bdr */
{
	if (anyfly) {
	  while (inport (0x3da) & 8);
	  while ((inport (0x3da) & 8) == 0);
	}
}

int savesound;
void soundon ()
{
	savesound = inportb (0x61);		/* Keep setting */
	outportb (0x61, savesound | 3);		/* Speaker on */
}

void setfreq (int hertz)
{
	int outfreq = 1331000/hertz;	/* Calc port val */
        outportb (0x43, 0xb6);		/* Set mode */
	outportb (0x42, outfreq & 0xff);	/* Write lo */
	outportb (0x42, outfreq >> 8);		/* Write hi */
}

void soundoff ()
{
	outportb (0x61,savesound);	/* restore setting */
}

void soundit (int hertz, int ticks)
{
	setfreq (hertz);
	soundon ();
	while (ticks > 0) {
	  syncfly ();
	  ticks --;
	}
	soundoff ();
}

void glide ()
{
	int cfreq;
	soundon ();
        for (cfreq = 50; cfreq < 1500; cfreq += 200) {
	  setfreq (cfreq);
	  syncfly ();
	}
	soundoff ();
}

void click ()
{
	soundit (200,1);
	soundit (1000,1);
}

void clrvdu ()		/* Wipe hires screen/board */
{
	unsigned int cptr;
	if (xgamode) {
	  Vdu = (BYTE far *) 0xa0000000;	/* Ptr to EGA/VGA screen */
	  graphmode (16);	/* Mode 16 = 640*350 16col */
	  Setink (15);		/* Wht ink */
	  chrsize = 14;
	  Vdui = Vdu;
	  Setplanes (0x0f02)	/* Enable ALL planes - Reg 2 = 15 */
	  Setmode (0)		/* RESET/SET fix pattern - WHT (ALL) */
	  Setmode (1)		/* Bit planes to effect - reg 1 */
	  for (cptr = 0; cptr < 32767; cptr ++) {
	    Vdui [cptr] = 0;
	  }
	} else {
	  Vdu = (BYTE far *) 0xb8000000;	/* Pointer to CGA screen */
	  graphmode (6);
	  chrsize = 8;
	}
}

#define Hidescreen hardscroll (1);
#define Showscreen hardscroll (0);

void hardscroll (int mode)	/* 1=hide,  0=reappear  */
{
	int cline,cinc;
	if (xgamode < 2) {	/* VGA only.. */
	  if (mode) clrvdu ();
	  return;
	}
	Vdui = Vdu;
	Setplanes (0x0f02)	/* Enable ALL planes - Reg 2 = 15 */
	Setmode (0)		/* RESET/SET fix pattern - WHT (ALL) */
	Setmode (1)		/* Bit planes to effect - reg 1 */
	for (cptr = 14000; cptr < 32767; cptr ++) {
	  Vdui [cptr] = 0;
	}
	cinc = 480; if (fastmode) cinc = 880;
	if (mode) {	/* Hide screen */
	  for (cline = 0; cline < 28000; cline += cinc) {
	    writestart (-cline);
	    syncfly ();
	  }
	  clrvdu ();
	  writestart (-28000);
	} else {	/* Re-show screen */
	  for (cline = 28000; cline > 0; cline -= cinc) {
	    writestart (-cline);
	    syncfly ();
	  }
	  writestart (0);
	}
}

void clrcol (int col, int cline)	/* Set text scr colors,0=whole scr */
{
	int xpos;
	Vdu = (BYTE far *) 0xb8000000;	/* Pointer to CGA screen */
	if (cline) {
	  cline = cline * 160 - 159;
	  for (xpos = cline; xpos < cline + 160; xpos += 2) {
	    Vdu [xpos] = col;
	  }
	} else {
	  graphmode (3);
	  for (xpos = 1; xpos < 4000; xpos += 2) {
	    Vdu [xpos] = col;
	  }
	}
}

void gotoxy (int xloc, int yloc)	/* Goto to loc X,Y on VDU */
{
	inr.h.bh = 0;
	inr.h.dl = xloc - 1;
	inr.h.dh = yloc - 1;
	inr.h.ah = 0x02;
	int86 (0x10,&inr,&outr);	/* INT 10, function 02 */
}

void printc (char ichr)		/* Print a Char */
{
	inr.h.ah = 0x0e;
	inr.h.al = ichr;
	int86 (0x10,&inr,&outr);	/* INT 10, function 0e */
}

void prints (char *istr)	/* Print a null-term string */
{
	int cchr;
        for (cchr = 0; istr [cchr]; cchr ++) {
	  printc ( istr [cchr]);
	  if (istr [cchr] == 10) printc (13);
	}
}

void printi (int iint)		/* Print a signed int */
{
	int cchr;
	if (iint == 0) {
	  printc ('0');
	  return;
	}
	if (iint < 0) {
	  printc ('-');
	  iint = -iint;
	}
	for (cchr = 0; iint; cchr ++) {
	  prbuffer [cchr] = 48 + (iint % 10);
	  iint /= 10;
	}
	prbuffer [cchr] = 0;
	while (cchr) {
	  cchr --;
	  printc ( prbuffer [cchr]);
	}
}

void printsi (char *istr, int iint)		/* Composite short cut */
{
	prints (istr);
	printi (iint);
}

void printwside (char *istr, int cline)
{
	gotoxy (75,cline); prints ("      ");
	gotoxy (75,cline); prints (istr);
}

void printside (char *istr, int cline)
{
	gotoxy (75,cline); prints (istr);
}

void printlwside (char *istr, int cline)
{
	gotoxy (1,cline); prints ("      ");
	gotoxy (1,cline); prints (istr);
}

void printlside (char *istr, int cline)
{
	gotoxy (1,cline); prints (istr);
}

int getkey ()
{
	inr.h.ah = 0x06;
	inr.h.dl = 0xff;
	int86 (0x21,&inr,&outr);	/* INT 21, function 6 */
	return (outr.h.al);
}

void floaddata (char *filename,void *brddata,int datasize)
{						/* Load data from disk */
	int chandle;
	diskerror = 0;
	inr.x.dx = (unsigned int) filename;
	inr.h.ah = 0x3d;
	inr.h.al = 0;		/* 0=read,1=write,2=rnd */
	int86 (0x21,&inr,&outr);	/* INT 21, 3d OPEN */
	chandle = outr.x.ax;
	if (outr.x.flags & 1) { 	/* Carry set ? */
	  prints ("Load Error!\n");
	  diskerror ++;
	  return ;
	}

	inr.x.bx = chandle;
	inr.x.dx = (unsigned int) brddata;
	inr.x.cx = datasize;
	inr.h.ah = 0x3f;
	int86 (0x21,&inr,&outr);	/* INT 21, 3f READ */

	inr.x.bx = chandle;
	inr.h.ah = 0x3e;
	int86 (0x21,&inr,&outr);	/* INT 21, 3e CLOSE */
}

void fsavedata (char *filename,void *brddata,int datasize)
{						/* Load data from disk */
	int chandle;
	diskerror = 0;
	inr.x.dx = (unsigned int) filename;
	inr.h.ah = 0x3c;
	inr.x.cx = 0;
	inr.h.al = 0;
	int86 (0x21,&inr,&outr);	/* INT 21, 3c CREATE */
	chandle = outr.x.ax;
	if (outr.x.flags & 1) { 	/* Carry set ? */
	  prints ("Save Error!\n");
	  diskerror ++;
	  return ;
	}

	inr.x.bx = chandle;
	inr.x.dx = (unsigned int) brddata;
	inr.x.cx = datasize;
	inr.h.ah = 0x40;
	int86 (0x21,&inr,&outr);	/* INT 21, 40 Write */
	inr.x.bx = chandle;
	inr.h.ah = 0x3e;
	int86 (0x21,&inr,&outr);	/* INT 21, 3e CLOSE */
}

void linput (char *istr, int maxlen)	/* Simple Alt to scanf */
{
	int cchr = 0;
	istr [0] = 0;
	do {
	  prints ("_\b");	/* Underline cursor */
	  do {
	    inkey = getkey ();
	  } while (inkey == 0);
	  istr [cchr] = 0;
	  if (inkey > 127)
	    continue;
	  if (inkey > 31) {		/* Norm char, display and add */
	    if (cchr >= maxlen)		/* Too long ? */
	      continue;
	    printc (inkey);
	    istr [cchr] = inkey;
	    cchr ++;
	    continue;
	  }
	  if (inkey == 8 && cchr > 0) {		/* Delete key ? */
            cchr --;
	    istr [cchr] = 0;
	    prints (" \b\b \b");
	  }
	} while (inkey != 13 && inkey != 27);
	prints (" \n");
	if (inkey == 27)
	  istr [0] = 0;
}

void promptin (char *iprompt,char *istr, int maxlen)
{
	prints (iprompt);
	linput (istr,maxlen);
}

int inchr (char *bigstr, char fchr)	/* Find char in BIGSTR (-1 fail) */
{
	int scount;
	for (scount = 0; bigstr [scount] != 0; scount ++)
	  if (bigstr [scount] == fchr)
	    return (scount);
	return (-1);
}

		/* Mouse control functions */

void mouse (int mode, int *button, int *xpos, int *ypos)
{
	inr.x.ax = mode;
	int86 (0x33,&inr,&outr);	/* INT 33, Mouse functions.. */
	*button = outr.x.bx;
	*xpos   = outr.x.cx;
	*ypos   = outr.x.dx;
}

void smouse (int mode)		/* Init mouse 1=show, 2=hide */
{
	inr.x.ax = mode;
	int86 (0x33,&inr,&outr);	/* INT 33, Mouse functions.. */
}

void showmouse ()
{
	if (mouseflag) smouse (1);	/* Show mouse */
}

void hidemouse ()
{
	if (mouseflag) smouse (2);	/* Hide mouse */
}

int getmouse ()
{
	mbutton = 0;
	if (mouseflag) {
	  mouse (3, &mbutton, &mousex, &mousey);
	}
	return (mbutton);
}

int mouse2sqr (int xloc, int yloc)	/* Conv Mouse to sqr no. */
{
	int tloc;
	xloc = (xloc - 8 * topx) / (charx * 8) + 1;
	yloc = (yloc - topy) / chary + 1;
	if (xloc < 1 || xloc > endx || yloc < 1 || yloc > endy)
	  return (0);
	return (xloc + yloc * bmult);
}

void printbit (char *istr, int endchr, int nchr)
{
	char ctext [40];
	int cchr,cmode = 0;
	for (cchr = 0; cchr < nchr; cchr ++) {
	  if (istr [cchr] == endchr) cmode ++;
	  if (cmode) {
	    ctext [cchr] = ' ';
	  } else {
	    ctext [cchr] = istr [cchr];
	  }
	}
	ctext [cchr] = 0;
	prints (ctext);
}

void menuprint (int menuwidth, int nmenu, char *mmenu)
{
	int cmenu;
	int nptr;
	int cptr = 0;
	gotoxy (2,1);
	printbit ("*", '*',menuwidth);
	for (cmenu = 1; cmenu <= nmenu; cmenu ++) {
	  gotoxy (2,1+cmenu);
	  printc (' ');
	  printbit (mmenu + cptr, '[',menuwidth-1);
	  nptr = inchr (mmenu + cptr,']');
	  if (nptr < 0) return;
	  cptr += nptr + 1;
	}
	gotoxy (2,2 + nmenu);
	printbit ("*", '*',menuwidth);

	fillobject (0,0,1,(nmenu + 2) * chrsize, 0xc0, Yel);
	fillobject (menuwidth+1,0,1,(nmenu + 2) * chrsize,0x03, Yel);
	fillobject (0,0,menuwidth+2,1,0xff, Yel);
	fillobject (0,(nmenu + 2) * chrsize, menuwidth+2,1,0xff, Yel);
}

int mousemenu (int menuwidth, int nmenu, char *retstr, char *mmenu)
{
	int temphi,cchr,lchr;
	int tempx,tempy;
	int hilite = 0;
	getpal (10);
	tempx = wherex (); tempy = wherey ();
	hidemouse ();
	menuprint (menuwidth, nmenu, mmenu);
	showmouse ();
	getpal (15);
	while (getmouse () == 2) {		/* Wait for button release */
	  temphi = mousey / chrsize;
	  if (mousex > menuwidth * 8 || mousey > nmenu * chrsize + chrsize - 2)
	    temphi = 0;
	  if (temphi != hilite) {
	    hidemouse ();
	    if (hilite) {
	      gotoxy (2,hilite + 1);
	      printc (' ');
	    }
	    hilite = temphi;
	    if (hilite) {
	      gotoxy (2,hilite + 1);
	      printc ('*');
	    }
	    showmouse ();
	  }
	}		/* Button released */
	hidemouse ();
	gotoxy (1,1);
	printc (' ');
	if (hilite) {
	  cchr = 0;
	  for (temphi = 1; temphi <= hilite; temphi ++) {
	    cchr += inchr (mmenu + cchr, '[') + 1;
	  }
	  inkey = mmenu [cchr];
	}
	gotoxy (tempx, tempy);
	fillobject (0,0,menuwidth + 2, 1 + (nmenu + 2) * chrsize, 0, Wht);
	return (hilite);
}


void putat (int xpos, int ypos, int cpiece)
{
	xpos = xpos * charx + topx - charx;
	ypos = ypos * chary + topy - chary;
	object ( xpos, ypos, charx, chary, sprites + cpiece * Ssize);
}

void fineputat (int xpos, int ypos, int cpiece)
{
	object ( xpos + topx - charx, ypos * 7 + topy - chary,
		charx, chary, sprites + cpiece * Ssize);
}

void bputat (int xpos, int ypos, int cpiece)
{
	if (cpiece == -1) {		/* -1, so take from board [] */
	  cpiece = Getboard (xpos,ypos) ;
	} else {
	  Setboard (xpos, ypos, cpiece);
	}
	if (showflag == 0) return;
	putat (xpos, ypos, cpiece);
}

int peekat (int xpos, int ypos)
{
	return (Getboard (xpos,ypos));
}

void redo (int xpos, int ypos)
{
	int cpiece;
	cpiece = Getboard (xpos,ypos);
	xpos = xpos * charx + topx - charx;
	ypos = ypos * chary + topy - chary;
	object ( xpos, ypos, charx, chary, sprites + cpiece * Ssize);
}

int halfy;
int keyhit = 0;

void moveit (int mxpos, int mypos, int mxdir, int mydir, int cpiece)
{
	syncfly ();
	putat (mxpos,mypos,Empty);
	if (xgamode == 0) {
	  putat (mxpos + mxdir, mypos + mydir, cpiece); return;
	}
	if (fastmode == 0) {
	  if (bigflag) {
	    txpos = mxpos * 3; typos = mypos * 3;
	    fineputat (txpos + mxdir, typos + mydir, cpiece);
	    syncfly ();
	    if (abs (mxdir + mydir) != 1) {  /* Diag refresh */
	      redo (mxpos, mypos + mydir);
	      redo (mxpos + mxdir, mypos);
	    }
	    fineputat (txpos + mxdir, typos + mydir, 0);
	    fineputat (txpos + mxdir + mxdir, typos + mydir + mydir, cpiece);
	    syncfly ();
	    fineputat (txpos + mxdir + mxdir, typos + mydir + mydir, 0);
	  } else {
	    fineputat ((mxpos << 1) + mxdir, ((mypos << 1) + mydir), cpiece);
	    syncfly ();
	    fineputat ((mxpos << 1) + mxdir, ((mypos << 1) + mydir), 0);
	  }
	}
	mxpos += mxdir; mypos += mydir;
	putat ( mxpos, mypos, cpiece);
	if (fastmode == 0 && abs (mxdir + mydir) != 1) {  /* Diag refresh */
	  redo (mxpos, mypos - mydir);
	  redo (mxpos - mxdir, mypos);
	}
}

int putrand (int cpiece)
{
	int scans = 0;
	do {
	  txpos = (rand () % (endx - begx)) + begx;
	  typos = (rand () % (endy - begy - 3)) + begy + 2;
	  if (scans > 100)
	    return (0);
	  scans ++;
	} while (peekat (txpos,typos) );
	bputat (txpos, typos, cpiece);
	return (1);
}

void statline ()		/* Update status line */
{
	getpal (12);
	if (twoplaymode) {
	  printlside ("Two",14);
	  printlside ("Player",15);
	} else {
	  printlwside ("",14);
	  printlwside ("",15);
	}
	if (editmode) {
	  printside ("EDIT. ",12);
	} else {
	  getpal (10);
	  printwside ("IQ:",12); printi (iqcutoff);
	}
	getpal (6);
	printside ("F10 =",14);
	printside ("Help",15);
	getpal (15);
	printlwside("",1);
	printlwside("",2);
	printlwside("",3);
	if (ccolor == Left) {
	  printlside ("Left",17);
	  printlside ("Move",18);
	  printwside ("",17);
	  printwside ("",18);
	} else {
	  printside ("Right",17);
	  printside ("Move",18);
	  printlwside ("",17);
	  printlwside ("",18);
	}
	getpal (13);
	if (negate) {
	  printlside ("NEGATE",10);
	} else {
	  printlside ("      ",10);
	}
	if (doubler) {
	  printlside ("DOUBLE",12);
	} else {
	  printlside ("      ",12);
	}
}

void printnumat (int cnum, int xpos, int ypos)
{
	putat (xpos,ypos,48 + (cnum % 10));
	cnum = cnum / 10; xpos --;
	putat (xpos,ypos,48 + (cnum % 10));
	cnum = cnum / 10; xpos --;
	putat (xpos,ypos,48 + (cnum % 10));
}

void printstrat (char *istr, int xpos, int ypos)
{
	int cstr = 0;
	while (istr [cstr]) {
	  temp = istr [cstr];
	  if (temp == 32) temp = Empty;
	  temp = temp & 63;
	  putat (xpos, ypos, temp);
	  xpos ++;
	  cstr ++;
	}
}

int features [] = {30,30,31,31,32,32,40,43};

void diamond (int xpos, int ypos)
{
	Setboard (xpos,ypos,Slope);Setboard (xpos + 1,ypos,Slope+1);
	Setboard (xpos,ypos + 1,Slope+2);Setboard (xpos + 1,ypos + 1,Slope+3);
}

void bigdiamond (int xpos, int ypos)
{
	Setboard (xpos+1,ypos,Slope);Setboard (xpos + 2,ypos,Slope+1);
	Setboard (xpos,ypos+1,Slope); Setboard (xpos + 1,ypos+1,Slope+4);
	Setboard (xpos + 2,ypos+1,Slope + 4); Setboard (xpos + 3,ypos+1,Slope+1);
	Setboard (xpos,ypos+2,Slope+2); Setboard (xpos + 1,ypos+2,Slope+4);
	Setboard (xpos + 2,ypos+2,Slope + 4); Setboard (xpos + 3,ypos+2,Slope+3);
	Setboard (xpos + 1,ypos + 3,Slope+2);Setboard (xpos + 2,ypos + 3,Slope+3);
}

void gelly (int xpos, int ypos)
{
	Setboard (xpos,ypos,Gel); Setboard (xpos+1,ypos,Gel);
	ypos ++;
	Setboard (xpos-1,ypos,Edge); Setboard (xpos,ypos,Edge);
	Setboard (xpos+1,ypos,Edge); Setboard (xpos+2,ypos,Edge);
}

int factor;

void newboard ()
{
	srand ((int) readtime ());
	negate = doubler = automode = 0;
	scoreleft = scoreright = 100;
	for (xpos = 0; xpos < 2000; xpos ++) {
	  board [xpos] = Blank;
	}
	for (xpos = 1; xpos <= Maxx; xpos ++) {
	  Setboard (xpos,endy-1,Edge);
	}
	factor = 31500 - bigflag * 1000;
	for (xpos = begx + 1; xpos < endx; xpos ++) {
	  for (ypos = begy; ypos <= endy; ypos ++) {
	    if (ypos < begy + 2) {
	      Setboard (xpos,ypos,Ball);
	    } else if (ypos < endy) {
	      Setboard (xpos,ypos,Letters + rand () % alphasize);
	      if (ypos > begy + 6) {
		if (usefeatures && rand () > factor) {
		  temp = features [rand () % 8];
		  Setboard (xpos,ypos,temp);
		}
	      }
	    } else {
	      Setboard (xpos,ypos,Empty);
	    }
	  }
	}
	if (bigflag == 0) {
	  if (layout & 1) {
	    for (txpos = begx; txpos < endx; txpos += 6) {
	      diamond (txpos,17);
	    }
	  }
	  if (layout & 2) {
	    for (txpos = begx + 3; txpos < endx; txpos += 6) {
	      diamond (txpos,14);
	    }
	  }
	  if (layout & 4) {
	    for (txpos = begx + 4; txpos < endx; txpos += 10) {
	      bigdiamond (txpos,7);
	    }
	  }
	  if (layout & 8) {
	    gelly (8,21); gelly (20,21); gelly (32,21);
	    gelly (15,10); gelly (25,10);
	  }
	} else {
	  if (layout & 1) {
	    diamond (begx,11); diamond (begx + 7,11);
	    diamond (endx - 1,11); diamond (endx - 8,11);
	  }
	  if (layout & 2) {
	    diamond (begx + 3,8); diamond (endx-4,8);
	  }
	  if (layout & 4) {
	    for (txpos = begx + 4; txpos < endx; txpos += 10) {
	      bigdiamond (txpos,3);
	    }
	  }
	  if (layout & 8) {
	    /* gelly (13,7); */
	    gelly (13,13);
	    Setboard (9,14,Regen); Setboard (19,14,Regen);
	  }
	}
	for (ypos = begy; ypos <= endy; ypos ++) {
	  Setboard (begx,ypos,Edge);
	  Setboard (endx,ypos,Edge);
	}
	for (xpos = 1; xpos <= Maxx; xpos ++) {
	  Setboard (xpos,endy,Empty);
	  Setboard (xpos,endy+1,Edge);
	}
}

void drawboard ()
{
	for (xpos = 1; xpos <= Maxx; xpos ++) {
	  for (ypos = 1; ypos <= endy + 1; ypos ++) {
	    bputat (xpos,ypos, -1);
	  }
	}
	showscores ();
}

void shutwindow (int xlen, int ylen)
{
	for (xpos = 1; xpos <= xlen; xpos ++) {
	  for (ypos = 1; ypos <= ylen; ypos ++) {
	    bputat (xpos,ypos, -1);
	  }
	}
}

int ngot,ccount,csplat;
#define Splat 42

int doamove (int cletter)	/* Remove letter from brd */
{
	register int cxpos;
	ngot = 0; ccount = 10;
	csplat = Splat;
	while (ccount && showflag) {
	  for (cypos = begy; cypos < endy; cypos ++) {
	    for (cxpos = begx; cxpos < endx; cxpos ++) {
	      if (Getboard (cxpos,cypos) == cletter) {
		putat (cxpos,cypos,csplat);
	      }
	    }
	  }
	  ccount --;
	  csplat = cletter + Splat - csplat;
	  syncfly ();
	  syncfly ();
	}
	for (cypos = begy; cypos < endy; cypos ++) {
	  for (cxpos = begx; cxpos < endx; cxpos ++) {
	    if (Getboard (cxpos,cypos) == cletter) {
	      ngot ++;
	      bputat (cxpos,cypos,Empty);
	    }
	  }
	}
	return (ngot);
}

void hilite ()
{
	register int cxpos, cletter;
	statline ();
	getpal (15);
	gotoxy (1,1);
	prints ("Hilite\nLetter\n(a..z)");
	click ();
	do {
	  cletter = getkey ();
	  if (cletter == 27 || cletter == 13) return;
	  if (cletter >= 'a') cletter -= 32;
	} while (cletter < 'A' || cletter > 'Z');
	cletter -= 64;
	statline ();
	gotoxy (1,1);
	prints ("Hit\nSPACE\n");
	csplat = Splat;
	while (getkey () != 32) {
	  temp = 0;
	  for (cypos = begy; cypos < endy; cypos ++) {
	    for (cxpos = begx; cxpos < endx; cxpos ++) {
	      if (Getboard (cxpos,cypos) == cletter) {
		putat (cxpos,cypos,csplat);
		temp ++;
	      }
	    }
	  }
	  if (temp == 0) return;
	  csplat = cletter + Splat - csplat;
	  syncfly ();
	  syncfly ();
	}
	drawboard ();
}

int makelist ()			/* Rebuild ball list */
{
	nballs = 0;
	for (rypos = endy; rypos >= begy; rypos --) {
	  for (rxpos = endx; rxpos >= begx; rxpos --) {
	    if (Getboard (rxpos,rypos) == Ball) {
	      if (nballs >= Mball) return;
	      nballs ++;
	      ballx [nballs] = rxpos; bally [nballs] = rypos;
	    }
	  }
	}
}

int lcount [65];

int anyletters ()
{
	int lflag = 0;
	for (ccount = 0; ccount < 64; ccount ++) {
	  lcount [ccount] = 0;
	}
	for (rypos = endy; rypos >= begy; rypos --) {
	  for (rxpos = endx; rxpos >= begx; rxpos --) {
	    temp = Getboard (rxpos,rypos);
	    lcount [temp & 63] ++;
	    if (temp >= Letters && temp <= Letters + 26) {
	      lflag ++;
	    }
	  }
	}
	return (lflag);
}

int gameover ()
{
	makelist ();
	if (nballs && anyletters ()) return (0);
	initsprites (0);
	printstrat ("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&",4,1);
	printstrat ("&                                &",4,2);
	printstrat ("&                                &",4,3);
	printstrat ("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&",4,4);
	if (scoreleft > scoreright) {
	  printstrat (" LEFT PLAYER WINS.",12,2);
	} else if (scoreleft < scoreright) {
	  printstrat ("RIGHT PLAYER WINS.",12,2);
	} else {
	  printstrat ("ITS A DRAW.",15,2);
	}
	printstrat ("GAME OVER, HIT SPACE.",11,3);
	glide (); glide ();
	while (getkey () != ' ');
	return (1);
}

int moving,ccell,ballval,restart;

void showscores ()
{
	printnumat (scoreleft,3,endy);
	printnumat (scoreright,Maxx,endy);
}

void blowup (int uxpos, int uypos)	/* Recursive blow-up.. */
{
	register int txpos, typos;
	for (txpos = uxpos - 1; txpos <= uxpos + 1; txpos ++) {
	  if (txpos > begx && txpos < endx) {
	    for (typos = uypos - 1; typos <= uypos + 1; typos ++) {
	      temp = peekat (txpos,typos);
	      if (temp == Gel) {
		bputat (txpos, typos, Empty);
		blowup (txpos, typos);
	      } else if (temp < Slope || temp >= Edge) {
		if (showflag) {
		  putat (txpos,typos,Splat);
		  soundit ((txpos * typos * 10) & 1023,1);
		}
		bputat (txpos,typos,Empty);
	      }
	    }
	  }
	}
}

int readboard (int xpos, int ypos)	/* Scan/act on given cell */
{
	ccell = Getboard (xpos, ypos);
	if (ccell == Empty) return (1);
	if (ccell == Neg) {
	  negate = 1 - negate;
	  if (showflag) {
	    statline ();
	    soundit (200,1);
	  }
	  Setboard (xpos, ypos, Empty);
	  return (1);
	}
	if (ccell == Bonus) {
	  ballval = 1 + doubler; if (negate) ballval = -ballval;
	  if (ccolor == Left) {
	    scoreleft += ballval * 5;
	  } else {
	    scoreright += ballval * 5;
	  }
	  if (showflag) {
	    showscores ();
	    soundit (1000,1);
	  }
	  Setboard (xpos, ypos, Empty);
	  return (1);
	}
	if (ccell == Doubler) {
	  doubler = 1 - doubler;
	  if (showflag) {
	    statline ();
	    soundit (400,1);
	  }
	  Setboard (xpos, ypos, Empty);
	  return (1);
	}
	if (ccell == Gel) {
	  bputat (xpos, ypos, Empty);
	  blowup (xpos, ypos);
	  restart = 1;
	}
	if (ccell == Regen) {
	  if (showflag) {
	    for (ccount = 0; ccount < 20; ccount ++) {
	      putat (xpos,ypos,Ball);
	      soundit (1000+ ccount * 50,1);
	      putat (xpos,ypos,Regen);
	      syncfly ();
	    }
	    putat (xpos,ypos,0);
	  }
	  Setboard (xpos,ypos,0);
	  ccount = 150;
	  while (ccount && putrand (Letters + rand () % alphasize)) {
	    ccount --;
	  }
	  if (nballs < 100) {
	    for (txpos = begx + 1; txpos <= endx - 1; txpos += 2) {
	      bputat (txpos,begy,Ball);
	    }
	  }
	  restart = 1;
	}
	return (0);
}

int oldxpos, oldypos;

int dropballs ()		/* Cascade balls */
{
	int cball;
redrop:
	restart = 0;
	makelist ();
	for (cball = 1; cball <= nballs; cball ++) {
	  rxpos = ballx [cball]; rypos = bally [cball];
	  Setboard (rxpos,rypos,Empty);
	  moving = 1;
	  do {
	    oldxpos = rxpos; oldypos = rypos;
	    temp = ((rand () & 1) << 1) - 1;
	    rypos ++;
            if (readboard (rxpos, rypos)) {
	    } else if (readboard (rxpos + temp, rypos) ) {
	      rxpos += temp;
	    } else if (readboard (rxpos - temp, rypos) ) {
	      rxpos -= temp;
	    } else {
	      rypos --;
	      moving = 0;
	      if (rypos >= endy) {
		ballval = 1 + doubler;
		if (negate) ballval = -ballval;
		if (ccolor == Left) {
		  while (rxpos > 3) {
		    if (showflag) {
		      putat (rxpos,rypos,Ball);
		      syncfly ();
		      putat (rxpos,rypos,Empty);
		    }
		    rxpos --;
		  }
		  scoreleft += ballval;
		  if (showflag) printnumat (scoreleft,3,endy);
		} else {
		  while (rxpos < Maxx - 2) {
		    if (showflag) {
		      putat (rxpos,rypos,Ball);
		      syncfly ();
		      putat (rxpos,rypos,Empty);
		    }
		    rxpos ++;
		  }
		  scoreright += ballval;
		  if (showflag) printnumat (scoreright,Maxx,endy);
		}
		if (showflag) {
		  soundit (700,1); soundit (350,1);
		}
		rxpos = 0;
		break;
	      }
	    }
	    if (restart) {
	      bputat (oldxpos, oldypos, -1);
	      goto redrop;
	    }
	    if (showflag) {
	      if (oldypos == rypos) {
		putat (rxpos, rypos, Ball);
	      } else {
		moveit (oldxpos, oldypos, rxpos - oldxpos, rypos - oldypos, Ball);
	      }
	    }
	  } while (moving);
	  if (rxpos) Setboard (rxpos,rypos,Ball);
	}
}

int acount [64];
int cmove,bmove,beval;

void calcwgt ()
{
	int cpos,temp;
	for (rypos = begy; rypos <= endy; rypos ++) {
	  for (rxpos = begx; rxpos <= endx; rxpos ++) {
	    bwgt [rxpos + rypos * bmult] = 0;
	    if (Getboard (rxpos,rypos) == Ball) {
	      temp = 0;
	      cpos = rxpos + rypos * bmult - bmult;
	      if (rypos > begy) {
		temp = bwgt [cpos] + bwgt [cpos - 1] + bwgt [cpos + 1];
		if (temp > 2) temp --;
	      }
	      bwgt [rxpos + rypos * bmult] = temp + 1;
	      /* gotoxy (rxpos,rypos); printc (49 + temp); */
	    }
	  }
	}
}

void pushbrd ()
{
	unsigned int bpos;
	tneg = negate; tdoub = doubler;
	tleft = scoreleft; tright = scoreright;
	endbrd = (endy + 2) * bmult; begbrd = 40;
	for (bpos = begbrd; bpos < endbrd; bpos ++) {
	  bstack [bpos] = board [bpos];
	  bpos ++;
	  bstack [bpos] = board [bpos];
	}
}

void pullbrd ()
{
	unsigned int bpos;
	negate = tneg; doubler = tdoub;
	scoreleft = tleft; scoreright = tright;
	endbrd = (endy + 2) * bmult; begbrd = 40;
	for (bpos = begbrd; bpos < endbrd; bpos ++) {
	  board [bpos] = bstack [bpos];
	  bpos ++;
	  board [bpos] = bstack [bpos];
	}
}

void execcomp ()
{
	int cball,cpos;
	statline ();
	getpal (2);
	printwside ("Hmm..",5);
	printwside ("",6);
	if (anyletters () == 0) {
	  return;
	}
	calcwgt ();
	for (cball = 0; cball < 63; cball ++) {
	  if (lcount [cball]) {
	    acount [cball] = 1;
	  } else {
	    acount [cball] = 0;
	  }
	}
	makelist ();
	for (cball = 1; cball <= nballs; cball ++) {
	  rxpos = ballx [cball]; rypos = bally [cball] + 1;
	  cpos = rxpos + rypos * bmult; temp = bwgt [cpos - bmult];
	  acount [board [cpos] & 63] += temp;
	  acount [board [cpos+1] & 63] += temp;
	  acount [board [cpos-1] & 63] += temp;
	}
	if (negate) {
 	  bmove = 0; beval = 9999;
	  for (cmove = 1; cmove <= 26; cmove ++) {
	    if (acount [cmove] && acount [cmove] < beval) {
	      bmove = cmove; beval = acount [cmove] ;
	    }
	  }
	} else {
 	  bmove = 0; beval = 0;
	  for (cmove = 1; cmove <= 26; cmove ++) {
	    if (acount [cmove] > beval) {
	      bmove = cmove; beval = acount [cmove] ;
	    }
	  }
	}
	if (iqcutoff == 2) {
 	  bmove = 0; beval = 0;
	  pushbrd ();
	  showflag = 0;
	  for (cmove = 1; cmove <= 26; cmove ++) {
	    srand (1);
	    if (doamove (cmove)) {	/* Any letters ? */
	      dropballs ();
	      if (ccolor == Left) {
	        xeval = 1000 + scoreleft - scoreright;
	      } else  {
		xeval = 1000 + scoreright - scoreleft;
	      }
	      printside ("Hmm..",5);
	      printc (64+cmove);
	      if (xeval > beval) {
		bmove = cmove; beval = xeval;
	      }
	      pullbrd ();
	    }
	  }
	  showflag = 1;
	}
	if (bmove == 0) bmove = anyletters ();
	if (bmove) {
	  #if Debug
	  if (debugflag) {
	    showflag = 0;
	    srand (1);
	    pushbrd ();
	    doamove (bmove);
	    dropballs ();
	    showflag = 1;
	    drawboard ();
	    while (getkey () != ' ');
	    pullbrd ();
	    drawboard ();
	    while (getkey () != ' ');
	  }
	  #endif
	  srand (1);
	  showflag = 1;
	  doamove (bmove);
	  getpal (10);
	  printwside ("I take",5);
	  printwside ("",6); printc (bmove + 64);
	  printsi ("=",beval-1000);
	  dropballs ();
	}
}

long lasttime = 0;

void game ()
{
      Hidescreen
      newboard ();
      pxpos = pypos = 10;
      ccolor = Left;
      drawboard ();
      if (mouseflag) smouse (0);	/* Reset Mouse */
      twoplaymode = 0;
      Setink (14);
      Showscreen
      do {		/* Main playing loop */
	cmdkey = 0;
	statline ();
	if (gameover ()) {
	  return ;
	}
	getpal (10);
	gotoxy (1,1);
	if (editmode) {
	  prints ("EDIT\nMODE");
	  if (cursorflag) putat (pxpos,pypos,Gcur);
	} else {
	  prints ("Select\nLetter\n(a..z)");
	}
	showmouse ();
	do {
	  cmdkey = getkey ();
	  if (cmdkey == 3) return;
	  if (cmdkey == 27) {
	    if (automode + editmode == 0) return;
	    if (editmode) bputat (pxpos,pypos,-1);
	    editmode = automode = 0;
	    mouseflag = 1; showmouse ();
	    cmdkey = 13;
	  }
	  if (cmdkey == 6) {
	    fastmode = 1 - fastmode;
	  }
	  #if Debug
	    if (cmdkey == 4) {
	      debugflag = 1 - debugflag;
	    }
	  #endif
	  if (automode && cmdkey) automode = 0;
	  if (editmode && lasttime != (readtime () & 4)) {
	    lasttime = readtime () & 4;
	    syncfly ();
	    if (cursorflag) {
	      hidemouse ();
	      if (lasttime) {	/* Cursor */
		bputat (pxpos,pypos,-1);
	      } else {
		putat (pxpos,pypos,Gcur);
	      }
	      showmouse ();
	    }
	  }

	  #if Debug
	    if (cmdkey == '!') {	/* Test hardware scroll.. */
	      Vdui = Vdu;
	      Setplanes (0x0f02)	/* Enable ALL planes - Reg 2 = 15 */
	      Setmode (0)		/* RESET/SET fix pattern - WHT (ALL) */
	      Setmode (1)		/* Bit planes to effect - reg 1 */
	      for (cptr = 14000; cptr < 32767; cptr ++) {
		Vdui [cptr] = 0;
	      }
	      temp = 0; vert = readvert ();
	      do {
		do {
		  inkey = getkey ();
		  if (inkey == '2') temp += 160;
		  if (inkey == '8') temp -= 160;
		  if (inkey == '4') temp -= 1;
		  if (inkey == '6') temp += 1;
		  if (inkey == '-') {
		    vert --; writevert (vert);
		  }
		  if (inkey == '+') {
		    vert ++; writevert (vert);
		  }
		  if (inkey == 27) exit (0);
		} while (inkey == 0);
		/* vert = readvert (); */
		/* gotoxy (1,1); printsi ("=",temp); printsi ("  ",vert); prints ("  "); */
		writestart (temp);
		syncfly ();
	      } while (1);
	    }
	  #endif 	/* Debug */

	  if (editmode) {
	    kcmd = inchr ("OPQKMGHI abcdefghijklmnopqrstuvwxyz0123456789:;<=>?@ABCD\x0d",cmdkey);
	  } else {
	    kcmd = inchr ("abcdefghijklmnopqrstuvwxyz;<=>?@ABCD\x0d",cmdkey);
	  }
          if (mouseflag) {
	    getmouse ();
	    if (mbutton == 1) {
	      temp = mouse2sqr (mousex, mousey);
	      if (temp) {		/* Legal move.. */
		hidemouse ();
		bputat (pxpos,pypos,-1);
		showmouse ();
		pxpos = temp % bmult;
		pypos = temp / bmult;
		kcmd = 100; cmdkey = Getboard (pxpos,pypos) + 96;
		if (cmdkey < 'a' || cmdkey > 'z') kcmd = -1;
	      }
	    } else if (mbutton == 2) {
		temp = mousemenu (20,6,gin,
		  " Help Screen (F10)[D] Edit Mode    (F1)[;] Computer Go  (F2)[g]"
		  " Auto Play    (F3)[=] Load Maze    (F7)[A]"
		  " Q U I T     (ESC)[q]");
	      shutwindow (12,9);
	      if (temp) {		/* Menu selected */
		kcmd = 100; cmdkey = inkey;
		if (inkey == 'q') return;
	      }
	      showmouse ();
	    }
	  }
	} while (kcmd < 0 && automode == 0);

	hidemouse ();
	    if (cmdkey == 'B') {
	      getpal (3);
	      printwside ("Save:",17);
	      printwside ("",18);
	      click ();
	      linput (gin,5);
	      if (gin [0]) {
		board [0] += bigflag;
		fsavedata (gin,board,2200);
	        drawboard ();
	      }
	      continue;
	    }
	  if (cmdkey == 'A') {
	    getpal (3);
	    printwside ("Load:",17);
	    printwside ("",18);
	    click ();
	    linput (gin,5);
	    if (gin [0]) {
	      floaddata (gin,board,2200);
	      if (board [0] < 27 || board [0] > 28) {
		newboard ();
	      } else {
		bigflag = board [0] - 27;
		board [0] = 27;
		clrvdu ();
		initsprites (-bigflag);
	      }
	      drawboard ();
	    }
	    continue;
	  }

	if (cmdkey == 'D') {	/* F10 - HELP */
	  helpscreen ();
	  Hidescreen
	  drawboard ();
	  Showscreen
	  continue;
	}

	if (editmode) {
	  /* if (kcmd > 7) kcmd -= 8; */
	  if (cursorflag) bputat (pxpos,pypos,-1);
	  if (kcmd < 8 && automode == 0) {	/* Cursor move.. */
	    xdir = hxdir [kcmd];		/* Get dir moved */
	    ydir = hydir [kcmd];
	    pxpos += xdir; pypos += ydir;
	    if (pxpos < begx || pypos < begy || pxpos > endx || pypos > endy) {
	      pxpos -= xdir; pypos -= ydir;
	      continue;
	    }
	    continue;
	  }
	  if (cmdkey == 13) {
	    editmode = 0;
	    bputat (pxpos,pypos,-1);
	    mouseflag = 1; showmouse ();
	    continue;
	  }
	  if (cmdkey >= 'a' && cmdkey <= 'z') {
	    Setboard (pxpos, pypos, cmdkey - 96);
	  }
	  if (cmdkey >= 48 && cmdkey <= 'D') {
	    Setboard (pxpos, pypos, cmdkey - 19);
	  }
	  if (cmdkey == 32) Setboard (pxpos,pypos,Empty);
	  continue;
	}	/* End EDIT mode. */

	if (cmdkey >= 'a' && cmdkey <= 'z') {
	  soundit (2000,1); soundit (1000,1);
	  if (doamove (cmdkey - 96) == 0) {
	    gotoxy (1,4); getpal (12);
	    prints ("Bad\nmove!");
	  } else {
	    printlwside ("",4); printlwside ("",5);
	    showflag = 1;
	    dropballs ();
	    ccolor = 3 - ccolor;
	    if (twoplaymode == 0) {
	      execcomp ();
	      ccolor = 3 - ccolor;
	    }
	  }
	}
	if (cmdkey == '?') {
	  twoplaymode = 1 - twoplaymode;
	  click ();
	}

	if (cmdkey == ';') {
	  hilite ();
	}
	if (cmdkey == '=') {
	  automode = 1;
	}
	if (automode) cmdkey = '<';
        if (cmdkey == '<') {		/* Computer go (F2).. */
	    execcomp ();
	    ccolor = 3 - ccolor;
	}
	if (cmdkey == '@') {
	  editmode = 1 - editmode;
	  hidemouse (); mouseflag = 0;
	  click ();
	}
	if (cmdkey == '>') {
	  iqcutoff = 3 - iqcutoff;
	}
	if (cmdkey == 'C') {
	  /* cursorflag = 1 - cursorflag; */
	}

      } while (1);
}

void hitspace ()
{
	click ();
	prints ("                    Hit SPACE to Continue.");
	while (getkey () != ' ');
}

#define Col1 2
#define Col2 14
#define Col3 15


void frontscreen (int mode)
{
	clrcol (Col2,0);
	clrcol (15,25);
	prints (
  "\n\t\t\t   *  CASCADE " PROG_VER "  *\n"
  "\t\t\t  ------------------\n\n"
  "\t\t\tCopyright A.Millett 1981-2024.\n\n\n"
  "    CASCADE is an open source strategy game for MSDOS computers.\n\n"
  "    Released as free software under GNU GPL3 license.\n\n"
  "       see: www.gnu.org/licenses/gpl-3.0.html\n\n"
	);
	if (mode == 0) {
	  hitspace ();
	  return;
	}
	gotoxy (1,22);
	prints ("  (You can now hit SPACE for default VGA, or select CGA,EGA,VGA modes)\n\n");
	prints ("        Hit SPACE to continue..   (or type c,e,v) ");
	click ();
	do {
	  inkey = getkey ();
	  if (inkey == 27) {
	    xgamode = 99; return;
	  }
	  if (inkey > 96) inkey -= 32;
	  xgamode = inchr ("CEV ",inkey);
	} while (xgamode < 0);
	if (xgamode == 3) xgamode = 2;
}

void initsprites (int cset)	/* Select a sprite-set (0=main,1=title) */
{
	topx = topy = 0;
	if (cset == 1) {		/* Mini-set.. */
	  if (xgamode) {		/* EGA/VGA... */
	    charx = 3;
	    chary = 18;
	    Ssize = 216;		/* On-disk size */
	    sprites = minisprites;
	  } else {
	    charx = 3;
	    chary = 10;
	    Ssize = 30;		/* On-disk size */
	    sprites = minisprites + 864;
	  }
	  return;
	}

	Maxx = 40; Maxy = 25;
	begx = 5; begy = 1;
	endx = 36, endy = 24;
	if (xgamode) {		/* EGA/VGA... */
	  if (cset == 0) {
	    charx = 2;
	    chary = 14;
	    Ssize = 112;
	    sprites = disksprites;
	  } else {
	    charx = 3;
	    chary = 21;
	    Ssize = 252;
	    sprites = bigsprites;
	    Maxx = 26; Maxy = 16;
	    begx = 3; begy = 1;
	    endx = 24; endy = 15;
	    topx = 1;
	  }
	} else {		/* CGA.. */
	  charx = 2;
	  chary = 8;
	  Ssize = 16;
	  sprites = disksprites + 7168;
	  if (cset) {
	    Maxx = 26; Maxy = 16;
	    begx = 3; begy = 1;
	    endx = 24; endy = 15;
	    topx = 9; topy = 20;
	  }
	}
}

void showmodes ()
{
	gotoxy (6,22);
	printsi ("Alphabet:",alphasize);
	printsi (" (+/-)  Layout:",layout);
	prints (" (F1) ");
	if (usefeatures) {
	  prints ("Extras ON.  (F2) ");
	} else {
	  prints ("Extras OFF. (F2) ");
	}
	if (bigflag) {
	  prints ("BIG chrs   (F3)  ");
	} else {
	  prints ("Small chrs (F3)  ");
	}

}

void showborder ()
{
	for (xpos = 1; xpos <= 26; xpos ++) {		/* Edges... */
	  putat ( xpos, 1, rand () % 3);
	  putat ( xpos, 19, rand () % 3);
	}
	for (ypos = 1; ypos <= 19; ypos ++) {
	  putat (  1, ypos, rand () % 3);
	  putat ( 26, ypos, rand () % 3);
	}
	putat (1,1,3); putat (1,19,3); putat (26,1,3); putat (26,19,3);
}

void fillscr ()
{
	for (xpos = 1; xpos <= 26; xpos ++) {		/* Edges... */
	  for (ypos = 1; ypos <= 19; ypos ++) {
	    putat ( xpos, ypos, rand () % 4);
	  }
	}
}

void show1border ()
{
	xpos = (rand () % 24) + 2;
	ypos = (rand () % 17) + 2;
	temp = rand () % 3;
	syncfly ();
	if (rand () & 1) {
	  putat ( xpos, 1, temp);
	  putat ( xpos,19, temp);
	} else {
	  putat (  1, ypos, temp);
	  putat ( 26, ypos, temp);
	}
}

void titlescreen ()
{
	long temptime = 99;
titleloop:
	Hidescreen
	initsprites (1);
	gotoxy (28,3);
	Setink (15);
	prints ("+    C A S C A D E    +\n\n");
	Setink (14);
	prints ("          Copyright A. Millett 1981-2024. Released as freeware.\n\n");
	Setink (2);
	prints (
"        Like all the best strategy games, CASCADE is easy to learn and\n"
"      yet tough to actually master. During play you are presented with\n"
"      a maze of letters, scattered with balls and other objects. Each\n"
"      player takes turns to remove a letter, and the balls cascade down\n"
"      the gaps left. On reaching the bottom, they will add a value to\n"
"      your score - this is normally 1, but is changed by hitting NEGATORS,\n"
"      DOUBLERS and other objects - for a fuller description hit the ");
	getpal (10); prints ("F10\n"); getpal (2); prints (
"      key NOW or during play. You can select the range of alphabet to use\n"
"      NOW with the +/- keys, or select screen layouts with the F1 key.\n"
"        To make moves during play, simply select the letter you want to\n"
"      remove by typing LOWERCASE a..z, or move the mouse to the letter and\n"
"      click the left button.\n"
	"\n");
	Setink (15);
	prints ("                        Hit SPACE to play, ESC to Exit." );

	Setink (11);
	glide ();
	showmodes ();
	showborder ();
	Showscreen
	do {
	  if ( temptime != (readtime () & 2) ) {
	    temptime = readtime () & 2;
	    show1border (0);
	  }
	  inkey = getkey ();
	  if (inkey == 3) return;
	  if (inkey == '+' && alphasize < 26) {
	    alphasize ++;
	  }
	  if (inkey == '-' && alphasize > 5) {
	    alphasize --;
	  }
	  if (inkey == ';') {
	    layout = (layout + 1) & 15;
	  }
	  if (inkey == '<') {
	    usefeatures = 1 - usefeatures;
	  }
	  if (inkey == '=') {
	    bigflag = 1 - bigflag;
	  }
	  if (inkey == 'D') {
	    helpscreen ();
	    goto titleloop;	/* GOTO - Yetch! */
	  }
	  if (inkey) showmodes ();
	}  while (inkey != ' ' && inkey != 27);
	if (inkey == 27) {
	  fillscr ();
	  pause (10);
	}
	initsprites (-bigflag);
}

void clrgraph ()
{
	int xpos,ypos;
	initsprites (0);
	for (xpos = 2; xpos < 40; xpos ++) {
	  for (ypos = 2; ypos < 25; ypos ++) {
	    putat (xpos,ypos,Empty);
	  }
	}
	for (xpos = 1; xpos <= 40; xpos ++) {
	  putat ( xpos, 1, Edge);
	  putat ( xpos, 25, Edge);
	}
	for (ypos = 1; ypos <= 25; ypos ++) {
	  putat (  1, ypos, Edge);
	  putat ( 40, ypos, Edge);
	}
}

void helpscreen ()
{
	Hidescreen
	initsprites (1);
	gotoxy (1,3);
	getpal (10);
	prints (
"        Like all the best strategy games, CASCADE is easy to learn and\n"
"      yet tough to actually master. On playing the game you are presented\n"
"      with a maze of letters, scattered with balls and other objects.\n"
"      Each player (you v Computer) takes turns to remove a letter, and\n"
"      the balls cascade down the gaps left. On reaching the bottom, they\n"
"      will enter your hopper and add a value to your score. This value is\n"
"      normally 1, but is changed if a ball hits a NEGATOR or DOUBLER in\n"
"      its travels. NEGATORS and DOUBLERS act as TOGGLES - ie. hitting a\n"
"      DOUBLER once turns the mode on, hit it again and its switched off.\n"
"      Hitting a BONUS is normally worth 4 points, although this becomes\n"
"      -4 points if NEGATE mode is on, or double that if DOUBLE mode is on.\n"
"      If you hit a flask of GELIGNITE you will clear a path adjacent to\n"
"      that square. When you hit a REGENERATOR, part of the maze is\n"
"      regenerated, and some extra balls are dropped in at the top.\n"
"        Here is an index to the above objects..."
	);
	showborder ();
	getpal (15);
	Showscreen
	gotoxy (6,22);
	hitspace ();
	Hidescreen
        clrgraph ();
	printstrat ("CASCADE",16,3);
	printstrat ("\x1d = BALLS",14,6);
	printstrat ("\x1e = NEGATORS",14,8);
	printstrat ("` = DOUBLERS",14,10);
	printstrat ("\x1F = BONUSES",14,12);
	printstrat ("( = REGENERATOR",14,14);
	printstrat ("+ = GELIGNITE",14,16);
	printstrat ("HIT SPACE TO CONTINUE",10,23);
	Showscreen
	while (getkey () != ' ');
	Hidescreen
	initsprites (1);
	gotoxy (1,3);
	getpal (10);
	prints (
"        Notes/Hints: Since point scores can be negative, each player\n"
"      starts with 100 points. The LOWEST balls in the maze are dropped\n"
"      first - remember this when trying to hit targets. When a ball has\n"
"      an equal choice of two routes down (left or right), a random choice\n"
"      is made.\n"
"        To make moves during play, simply select the letter you want to\n"
"      remove by typing LOWERCASE a..z, or move the mouse to the letter and\n"
"      click the left button. Other Commands:\n"
"        F1 - Highlight letter - show positions of selected letter.\n"
"        F2 - Computer takes your go.  F3 - Auto play - Hit ESC to end.\n"
"        F4 - Change IQ level.\n"
"        F5 - Toggle Two-player mode on/off. F7 - Load a maze off disk.\n"
"        F6 - Enter EDIT MODE - Move cursor & type a..z, 0..9, F1..F4 keys\n"
"             to place objects in maze. Hit RETURN to get back to game.\n"
"        F8 - Save current maze to disk.\n"
	);
	showborder ();
	getpal (15);
	gotoxy (6,22);
	Showscreen
	hitspace ();
	initsprites (-bigflag);
}

void main ()
{
	testfly ();
	sprites = disksprites;
	#if (Noload == 0)
	  floaddata ("casc.spr", disksprites, Msprite);
	  if (diskerror)
	    return;
	#endif
	graphmode (3);
	frontscreen (1);
	if (xgamode == 0) bigflag = 0;
	if (xgamode == 99) return;
	initsprites (0);
	clrvdu ();
	do {
	  titlescreen ();
	  if (inkey == 3) {
	    graphmode (3);
	    return;
	  }
	  if (inkey == 27) break;
	  game ();
	  if (cmdkey == 3) {
	    graphmode (3);
	    return;
	  }
	} while (cmdkey != 3);
	#if Advert
	  do {
	    adscreen (0);
	    adscreen2 (0);
	  } while (regscreen () );
	#endif
	graphmode (3);
}


