/*  DROP-IT.C, Stategy game. 
      Copyright 1992-2014 A.Millett, PC Solutions. 

  Take DROP17.C 1992 orig, strip back to make simple C99 ver.
  Working as StdC console compile.
->DROPX30, 22.1.14.
  Sep engine & front end
  Imp n## - Set boardx/y size.
->DROPX31, 23.1.14
  Tidy more code..
  Convert evalpos/scanline to simpler non-macro version.
  (compiles using CLMAK DROPX.C, TNCMAK DROPX.C, TC2MAKE DROPX.C ..)
->DROPX32, 23.1.14
  Convert to K&R compatible fn calls.
->DROPX33, 23.1.14
  Imp full AlphaBeta() search..
  Imp nodecount.
->DROPX34 (24.1.14)
->DROPX35 (25.1.14)
  Bug in SmallC80, signed Compare fails for large vals.
->DROPX36 (26.1.14)

*/

#include <stdio.h>
#include <stdlib.h>

#define FALSE 0
#define TRUE  1


  /* map my print.. fns to std C lib */

#define printc putchar

char prbuffer [16];	/* Buffer for int-print */

prints (istr)  char *istr;	/* Print a null-term string */
{
	int cchr;
        for (cchr = 0; istr [cchr]; cchr ++) {
	  printc ( istr [cchr]);
	  if (istr [cchr] == 10) printc (13);
	}
}

  /* Print a signed int */

printi(x) int x;
{
	if (x<0) {
	 x = -x; printc ('-');
	}
        if (x>9) {
	  printi (x/10);
	}
        printc ('0' + x%10);
}

/* printi (iint) int iint;	
{
	int cchr;
	if (iint == 0) {
	  printc ('0');
	  return;
	}
	if (iint < 0) {
	  printc ('-');
	  iint = -iint;
	}
	for (cchr = 0; iint; cchr ++) {
	  prbuffer [cchr] = 48 + (iint % 10);
	  iint /= 10;
	}
	prbuffer [cchr] = 0;
	while (cchr) {
	  cchr --;
	  printc ( prbuffer [cchr]);
	}
} */

printsi (istr, iint) char *istr; int iint;		/* Composite short cut */
{
	prints (istr);
	printi (iint);
}

/*-------------------------------------------------
   Engine code starts here..
---------------------------------------------------*/

  /* Shared varibles, set by frontend */

int boardx = 7;		/* Board size */
int boardy = 6;
int losemode = 0;	/* Play to lose option */
int iqlevel = 5;	/* Level of play */
int automode = 0;
int twoplaymode = 0;
int inaline = 4;	/* # in a line wins/loses */

#define White 1		/* Board vals */
#define Black 2
#define Edge -4

  /* Private engine vars  */

int bmult;		/* Multiplier */
int cmdkey;
int pxpos,pypos; 	/* Player posn */
int cxpos,cypos;	/* Computer posn */
int xpos,ypos;		/* General pos */
int xdir,ydir;
int yoff;
int ccolor;		/* White = 1, Black = 2 */
int cpiece;

int bxpos,bypos;	/* Best xy pos */
int beval;		/* Best score */
int nodecount = 0;
int xeval;		/* Comp term eval score */
int ceval;		/* Temp eval score */
int nline;		/* No in line */
int mline;
int nclosed;		/* No of open ends */
int ngaps;		/* No of gaps in line */
int debugflag = 0;

int offseteval = 1;

char board [400];	/* Playing area */



	/* Eval scores nclosed 0,1,2 */
int wineval [24] =
	{ 0, 1,10,30,200, 2000, 0, 0,
	  0, 0, 5,10, 70, 2000, 0, 0,
	  0, 0, 0, 0,  0, 2000 }; 

/* ORIG: int wineval [24] =	
	{ 0, 1,10,30,200, 2000, 0, 0,
	  0, 0, 5,10, 70, 2000, 0, 0,
	  0, 0, 0, 0,  0, 2000 }; */

/* int wineval [24] =	
	{ 0, 1, 5,20,100, 2000, 0, 0,
	  0, 0, 2, 7, 50, 2000, 0, 0,
	  0, 0, 0, 0,  0, 2000 }; */

  /* Set a board pos */
Setboard (xpos,ypos,cpiece) int xpos,ypos,cpiece;
{
      board [xpos + ypos * bmult] = cpiece;
}

  /* Get a board pos */
Getboard (xpos,ypos) int xpos,ypos;
{
     return board [xpos + ypos * bmult];
}

newboard ()
{
	ccolor = White;
	bmult = boardx + 2;
	automode = 0;
	for (xpos = 1; xpos <= boardx; xpos ++) {
	  Setboard ( xpos, 0, Edge);
	  Setboard ( xpos, boardy + 1, Edge);
	  for (ypos = 1; ypos <= boardy; ypos ++) {
	    Setboard ( xpos, ypos, 0);
	  }
	}
	for (ypos = 0; ypos <= boardy + 1; ypos ++) {
	  Setboard ( 0, ypos, Edge);
	  Setboard ( boardx + 1, ypos, Edge);
	}
}

int winside,winpos,windir;

  /* See if win-line in this cdir? */

isWin (tpos, cdir) int tpos; int cdir;
{
	int cpos;
	while ( board [tpos] == ccolor) {	/* Back track */
	  tpos -= cdir;
	}
	tpos += cdir;
	winpos = tpos;			/* Save win-line pos/dir.. */
	windir = cdir;
	winside = ccolor;
	nline = 0;
	cpos = tpos;
	while ( board [cpos] == ccolor) {	/* Count line */
	  cpos += cdir;
	  nline ++;
	}
	if (nline < inaline)  return FALSE;		/* Nope */
	return TRUE;
}

  /* Ret TRUE if game over */
isGameOver (wxpos, wypos) int wxpos; int wypos;
{
	int tpos;
	tpos = wxpos + wypos * bmult;
	if (isWin (tpos,1)) return TRUE;
	if (isWin (tpos,bmult - 1)) return TRUE;
	if (isWin (tpos,bmult)) return TRUE;
	if (isWin (tpos,bmult + 1)) return TRUE;
	winside = 0;
	return FALSE;
}

	/* Computer Move evaluation functions */

  /* Scan line at (tpos,ccdir) & count how many in-a-row (nline,nclosed) for side (ccolor) */

scanline (tpos, icolor, ccdir) int tpos,icolor,ccdir;
{
	int tpiece;
	nline = 1;
	nclosed = 0;

	/* Count (nline,nclosed) in dir (ccdir) : Scandir (+ccdir) */
	if ( (tpiece = board [tpos + ccdir ]) == icolor) {
	  nline ++;
	  if ( (tpiece = board [tpos + ccdir + ccdir ]) == icolor) {
	    nline ++;
	    if ( (tpiece = board [tpos + ccdir + ccdir + ccdir ]) == icolor) {
	      nline ++;
	      if ( (tpiece = board [tpos + ccdir + ccdir + ccdir + ccdir ]) == icolor) {
	        nline ++;
	      } else if (tpiece) {
	        nclosed ++;
	      }
	    } else if (tpiece) {
	      nclosed ++;
	    }
	  } else if (tpiece) {
	    nclosed ++;
	  }
	} else if (tpiece) {
	  nclosed ++;
	}

	/* Count (nline,nclosed) in dir (-ccdir) : Scandir (-ccdir) */
	if ( (tpiece = board [tpos - ccdir ]) == icolor) {
	  nline ++;
	  if ( (tpiece = board [tpos - ccdir - ccdir ]) == icolor) {
	    nline ++;
	    if ( (tpiece = board [tpos - ccdir - ccdir - ccdir ]) == icolor) {
	      nline ++;
	      if ( (tpiece = board [tpos - ccdir - ccdir - ccdir - ccdir ]) == icolor) {
	        nline ++;
	      } else if (tpiece) {
	        nclosed ++;
	      }
	    } else if (tpiece) {
	      nclosed ++;
	    }
	  } else if (tpiece) {
	    nclosed ++;
	  }
	} else if (tpiece) {
	  nclosed ++;
	}

	/* (nclosed > 2) prints ("Nclosed > 2"); */
	if (nline >= inaline) {
	  mline = inaline; nline = inaline;
	}
	ceval += wineval [nline + (nclosed << 3) + offseteval];
}

  /* Term-node eval (cxpos,cypos,ccolor), ceval */

evalpos (ixpos, iypos, icolor) int ixpos, iypos, icolor;
{
	int tpos;
	tpos = ixpos + iypos * bmult;
	ceval = 0;
	mline = 0;
	scanline (tpos, icolor, 1);
	scanline (tpos, icolor, bmult - 1);
	scanline (tpos, icolor, bmult);
	scanline (tpos, icolor, bmult + 1);
	if (losemode) ceval = -ceval;
	return ceval;
}

  /* Find next vacant row on col. */

findypos (fxpos) int fxpos;
{
	int fypos;
	yoff = fxpos + boardy * bmult;
	for (fypos = boardy; fypos; fypos--) {
	  if ( board [yoff] == 0) return (fypos);
	  yoff -= bmult;
	}
	return (-1);
}

  /* Eval for (ccolor), ret best move (bxpos,bypos,beval) 
       Simple original 1 ply static search */

/* SIMPLE ENGINE

compmove ()
{
	bxpos = 0; bypos = 0;
        if ( ccolor == White)
	  beval = -32000;
	else
	  beval = -32000;

	for ( cxpos = 1; cxpos <= boardx; cxpos ++) {
	    cypos = findypos (cxpos);
            if ( cypos > 0) {
	      xeval = evalpos (cxpos, cypos, ccolor);
				/ * xeval += (rand () % 8 ) ; * /
	      xeval -= abs (cxpos - ((boardx >> 1) + 1));	/ * Center tropism * /
	      xeval += (evalpos (cxpos, cypos, 3 - ccolor) >> 1);
	      if (iqlevel > 1) {
                if (Getboard (cxpos,cypos - 1) == 0) {
		  ceval = evalpos (cxpos, cypos-1, ccolor);
		  xeval -= (ceval >> 3);
		  ceval = evalpos (cxpos, cypos-1, 3 - ccolor);
		  xeval -= (ceval >> 2);
		}
	      }
	      if (xeval > beval) {	/ * Found best move.. * /
		bxpos = cxpos;
		bypos = cypos;
                beval = xeval;
		printpos (bxpos, bypos, beval);
	      }
	    }
	}
}

*/

int startdepth;

#define WIN_EVAL 5000

AlphaBeta(depth, alpha, beta, upeval) int depth, alpha,beta,upeval;
{
    int seval;
    int sxpos,sypos;
    int neweval;
    int nmoves;

    nmoves = 0;
    for ( sxpos = 1; sxpos <= boardx; sxpos ++) {
      sypos = findypos (sxpos);
      if ( sypos > 0) {
        nmoves ++;
        neweval = upeval + evalpos (sxpos, sypos, ccolor);
	neweval -= (abs (sxpos - ((boardx >> 1) + 1)) << 2);	/* Center tropism */
	if (mline >= inaline) {
	  if (depth == startdepth) {
	    bxpos = sxpos; bypos = sypos;
	  }
	  nodecount ++;
	  return WIN_EVAL + depth;
	}
  	neweval += (evalpos (sxpos, sypos, 3-ccolor) >> 2);
		/* Do move */
	Setboard (sxpos,sypos,ccolor);
	ccolor = 3 - ccolor;
		/* Search deeper? */
	if (depth > 0) {
	  seval = -AlphaBeta (depth-1, -beta, -alpha, -neweval);
	} else {	
	  seval = neweval;	/* Use accumulated seval as score */
	  nodecount ++;
	}
		/* Undo move */
	Setboard (sxpos,sypos,0);
	ccolor = 3 - ccolor;
	if (debugflag) {
	  printsi (".",depth); printsi (":",sxpos); printsi ("=",seval);
	  if (seval > alpha) printc ('*');
	  if (depth == startdepth) prints ("\n");
	}
		/* First ply.. */
	if (depth == startdepth) {
	  if (seval > alpha) {
	    bxpos = sxpos; bypos = sypos;
	  }
	  sch_callback (sxpos, sypos, seval);
	}
	if (seval > alpha) {
	  alpha = seval;
	}
	if (seval >= beta) {
	  return beta;
	}
      }
    }
    if (nmoves == 0) {	/* No moves, drawn. */
      nodecount ++;
      return 0;	
    }
    return alpha;
}

compmove ()
{
    startdepth = iqlevel; 
    nodecount = 0;
    bxpos = -1;
    beval = AlphaBeta (iqlevel, -12000, 12000, 0);
}

/* 
int AlphaBeta(int depth, int alpha, int beta)
{
    if (depth == 0)
        return Evaluate();
    GenerateLegalMoves();
    while (MovesLeft()) {
        MakeNextMove();
        val = -AlphaBeta(depth - 1, -beta, -alpha);
        UnmakeMove();
        if (val >= beta)
            return beta;
        if (val > alpha)
            alpha = val;
    }
    return alpha;
}
*/

/*-------------------------------------------------
   Front end code starts here, simple console i.o
---------------------------------------------------*/

int flag_graphics = 1;		/* Enable ascii-art graphics */


char szGfx[] = "|    \0| ++ \0| /\\ \0|    \0| ++ \0| \\/ \0|    \0|    \0|    ";
char szPc[4] = ".*O";

  /* char szGfx[] = "|    \0| \\/ \0| /\\ \0|    \0| /\\ \0| \\/ \0|    \0|    \0|    ";  */

printpos (xpos, ypos, eval) int xpos; int ypos; int eval;
{
	/* printc (64 + xpos); printi (boardy + 1 - ypos); */
        printsi (" ",xpos);
	printsi ("=",eval);
}

sch_callback (sxpos, sypos, seval) int sxpos, sypos, seval;
{
    printpos (sxpos, sypos, seval);
}

drawboard ()
{
        int ch;
	int xpos,ypos,lin;
	prints ("\n");
	if (flag_graphics) {
	  for (ypos = 1; ypos <= boardy; ypos ++) {
	    for (lin = 0; lin <= 36; lin+=18) {
	      for (xpos = 1; xpos <= boardx; xpos ++) {
	        ch = Getboard(xpos,ypos);
		ch = (ch * 6) + lin;
	        prints(szGfx+ch);
	      }
	      prints ("|\n");
	    }
	  }
	  for (xpos = 1; xpos <= boardx; xpos ++) {
	    prints("+-");printc(48+xpos);prints("--");
	  }
	  prints("+\n");
	  return;
	} 
	for (ypos = 1; ypos <= boardy; ypos ++) {
	  for (xpos = 1; xpos <= boardx; xpos ++) {
	    ch = Getboard(xpos,ypos);
	    printc(szPc [ch]);
	  }
	  prints ("\n");
	}
	for (xpos = 1; xpos <= boardx; xpos ++) {
	  printc(48+xpos);
	}
	prints ("\n");
}

testend (xpos,ypos) int xpos,ypos;
{
	if (isGameOver (xpos, ypos) == 0) return 0;
	if (ccolor == White + losemode) {
	  prints ("White (*) wins!\n");
	} else {
	  prints ("Black (O) wins!\n");
	}
	return 1;
}

  /* Call engine to search for best move */

execcomp (hintmode) int hintmode;
{
	compmove ();		/* Find best comp bxpos,bypos */
	if (bxpos > 0 && bypos > 0) {
	  cxpos = bxpos; cypos = bypos;
	  ceval = evalpos (bxpos, bypos, ccolor);			/* 5 line ? */
	  if (hintmode) {
	    pxpos = cxpos; pypos = cypos;
	    prints (" Try ");
	    printpos (cxpos, cypos, beval);
	    return;
	  }
	  /* droppiece ( bxpos, bypos, ccolor); */
	  Setboard ( bxpos, bypos, ccolor);
	  prints ("\n I Move ");
	  pxpos = bxpos; pypos = bypos;
	  printpos (pxpos, pypos, beval);
	  printsi (", Nodes:",nodecount);
          prints ("\n");
	  if (mline >= inaline) {		/* Win.. */
	    testend (bxpos, bypos);
	    return;
	  }
	} else {
	  prints (" Drawn !\n");
	  automode = 0;
	}
}

char istr[100];		/* Input buffer */

game ()
{
      newboard ();
      twoplaymode = 0;
      ccolor = White;
      do {		/* Main playing loop */
        drawboard ();
	if (ccolor == White) {
	  prints ("White (*)");
	} else {
	  prints ("Black (O)");
	}
	prints (" to move.\nEnter command/move (1-9,gin[##]htvx) :");
	gets (istr);
	cmdkey = istr[0];
	if (cmdkey == 0) cmdkey = 'g';
	if (cmdkey == 'x') return;

		/* Move column 1-9 */
	if (cmdkey > '0' && cmdkey <= boardx + 48) {
	  pxpos = cmdkey & 15;
	  pypos = findypos (pxpos);
	  if ( pypos < 1) {
	    continue;
	  }
          ceval = evalpos (pxpos, pypos, ccolor);			/* win - line ? */
	  /* droppiece ( pxpos, pypos, ccolor); */
	  Setboard ( pxpos, pypos, ccolor);
	  if (mline >= inaline) {		/* Win.. */
	    testend (pxpos, pypos);
	    drawboard ();
	    newboard ();
	    continue;
	  }
	  ccolor = 3 - ccolor;
	  if (twoplaymode == 0) {
	    execcomp (0);
	    if (mline >= inaline) {
              drawboard ();
	      newboard ();
	      continue;
	    }
	    ccolor = 3 - ccolor;
	  }
	}

	if (cmdkey == 'i') {		/* i: Level of play */
	  iqlevel = istr [1] & 15;
	  printsi ("iq:",iqlevel);
	  continue;
	}

        if (cmdkey == '$') debugflag = !debugflag;

        if (cmdkey == 'g') {		/* g: Computer go .. */
	  execcomp (0);
	  if (mline >= inaline) {
            drawboard ();
	    newboard ();
	    continue;
	  }
	  ccolor = 3 - ccolor;
	}

        if (cmdkey == '?') {		/* HINT .. */
	  execcomp (1);
	}
	if (cmdkey == 'n') {		/* n: New game.. */
	  if (istr [1] > '3' && istr [2] > '3') {
	    boardx = istr [1] - '0';
	    boardy = istr [2] - '0';
	  }
	  newboard ();
	}
	if (cmdkey == 't') {
	  twoplaymode = 1 - twoplaymode;
	}
	if (cmdkey == 'v') {
	  flag_graphics = 1 - flag_graphics;
	}
      } while (1);
}

main ()
{
    game ();
}
