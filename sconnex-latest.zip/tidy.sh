#!/bin/sh
rm *.map 
rm *.lbl
rm *.int
rm sconnex-*.asm
