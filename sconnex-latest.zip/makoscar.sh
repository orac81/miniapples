#!/bin/sh
# Build sconnex with OSCAR64

oscar64 -D IS_8BIT=1 -D IS_CBM=1 -D IS_C64=1 -D USE_TIME=1 -D IS_HIRES=1 -D IS_OSCAR=1 -O2  -tm=c64 sconnex.c -o=sconnex-c64.prg
oscar64 -D IS_8BIT=1 -D IS_CBM=1 -D IS_C64=1 -D MINIMAL=1 -D USE_TIME=0 -D IS_HIRES=0 -D IS_OSCAR=1 -O2 -tm=c64 sconnex.c -o=sconnex-oscar-c64-minimal-petscii.prg # minimal version

#oscar64 -D IS_8BIT=1 -D IS_CBM=1 -D IS_VIC20=1 -D MINIMAL=1 -D USE_TIME=0 -D IS_HIRES=0 -D IS_OSCAR=1 -O2 -tm=vic20+8 sconnex.c -o=sconnex-oscar-vic20-small8k.prg  # minimal version
oscar64 -D IS_8BIT=1 -D IS_CBM=1 -D IS_VIC20=1 -D USE_TIME=1 -D IS_HIRES=1 -D IS_OSCAR=1 -O2 -tm=vic20+16 sconnex.c -o=sconnex-vic20-16k.prg

#oscar64 -D IS_8BIT=1 -D IS_CBM=1 -D IS_C16=1 -D USE_TIME=0 -D IS_HIRES=0 -D IS_OSCAR=1 -O2 -tm=plus4 sconnex.c -o=sconnex-oscar-c16-petscii.prg
oscar64 -D IS_8BIT=1 -D IS_CBM=1 -D IS_C16=1 -D USE_TIME=1 -D IS_HIRES=1 -D IS_OSCAR=1 -O2 -tm=plus4 sconnex.c -o=sconnex-c16.prg

oscar64 -D IS_8BIT=1 -D IS_CBM=1 -D IS_PET=1 -D USE_TIME=0 -D IS_HIRES=0 -D IS_OSCAR=1 -O2 -tm=pet sconnex.c -o=sconnex-pet.prg
oscar64 -D IS_8BIT=1 -D IS_CBM=1 -D IS_PET=1 -D USE_TIME=0 -D IS_HIRES=0 -D MINIMAL -D IS_OSCAR=1 -O2 -tm=pet sconnex.c -o=sconnex-pet-minimal.prg

