#!/bin/sh
# Build SCONNEX-C99.ELF
cc -o sconnex-c99.elf sconnex.c -Os -DIS_C99 -DUSE_TIME
strip sconnex-c99.elf

# Build SCONNEX-SDL.ELF
#./sdlmak sconnex sdlwio.c -Os -DIS_SDL -DUSE_TIME
cc -o sconnex-sdl.elf sconnex.c sdlwio.c -Os -DIS_SDL -DUSE_TIME `sdl2-config --cflags --libs`
strip sconnex-sdl.elf
