/* SCONNEX.  Classic "Four Balls in a line" game. 
   (C) A.Millett 1982-2025. Released as free software under GPL3.
 
To build C99 text console version:
  cc -o sconnex.elf sconnex.c -Os -DIS_C99

To build SDL2 version: ./sdlmak sconnex sdlwio.c -Os -DIS_SDL
    (or: gcc -o sconnex.elf sconnex.c sdlwio.c -Os -DIS_SDL `sdl2-config --cflags --libs`)

To build other versions, use -DIS_8BIT (see #if IS_8BIT  below)

To install/build SDL2, extract source, type: ./configure;  make; sudo make install  

History: - import "simple" version CONNEXC..
  Take DROP17.C 1992 orig, strip back to make simple C99 ver.
  Working as StdC console compile.
->DROPX30, 22.1.14.
  Sep engine & front end
  Imp n## - Set sch_boardx/y size.
->DROPX31, 23.1.14
  Tidy more code..
  Convert sch_EvalPos/sch_ScanLine to simpler non-macro version.
  (compiles using CLMAK DROPX.C, TNCMAK DROPX.C, TC2MAKE DROPX.C ..)
->DROPX32, 23.1.14
  Convert to K&R compatible fn calls.
->DROPX33, 23.1.14
  Imp full sch_AlphaBeta() search..
  Imp nodecount.
->DROPX34 (24.1.14)
->DROPX35 (25.1.14)
  Bug in SmallC80, signed Compare fails for large vals.
->DROPX36 (26.1.14)
  Imp 8bit optimisations. Convert back from K+R.
->CONNEXC42 (5.11.2024)
  [orig:iq=3:mv2,781n,i5=m4,12805n,ev14.i7=m4,185525n,ev-20.i8=907092,i9=2995461.i10=14825194
    i11=50762660,i12=mv4,243348741n,ev69,34s. i13=mv2,783442831n,-44,116s]
2do: Imp 8bit opt (BYTE ints etc). Imp fixed BMULT (<<4), const dir.  Imp help. Imp n#,#. Imp i# (iq). Imp r# (rnd).  
  Imp deep scan if play on same column as last move.
  IS_VIC/C16/C64/PET macro, set color, PETSCII, CLS etc. Build for CC65/VBCC/LLVM.
  Imp simple order improve, start at 1/2-1 pos. 
-----------------------------------------------
  Imp SDL version, imp IS_C99, IS_SDL.
-> SCONNEX141  (8.2.2025)
  Imp Go, new, very elementary version running under SDL. (printing txt to console window)
-> SCONNEX142  (8.2.2025)
  Imp playermove(), input using: SDL_MOUSEBUTTONDOWN, sEvent.button.x
  Imp flag_gfx, cmd V, toggle primitive drawn graphics.
  Imp cmd X,Y change sch_Board size.
-> SCONNEX143  (9.2.2025)
  Imp sdltxt_ bmp font rendering library.
  remove SDL_CreateSoftwareRenderer, use "modern" render loop. 
  Imp redrawAll(), drawText()..
-> SCONNEX144  (14.2.2025)
  Imp pTextureBmp, rendering bmps by Texture.
  Imp more drawing functions, mov/eval/node/2play/etc.
  Imp flag_edit.
-> SCONNEX145  (14.2.2025)
  Remove console txt output.
  Imp BRD_BORDER, drawborder()
-> SCONNEX146  (23.2.2025)
  Imp SDLTOOL_ toolbar functions.
-> SCONNEX147  (23.2.2025)
  Create sdlwio.c, move font/toolbar there.
  Imp anim drop piece.
-> SCONNEX148  (26.2.2025)
  Imp full toolbar. Imp eng callback display move.
-> SCONNEX149  (28.2.2025)
  Imp win-line display, simplify gameover code.
  Imp better font.
-> SCONNEX150  (2.3.2025)
-> SCONNEX151  (2.3.2025)
  Imp USE_TIME.
  Tidy up C99 console code.
-> SCONNEX152  (9.3.2025)
  Imp SCH_SIMPLE_ORDER - search center moves first.
   (SCH_SIMPLE_ORDER: i13=mv2,98448147n,ev-44,16s. 10xfaster)
-> SCONNEX153  (11.3.2025)
  Imp gameHelp() SDL help/title screen
-> SCONNEX154  (14.3.2025)
  CBM quick patch C99 ver.
-> SCONNEX155  (14.3.2025)
  Use -DIS_SDL or -DIS_C99 to define target system.
  Imp IS_8BIT and IS_ZX81 simple zx81 version.   
-> SCONNEX156  (29.6.2025)
  Imp more ZX81 bits
-> SCONNEX157  (3.7.2025)
  Make fairly complete ZX81 version
  Start IS_CBM64 version.
-> SCONNEX158  (5.7.2025)
  Imp more of C64 version, hires gfx. works ok.
-> SCONNEX159  (6.7.2025)
  Imp C16 ver
-> SCONNEX160  (9.7.2025)
  Imp V20, use VBCC. imp CBMIO-VBCC.ASM lib.
  Imp C16, PET ver, use VBCC. 
  imp CBMIO-VBCC.ASM lib. (prn/get chr)
-> SCONNEX161  (11.7.2025)
-> SCONNEX161  (12.7.2025)
  Imp IS_SPEC, simple ver runs.
-> SCONNEX162  (13.7.2025)
  More messing with Spec/z88, add asm routines..
-> SCONNEX163  (14.7.2025)
  Tidy up spectrum version, working ok.
  Tidy up ZX81 version, mostly ok.
-> SCONNEX164  (15.7.2025)
  Small tweaks.
-> SCONNEX165  (17.7.2025)
  Change +4 ver to run on C16.
  Imp IS_HIRES for VIC20.
-> SCONNEX166  (20.7.2025)
  Change to clock() 
  Small changes to build with CC65
-> SCONNEX167  (31.7.2025)
  Changes to build with OSCAR64, ie add (char *) to all string parms.
-> SCONNEX168  (3.8.2025)
  Changes to build with OSCAR64.. imp USE_OSCAR, io_init_compiler(). use #ifdef.
-> SCONNEX169  (6.8.2025)
-> SCONNEX170  (7.8.2025)
  Build C16 & VIC20 verisons for OSCAR.
-> SCONNEX171  (7.8.2025)

[OSCAR-BENCH:new,iq5:12s,3283n.iq6:57s,16550n. iq7:193s,-13383n.]
[VBCC:iq5:23s,3283n. iq6:111s,16550n. iq7:371,-13383n]
[CC65:iq5:37s,3283n. iq6:171s,16550n. iq7:575s,-13383n]

2do:Toolbar. brd border. del conprn. anim mv/win. eng-thread. draw detect. help/title screen. sdltxt - big fonts.
  eng-sort moves. time/node ctl, iterate. rnd.
*/

#ifdef IS_VIC20
 #if IS_HIRES
  #include <c64/memmap.h>
	// Force VIC20 start up high for hires gfx
  #pragma region( main, 0x1c00, 0x6000, , , {code, data, bss, heap, stack} )
 #endif
#endif

char szProg [] = " SDL-CONNEX 1.71. (C)A.Millett 2015-25";
char szProg2 [] = "\n Released as freeware under GPL";

#define FALSE 0
#define TRUE  1

typedef unsigned char BYTE;
typedef unsigned char UINTBY;		/* A UINT that can be a BYTE, speedup 8bit CPUs:6502/z80.. */
typedef unsigned int UINT;	
#define XSTATIC static			/* Variable can be static */

		/* Set JUST ONE of these defs:  -DIS_SDL, -DIS_C99, _DIS_8BIT .. */
// #define IS_SDL 1	/* SDL version */
// #define IS_C99 0	/* Simple text console version */

// #define USE_TIME     1		/* Use time functions */
// #define IS_CBM       0		/* Also set IS_C99 above (1=c64,2=v20,3=c16) */

/*
#ifndef IS_C99
 #ifndef IS_SDL
  #ifndef IS_8BIT
   #define IS_C99	// Default to IS_C99 (std txt console) if nothing else specified
  #endif
 #endif
#endif
*/

#include <stdio.h>
#include <stdlib.h>


#if USE_TIME
 #include <time.h>		// For clock()
#endif

#define MY_DEBUG 0

#if MY_DEBUG
 #define MY_ASSERT(EX) { if ((EX) == FALSE) { io_prints ((char *) "Error."); exit(1);}  }
#else 
 #define MY_ASSERT(EX) ;
#endif

/*-----------------------------------------------------------------------
   Simple console functions
-------------------------------------------------------------------------*/

#define IO_TOUPPER(CH) (((CH)>='a' && (CH)<='z') ? (CH)-'a'+'A' : (CH))
#define IO_TOLOWER(CH) (((CH)>='A' && (CH)<='Z') ? (CH)-'A'+'a' : (CH))

BYTE io_flag_add_cr = 1;		/* Add CR if LF sent */

//#define io_printc putchar
void io_printc (char c) ;		// Fwd declare


	/* Print a null-term string */
void io_prints (char *pStr)	
{
	char ch;
	while (ch = *pStr) {
	  io_printc ( ch);
	  if (ch == 10 && io_flag_add_cr) io_printc (13);
	  ++ pStr;
	}
}

  /* Print a signed int */
void io_printi (int x)		
{
	if (x<0) {
	 x = -x; io_printc ('-');
	}
        if (x>9) {
	  io_printi (x/10);
	}
        io_printc ('0' + x%10);
}

		/* Composite short cut */
void io_printsi (char *istr, int iint)
{
	io_prints (istr);
	io_printi (iint);
}

#define io_isdigit(x) ((x)>='0' && (x)<='9')

  /* Simple asc to int */
int io_atoi (char *pStr)
{
    int val = 0;
    while (io_isdigit (*pStr)) {
      val = val * 10 + *pStr - '0';
      pStr ++;
    }
    return val;
}

/*-----------------------------------------------------------------------
   Engine code starts here..
-------------------------------------------------------------------------*/

void sch_callback (UINTBY sxpos, UINTBY sypos, int seval);		/* Fwd dec */

#define SCH_EXT_REPLY 1		/* Extend a ply by looking at reply at end of sch */
#define SCH_SIMPLE_ORDER 1	/* Scan from center */
#define SCH_DOUBLE1ST 1 		/* Double first eval */

  /* Shared varibles, set by frontend */

UINTBY sch_boardx = 8;		/* Board size */
UINTBY sch_boardy = 8;
UINTBY sch_LoseMode = 0;	/* Play to lose option */
UINTBY sch_level = 8;	/* Level of play */
UINTBY automode = 0;
UINTBY flag_twoplay = 0;
UINTBY sch_inaline = 4;	/* # in a line wins/loses */
UINTBY flag_edit = 0;
UINTBY flag_misc = 1;	/* Assort test */

#define White 1		/* Board vals */
#define Black 2
#define Edge  4

#define DRAWN 3
#define BMULT 16	/* Board multiply for ypos */

#define WIN_EVAL 5000

  /* Board pos conversion macros  */
#define BoardPos(xpos,ypos) ( ((ypos) << 4) + (xpos))
#define SetBoard(xpos,ypos,cpiece) sch_Board [BoardPos (xpos, ypos)] = cpiece;
#define GetBoard(xpos,ypos) sch_Board [BoardPos (xpos, ypos)]
#define Pos2X(bpos) ((bpos) & 15)
#define Pos2Y(bpos) ((bpos) >> 4)


  /* Private engine vars  */

UINTBY gameover;		/* Game is over (1=white win, 2=bwin,3=draw) */
UINTBY winpos,windir;	/* Pos/dir of winning move */
//UINTBY BMULT;		/* Multiplier */
UINTBY cmdkey;
UINTBY pxpos,pypos; 	/* Player posn */
UINTBY cxpos,cypos;	/* Computer posn */
UINTBY xpos,ypos;		/* General pos */
UINTBY xdir,ydir;
UINTBY yoff;
UINTBY sch_side;		/* White = 1, Black = 2 */
UINTBY cpiece;

UINTBY sch_bestx, sch_besty;	/* Best xy pos */
int beval;		/* Best score */

#ifdef IS_SDL
 long nodecount = 0;
#else
 int nodecount = 0;
#endif

#if USE_TIME
 clock_t sch_timeStart;
 UINT sch_timeMove = 0;
#endif

int xeval;		/* Comp term eval score */
int ceval;		/* Temp eval score */
UINTBY nline;		/* No in line */
UINTBY mline;
UINTBY nclosed;		/* No of open ends */
UINTBY ngaps;		/* No of gaps in line */
UINTBY debugflag = 0;

int offseteval = 1;
UINTBY lastx = 0;		/* Last move played */
UINTBY lasty = 0;

#define MAXBOARD 250
BYTE sch_Board [MAXBOARD+4];	/* Playing area */

BYTE idx [20];
 
	/* Eval scores nclosed 0,1,2 */
int wineval [24] =
	{ 0, 1,10,30,200, 2000, 0, 0,
	  0, 0, 5,10, 70, 2000, 0, 0,
	  0, 0, 0, 0,  0, 2000 }; 

int startdepth;

	/* Start new game */
void sch_NewGame ()
{
	flag_twoplay = 0;
	pxpos = sch_bestx = beval = 0;
	gameover = 0;
	flag_edit = 0;
	winpos = 0;
	lastx = 0;
	sch_side = White;
	//BMULT = sch_boardx + 2;
	automode = 0;
		/* Fill sch_Board with non-play sqrs */
	for (xpos = 0; xpos < MAXBOARD; xpos ++) {
	  sch_Board [xpos] = Edge;
	}
		/* Clr play area */
	for (xpos = 1; xpos <= sch_boardx; xpos ++) {
	  for (ypos = 1; ypos <= sch_boardy; ypos ++) {
	    SetBoard ( xpos, ypos, 0);
	  }
	}
}


  /* See if move makes win-line in this cdir? */

UINTBY sch_isWin (UINTBY tpos, UINTBY cdir) 			/*KR sch_isWin (tpos, cdir) int tpos; int cdir; */
{
	UINTBY cpos;
	while ( sch_Board [tpos] == sch_side) {	/* Back track */
	  tpos -= cdir;
	}
	tpos += cdir;
	nline = 0;
	cpos = tpos;
	while ( sch_Board [cpos] == sch_side) {	/* Count line */
	  cpos += cdir;
	  nline ++;
	}
	if (nline < sch_inaline) return FALSE;		/* Nope */
	winpos = tpos;			/* Save win-line pos/dir.. */
	windir = cdir;
	gameover = sch_side;
	return TRUE;
}

  /* Ret TRUE if game over */
UINTBY sch_isGameOver (UINTBY wxpos, UINTBY wypos)		
{
	int tpos;
	UINTBY xpos;
	tpos = BoardPos (wxpos, wypos);
	gameover = 0;
	if (sch_isWin (tpos,1)) return TRUE;
	if (sch_isWin (tpos,BMULT - 1)) return TRUE;
	if (sch_isWin (tpos,BMULT)) return TRUE;
	if (sch_isWin (tpos,BMULT + 1)) return TRUE;
		/* See if top row is full (=draw) */
        for (xpos = 1; xpos <= sch_boardx; xpos ++) {
          if (GetBoard (xpos,1) == 0) return FALSE;
        }
	gameover = DRAWN;
	return TRUE;
}

	/* Computer Move evaluation functions */

  /* Scan line at (tpos,ccdir) & count how many in-a-row (nline,nclosed) for side (sch_side) */

void sch_ScanLine (UINTBY tpos, UINTBY icolor, UINTBY ccdir)	
{
	UINTBY tpiece;
	nline = 1;
	nclosed = 0;

	/* Count (nline,nclosed) in dir (ccdir) : Scandir (+ccdir) */
	if ( (tpiece = sch_Board [tpos + ccdir ]) == icolor) {
	  nline ++;
	  if ( (tpiece = sch_Board [tpos + ccdir + ccdir ]) == icolor) {
	    nline ++;
	    if ( (tpiece = sch_Board [tpos + ccdir + ccdir + ccdir ]) == icolor) {
	      nline ++;
	      if ( (tpiece = sch_Board [tpos + ccdir + ccdir + ccdir + ccdir ]) == icolor) {
	        nline ++;
	      } else if (tpiece) {
	        nclosed ++;
	      }
	    } else if (tpiece) {
	      nclosed ++;
	    }
	  } else if (tpiece) {
	    nclosed ++;
	  }
	} else if (tpiece) {
	  nclosed ++;
	}

	/* Count (nline,nclosed) in dir (-ccdir) : Scandir (-ccdir) */
	if ( (tpiece = sch_Board [tpos - ccdir ]) == icolor) {
	  nline ++;
	  if ( (tpiece = sch_Board [tpos - ccdir - ccdir ]) == icolor) {
	    nline ++;
	    if ( (tpiece = sch_Board [tpos - ccdir - ccdir - ccdir ]) == icolor) {
	      nline ++;
	      if ( (tpiece = sch_Board [tpos - ccdir - ccdir - ccdir - ccdir ]) == icolor) {
	        nline ++;
	      } else if (tpiece) {
	        nclosed ++;
	      }
	    } else if (tpiece) {
	      nclosed ++;
	    }
	  } else if (tpiece) {
	    nclosed ++;
	  }
	} else if (tpiece) {
	  nclosed ++;
	}

	/* (nclosed > 2) io_prints ((char *) "Nclosed > 2"); */
	if (nline >= sch_inaline) {
	  mline = sch_inaline; nline = sch_inaline;
	}
	ceval += wineval [nline + (nclosed << 3) + offseteval];
}

  /* Term-node eval (cxpos,cypos,sch_side), ceval */

int sch_EvalPos (UINTBY ixpos, UINTBY iypos, UINTBY icolor)	
{
	UINTBY tpos;
	tpos = BoardPos (ixpos, iypos);
	ceval = 0;
	mline = 0;
	sch_ScanLine (tpos, icolor, 1);
	sch_ScanLine (tpos, icolor, BMULT - 1);
	sch_ScanLine (tpos, icolor, BMULT);
	sch_ScanLine (tpos, icolor, BMULT + 1);
	if (sch_LoseMode) ceval = -ceval;
	return ceval;
}

  /* Find next vacant row on col. */

UINTBY sch_FindYPos (UINTBY fxpos)		
{
	UINTBY fypos;
	yoff = BoardPos (fxpos, sch_boardy);
	for (fypos = sch_boardy; fypos; fypos--) {
	  if ( sch_Board [yoff] == 0) return (fypos);
	  yoff -= BMULT;
	}
	return (0);
}

  /* Eval for (sch_side), ret best move (sch_bestx,sch_besty,beval) 
       Simple original 1 ply static search */

/* SIMPLE ENGINE

sch_CompMove ()
{
	sch_bestx = 0; sch_besty = 0;
        if ( sch_side == White)
	  beval = -32000;
	else
	  beval = -32000;

	for ( cxpos = 1; cxpos <= sch_boardx; cxpos ++) {
	    cypos = sch_FindYPos (cxpos);
            if ( cypos > 0) {
	      xeval = sch_EvalPos (cxpos, cypos, sch_side);
				/ * xeval += (rand () % 8 ) ; * /
	      xeval -= abs (cxpos - ((sch_boardx >> 1) + 1));	/ * Center tropism * /
	      xeval += (sch_EvalPos (cxpos, cypos, 3 - sch_side) >> 1);
	      if (sch_level > 1) {
                if (GetBoard (cxpos,cypos - 1) == 0) {
		  ceval = sch_EvalPos (cxpos, cypos-1, sch_side);
		  xeval -= (ceval >> 3);
		  ceval = sch_EvalPos (cxpos, cypos-1, 3 - sch_side);
		  xeval -= (ceval >> 2);
		}
	      }
	      if (xeval > beval) {	/ * Found best move.. * /
		sch_bestx = cxpos;
		sch_besty = cypos;
                beval = xeval;
		printpos (sch_bestx, sch_besty, beval);
	      }
	    }
	}
}

*/

  /* Routine recursively searches a position for the best move. (sch_bestx,sch_besty) */
  
int sch_AlphaBeta (UINTBY depth, int alpha, int beta, int upeval)		
{
    int seval;
    UINTBY sxpos,sypos;
    int neweval;
    UINTBY nmoves;
    UINTBY cmov;

    nmoves = 0;
    for ( cmov = 1; cmov <= sch_boardx; cmov ++) {
      sxpos = idx [cmov];
      sypos = sch_FindYPos (sxpos);
      if ( sypos > 0) {
        nmoves ++;
        neweval = upeval + sch_EvalPos (sxpos, sypos, sch_side);
	neweval -= (abs (sxpos - ((sch_boardx >> 1) + 1)) << 2);	/* Center tropism */
	if (mline >= sch_inaline) {	/* Winning move */
		/* First ply.. */
	  if (depth == startdepth) {
	    sch_bestx = sxpos; sch_besty = sypos;
	  }
	  nodecount ++;
	  if (sch_LoseMode) return -(WIN_EVAL + depth);
	  return WIN_EVAL + depth;
	}
  	neweval += (sch_EvalPos (sxpos, sypos, 3-sch_side) >> 2);
	#if SCH_DOUBLE1ST
	 if (depth == startdepth) {	/* Double eval for first ply */
	   neweval += neweval;
	 }
	#endif
		/* Do move */
	SetBoard (sxpos,sypos,sch_side);
	sch_side = 3 - sch_side;
		/* Search deeper? */
	if (depth > 0) {
	  seval = -sch_AlphaBeta (depth-1, -beta, -alpha, -neweval);
	} else {	
	  #if SCH_EXT_REPLY
	    if (flag_misc && sypos > 1) {	/* Subtract eval for reply on same xpos */
	      neweval -= sch_EvalPos (sxpos, sypos-1, 3 - sch_side)/2;
	    }
	  #endif
	  seval = neweval;	/* Use accumulated seval as score */
	  nodecount ++;
	}
		/* Undo move */
	SetBoard (sxpos,sypos,0);
	sch_side = 3 - sch_side;
	if (debugflag) {
	  io_printsi ((char *) ".",depth); io_printsi ((char *) ":",sxpos); io_printsi ((char *) "=",seval);
	  if (seval > alpha) io_printc ('*');
	  if (depth == startdepth) io_prints ((char *) "\n");
	}
		/* First ply.. */
	if (depth == startdepth) {
	  if (seval > alpha) {
	    sch_bestx = sxpos; sch_besty = sypos;
	  }
	  #if USE_TIME
	    sch_timeMove = (UINT) ((clock_t) (clock () - sch_timeStart) / CLOCKS_PER_SEC);
	  #endif
	  sch_callback (sxpos, sypos, seval);
	}
	if (seval > alpha) {
	  alpha = seval;
	}
	if (seval >= beta) {
	  return beta;
	}
      }
    }
    if (nmoves == 0) {	/* No moves, drawn. */
      nodecount ++;
      return 0;	
    }
    return alpha;
}

void sch_GenInitialOrder ()
{
    UINTBY i,x,x2;
    #if SCH_SIMPLE_ORDER
    i = 1;
    for (x = (sch_boardx + 1)/2; x; x--) {
      idx [i] = x; i ++;
      x2 = sch_boardx + 1 - x;
      if (x2 != x) {
        idx [i] = x2; i ++;
      }
    }
    #else
      for (x = 1; x <= sch_boardx; x++) {
        idx [x] = x;
      }
    #endif
}

  /* Find best move.. */
void sch_CompMove ()	
{
    #if USE_TIME
      sch_timeStart = clock ();
      sch_timeMove = 0;
    #endif
    sch_GenInitialOrder ();
    startdepth = sch_level; 
    nodecount = 0;
    sch_bestx = 0;
    beval = sch_AlphaBeta (sch_level, -12000, 12000, 0);
    #if USE_TIME
      sch_timeMove = (UINT) ((clock_t) (clock () - sch_timeStart) / CLOCKS_PER_SEC);
    #endif
}

/* 
int sch_AlphaBeta(int depth, int alpha, int beta)
{
    if (depth == 0)
        return Evaluate();
    GenerateLegalMoves();
    while (MovesLeft()) {
        MakeNextMove();
        val = -sch_AlphaBeta(depth - 1, -beta, -alpha);
        UnmakeMove();
        if (val >= beta)
            return beta;
        if (val > alpha)
            alpha = val;
    }
    return alpha;
}
*/


/*--------------------------------------------------------------------------
   C99: Text only front-end code starts here, simple console i.o
----------------------------------------------------------------------------*/

#ifdef IS_C99

void io_printc (char c) 
{
    putchar (c);
}

int flag_graphics = 1;		/* Enable ascii-art graphics */


char szGfx[] = "|    \0| ++ \0| /\\ \0|    \0| ++ \0| \\/ \0|    \0|    \0|    ";
char szPc[4] = ".*O";

  /* char szGfx[] = "|    \0| \\/ \0| /\\ \0|    \0| /\\ \0| \\/ \0|    \0|    \0|    ";  */

void printpos (UINTBY xpos, UINTBY ypos, int eval)		/* printpos (xpos, ypos, eval) int xpos; int ypos; int eval; */
{
	/* io_printc (64 + xpos); io_printi (sch_boardy + 1 - ypos); */
        io_printsi ((char *) " ",xpos);
	io_printsi ((char *) "=",eval);
}

void sch_callback (UINTBY sxpos, UINTBY sypos, int seval)		/*KR sch_callback (sxpos, sypos, seval) int sxpos, sypos, seval; */
{
    printpos (sxpos, sypos, seval);
	#if USE_TIME
	  io_printsi ((char *) ", ", sch_timeMove);
	#endif
	io_printsi ((char *) "s, ",nodecount);
	io_prints ((char *) "n  \n");
}

void drawboard () 	
{
        UINTBY ch;
	UINTBY xpos,ypos,lin;
	io_prints ((char *) "\n");
	if (flag_graphics) {
	  for (ypos = 1; ypos <= sch_boardy; ypos ++) {
	    for (lin = 0; lin <= 36; lin+=18) {
	      for (xpos = 1; xpos <= sch_boardx; xpos ++) {
	        ch = GetBoard(xpos,ypos);
		ch = (ch * 6) + lin;
	        io_prints(szGfx+ch);
	      }
	      io_prints ((char *) "|\n");
	    }
	  }
	  for (xpos = 1; xpos <= sch_boardx; xpos ++) {
	    io_printsi((char *) "+-",xpos); io_prints((char *) "-"); 
	    if (xpos < 10) io_prints ((char *) "-");
	  }
	  io_prints((char *) "+\n");
	  return;
	} 
	for (ypos = 1; ypos <= sch_boardy; ypos ++) {
	  for (xpos = 1; xpos <= sch_boardx; xpos ++) {
	    ch = GetBoard(xpos,ypos);
	    io_printc(szPc [ch]);
	  }
	  io_prints ((char *) "\n");
	}
	for (xpos = 1; xpos <= sch_boardx; xpos ++) {
	  io_printc(48+(xpos % 10));
	}
	io_prints ((char *) "\n");
}

UINTBY testend (UINTBY xpos, UINTBY ypos)		/*KR testend (xpos,ypos) int xpos,ypos; */
{
	if (sch_isGameOver (xpos, ypos) == 0) return 0;
	if (sch_side == White + sch_LoseMode) {
	  io_prints ((char *) "White (*) wins!\n");
	} else {
	  io_prints ((char *) "Black (O) wins!\n");
	}
	return 1;
}

  /* Call engine to search for best move */
void execcomp (UINTBY hintmode)			/*KR execcomp (hintmode) int hintmode; */
{
	sch_CompMove ();		/* Find best comp sch_bestx,sch_besty */
	if (sch_bestx > 0 && sch_besty > 0) {
	  cxpos = sch_bestx; cypos = sch_besty;
	  ceval = sch_EvalPos (sch_bestx, sch_besty, sch_side);			/* 5 line ? */
	  if (hintmode) {
	    pxpos = cxpos; pypos = cypos;
	    io_prints ((char *) " Try ");
	    printpos (cxpos, cypos, beval);
	    return;
	  }
	  /* droppiece ( sch_bestx, sch_besty, sch_side); */
	  SetBoard ( sch_bestx, sch_besty, sch_side);
	  io_prints ((char *) "\n I Move ");
	  pxpos = sch_bestx; pypos = sch_besty;
	  printpos (pxpos, pypos, beval);
	  #if USE_TIME
	    io_printsi ((char *) ", Time:", sch_timeMove);
	  #endif
	  io_printsi ((char *) ", Nodes:",nodecount);
          io_prints ((char *) "\n");
	  testend (sch_bestx, sch_besty);
	  if (gameover) {		/* Win */
	    return;
	  }
	} else {
	  gameover = DRAWN;
	  io_prints ((char *) " Drawn !\n");
	  automode = 0;
	}
}

void gamehelp ()
{
  io_prints ((char *) "\n");
  io_prints (szProg);
  io_prints (szProg2);
  io_prints ((char *)
    "\n\n In this game each player takes turns to drop a stone on\n"
    " a grid. The first player to get 4 pieces in a line wins.\n"
    "\nCOMMANDS:\n"
    " n  - New game. (nx# = set board width (4-12), ny# set height) ie: n <ENTER> \n"
    " #  - Enter move column 1-12. ie: 4 <ENTER> \n"
    " g  - Make computer take current go. (Also just <ENTER> does this.) \n"
    " i# - Set iq search level (1-16) high levels can be slow.\n"
    " ?  - Ask for hint.\n"
    " t  - Toggle two player mode \n"
    " v  - Toggle small/large graphics \n"
    " x  - Exit game\n"
    "\n"); 
}

char istr[100];		/* Input buffer */

  /* C99 game loop, input commands by console */

void gameLoop ()	
{
      int cpos;
      sch_NewGame ();
      flag_twoplay = 0;
      sch_side = White;
      do {		/* Main playing loop */
        drawboard ();
game_noboard:
	if (sch_side == White) {
	  io_prints ((char *) "White (*)");
	} else {
	  io_prints ((char *) "Black (O)");
	}
	io_prints ((char *) " to move.\nEnter command/move (1-9,gintvx?,h=help) :");
	gets (istr);
	cmdkey = istr[0];
	if (cmdkey == 0) cmdkey = 'g';
	if (cmdkey == 'x') return;

		/* Move column 1-9 */
        cpos = io_atoi (istr);
	if (cpos && cpos <= sch_boardx && gameover == 0) {
	  pxpos = cpos;
	  pypos = sch_FindYPos (pxpos);
	  if ( pypos < 1) {
	    continue;
	  }
          ceval = sch_EvalPos (pxpos, pypos, sch_side);			/* win - line ? */
	  /* droppiece ( pxpos, pypos, sch_side); */
	  SetBoard ( pxpos, pypos, sch_side);
	  if (mline >= sch_inaline) {		/* Win.. */
	    testend (pxpos, pypos);
	    continue;
	  }
	  sch_side = 3 - sch_side;
	  if (flag_twoplay == 0) {
	    execcomp (0);
	    sch_side = 3 - sch_side;
	  }
	}

	if (cmdkey == 'i') {		/* i: Level of play */
	  if (istr [1]) { 
	    sch_level = io_atoi (istr + 1);
	  }
	  io_printsi ((char *) "iq:",sch_level);
	  continue;
	}

        if (cmdkey == '$') debugflag = !debugflag;

        if (cmdkey == 'g') {		/* g: Computer go .. */
	  if (gameover) {		/* If gameover, start new game */
	    sch_NewGame ();
	  }
	  execcomp (0);
	  sch_side = 3 - sch_side;
	}

        if (cmdkey == '?') {		/* HINT .. */
	  execcomp (1);
	}
	if (cmdkey == 'n') {		/* n: New game.. */
          if (istr [1] == 'x') {	/* nx#  Set width (4-12) */
            cpos = io_atoi (istr + 2);
	    if (cpos >= 4 && cpos <= 12) {
	      sch_boardx = cpos;
	    }
	  }
          if (istr [1] == 'y') {	/* ny#  Set height (4-12) */
            cpos = io_atoi (istr + 2);
	    if (cpos >= 4 && cpos <= 12) {
	      sch_boardy = cpos;
	    }
	  }
	  sch_NewGame ();
	}
	if (cmdkey == 't') {
	  flag_twoplay = 1 - flag_twoplay;
	}
	if (cmdkey == 'v') {
	  flag_graphics = 1 - flag_graphics;
	}
	if (cmdkey == 'h') {
	  gamehelp ();
	  goto game_noboard;
	}
      } while (1);
}

void main ()		
{
    #if IS_CBM		/* Commodore - hack to set colours etc. */
	  #if (IS_CBM == 1)   	/* c64 */
	    *((char *) (int) 53280) = 0; *((char *) (int) 53281) = 0;
	  #endif
	  #if (IS_CBM == 2)	/* v20 */
	    *((char *) (int) 36879) = 8;
	    flag_graphics = 0;
	  #endif
	  #if (IS_CBM == 3)   	/* c16/+4 */
	    *((char *) (int) 65301) = 0; *((char *) (int) 65305) = 0;
	  #endif
	  sch_boardx = 7; sch_boardy = 6; sch_level = 5;
	  io_prints ((char *) "\x05\x93");
    #endif
    io_prints (szProg);
    io_prints (szProg2);
    gameLoop ();
}

#endif   	/* IS_C99 */


/*-------------------------------------------------------------------
   SDL - Graphical Front end code starts here
---------------------------------------------------------------------*/

#ifdef IS_SDL

#include <unistd.h>
#include <SDL.h>
#include <SDL_scancode.h>
#include "sdlwio.h"		/* Header for font/toolbar lib */


typedef unsigned char BYTE;

SDL_Window  * hWin = NULL;		/* Main program window */
SDL_Texture * pTextureBmp = NULL;	/* Texture with piece graphic bitmaps */
SDL_Renderer * sRender = NULL;		/* Used for drawing comands */

SDLTXT_FONT sdltxt_font;	/* Bitmap font object */

SDL_DisplayMode dispMode;	/* Used to find screen size */
SDL_Event sEvent;		/* Used for event loop (kbd/mouse etc */
SDL_Rect rect;

int vdux = 200;
int vduy = 200;
int finished = 0;

int srcx = 100;		/* size of pieces in bmp */
int srcy = 100;
int pixx = 80;		/* size to draw on screen */
int pixy = 80;
int text_at_bottom = 0;
int txtposx,txtposy;	/* Area to draw text */
int flag_gfx = 0;	/* Set if no bmp, draws simple rects */
int flag_anim = 1;	/* Move animation */

void io_printc (char c) 
{
    putchar (c);
}

  /* SDL function error */
void sdl_error (char *pMsg)
{ 
     printf ((char *) "%s error: %s\n", pMsg, SDL_GetError ());
     sleep (1);
     exit (1);
}

#define TOOL_SIZEX 41
#define TOOL_SIZEY 38

SDLTOOL_DATA sdltool_data = {TOOL_SIZEX,TOOL_SIZEY,9,15,4,NULL};

int topx = 20;		/* Top of sch_Board draw area */
int topy = TOOL_SIZEY + 20;
#define BRD_BORDER 8

void printpos (UINTBY xpos, UINTBY ypos, int eval)		
{
	//io_printsi ((char *) " ",xpos);
	//io_printsi ((char *) "=",eval);
}


SDL_Rect src,dest;

	/* Draw a piece */
void drawpiece (int xpos, int ypos, int ch) 
{
    dest.x = topx + ((xpos-1) * pixx);
    dest.y = topy - ypos;		/* if ypos -ve, pos in pixels. */
    if (ypos > 0) {
      dest.y = topy + ((ypos-1) * pixy);
    }
    dest.w = pixx; 
    dest.h = pixy;
    if (ch < White || ch > Black) {	/* Empty square fill */
      SDL_SetRenderDrawColor (sRender, 87, 77, 77, 255);
      SDL_RenderFillRect (sRender, &dest);      
      dest.x = dest.x + pixx/2 - 2;
      dest.y = dest.y + pixy/2 - 2;
      dest.w = 4; 
      dest.h = 4;
      SDL_SetRenderDrawColor (sRender, 0, 0, 0, 255);
      SDL_RenderFillRect (sRender, &dest);      
      return;
    }
    if (flag_gfx) {	/* No bmp, use drawing */
      SDL_SetRenderDrawColor (sRender, 87, 77, 77, 255);
      SDL_RenderFillRect (sRender, &dest);      
      dest.x = dest.x + pixx/4;
      dest.y = dest.y + pixy/4;
      dest.w = pixx/2; 
      dest.h = pixy/2;
      SDL_SetRenderDrawColor (sRender, 0, 0, 0, 255);
      if (ch == White) {
        SDL_SetRenderDrawColor (sRender, 255, 255, 255, 255);
      }
      SDL_RenderFillRect (sRender, &dest);      
      return;      
    }
    src.x = (ch - 1) * srcx;
    src.y = 0;
    src.w = srcx; 
    src.h = srcy;
    SDL_RenderCopy (sRender, pTextureBmp, &src, &dest);
}

    	/* Hilite piece (for win, last move) col=0-255, bit0 clr for double */
void drawhilite (int xpos, int ypos, int col) 
{
    dest.x = topx + ((xpos-1) * pixx);
    dest.y = topy + ((ypos-1) * pixy);
    dest.w = pixx; 
    dest.h = pixy;
    SDL_SetRenderDrawColor (sRender, col, col, col, 255);
    SDL_RenderDrawRect (sRender, &dest);      
    if (col & 1) return;
    dest.x ++; dest.y ++;
    dest.w -= 2; dest.h -= 2;
    SDL_RenderDrawRect (sRender, &dest);      
}

void drawborder ()
{
    int z;
    BYTE c;
    for (z=1; z<BRD_BORDER; z++) {
      c = (int) z * (250/BRD_BORDER);
      dest.x = topx -z;
      dest.y = topy -z;
      dest.w = pixx * sch_boardx + z+z; 
      dest.h = pixy * sch_boardy + z+z;
      SDL_SetRenderDrawColor (sRender, c, c, c, 255);
      SDL_RenderDrawRect (sRender, &dest);      
    }
}

	/* Draw the game sch_Board */
void drawboard () 
{
    int ch;
    int xpos,ypos;
    drawborder ();
    for (ypos = 1; ypos <= sch_boardy; ypos ++) {
      for (xpos = 1; xpos <= sch_boardx; xpos ++) {
	ch = GetBoard(xpos,ypos);
	drawpiece (xpos,ypos,ch);
      }
    }
}

  /* Calculate piece size and text area for screen size (vdux,vduy) */
void calcDrawPos ()
{
    int rightgap = 0;
    int bottomgap = 0;
    text_at_bottom = (vduy-topy+200 > vdux-topx );
    SDLTXT_SetScale (200); 
    if (text_at_bottom) {	/* Arrange text output underneath sch_Board */
      bottomgap = sdltxt_font.outy * 3;
    } else {
      rightgap = sdltxt_font.outx * 14;
    }
    pixx = (vdux - topx * 2 - rightgap) / sch_boardx;
    pixy = (vduy - topy * 2 - bottomgap) / sch_boardy;
	/* Use smallest piece size */
    if (pixx < pixy) pixy = pixx;
    pixx = pixy;

    txtposx = txtposy = 0;
    if (text_at_bottom) {	/* Arrange text output underneath sch_Board */
      txtposy = pixy * sch_boardy + topy + 8 + 2;
    } else {
      txtposx = pixx * sch_boardx + topx + 8;
    }
}

void drawSide (int mode)
{
    if (gameover == DRAWN) {
      SDLTXT_PrintStr ((char *) "Drawn.");
      return;
    }
    if (sch_side == White) {
      SDLTXT_PrintStr ((char *) "White");
    } else {
      SDLTXT_PrintStr ((char *) "Black");
    }
    if (gameover) {
      SDLTXT_PrintStr ((char *) " wins.");
      return;
    } 
    if (mode & 1) {
      SDLTXT_PrintStr ((char *) "...");
    } else {
      SDLTXT_PrintStr ((char *) " move.");
    }
}

void drawText (int mode)
{
    SDLTXT_SetScale (200); 
    SDLTXT_SetColor (255, 255, 128); 
    if (text_at_bottom) {	/* Arrange text output underneath sch_Board */
      int chy = sdltxt_font.outy;
      SDLTXT_SetCursorPos (8,txtposy);
      SDLTXT_PrintStrInt ((char *) "IQ:",sch_level);
      SDLTXT_PrintStr ((char *) "  ");
      drawSide (mode);
      SDLTXT_SetColor (200, 100, 200); 
      if (sch_bestx) {
        SDLTXT_SetCursorPos (8,txtposy+chy);
        SDLTXT_PrintStrInt ((char *) "Move:",sch_bestx);
        SDLTXT_PrintStrInt ((char *) " Eval:",beval);
        #if USE_TIME
          SDLTXT_PrintStrInt ((char *) " Time:", sch_timeMove);
        #endif
        SDLTXT_PrintStrInt ((char *) " Node:",nodecount);
      }
      SDLTXT_SetColor (0, 100, 200); 
      SDLTXT_SetCursorPos (8,txtposy+chy*2);
      if (flag_twoplay) SDLTXT_PrintStr ((char *) " 2 Player mode.");
      if (flag_edit) SDLTXT_PrintStr ((char *) "  Edit mode.");
      return ;
    }
    SDLTXT_SetColor (128, 255, 255); 
    SDLTXT_SetScale (200); 
    SDLTXT_SetCursorPos (txtposx,-4);
    SDLTXT_PrintStr ((char *) " SCONNEX");
    SDLTXT_SetColor (255, 255, 128); 
    SDLTXT_SetCursorPos (txtposx,-6);
    SDLTXT_PrintStrInt ((char *) "IQ:",sch_level);
    SDLTXT_SetCursorPos (txtposx,-8);
    drawSide (mode);

    SDLTXT_SetColor (200, 100, 200); 
    if (sch_bestx) {
      SDLTXT_SetCursorPos (txtposx,-10);
      SDLTXT_PrintStrInt ((char *) "Move:",sch_bestx);
      SDLTXT_SetCursorPos (txtposx,-11);
      SDLTXT_PrintStrInt ((char *) "Eval:",beval);
      SDLTXT_SetCursorPos (txtposx,-12);
      #if USE_TIME
        SDLTXT_PrintStrInt ((char *) "Time:", sch_timeMove);
        SDLTXT_SetCursorPos (txtposx,-13);
      #endif
      SDLTXT_PrintStrInt ((char *) "Node:",nodecount);
    }
    SDLTXT_SetColor (0, 100, 200); 
    SDLTXT_SetCursorPos (txtposx,-14);
    if (flag_twoplay) SDLTXT_PrintStr ((char *) "2 Player mode.");
    SDLTXT_SetCursorPos (txtposx,-15);
    if (flag_edit) SDLTXT_PrintStr ((char *) "Edit mode.");
    SDLTXT_SetCursorPos (txtposx,-16);
    if (sch_LoseMode) SDLTXT_PrintStr ((char *) "Play to lose!");
    /*if (1) { int x;
      SDLTXT_SetColor (128, 255, 255); SDLTXT_SetCursorPos (1,-42);
      for (x=0; x< 128; x++) { SDLTXT_PrintStr ((char *) &x);}    } */
} 

void drawWinLine ()
{
    int cpos;
    if (winpos == 0) return;
    if (sch_Board [winpos] != gameover) return;
    for (cpos = winpos; sch_Board [cpos] == gameover; cpos += windir) {
      drawhilite (Pos2X (cpos), Pos2Y (cpos), 254);
    }
    for (cpos = winpos; sch_Board [cpos] == gameover; cpos -= windir) {
      drawhilite (Pos2X (cpos), Pos2Y (cpos), 254);
    }
}


  /* Redraw sch_Board and text (mode 1=thinking) (mode=2 dont finish render ) */
void redrawAll (int mode)
{
    SDL_SetRenderDrawColor (sRender, 0, 16, 32, 255);
    SDL_RenderClear (sRender); 
    SDL_GetWindowSize (hWin, &vdux, &vduy);
    calcDrawPos ();
    drawboard ();
    if (lastx) {
      drawhilite (lastx, lasty, 31);
    }
    if (gameover) drawWinLine ();
    drawText (mode);
    SDLTOOL_Draw (&sdltool_data, sRender);
    if ((mode & 2) == 0) SDL_RenderPresent (sRender); 
}

  /* Animate piece move/drop (using render loop) */
void droppiece (int xpos, int ypos, int col)
{
    int mypos;
    for (mypos = 1; mypos <= (ypos-1) *pixy; mypos += pixy/2) {
      redrawAll (2);
      drawpiece (xpos, -mypos, col);
      SDL_RenderPresent (sRender); 
      SDL_Delay (20);		// Delay X millisec 
    }
}

	/* Search engine callback routine, update display */
void sch_callback (UINTBY sxpos, UINTBY sypos, int seval)
{
    redrawAll (1);
}

  /* Call engine to search for best move */
void execcomp (UINTBY hintmode)		
{
	sch_CompMove ();		/* Find best comp sch_bestx,sch_besty */
	if (sch_bestx > 0 && sch_besty > 0) {
	  cxpos = sch_bestx; cypos = sch_besty;
	  ceval = sch_EvalPos (sch_bestx, sch_besty, sch_side);			/* 5 line ? */
	  if (hintmode) {
	    pxpos = cxpos; pypos = cypos;
	    // io_prints ((char *) " Try "); printpos (cxpos, cypos, beval);
	    return;
	  }
	  if (flag_anim) droppiece ( sch_bestx, sch_besty, sch_side);
	  SetBoard ( sch_bestx, sch_besty, sch_side);
	  lastx = sch_bestx; lasty = sch_besty;
	  redrawAll (1);
	    // io_prints ((char *) "\n I Move ");
	  pxpos = sch_bestx; pypos = sch_besty;
	    // printpos (pxpos, pypos, beval); io_printsi ((char *) ", Nodes:",nodecount); io_prints ((char *) "\n");
	  if (sch_isGameOver (sch_bestx, sch_besty)) {		/* Win.. */
	    return;
	  }
	} else {
	  gameover = DRAWN;
	  // io_prints ((char *) " Drawn !\n");
	  automode = 0;
	}
}

void playermove (int mov)
{
	if (gameover) return;
	pxpos = mov;
	pypos = sch_FindYPos (pxpos);
	if ( pypos < 1) {
	  return;
	}
        ceval = sch_EvalPos (pxpos, pypos, sch_side);			/* win - line ? */
	if (flag_anim) droppiece ( pxpos, pypos, sch_side);
	SetBoard ( pxpos, pypos, sch_side);
	lastx = pxpos; lasty = pypos;
	if (sch_isGameOver (pxpos, pypos)) {		/* Win/Draw.. */
	  return;
	}
	sch_side = 3 - sch_side;
	redrawAll (1);
	if (flag_twoplay == 0) {
	  execcomp (0);
	  if (gameover) {
	    redrawAll (0);
	    return;
	  }
	  sch_side = 3 - sch_side;
	}
}

char szHelp [] = 
  "\n\n"
 " Welcome to SCONNEX! In this game each\n"
 " player takes turns to drop a stone on\n"
 " a grid. The first player to get 4\n"
 " pieces in a line wins.\n"
 " When playing, simply touch/click the\n"
 " square where you want to play your\n"
 " piece.\n\n"
 " For more help, see file: \x22sconnex.txt\x22 \n"
 "\n\0";

char szHelp2 [] = 
 "\n\n"
 "  TOOLBAR COMMANDS: (Top left to right)\n\n"
 " 1: New game. \n"
 " 2: Change board width. (4-12)\n"
 " 3: Change board height. (4-12)\n"
 " 4: Change play level. (IQ1-12)\n"
 " 5: Compute - make computer take go.\n"
 " 6: Toggle two player mode.\n"
 " 7: Toggle edit mode.\n"
 " 8: Show help screen\n"
 " 9: Exit game.\n"
 "\n\0";

char szHelp3 [] = 
 " To play, click anywhere, or hit a key.\n";

#define HELPX 40
#define HELPY 30

  /* Display a Help/Title screen. */
int gameHelp ()
{
    int cmd;
    int cret;
    int x,y;
    while (1) {
      SDLTXT_SetOutputRenderer (sRender);
	/* Sys/Mouse/Keyboard event managment */
      while (SDL_PollEvent (&sEvent)) {
	cmd = 0;
	switch (sEvent.type) {
	  case SDL_QUIT:
	    return FALSE;

          case SDL_MOUSEBUTTONDOWN:	
	    return TRUE;
	  case SDL_KEYDOWN:
	    cmd = sEvent.key.keysym.scancode;	/* Pass key command to statement below.. */
	    if (cmd) return TRUE;
	    break;
	  }
        }
        SDL_SetRenderDrawColor (sRender, 0, 16, 32, 255);
        SDL_RenderClear (sRender); 
        SDL_GetWindowSize (hWin, &vdux, &vduy);
		/* Calc scaling */
        x = vdux / HELPX;
	y = vduy / HELPY;
        if (y < x) x=y;
		/* Render help/title text*/
        SDLTXT_SetScale ((100 * x) / 8); 
        SDLTXT_SetCursorPos (0,20);
        SDLTXT_SetColor (255, 255, 255); 
        SDLTXT_PrintStr (szProg);
        SDLTXT_SetColor (80, 240, 80); 
        SDLTXT_PrintStr (szProg2);
        SDLTXT_SetColor (80, 160, 240); 
        SDLTXT_PrintStr (szHelp);
        SDLTXT_SetColor (160, 80, 240); 
        SDLTXT_PrintStr (szHelp2);
        SDLTXT_SetColor (240, 240, 240); 
        SDLTXT_PrintStr (szHelp3);
        SDL_RenderPresent (sRender); 
	
      }
}

#define ID_TOOL 0x8000		/* ID Code for toolbar selections */

void gameLoop ()
{
    int mov;
    int cmd;
    int cret;
    //sch_level = 6;
    //sch_boardx = sch_boardy = 8;
    sch_NewGame ();
    cret = gameHelp ();
    if (cret == FALSE) return;
	/* Main program loop */
    do {
      SDLTXT_SetOutputRenderer (sRender);
	/* Sys/Mouse/Keyboard event managment */
      while (SDL_PollEvent (&sEvent)) {
	cmd = 0;
	switch (sEvent.type) {
	  case SDL_QUIT:
	    return ;

          case SDL_MOUSEBUTTONDOWN:	
			/* Toolbar button hit?  */
	    cret = SDLTOOL_Service (&sdltool_data, sEvent.button.x, sEvent.button.y);
	    if (cret) {	
	      cmd = ID_TOOL + cret;	/* Process command below.. */
	      break;
	    }
	    if (flag_edit) {		/* User edit selected square */
	      int pc;
	      pxpos = (sEvent.button.x - topx) / pixx + 1;
	      pypos = (sEvent.button.y - topy) / pixy + 1;
	      if (GetBoard ( pxpos, pypos+1) == 0) break;
	      pc = (GetBoard ( pxpos, pypos) + 1) % 3;
	      SetBoard ( pxpos, pypos, pc);
	      gameover = 0;
	      winpos = 0;
	      lastx = 0;
	      break;
	    }
		/* Has move been made? */
	    if (sEvent.button.y < topy) break;
	    mov = (sEvent.button.x - topx) / pixx;
	    // io_printsi ((char *) " Mouse:",sEvent.button.x); io_printsi ((char *) ",",sEvent.button.y); io_printsi ((char *) ":",mov); io_prints ((char *) "\n");
	    if (mov < 0 || mov > sch_boardx) break;
            playermove (mov+1);
	    break;

	  case SDL_KEYDOWN:
	    cmd = sEvent.key.keysym.scancode;	/* Pass key command to statement below.. */
	    break;
	  }
		/* Process command (keystroke or toolbar) */
	  if (cmd) {
	    switch (cmd) {
	      case ID_TOOL+9:
	      case SDL_SCANCODE_ESCAPE:		/* Quit */
		return;

	      case ID_TOOL+6:
	      case SDL_SCANCODE_T:		/* Toggle 2 player mode */
		flag_twoplay = !flag_twoplay;
		sch_bestx = 0;
		break;

	      case ID_TOOL+7:
	      case SDL_SCANCODE_E:		/* Toggle edit mode */
		flag_edit = !flag_edit;
		sch_bestx = 0;
		break;

	      case ID_TOOL+2:
	      case SDL_SCANCODE_X:		/* Change sch_Board width */
		sch_boardx ++; 
		if (sch_boardx > 12) sch_boardx = 4;
		sch_NewGame ();
		break;

	      case ID_TOOL+3:
	      case SDL_SCANCODE_Y:		/* Change sch_Board height */
		sch_boardy ++; 
		if (sch_boardy > 12) sch_boardy = 4;

	      case ID_TOOL+1:
	      case SDL_SCANCODE_N:		/* New game */
		sch_NewGame (); 
		break;

	      case ID_TOOL+4:
	      case SDL_SCANCODE_I:		/* Change play level (IQ)  */
		if (flag_edit) {
		  sch_level = (sch_level % 30) + 1;	/* Allow high levels in edit mode */
		} else {
		  sch_level = (sch_level % 12) + 1;
		}
		break;

	      /* case SDL_SCANCODE_L:	// Play to lose 
		sch_LoseMode = !sch_LoseMode;
		break; */

	      case ID_TOOL+5:
	      case SDL_SCANCODE_G:		/* Make computer play turn */
		if (gameover) break;
		execcomp (0);
		if (gameover) {
		  break;
	        }
	        sch_side = 3 - sch_side;
		break;

	      case SDL_SCANCODE_U:		/* Toggle animations */
		flag_anim = !flag_anim;
		break;

	      case SDL_SCANCODE_V:		/* Toggle to simple graphics */
		flag_gfx = !flag_gfx;
		break;

	      case SDL_SCANCODE_Z:
		flag_misc =!flag_misc;
		break;

	      case ID_TOOL+8:
	      case SDL_SCANCODE_H: 	/* Help.. */
		cret = gameHelp ();
		if (cret == FALSE) return;
		/* cret = SDL_ShowSimpleMessageBox (0, szProg, szHelp, NULL);
		if (cret != 0) {
		  sdl_error ((char *) "SDL_ShowSimpleMessageBox");
		} */
		break;
	    }
	  }
      }
	/* Ok redraw and render screen */
      redrawAll (0);
      SDL_Delay (200);		/* Delay X millisec */
		/* can be: while (GetCmd ()); */
    } while (finished == 0 );	/* until key/mouse hit */
}

void gameInit ()
{
    int cret;
    SDL_Surface * pSurfaceBmp = NULL;		/* bmps for pieces */
	/* Initialise SDL libs */
    cret = SDL_Init (SDL_INIT_VIDEO);
    if (cret != 0) {
      sdl_error ((char *) "SDL_Init");
    }
    
	/* Get desktop size */
    cret = SDL_GetCurrentDisplayMode (0, &dispMode);    
    if (cret != 0) {
      sdl_error ((char *) "SDL_GetCurrentDisplayMode");
    }
    vdux = dispMode.w - 10;
    vduy = dispMode.h - 60; 

    if (SDL_CreateWindowAndRenderer (vdux, vduy, SDL_WINDOW_RESIZABLE, &hWin, &sRender) < 0) {
      sdl_error ((char *) "SDL_CreateWindowAndRenderer");
    }
    if (sRender == NULL) {
      sdl_error ((char *) "sRender is NULL");
    }
    SDL_SetWindowTitle (hWin, szProg);
    SDL_GetWindowSize (hWin, &vdux, &vduy);
    
	/* Initialise bmp font */
    sdltxt_font.is_user_font = FALSE;	 	/* Use default font */
    if (SDLTXT_CreateFont (sRender, &sdltxt_font) == FALSE) {
      sdl_error ((char *) "SDLTXT_CreateFont");
    }

	/* Init toolbar */
    cret = SDLTOOL_Create (&sdltool_data, sRender, "toolbar.bmp");
    if (cret == 0) {
      sdl_error ((char *) "SDLTOOL_Create");
    }

	/* Load piece bmps */
    pSurfaceBmp = SDL_LoadBMP ((char *) "sconnex.bmp");
    if (pSurfaceBmp == NULL) {
      flag_gfx = 1; return;
      //sdl_error ((char *) "SDL_LoadBMP ");
    }
	/* Transfer bmp to texture for rendering.. */
    pTextureBmp = SDL_CreateTextureFromSurface (sRender, pSurfaceBmp);
    if (pTextureBmp == NULL) {
      sdl_error ((char *) "SDL_CreateTextureFromSurface ");
    }
    SDL_FreeSurface (pSurfaceBmp);
}


	/* Tidy up, quit. */
void gameFinish ()
{
    SDLTXT_DestroyFont (&sdltxt_font);
    SDLTOOL_Destroy (&sdltool_data);
    SDL_DestroyTexture (pTextureBmp);
    SDL_DestroyWindow (hWin);
    SDL_Quit ();
}

	/* Main program */
void main ()
{
    gameInit ();
    gameLoop ();
    gameFinish ();
}

#endif  	/* IS_SDL */


/*------------------------------------------------------------------------------------
   IS_8BIT - Graphical/txt Front end for 8 bit or DOS type systems (not polling based)
--------------------------------------------------------------------------------------*/


#ifdef IS_8BIT

  // Simple peek/poke macros
#define IO_POKE(AD,BY) *((BYTE *) ((UINT) AD))=(BYTE) (BY);
#define IO_PEEK(AD) ((BYTE) *((BYTE *) ((UINT) AD)))

BYTE flag_gfx = 1;	/* Small / Large gfx */
int io_txtposy = 1;
BYTE flag_anim = 1;	/* Move animation */
int sqsize = 1;
int io_cursorx;
int io_cursory;
BYTE autoplay = 0;
BYTE print_lower_case = 0;
  
  // Portable color defs (RGB=bits 0,1,2)
#define IO_INK_BLACK  0		// 144
#define IO_INK_RED    1		// 28
#define IO_INK_GREEN  2		// 30
#define IO_INK_YELLOW 3		// 158
#define IO_INK_BLUE   4		// 31
#define IO_INK_PURPLE 5		// 156
#define IO_INK_CYAN   6		// 159
#define IO_INK_WHITE  7		// 5

#define SZPROG_SPLIT 17		// Progname, Split for small screen

#if IS_HIRES	/* Use hires gfx */

BYTE game_hires[]= {
	// White piece
  0x00,0x03,0x0f,0x1c,0x3b,0x37,0x6e,0x6d,
  0x6d,0x6e,0x37,0x3b,0x1c,0x0f,0x03,0x00,
  0x00,0xc0,0xf0,0x38,0xdc,0xec,0x76,0xb6,
  0xb6,0x76,0xec,0xdc,0x38,0xf0,0xc0,0x00,
	// Black piece
  //0x00,0x03,0x0c,0x10,0x20,0x20,0x41,0x42,
  //0x42,0x41,0x20,0x20,0x10,0x0c,0x03,0x00,
  //0x00,0xc0,0x30,0x08,0x04,0x04,0x82,0x42,
  //0x42,0x82,0x04,0x04,0x08,0x30,0xc0,0x00,
	// Piece marks
  0x40,0xc3,0x0f,0x1c,0x3b,0x37,0x6e,0x6d,
  0x40,0xc3,0x0c,0x10,0x20,0x20,0x41,0x42,
	// Empty sqr dot mark
  0,0,0,0,0,0,0,1,
	// Edge
  // 0x18,0x30,0x30,0x18,0x18,0x0c,0x0c,0x18,
   0x18,0x24,0x24,0x18,0x18,0x24,0x24,0x18,
  //0x24,0x48,0x48,0x24,0x24,0x12,0x12,0x24,
 0};
#endif

/*------------------------------------------------------------------------------------
   IS_CBM - Commodore specific code. set IS_C64, IS_C16, IS_PET, IS_VIC20
     Build CC65:cd w\cbm\cc65\c; ccinit; comp sconnex -t c64 -Or -DIS_8BIT -DIS_CBM -DIS_CBM64  
--------------------------------------------------------------------------------------*/

#if IS_CBM


  /* simple CBM print char */
void io_printc_raw (BYTE c);
char io_getkey ();

#define TED_ROMSEL   0xff3e		// A write to this address selects ROM at $8000-FFFF
#define TED_RAMSEL   0xff3f		// A write to this address selects RAM at $8000-FFFF

#ifdef USE_CONIO

  /* Use conio console functions */
#include <conio.h>

void io_printc_raw (BYTE ch)
{
    putch (ch);
}

char io_getkey ()
{
    if (kbhit () ==0) return 0;
    return getch ();
}

void io_init_compiler () {}	/* Do nothing */

#endif 	/* USE_CONIO */

#ifdef IS_OSCAR

#include <conio.h>

void io_printc_raw (BYTE ch)
{
    #if 1
      putch (ch);	// conio method
    #else
      __asm {		
	lda ch
	jsr $ffd2
      }
    #endif
}

char io_getkey ()
{
    #ifdef IS_C16
      __asm {			// Oscar/c16, use asm (conio has bug?)
	sta TED_ROMSEL		// Switch in ROM temp..
	jsr $ffe4
	sta accu
	sta TED_RAMSEL
	lda #0
	sta accu+1
      }
    #else
      if (kbhit () ==0) return 0;
      return getch ();
    #endif
}

void io_init_compiler () 
{
    iocharmap(IOCHM_PETSCII_2); 
    //flag_anim = 0; 
    io_flag_add_cr = 0;
}

#endif

#ifdef IS_CC65

void io_printc_raw (register BYTE ch)
{ 
    __AX__ = (ch);
    asm ( "jsr $ffd2");
}

char io_getkey ()
{
    char ch;
    asm ( "jsr $ffe4");
    ch = (char) __AX__;
    return ch;
}

void io_init_compiler () {}	/* Do nothing */

#endif

#ifdef IS_VBCC		

BYTE io_parm_byte1;
BYTE io_parm_byte2;
BYTE io_parm_int1;

extern BYTE io_parm_byte1;
extern BYTE io_parm_byte2;
extern BYTE io_parm_int1;

	// Asm routines..
void io_getkey_asm ();
void io_printc_asm ();

void io_printc_raw (BYTE ch)
{
    io_parm_byte1 = ch;
    __asm ("  lda _io_parm_byte1");
    __asm ( "  jsr $ffd2");
    //io_printc_asm ();
}

char io_getkey ()
{
    // io_getkey_asm ();
    __asm ( "  jsr $ffe4");
    __asm ( "  sta _io_parm_byte1");
    return io_parm_byte1;

}

void io_init_compiler () {}	/* Do nothing */

#endif		/* IS_VBCC */

void io_printc (char c) 
{
    if (!print_lower_case) {
      if (c >= 'A' && c <= 'Z') c = c - 'A' + 'a';
    }
    io_printc_raw ((BYTE) c);
}


//------------------------------------------------------------------------------------

#ifdef IS_C64		/* CBM64 specific code */

#define IS_COLOUR TRUE

#define CBM_VDULOC  0x0400	/* Screen loc  */
#define CBM_COLRAM  0xd800	/* Colour ram loc */

#define VDUX 40
#define VDUY 25
#define VDUPOS(X,Y) ((X)+((Y)<<5)+((Y)<<3))

BYTE *pVdu = (BYTE *) ((UINT) CBM_VDULOC);	/* Ptr to screen */
BYTE *pCol = (BYTE *) ((UINT) CBM_COLRAM);	/* Ptr to colour ram */

#define COL_PWHITE 1
#define COL_PBLACK 4
#define COL_HIWHITE 7
#define COL_HIBLACK 6
#define COL_EDGE 3

#define CBM_JIFFY 0xa0			// CBM Jiffy clock (hi to lo)

const UINT VIC_MEMCTL  = 0xd018;  	// VIC Memory Control Register: Bit:4-7 (VDU Base Bit 13-10) Bit:1-3 (Char Set Bit 13-11)
const UINT VIC_BORDER  = 0xd020;	// VIC border colour
const UINT PTR_CHRSET  = 0x3000;	// Hires Char set location (NOTE - Check its past end-of-code)
const UINT PTR_ROMSET  = 0xd000;	// Hires Char set location
const UINT C64_MEMCTL  = 1;		// C64 Mem ctl register
const UINT C64_INTERRUPT = 56334;	// Bit 0 turns IRQ on/off
#define CUSTOM_CHR 0xc0			// Offset for first custom char in chrset..
#define CUSTOM_NO 8			// # Custom chrs 
	
void io_cls ()
{
    print_lower_case = FALSE;
    io_printc (5); io_printc (142); io_printc (147);
    #if IS_HIRES	// Set up hires gfx
     IO_POKE (VIC_MEMCTL, 0x1d);		// Set VDU=$0400,CHRSET=$D000 (def $15)
    #endif
}

void io_enable_lower_case ()
{
    print_lower_case = TRUE;
    #if IS_HIRES	// Set up lower case gfx
     IO_POKE (VIC_MEMCTL, 0x15);		// Set VDU=$0400,CHRSET=$D000 (def $15)
    #endif
    io_printc (14);
}

	/* Init code */
void game_Init ()
{
    io_init_compiler ();			/* Compiler specific inc */
    pVdu = (BYTE *) ((int) 1024) ;
    IO_POKE (VIC_BORDER,   0);
    IO_POKE (VIC_BORDER+1, 0);
    io_cls();
    sch_level = 4;	/* Level of play */
	
    #if IS_HIRES	// Set up hires gfx
    {
      BYTE *pSrc  = (BYTE *) PTR_ROMSET;
      BYTE *pDest = (BYTE *) PTR_CHRSET;
      BYTE *pIntr = (BYTE *) C64_INTERRUPT;
      BYTE *pMemCtl = (BYTE *) C64_MEMCTL;
      UINT p;
      *pIntr = *pIntr & 254;		// IRQ off
      *pMemCtl = *pMemCtl & 0xfb;	// Bit 2 off
      for (p=0; p<2048; p++) {		// Copy orig ROM set to RAM
	pDest [p] = pSrc [p];
      }
      for (p = 0; p < CUSTOM_NO*8; p++) {	// Add custom chars
	pDest [CUSTOM_CHR*8 + p] = game_hires [p];
      }
      *pMemCtl = *pMemCtl | 4;
      //IO_POKE (VIC_MEMCTL, 0x1d);	// Set VDU=$0400,CHRSET=$3000 (def $15)
      *pIntr = *pIntr | 1;		// IRQ back on
    }
     #define CHR_LINE CUSTOM_CHR+7
    #else
     #define CHR_LINE 66
    #endif
}

	/* Tidy up, quit. */
void game_Finish ()
{
    io_cls ();
}

#endif 		/* IS_C64 */

//------------------------------------------------------------------------------------

#ifdef IS_C16		/* C16/+4 specific code */

#define IS_COLOUR TRUE

#define CBM_VDULOC  0x0c00	/* Screen loc  */
#define CBM_COLRAM  0x0800	/* Colour ram loc */

#define VDUX 40
#define VDUY 25
#define VDUPOS(X,Y) ((X)+((Y)<<5)+((Y)<<3))

BYTE *pVdu = (BYTE *) ((UINT) CBM_VDULOC);	/* Ptr to screen */
BYTE *pCol = (BYTE *) ((UINT) CBM_COLRAM);	/* Ptr to colour ram */

#define CBM_JIFFY 0xa3			// CBM Jiffy clock (hi to lo)

// C16 Direct colours: Lo nibble = base colour, bit 4-6=brightness, Bit7 for flash.
#define COL_PWHITE  0x76
#define COL_PBLACK  0x34
#define COL_HIWHITE 0xf6
#define COL_HIBLACK 0xb4
#define COL_EDGE    0x43

/*
  TEDmemctl  = $FF12	; Bitmap/Character Memory Control (Bit0-1:Sound MSB, Bit 2:chr/bmp ROM/RAM, Bit3-5:Bmp Base 8K steps)
  TEDchrbase = $FF13	; System Clock and Character Memory Control (Bit 2-7:chr base 1K steps)
  TEDvduloc  = $FF14	; Video ram loc 2k steps (Bit 3-7)
  TEDvducol  = $FF15	; Screen background colour (Bit 0-3:Color, Bit 4-6:Luminance)
  TEDbordcol = $FF19	; Border colour
  TEDrasthi  = $FF1C	; Raster line hi bit (Bit 0)
  TEDraster  = $FF1D	; Current raster line (Bit 0-7)
  
  TEDmemctl_TEXT = 196	; Bit 2 on for Text (use ROM)
  TEDmemctl_GFX  = 192	; Bit 2 off for GFX (use RAM)
*/

const UINT TED_MEMCTL  = 0xff12;  	// Bitmap/Character Memory Control (Bit0-1:Sound MSB, Bit 2:chr/bmp ROM/RAM, Bit3-5:Bmp Base 8K steps)
const BYTE TED_MEMCTL_TEXT = 196;		// Bit 2 on for Text (use ROM)
const BYTE TED_MEMCTL_GFX  = 192;		// Bit 2 off for GFX (use RAM)
const UINT TED_CHRBASE  = 0xff13;  	// System Clock and Character Memory Control (Bit 2-7:chr base 1K steps) 

const UINT TED_BORDER  = 0xff19;	// border colour
const UINT TED_BACK    = 0xff15;	// back colour

const UINT PTR_CHRSET  = 0x3800;	// Hires Char set location (NOTE - Check its past end-of-code) (ie: 0x6000)
const UINT PTR_ROMSET  = 0xd000;	// Hires Char set location

#define CUSTOM_CHR 0x40			// Offset for first custom char in chrset..
#define CUSTOM_NO 8			// # Custom chrs 
	
void io_cls ()
{
    print_lower_case = FALSE;
    #if IS_HIRES
     IO_POKE (TED_MEMCTL, TED_MEMCTL_GFX);		// Switch GFX ROM to RAM
     IO_POKE (TED_CHRBASE, (PTR_CHRSET/256));		// Set CHRSET base in RAM. Check this is past code-end!
    #endif
    io_printc (5); io_printc (142); io_printc (147);
}

void io_enable_lower_case ()		// Enable textmode
{
    print_lower_case = TRUE;
    #if IS_HIRES
     IO_POKE (TED_MEMCTL, TED_MEMCTL_TEXT);		// Switch Chrset back to ROM.
     IO_POKE (TED_CHRBASE, (PTR_ROMSET/256));		// Set CHRSET base in RAM. Check this is past code-end!
    #endif
    io_printc (14);
    io_printc (5); io_printc (147);
}

	/* Init code */
void game_Init ()
{
    io_init_compiler ();				/* Compiler specific inc */
    IO_POKE (TED_BORDER,   0);
    IO_POKE (TED_BACK, 0);
    io_cls();
    sch_level = 4;	/* Level of play */
	
    #if IS_HIRES	// Set up hires gfx
    {
      BYTE *pSrc  = (BYTE *) PTR_ROMSET;
      BYTE *pDest = (BYTE *) PTR_CHRSET;
      UINT p;
      #ifdef IS_OSCAR
        __asm {
	  sei
	  sta TED_ROMSEL
	}
        for (p=0; p<1024; p++) {		// Copy orig ROM set to RAM
	  pDest [p] = pSrc [p];
        }
        __asm {
	  sta TED_RAMSEL
	  cli
	}
      #else
        for (p=0; p<1024; p++) {		// Copy orig ROM set to RAM
	  pDest [p] = pSrc [p];
        }
      #endif
      for (p = 0; p < CUSTOM_NO*8; p++) {	// Add custom chars
	pDest [CUSTOM_CHR*8 + p] = game_hires [p];
      }
    }
     #define CHR_LINE CUSTOM_CHR+7
    #else
     #define CHR_LINE 66
    #endif
}

	/* Tidy up, quit. */
void game_Finish ()
{
    io_cls ();
}
#endif 		/* IS_C16 */

//------------------------------------------------------------------------------------


#ifdef IS_VIC20		/* VIC20 specific code */

#define IS_COLOUR TRUE

#define CBM_VDULOC  0x1000		/* Screen loc  */
#define CBM_COLRAM  0x9400		/* Colour ram loc */


	// VIC regs
#define V20_HPOS    0x9000		// bits 0-6 horizontal pos/centering, bit 7 sets interlace scan (36864) [PAL:12,NTSC:5]
#define V20_VPOS    0x9001		// vert position [PAL:38,NTSC:25]
#define V20_HSIZE   0x9002		// bits 0-6 set # of columns, bit 7 part video matrix address
#define V20_VSIZE   0x9003		// bits 1-6 set # of rows, bit 0 for 8x8 or 8x16 chars
#define V20_RASTER  0x9004		// current video raster line
#define V20_VIDADD  0x9005		// Vid/chrset address: bits 0-3 charset address, bits 4-7 screen address.  (36869)
#define V20_PENH    0x9006		// Light pen horiz
#define V20_PENV    0x9007		// Light pen vert
#define V20_PADX    0x9008		// Paddle X
#define V20_PADY    0x9009		// Paddle Y
#define V20_VOICE1  0x900a		// Voice osc 1 (128-255) bit 7 on/off (36874)
#define V20_VOICE2  0x900b		// Voice osc 2 (128-255) bit 7 on/off
#define V20_VOICE3  0x900c		// Voice osc 3 (128-255) bit 7 on/off
#define V20_NOISE   0x900d		// Voice noise (128-255) bit 7 on/off
#define V20_VOL     0x900e		// bit 0-3 overall volume, bits 4-7 aux color in multicolor mode.
#define V20_BACKCOL 0x900f		// Screen/border color, bits 4-7 screen background, bits 0-2 border, bit 3 for inverted/normal mode (36879)
	// Other regs
#define V20_VIA1    0x9110		// VIC20 6522 VIA1
#define V20_VIA2    0x9120		// VIC20 6522 VIA2
//#define V20_COLRAM  0x9400		// VIC20 colour ram if vdu $1000 (9600 for vdu $1e00)  
#define V20_CHARROM 0x8000		// VIC20 ROM char set.

//#define V20_VDULOC  0x1000
#define V20_CHARRAM 0x1400

#define CUSTOM_CHR 0xc0			// Offset for first custom char in chrset..
#define CUSTOM_NO 8			// # Custom chrs 

#define VDUX 22
#define VDUY 23
#define VDUPOS(X,Y) ((X)+((Y)*VDUX))

BYTE *pVdu = (BYTE *) ((UINT) CBM_VDULOC);	/* Ptr to screen */
BYTE *pCol = (BYTE *) ((UINT) CBM_COLRAM);	/* Ptr to colour ram */

#define CBM_JIFFY 0xa0			// CBM Jiffy clock (hi to lo)

#define COL_PWHITE 1
#define COL_PBLACK 4
#define COL_HIWHITE 7
#define COL_HIBLACK 6
#define COL_EDGE 3

void io_cls ()
{
    print_lower_case = FALSE;
    io_printc (5); io_printc (142); io_printc (147);
    #if IS_HIRES	// Set up hires gfx
      //IO_POKE (V20_BACKCOL, 8);
      IO_POKE (V20_VIDADD,0xcd);		// Set VDU=$1000,CHRSET=$1200 (Normally $c0 (v20+8k) for Default VDU=$1200,CHRSET=$8000)
    #endif
}

void io_enable_lower_case ()
{
    io_printc (14);
    #if IS_HIRES	// Disable hires gfx
      //IO_POKE (V20_BACKCOL, 8);
      IO_POKE (V20_VIDADD,0xc2);		//  Default VDU=$1200,CHRSET=$8800)
    #endif
    print_lower_case = TRUE;
}

	/* Init code */
void game_Init ()
{
    io_init_compiler ();				/* Compiler specific inc */
    IO_POKE (V20_BACKCOL, 8);
    io_cls();
    sch_level = 4;	/* Level of play */
	
    #if IS_HIRES	// Set up hires gfx
    {
      BYTE *pSrc  = (BYTE *) V20_CHARROM ;
      BYTE *pDest = (BYTE *) V20_CHARRAM;
      UINT p;
      for (p=0; p<2048; p++) {		// Copy orig ROM set to RAM
	pDest [p] = pSrc [p];
      }
      for (p = 0; p < CUSTOM_NO*8; p++) {	// Add custom chars
	pDest [CUSTOM_CHR*8 + p] = game_hires [p];
      }
    }
     #define CHR_LINE CUSTOM_CHR+7
    #else
     #define CHR_LINE 66
    #endif
}

	/* Tidy up, quit. */
void game_Finish ()
{
    io_cls ();
}
#endif 		/* IS_VIC20 */

//------------------------------------------------------------------------------------

#ifdef IS_PET		/* PET 30xx/40xx (40 col) specific code */

#define IS_COLOUR FALSE

#define CBM_VDULOC  0x8000		/* Screen loc  */

#define VDUX 40
#define VDUY 25
#define VDUPOS(X,Y) ((X)+((Y)<<5)+((Y)<<3))

BYTE *pVdu = (BYTE *) ((UINT) CBM_VDULOC);		/* Ptr to screen */

//#define CBM_JIFFY 0x8d			// CBM Jiffy clock (hi to lo)

#define COL_PWHITE 0
#define COL_PBLACK 0
#define COL_HIWHITE 0
#define COL_HIBLACK 0
#define COL_EDGE   0

#define PET_CASE 0xe84c		// Bit 1 case switch (59468)

void io_cls ()
{
    print_lower_case = FALSE;
    io_printc (5); io_printc (142); io_printc (147);
    IO_POKE (PET_CASE, 12);
}

void io_enable_lower_case ()
{
    print_lower_case = TRUE;
    IO_POKE (PET_CASE, 14);
    io_printc (14);
}

	/* Init code */
void game_Init ()
{
    io_init_compiler ();				/* Compiler specific inc */
    io_cls();
    sch_level = 4;	/* Level of play */
	
    #define CHR_LINE 66
}

	/* Tidy up, quit. */
void game_Finish ()
{
    io_cls ();
}
#endif 		/* IS_PET */

//------------------------------------------------------------------------------------
// IS_CBM : Code common for all CBM

#if IS_COLOUR
BYTE io_inktab[] = {144,28,30,158,31,156,159,5};	// CBM Colour index lookup (C64/C16/V20) , RGB=bits 0,1,2:

void io_ink (BYTE ink)
{
    io_printc (io_inktab[ink]);
}
#else
  #define io_ink(INK) ;		// No colour, NULL macro
#endif

void io_clrline (int ypos)
{
    BYTE x;
    BYTE *pLin = pVdu + VDUPOS (0, ypos-1);
    for (x=0; x<VDUX; x++) {
      pLin[x] = 32;
    }
}

   /* Set cursor pos (generic CBM) */
void io_SetPos (int x, int y)
{
    int z;
    io_printc (19);
    for (z=1; z<y; z++) io_printc (17);
    for (z=1; z<x; z++) io_printc (29);
}

  // Sleep (tim) milliseconds
void io_sleep (int tim) 
{
    //msleep (tim);
    #ifdef CBM_JIFFY
      BYTE last;
      do {
	#if IS_OSCAR
         __asm {
	     lda CBM_JIFFY+2
	   looptim:
	     cmp CBM_JIFFY+2
	     beq looptim
	 };
	#else
	  last = IO_PEEK (CBM_JIFFY+2);
	  while (IO_PEEK (CBM_JIFFY+2) == last);		// Delay 1 jiffy (but OSCAR optimizes this out!)
	#endif
	tim = tim - 18;
      } while (tim > 0);
    #else
      { 
	int x;
        for (x=0; x<tim*10; x++) {}	// Approx
      }
    #endif
}

#if 0
  // Sleep (tim) milliseconds
void io_sleep (int tim) 
{
    //msleep (tim);
    int t; 
    #ifdef CBM_JIFFY
      BYTE last;
      BYTE *pJif = (BYTE *) (CBM_JIFFY+2);	// lo byte jiffy clock
      for (t=0; t<tim; t+=17) {
	last = *pJif;
	while (*pJif == last);		// Delay 1 jiffy
      }
    #else
      for (t=0; t<tim*10; t++) {
      }	// Approx
    #endif
}
#endif


//BYTE chtab[4] = {46,15,24,45};		/* ".OX-" */
BYTE chtab[4] = {46,81,87,45};		/* ".OX-" */

#if IS_HIRES
 BYTE chtab2[16] = {		/*  2x2 piece set (HIRES) */
	CUSTOM_CHR+6,32,32,32,
	CUSTOM_CHR,CUSTOM_CHR+2,CUSTOM_CHR+1,CUSTOM_CHR+3, 
	CUSTOM_CHR,CUSTOM_CHR+2,CUSTOM_CHR+1,CUSTOM_CHR+3, 
	// CUSTOM_CHR+4,CUSTOM_CHR+6,CUSTOM_CHR+5,CUSTOM_CHR+7, 
	102,102,102,102 };
#else
  BYTE chtab2[16] = {32,32,32,32, 233,223,95,105, 85,73,74,75, 102,102,102,102};	/*  2x2 piece set PETSCII, white diamond */
 //BYTE chtab2[16] = {32,32,32,32, 0xcf,0xd0,0xcc,0xfa, 85,73,74,75, 102,102,102,102};	/*  2x2 piece set PETSCII, white block */
 // BYTE chtab2[16] = {32,32,39,32,  85,73,74,75, 85,73,74,75, 102,102,102,102};	/*  2x2 piece set PETSCII */
#endif

void draw_calcScale ()
{
    sqsize = 1;
    if (flag_gfx) {
      if (sch_boardx * 2 < VDUX - 4 && sch_boardy * 2 < VDUY - 6) sqsize = 2;
    }
    io_txtposy = sch_boardy * sqsize + 4;
}

	/* Draw a piece */
void draw_Piece (int xpos, int ypos, UINTBY ch, UINTBY yoff, UINTBY hilite) 
{
    int p;
    BYTE c;
    BYTE col;
    if (hilite) {
      col = COL_HIWHITE; 
      if (ch == Black) col=COL_HIBLACK;
    } else {
      col = COL_PWHITE; 
      if (ch == Black) col=COL_PBLACK;
    }
    if (sqsize > 1) {
      p = VDUPOS (xpos+xpos, ypos+ypos-1+yoff);
      c = (ch & 3) << 2;
      pVdu [p] = chtab2 [c];
      pVdu [p+1] = chtab2 [c+1];
      #if IS_COLOUR
       pCol[p] = pCol[p+1] = col;
      #endif
      p = p + VDUX ;
      pVdu [p] = chtab2 [c+2];
      pVdu [p+1] = chtab2 [c+3];
      #if IS_COLOUR
       pCol[p] = pCol[p+1] = col;
      #endif
    } else {
      p = VDUPOS(xpos,ypos);
      pVdu [p] = chtab[ch&3];
      #if IS_COLOUR
       pCol[p] = col;
      #endif
    }
}


void draw_Edges ()
{
    int cpos;
    int xlen;
    int botline;
    xlen = sch_boardx * sqsize + 1;
    cpos = VDUX + sqsize - 1;
    botline = VDUPOS (sqsize-1,sch_boardy*sqsize+1);
    for (cpos = VDUPOS (sqsize-1,1); cpos < botline; cpos += VDUX) {
      pVdu [cpos] = CHR_LINE;  
      pVdu [cpos+xlen] = CHR_LINE;
      #if IS_COLOUR
        pCol [cpos] = COL_EDGE;
        pCol [cpos + xlen] = COL_EDGE;
      #endif
    }
    xlen += botline;
    for (cpos = botline; cpos <= xlen; cpos ++) {
       pVdu [cpos] = 160;
       #if IS_COLOUR
         pCol [cpos] = COL_EDGE;
       #endif
    }
    for (cpos=1; cpos<= sch_boardx; cpos++) {
      pVdu [botline+cpos*sqsize-sqsize+1] = 176 + cpos - (cpos>9)*57;
    }
}


#endif		/* IS_CBM */


/*------------------------------------------------------------------------------------
   IS_SPEC - ZX_SPECTRUM specific code
--------------------------------------------------------------------------------------*/

#ifdef IS_SPEC		/* ZX81 specific code */

#define ZX_VDU (0x4000)
#define ZX_COLOR (0x5800)
#define ZX_CHRSET (0x3d00)	// Spectrum charset, for ascii 0x20-0x7f (32-127)
#define ZX_FRAMES 23672
#define ZX_VDUPOS(X,Y)  (((Y) & 7) * 256 + (((Y)/8) & 7) * 32 +((Y)/64) * 2048 + (X))
#define ZX_COLORPOS(X,Y)  ((X) + (Y) * 32)
#define ZX_ULA (0xfe)		// OUT to ULA, bot 3 bits = border col.

#define ZX_RED   2		// ZX raw colours (purple = ZX_RED+ZX_BLUE etc)
#define ZX_GREEN 4
#define ZX_BLUE  1

#define COL_PWHITE  7			// Colours of white/black pieces
#define COL_PBLACK  (ZX_RED+ZX_BLUE)  	// Purple
#define COL_HIWHITE (ZX_RED+ZX_GREEN)	// Yellow. Hilite col (for wins)
#define COL_HIBLACK ZX_BLUE
#define COL_EDGE    (ZX_BLUE+ZX_GREEN)	// Colour of edge/bottom of board

#define CHR_LINE 8 		// UDG vertical border

BYTE game_hires[]= {
	// White piece
  0x00,0x03,0x0f,0x1c,0x3b,0x37,0x6e,0x6d,
  0x6d,0x6e,0x37,0x3b,0x1c,0x0f,0x03,0x00,
  0x00,0xc0,0xf0,0x38,0xdc,0xec,0x76,0xb6,
  0xb6,0x76,0xec,0xdc,0x38,0xf0,0xc0,0x00,
	// Empty
  0,0,0,0,0,0,0,0,
	// Empty sqr dot mark
  0,0,0,0,0,0,0,1,
	// 1x1 small piece
  0x00,0x3c,0x7e,0x7e,0x7e,0x7e,0x3c,0x00,
	// 1x1 empty
  0x00,0x00,0x00,0x00,0x10,0x00,0x00,0x00,
	// Vert Edge
  0x18,0x24,0x24,0x18,0x18,0x24,0x24,0x18,
	// Hor Edge
  //0xaa,0xff,0xff,0xff,0xff,0xff,0xff,0xaa,
  // 0xaa,0xff,0x55,0xff,0xff,0x55,0xff,0xaa,
 0};

  // Output UDG char to spectrum VDU (xpos 0-31,ypos 0-24)
void zx_drawchar (BYTE *pSrc, BYTE xpos, BYTE ypos, BYTE ch, BYTE ink)
{
    UINT x;
    BYTE *pVdu;
    pSrc += ch * 8; 
    x = (UINT) (ZX_COLOR + ZX_COLORPOS(xpos,ypos));
    *((BYTE *) x) = ink;   
    ypos = ypos << 3;
    x = ((UINT) (ZX_VDU + ZX_VDUPOS (xpos,ypos)));
    // io_printsi ((char *) "x=",x);
    pVdu = (BYTE *) x;
    for (x=0; x<8; x++) {
      //pVdu [x << 8] = pSrc [x];
      *pVdu = *pSrc;
      pVdu += 256; pSrc ++;
    }
}

  // Draw char from ROM onto VDU. (ch=ascii 32-127)
void zx_draw_rom_char (BYTE xpos, BYTE ypos, BYTE ch, BYTE ink)
{
    zx_drawchar ( (BYTE *) (UINT) ZX_CHRSET, xpos, ypos, ch-32, ink);
}

void zx_clr_vdu (BYTE ink)
{
    UINT x;
    for (x=0; x< 32*24; x++) {
      ((BYTE *) ZX_COLOR) [x] = ink;
    }
    for (x=0; x< 32*24*8; x++) {
      ((BYTE *) ZX_VDU) [x] = 0;
    }
}

#define VDUX 32
#define VDUY 24
#define VDUPOS(X,Y) ((X)+((Y)<<5)+(Y))

BYTE *pVdu;	/* Ptr to screen */

	/* Init code */
void game_Init ()
{
    sch_level = 3;	/* Level of play */
}

	/* Tidy up, quit. */
void game_Finish ()
{
}


  /* simple print char */
BYTE zx_outchar;
void io_printc (char c) 
{
    /*   // ASM version
    zx_outchar = c;
    __asm 
        ld a,(_zx_outchar)
        rst 0x10	; Call Spec ROM, write char
    __endasm; */
    putchar (c);
}

BYTE io_inktab[] = {0,2,4,6,1,3,5,7};	// Convert from RGB=bit012 to Spectrum Colour index

  // Set print colour
void io_ink (BYTE ink)
{
    io_printc (17); io_printc (0); 	// Paper=black
    io_printc (16); io_printc (io_inktab[ink]); 
}

  // Set print cursor pos
void io_SetPos (int x, int y)
{
    if (x<1 || x>24 || y<1 || y>32) return;
    io_cursorx = x-1; 
    io_cursory = y-1;
    putchar (22); putchar (y-1); putchar (x-1);
}

void io_cls ()
{
    __asm 
        ld a,0
	out (0xfe),a	// Set border black
    __endasm; 
   io_SetPos (1,1);
   io_cursorx = io_cursory = 0;
   zx_clr_vdu (COL_PWHITE);
   //putchar(12);
}

void io_enable_lower_case ()
{
}

void io_clrline (int ypos)
{
    BYTE xpos;
    for (xpos = 0; xpos < VDUX; xpos ++) {
      zx_draw_rom_char (xpos, ypos-1, 32, COL_PWHITE);      
    }
}

void io_sleep (int tim) 
{
    int x;
    for (x=0; x<tim*100; x++) {}
}

/*
char io_getkey ()
{
    return getc (NULL);
}
*/

  /* Read Spectrum keyboard using ROM calls. Return ascii, or 0 if no key */
BYTE *pKeyTab = (BYTE *) 0x0205;	// Translate table in ROM
BYTE zx_key, zx_lastkey;		// Globals for asm call

BYTE io_getkey ()
{
    __asm 
        call 0x028e	; Call Spec ROM, ret keydown (0-27) in E, 255 if none.
        ld a,e
        ld (_zx_key),a
    __endasm;
    if (zx_lastkey == zx_key) return 0;	// Same as last time
    zx_lastkey = zx_key;
    if (zx_key == 255) return 0;		// No key down
    return pKeyTab [zx_key];
}


BYTE chtab[4] = {7,6,6,0};		/* ".OX-" */

BYTE chtab2[16] = {		/*  2x2 piece set (HIRES) */
	5,4,4,4,  0,2,1,3,  0,2,1,3,  5,5,5,5 };

void draw_calcScale ()
{
    sqsize = 1;
    if (flag_gfx) {
      if (sch_boardx * 2 < VDUX - 6 && sch_boardy * 2 < VDUY - 7) sqsize = 2;
    }
    io_txtposy = sch_boardy * sqsize + 3;
}

	/* Draw a piece */
void draw_Piece (int xpos, int ypos, UINTBY ch, UINTBY yoff, UINTBY hilite) 
{
    BYTE ink;
    BYTE c;
    ink = COL_PWHITE; 
    if (ch == Black) ink = COL_PBLACK;
    if (hilite) {
      ink = COL_HIWHITE; 
      if (ch == Black) ink = COL_HIBLACK;
    }
    if (sqsize > 1) {
      ypos += ypos - 1; 
      xpos += xpos;
      c = (ch & 3) << 2;
      zx_drawchar (game_hires, xpos,   ypos,   chtab2[c],   ink);
      zx_drawchar (game_hires, xpos+1, ypos,   chtab2[c+1], ink);
      zx_drawchar (game_hires, xpos,   ypos+1, chtab2[c+2], ink);
      zx_drawchar (game_hires, xpos+1, ypos+1, chtab2[c+3], ink);
    } else {
      zx_drawchar (game_hires, xpos, ypos, chtab[ch&3], ink);
    }
}

void draw_Edges ()
{
    int xpos, ypos;
    int xtop,ytop, yend, xend;
    ytop = 1; xtop = sqsize - 1;
    xend = xtop + sch_boardx * sqsize + 1;
    yend = sch_boardy * sqsize ;
    for (ypos = ytop; ypos <= yend; ypos ++) {
      zx_drawchar (game_hires, xtop, ypos, CHR_LINE, COL_EDGE);      
      zx_drawchar (game_hires, xend, ypos, CHR_LINE, COL_EDGE);      
    }
    for (xpos = xtop; xpos <= xend; xpos ++) {
      //zx_drawchar (game_hires, xpos, ypos, CHR_LINE+1, COL_EDGE);      
      zx_draw_rom_char (xpos, ypos, 32, COL_EDGE*8);      
    }
    for (xpos=1; xpos<= sch_boardx; xpos++) {
      zx_draw_rom_char (xtop+xpos*sqsize-sqsize+1, ypos, 48 + xpos + (xpos>9)*7, COL_EDGE*8);      
    }
}

#endif 			/* IS_SPEC */

/*------------------------------------------------------------------------------------
   IS_ZX81 - ZX81 specific code
--------------------------------------------------------------------------------------*/

#ifdef IS_ZX81		/* ZX81 specific code */

//#include <input.h>
//#define VDU_GOTOXY(X,Y) {putchar (22); putchar(X); putchar(Y);}

#define VDUX 32
#define VDUY 24
#define VDUPOS(X,Y) ((X)+((Y)<<5)+(Y))

BYTE *pVdu;	/* Ptr to screen */

	/* Init code */
void game_Init ()
{
    int x;
    int *pv = 16396;
    pVdu = (BYTE *) ((int) pv[0]) + 1;
    sch_level = 3;	/* Level of play */
}

	/* Tidy up, quit. */
void game_Finish ()
{
}

 // Table Convert lower ascii (32-63) to zx81 codes
BYTE asc2zx[32] = {0,1,11,8,13,8,8,1,16,17,23,21,26,22,27,24, 28,29,30,31,32,33,34,35,36,37, 14,25,19,20,18,15};

/*
  ASCII: " !"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\]^_`abcdefghijklmnopqrstuvwxyz{|}~"
  ZX81 char set:
  ----0---1---2---3---4---5---6---7---8---9---A---B---C---D---E---F----
  00 SPC [' ][ '][''][. ][: ][.'][:']{::}{..}{''} "  GBP  $   :   ?  0F
  10  (   )   >   <   =   +   -   *   /   ;   ,   .   0   1   2   3  1F
  20  4   5   6   7   8   9   A   B   C   D   E   F   G   H   I   J  2F
  30  K   L   M   N   O   P   Q   R   S   T   U   V   W   X   Y   Z  3F
*/

/*
BYTE zx_outchar;
void io_printc (char c) 
{
       // ASM version
    if (c & 64) {	// Convert ASC to ZX81 
      c = ((c & 31) + 37) & 63;
    } else {
      c = asc2zx[c & 31];
    }
    zx_outchar = c;
    __asm 
        ld a,(_zx_outchar)
        rst 0x10	; Call Spec ROM, write char
    __endasm; 
    //putchar (c);
} */

  /* Simple ZX81 print char direct */
void io_printc (char c) 
{
    if (c == 10) {
      io_cursorx = 0;
      if (io_cursory < VDUY) io_cursory ++;
      return;      
    }
    if (c < 32) return;
    if (c & 64) {	/* Convert ASC to ZX81 */
      c = ((c & 31) + 37) & 63;
    } else {
      c = asc2zx[c & 31];
    }
    pVdu [(int) VDUPOS (io_cursorx, io_cursory)] = (BYTE) c;
    io_cursorx ++;
    if (io_cursorx >= VDUX) {
      io_cursorx = 0;
      if (io_cursory < VDUY) io_cursory ++;
    } 
    //putchar (c);
}

#define io_ink(INK) ;	// Empty def (ZX81 no col)

void io_cls ()
{
   io_cursorx = io_cursory = 0;
   putchar(12);
   // int x; for (x=0; x<30; x++) { pVdu[x] = x;}
}

void io_enable_lower_case ()
{
    putchar (14);
}

void io_clrline (int ypos)
{
    BYTE x;
    BYTE *pLin = pVdu + VDUPOS (0, ypos-1);
    for (x=0; x<VDUX; x++) {
      pLin[x] = 0;
    }
}

void io_SetPos (int x, int y)
{
    io_cursorx = x-1; 
    io_cursory = y-1;
}

void io_sleep (int tim) 
{
    msleep (tim);
}

char io_getkey ()
{
    return getchar ();
}

BYTE chtab[4] = {27,52,61,22};		/* ".OX-" */

BYTE chtab2[16] = {27,0,0,0,  6,4,2,0, 7,5,3,1, 0,22,0,0};	/* ZX81: 2x2 piece set */

void draw_calcScale ()
{
    sqsize = 1;
    if (flag_gfx) {
      if (sch_boardx * 2 < VDUX - 6 && sch_boardy * 2 < VDUY - 7) sqsize = 2;
    }
    io_txtposy = sch_boardy * sqsize + 4;
}

	/* Draw a piece */
void draw_Piece (UINTBY xpos, UINTBY ypos, UINTBY ch, UINTBY yoff, UINTBY hilite) 
{
    XSTATIC int p;
    XSTATIC BYTE c;
    if (sqsize > 1) {
      p = VDUPOS (xpos+xpos, ypos+ypos-1+yoff);
      c = (ch & 3) << 2;
      pVdu [p] = chtab2 [c];
      pVdu [p+1] = chtab2 [c+1];
      p = p + VDUX + 1;
      pVdu [p] = chtab2 [c+2];
      pVdu [p+1] = chtab2 [c+3];
    } else {
      pVdu [VDUPOS(xpos,ypos)] = chtab[ch&3];
    }
}

void draw_Edges ()
{
    int p,p2,x,y;
    //if (sqsize == 1) return;
    y=sch_boardy*sqsize;
    p2 = VDUPOS (1,y);
    x = sch_boardx * sqsize + sqsize;
    for (p = VDUPOS (1,1)-1; p<p2; p+= VDUX + 1) {
       pVdu [p] = 8;
       pVdu [p+x] = 8;
    }
    p2 = p+x;
    for (; p<=p2; p++) {
       pVdu [p] = 128;
    }
    p2 = VDUPOS (0,y+1);
    for (x=1; x<= sch_boardx; x++) {
      pVdu [p2+x*sqsize] = 156 + x;
    }
}

#endif		/* IS_ZX81 */


//------------------------------------------------------------------------------------
// IS_8BIT : Code common to all platforms..

	/* Draw the game sch_Board */
void draw_Board () 
{
    UINTBY ch;
    XSTATIC UINTBY xpos,ypos;
    for (ypos = 1; ypos <= sch_boardy; ypos ++) {
      for (xpos = 1; xpos <= sch_boardx; xpos ++) {
	ch = GetBoard(xpos,ypos);
        draw_Piece (xpos, ypos, ch,0,0);
      }
    }
}

  /* Animate piece move/drop  */
void draw_DropPiece (UINTBY dxpos, UINTBY dypos, UINTBY dcol)
{
    XSTATIC UINTBY typos;
    MY_ASSERT ((UINT) dxpos <= (UINT) sch_boardx);
    for (typos = 1; typos < dypos; typos ++) {
      MY_ASSERT ((UINT) typos <= (UINT) sch_boardy);
      draw_Piece (dxpos, typos, dcol,0,0);
      io_sleep (10);
      draw_Piece (dxpos, typos, 0,0,0);
      if (sqsize == 2) {
        draw_Piece (dxpos, typos, dcol,1,0);
        io_sleep (10);
        draw_Piece (dxpos, typos, 0,0,0);
      }
    }
    draw_Piece (dxpos, dypos, dcol,0,0);
}

void draw_Side (int mode)
{
    if (gameover) {
      io_ink (IO_INK_RED);
      if (gameover == DRAWN) {
        io_prints ((char *) "Drawn.");
        return;
      }
    }
    if (sch_side == White) {
      io_prints ((char *) "White");
    } else {
      io_prints ((char *) "Black");
    }
    if (gameover) {
      io_prints ((char *) " wins.");
      return;
    } 
    if (mode & 1) {
      io_prints ((char *) "...");
    } else {
      io_prints ((char *) " move.");
    }
}

void draw_TextInfo (int mode)
{
      io_SetPos (1,io_txtposy);
      io_ink (IO_INK_GREEN);
      io_printsi ((char *) "IQ:",sch_level);
      io_prints ((char *) " ");
      io_ink (IO_INK_YELLOW);
      draw_Side (mode);
      if (sch_bestx) {
        io_ink (IO_INK_PURPLE);
        io_SetPos (1,io_txtposy+1);
        io_printsi ((char *) "Move:",sch_bestx);
        io_printsi ((char *) " Eval:",beval);
        #if USE_TIME
          io_printsi ((char *) " Time:", sch_timeMove);
        #endif
        io_printsi ((char *) " Node:",nodecount);
	io_prints ((char *) "  ");
      }
      io_SetPos (1,io_txtposy+2);
      io_ink (IO_INK_BLUE );
      if (flag_twoplay) io_prints ((char *) " 2 Player mode.");
      if (flag_edit) io_prints ((char *) "  Edit mode.");
}

  /* Hilight win line */
void draw_WinLine ()
{
    int cpos;
    if (winpos == 0) return;
    if (sch_Board [winpos] != gameover) return;
    for (cpos = winpos; sch_Board [cpos] == gameover; cpos += windir) {
      draw_Piece (Pos2X (cpos), Pos2Y (cpos), gameover,0,1);
    }
    for (cpos = winpos; sch_Board [cpos] == gameover; cpos -= windir) {
      draw_Piece (Pos2X (cpos), Pos2Y (cpos), gameover,0,1);
    }
}


  /* Redraw sch_Board and text */
void draw_All ()
{
    draw_calcScale ();
    //io_cls ();
    draw_Board ();
    draw_TextInfo (0);
    draw_Edges ();
    draw_WinLine ();
    // int x; for (x=32; x< 64; x++) putchar(x);
}

#ifdef MINIMAL
void game_Help () {}
#else
char szHelp [] = 
 "\n\n"
 "1-9,A-C: Make move\n"
 "N:New game\n"
 "X:Change board width\n"
 "Y:Change board height\n"
 "I:Change play level\n"
 "G:Make computer play\n"
 "T:Toggle 2-player\n"
 "H:Help screen\n"
 "Z:Auto-play\n"
 "Q:Quit\n";

char szHelp2 [] = "\nHit ENTER to play\n";

  /* Display a Help/Title screen. */
void game_Help ()
{
    //BYTE bb;
    io_ink (IO_INK_WHITE);
    io_cls ();
    io_enable_lower_case ();
    szProg [SZPROG_SPLIT] = 10;
    io_prints (szProg);
    #if VDUX>31
      io_ink (IO_INK_PURPLE);
      io_prints (szProg2);
    #endif
    io_ink (IO_INK_CYAN);
    io_prints (szHelp);
    io_ink (IO_INK_YELLOW);
    io_prints (szHelp2);
    // Some little tests..
    //for (bb = 0; bb < 8; bb++) { io_ink(bb); io_printsi ((char *) "#",bb);}
    // do { bb = io_getkey(); if (bb) io_printsi ((char *) "key",bb); } while (bb != 13);
    while (io_getkey() == 0);
    io_cls ();
}

#endif

  /* Call engine to search for best move */
void game_ExecComp ()		
{
	io_clrline (1);
        io_ink (IO_INK_PURPLE);
        io_SetPos (1,1);
	io_prints ((char *) "Hmm..");
	sch_CompMove ();		/* Find best comp sch_bestx,sch_besty */
	if (sch_bestx > 0 && sch_besty > 0) {
	  sch_besty = sch_FindYPos (sch_bestx);		/* ensure */
	  cxpos = sch_bestx; cypos = sch_besty;
	  ceval = sch_EvalPos (sch_bestx, sch_besty, sch_side);			/* 5 line ? */
	  SetBoard ( sch_bestx, sch_besty, sch_side);
	  if (flag_anim) draw_DropPiece ( sch_bestx, sch_besty, sch_side);
	  MY_ASSERT ((UINT) sch_bestx <= (UINT) sch_boardx);
	  MY_ASSERT ((UINT) sch_besty <= (UINT) sch_boardy);
	  lastx = sch_bestx; lasty = sch_besty;
	  draw_All ();
	  pxpos = sch_bestx; pypos = sch_besty;
	  if (sch_isGameOver (sch_bestx, sch_besty)) {		/* Win.. */
	    return;
	  }
	  sch_side = 3 - sch_side;
	} else {
	  gameover = DRAWN;
	  automode = 0;
	}
}

int game_PlayerMove (int mov)
{
	if (mov < 1 || mov > sch_boardx) return FALSE;
	if (gameover) return FALSE;
	pxpos = mov;
	pypos = sch_FindYPos (pxpos);
	if ( pypos < 1) {
	  return FALSE;
	}
        ceval = sch_EvalPos (pxpos, pypos, sch_side);			/* win - line ? */
	SetBoard (pxpos, pypos, sch_side);
	if (flag_anim) draw_DropPiece ( pxpos, pypos, sch_side);
	lastx = pxpos; lasty = pypos;
	if (sch_isGameOver (pxpos, pypos)) {		/* Win/Draw.. */
	  return FALSE;
	}
	sch_side = 3 - sch_side;
	draw_All ();
	return TRUE;
}

void sch_callback (UINTBY sxpos, UINTBY sypos, int seval)		/*KR sch_callback (sxpos, sypos, seval) int sxpos, sypos, seval; */
{
    io_SetPos (7,1);
    io_printi (sxpos);
    io_printsi ((char *) "=",seval);
    io_prints ((char *) "    ");
}

void game_Loop ()
{
    BYTE cpos;
    BYTE cmd;
    int cret;
    game_Help ();
    //io_cls ();
    sch_NewGame ();
	/* Main program loop */
    do {
	draw_All ();		/* Draw board & text info */
	if (autoplay) {
	  game_ExecComp ();
	  if (io_getkey () == ' ') autoplay = 0;
	  if (gameover == 0) continue;
	  draw_All ();		/* Draw board & text info */
	}
	autoplay = 0;
        io_SetPos (1,1);
        io_ink (IO_INK_YELLOW);
        io_prints ((char *) "CMD: (GIVNTQXY,H=Help)");
	#ifdef IS_C16
	#endif
	// gets (istr); cmd = istr[0];
        do {
	  cmd = io_getkey ();
	  #if MY_DEBUG
	    #ifdef CBM_JIFFY		// Test, show clock running
	      IO_POKE (CBM_VDULOC, IO_PEEK(CBM_JIFFY));
	      IO_POKE (CBM_VDULOC+1, IO_PEEK(CBM_JIFFY+1));
	      IO_POKE (CBM_VDULOC+2, IO_PEEK(CBM_JIFFY+2));
	    #endif
	  #endif
	} while (cmd == 0);
        cmd = IO_TOUPPER(cmd);
		/* Move column 1-9 */
        cpos = cmd - '0';
        if (cmd >= 'A') cpos = cmd + 10 - 'A';
	if (cpos <= sch_boardx) {
	  cret = game_PlayerMove (cpos);
	  if (cret == FALSE) continue;
	  if (gameover == 0 && flag_twoplay == 0) {
	    game_ExecComp ();
	  }
	  continue;
	}

        switch (cmd) {
	  case 'G':		/* Make computer take go */
	    if (gameover) break;
	    game_ExecComp ();
	    break;

	  case 'X':		/* Change Board width */
	    sch_boardx ++; 
	    if (sch_boardx > 12) sch_boardx = 4;
	    sch_NewGame ();
	    io_cls ();
	    break;

	  case 'Y':	      		/* Change Board height */
	    sch_boardy ++; 
	    if (sch_boardy > 12) sch_boardy = 4;

	  case 'N':		/* New game */ 
	    sch_NewGame ();
	    autoplay = 0;
	    io_cls ();
	    break;

	  case 'H':		/* Help */
	    game_Help ();
	    break;

	  case 'I':		/* IQ level */
	    if (flag_twoplay) { 
	      sch_level = (sch_level & 15) + 1;
	    } else {
	      sch_level = (sch_level & 7) + 1;
	    }
	    break;;

	  case 'U':
	    flag_anim = !flag_anim;
	    break;

	  case 'V':
	    flag_gfx = !flag_gfx;
	    io_cls ();
	    break;

	  case 'Z':
	    if (gameover) break;
	    autoplay = !autoplay;
	    io_cls ();
	    break;

	  case 'T':
	    flag_twoplay = !flag_twoplay;
	    sch_bestx = 0;
	    io_cls ();
	    break;

	  case 'Q':		/* Quit */
	    // exit (1);
	    return;

	  default:
	    break;
	}	
     
    } while (1);
}


	/* Main program */
int main ()
{
    game_Init ();
    game_Loop ();
    game_Finish ();
    return 0;
}

#endif   	/* IS_8BIT */

//------------------------------------------------------------------------------------
