/*  Header for SDLTXT.C  - SDL bitmap font rendering lib, render strings to sdl surface. 
  (C) A.Millett 2025, Released as free software under GNU GPL3 license.
  Provides a set of functions in form: SDLTXT_func (..) 
*/

#define FALSE 0
#define TRUE  1

	/* Data for a bitmap font*/
typedef struct  {
  int is_user_font;	// Set to 1 for user font, otherwise default 
  unsigned char *pFontData;	// Raw data for each char.
  int fontx,fonty;	// Size of source font 
  int outx,outy;	// Scaled output font size
  int nchar;		// No of chars in set 
  int startchar;	// Ascii start char in set 
  int scale;		// % Size to rescale when printing (100=default, same size as source)
  SDL_Texture  *fontTexture;	// Texture to hold bmp ready to render to screen 
} SDLTXT_FONT;

int SDLTXT_CreateFont (SDL_Renderer * pRenderer, SDLTXT_FONT *pFont);
void SDLTXT_DestroyFont (SDLTXT_FONT *pFont) ;
void SDLTXT_SetOutputRenderer (SDL_Renderer * pRenderer);
void SDLTXT_SetColor (Uint8 r, Uint8 g, Uint8 b); 
void SDLTXT_SetCursorPos (int xpos, int ypos);
void SDLTXT_SetScale (int scale);
int SDLTXT_PrintChar (unsigned char cchr);
int SDLTXT_PrintStr (char *pStr);
int SDLTXT_PrintInt (long xint);
int SDLTXT_PrintStrInt (char *pStr, long xint);
int SDLTXT_ShowSet ();

//----------------------------------------------------------------------
 /* Very simple toolbar mini API */
typedef struct {
  int sizex,sizey;		// Size of buttons
  int nbuttons;			// no of buttons
  int topx,topy;		// pos to render them
  SDL_Texture  *pTTexture;	// Texture to hold bmp ready to render to screen 
} SDLTOOL_DATA;

int SDLTOOL_Create (SDLTOOL_DATA *pTool, SDL_Renderer * pRender, char *pName);
void SDLTOOL_Draw (SDLTOOL_DATA *pTool, SDL_Renderer * pRender);
int SDLTOOL_Service (SDLTOOL_DATA *pTool, int hitx, int hity);
void SDLTOOL_Destroy (SDLTOOL_DATA *pTool);



