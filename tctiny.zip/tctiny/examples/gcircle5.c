/* 
  GCIRCLEx.C   -  Circular function effects. a Freeware demo. (C) A.Millett 2013.

    Build using:  tctiny [TC3PATH] gcircle5 

*/

#include "tctiny.c"

#define VDUX 320	/* 320x200 in VGA mode 0x13 */
#define VDUY 200
#define VDUMAX (VDUX * VDUY)
#define VDUPOS(x,y) ((y)*VDUX+(x))

int io_rand;
BYTE far *pVdu;	

  /* Assort circular functions to try.. */

#define CALC1 (tim+(x*x+pre))				/* Simple circles */
#define CALC2 (tim+(x*x-pre))
#define CALC3 (tim+(x*pre))
#define CALC4 (tim+(x*y+pre))
#define CALC5 (tim+(x*x^pre))
#define CALC6 (tim+(x*x+pre)^x)
#define CALC7 (tim+(x*x-pre)^x)
#define CALC8 (tim+(x*x^pre)*(y))
#define CALC9 (tim+(x*x+pre)^(x-y))
#define CALC10 (tim+((x<<6)/(y+4)+pre))		/* Sideways 3d fly */
#define CALC11 (tim+((x<<6)/(y+4)-pre))		/* Sideways 3d fly */
#define CALC12 (tim+(((x<<6)/(y+4))+pre/(x+4)))		/* Sideways 3d fly */
#define CALC14 (tim+(x<<6)/(y+8)^pre)
#define CALC15 (tim+(y<<6)/(x+4)^pre)
#define CALC16 (tim+pre/(x+4)^x)
#define CALC17 (64*(tim+x)/(y+4)^x)			/* Singularity  GCIRCLE3Q.COM */
#define CALC18 ((15*tim+(x*y))/(1+(x^y)))		/* LavaLamp     GCIRCLE3R.COM */
#define CALC19 ((15*tim+(pre))/(1+(x^y)))
#define CALC20 tim+(pre/x)-(x^y)
#define CALC21 (tim+(x<<6)/(y+8)^(y+x))    /* GCIRCL4A.COM */
#define CALC22 (tim+(x*x+pre))	

void main ()
{
    int x,y,ytop;   
    int tim,pre;
    int ch;
    IO_VIDEOMODE (0x13);	/* Set VGA video mode 13h 320x200x256 */
	/* Generate a simple 256 color palette  */
    IO_OUTPORT(0x3c8,0);
    for (x =0; x < 256; x ++) {
      IO_OUTPORT (0x3c9, x);        
      IO_OUTPORT (0x3c9, x/2);        
      IO_OUTPORT (0x3c9, x*2);        
    }
    tim = 1;
    do {
      pVdu = (BYTE far *) ((long) 0xa0000000);		/* Top of VDU */
      if(tim&1) pVdu+=VDUX;
      for (y=(tim&1)+1; y<VDUY; y+=2) {
        pre = y*y;			/* pre-calc y*y */
        for (x=1; x<VDUX; x++) {
          *pVdu = CALC21;		/* Try CALC1..CALC21 here for different FX */
	    pVdu ++;
	  }
	  pVdu += VDUX+1; 
	}
	tim++;
      IO_GETKEY(ch);
    } while (!ch);
}
