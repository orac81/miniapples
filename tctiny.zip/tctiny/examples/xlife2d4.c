/* 
  XLIFE2Dx.C  - 2D Life/Cellular Automata demo, in <256 bytes for TurboC + TCTINY.

   (C) A.Millett 2012-2025. Released as free software under GNU GPL3 license. 
	(See: www.gnu.org/licenses/gpl-3.0.html )

   SPACE to generate new pattern. 
   ESC to end.
   
   Use TCTINY [TC3PATH] XLIFE2Dx   to build tiny .COM file (<1k)

*/

#include "tctiny.c"

char far *pVdu;
char far *pTop = (char far *) ((long) 0xa0000000);		/* Vdu top, also used as "Rules" array */

#define XMOD 5

/*char szMsg[]="XLIFE2D - Freeware (C) A.Millett 2013.\r\n$";*/

void main ()
{
    register unsigned int x;
    int io_rand;
    
		/* Set VGA video mode 13h 320x200x256 */
    IO_VIDEOMODE (0x13);
    do {
      /* IO_SRAND (IO_TIMER); */
		/* Top line is a "rules" lookup table for rest of screen */
      for (x=0; x<320; x ++) {
	pTop [x] = IO_RAND % XMOD;
      }
      pVdu = pTop;
	for (x= 63679; x; x--) {
	  pVdu [321] = XMOD+pTop[(*pVdu+pVdu[1]+pVdu[2]) % XMOD];
	  pVdu ++;
	}
	do {
          IO_GETKEY (x); 
          io_rand ++;
	} while (x == 0);
    } while (x != 27);
    IO_VIDEOMODE (3);
    /* IO_PUTS(szMsg); */
}

