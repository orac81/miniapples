/*	HELLOW.C

Simplest Demo for TCTINY library

 To build: tctiny [tc3path] hellow

*/

#include "tctiny.c"

char str[] = "Hello World.$";

void main()
{
    IO_PUTS (str); 
}
