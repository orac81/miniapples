/* 
  GPLASMAx.C   -  Plasma effects, using int maths. 
    A Freeware demo. (C) A.Millett 2014.

    Build using   MAKPICO GPLASMAx -f87

   Working version.
  ->GPLASMA1.C  (30.10.2014)
   Use larger patterns
   Imp qsine(), use 64 byte sinetab, use reflect to gen all vals.
  ->GPLASMA2.C  (31.10.2014)  (452 bytes)
   Adjust for larger pattern
  ->GPLASMA3.C  (31.10.2014)  (500 bytes)
   Imp palette change every few seconds
  ->GPLASMA4.C  (31.10.2014)
   Imp more complex factors..
  ->GPLASMA5.C  (20.11.2014)
   Imp more complex factors..
  ->GPLASMA6.C  (28.12.2014)

*/

#include "tctiny.c"

#define PALETTE_CHANGES 1	/* Palette rotates every few seconds */
#define FLYBACK_SYNC    0	/* Lock to hardware flyback */
#define ALT_SCANLINES   0	/* Alt scanlines per frame for faster rendering */


#define VDUX 320	/* 320x200 in VGA mode 0x13 */
#define VDUY 200
#define VDUMAX (VDUX * VDUY)
#define VDUPOS(x,y) ((y)*VDUX+(x))

int io_rand=0;
BYTE far *pVdu;	

	/* Sine lookup table range -127..127.. */
BYTE sintab [64] = {
  128,131,134,137,140,143,146,149,152,155,159,162,165,168,171,173,
  176,179,182,185,188,190,193,196,198,201,204,206,209,211,213,216,
  218,220,222,224,226,228,230,232,234,235,237,239,240,242,243,244,
  245,247,248,249,250,251,251,252,253,253,254,254,255,255,255,255};


BYTE bufx[VDUX+4];
BYTE bufy[VDUY+4];

int  px1start=0;		/* Start index offset for sine tables */
int  px2start=0;
int  px3start=0;
int  py1start=0;
int  py2start=0;
int  py3start=0;

		/*  X STEP factors (2,0,1,2) */
#define STEPSX1 2
#define STEPSX2 1
#define STEPSX3 3
#define STEPX1 1
#define STEPX2 1
#define STEPX3 3

		/* Y STEP factors (1,-2,2,-1) */
#define STEPSY1 1
#define STEPSY2 1
#define STEPSY3 (-2)
#define STEPY1 1
#define STEPY2 1
#define STEPY3 4


int qsine (int x)
{
    int r=sintab[x & 127];
    if (x & 64) {
      r = sintab[63-(x & 63)];
    }
    if (x & 128) {
      return (256-r);
    }
    return (r);
}

void main ()
{
    int x,y;
    int tim,ypre,tmp;
    int rndx,rndy;
    int ch;
    unsigned int px1,px2,px3;
    unsigned int py1,py2,py3;	
    int  ti1;
    IO_VIDEOMODE (0x13);	/* Set VGA video mode 13h 320x200x256 */
    tim = 0;
    rndx = rndy = 0; 
    do {

     #if PALETTE_CHANGES
      if ((tim & 1023) == 0) {
        int d1,d2,d3;
	d1=(IO_RANDTIME & 3) + 1;
	d2=((io_rand/4) & 3) + 1;
	d3=((io_rand/16) & 3) + 1;
	/* Generate a simple 256 color palette  */
        IO_OUTPORT(0x3c8,0);
        for (x =0; x < 256; x ++) {
          IO_OUTPORT (0x3c9, x/d1);        
          IO_OUTPORT (0x3c9, x/d2);        
          IO_OUTPORT (0x3c9, x/d3);        
        }
	rndx = (IO_RANDTIME & 3)+1; 
	rndy = ((io_rand/4) & 3)+1;
      }
     #endif /* PALETTE_CHANGES */

     #if FLYBACK_SYNC
       do {
         IO_INPORT (x,0x3da);
       } while (x & 8);
       do {
         IO_INPORT (x,0x3da);
       } while ((x & 8) == 0);
     #endif

      ti1=qsine(tim)/64;
		/* Gen precalc X sin pattern table bufx[] */
      px1start += STEPSX1; px2start += STEPSX2; px3start += STEPSX3; 
      /* px1start += 2; px2start -= 3;  */
      px1 = px1start; px2 = px2start; px3 = px3start;
      for (x=0; x<VDUX; x++) {
        tmp = (qsine(px2/4) * qsine(px3))/256;
        bufx[x] = tmp + (qsine(px1/2) - qsine(px2+ti1));
        px1+= STEPX1; px2 += (rndx);  px3 += STEPX3;
      }
		/* Gen precalc Y sin pattern table bufy[] */
      py1start += STEPSY1; py2start += STEPSY2;  py3start += STEPSY3;
      /* py1start ++; py2start -= 2; */
      py1 = py1start; py2 = py2start;  py3 = py3start;
      for (y=0; y<VDUY; y++) {
        tmp = (qsine(py2/4) * qsine(py3))/256;
        bufy[y] = tmp + (qsine(py1/2) - qsine(py2+ti1))+y;
        py1+= STEPY1; py2 += (rndy); py3 += STEPY3;
      }
		/* Fill screen using precalc tables */
      pVdu = (BYTE far *) ((long) 0xa0000000);		/* Top of VDU */
      #if ALT_SCANLINES
        for (y=(tim & 1); y<VDUY; y += 2) {
	  pVdu = (BYTE far *) ((long) 0xa0000000) + y*VDUX;
      #else
        for (y=0; y<VDUY; y ++) {
      #endif
        ypre = bufy[y];
        for (x=0; x<VDUX; x++) {
          *pVdu = (ypre + bufx[x]);
	  pVdu ++; x++; 
	  *pVdu = (ypre + bufx[x]);
	  pVdu ++;
	}
      }
      tim++;
      IO_GETKEY(ch);
    } while (!ch);
}
