/* 
  GTOASTY.C   -  Simple "fire" graphic effects for MSDOS/TurboC. 
    a Freeware demo. (C) A.Millett 2013-25.
    Build using   TCTINY TC3PATH GTOASTY4
*/

#include "tctiny.c"

#define VDUX 320	/* 320x200 in VGA mode 0x13 */
#define VDUY 200
#define VDUMAX (VDUX * VDUY)
#define VDUPOS(x,y) ((y)*VDUX+(x))

#define USER_PALETTE TRUE

BYTE far *pVduTop = (BYTE far *) ((long) 0xa0000000);		/* Top of VDU */
BYTE far *pVdu;

  /* Simple rand() function */

int io_randv = 1234;
int io_randv2 = 4567;

int io_rand ()
{
    io_randv = ((io_randv) ^ 0xCDCD) + 17 + (io_randv2 +=  (io_randv >> 8));
    return io_randv & 32767;
}

#define XMARGIN  4

  /* Main program loop.. */

void main ()
{
    int x,y,a;
    int rn;
    int ch;
    unsigned int stp,tim;
    
    IO_VIDEOMODE (0x13);	/* Set VGA video mode 13h 320x200x256 */
 
    #if USER_PALETTE		/* Generate a simple 256 color palette: black->red->yellow->white */
      IO_OUTPORT(0x3c8,0);
      for (x =0; x < 64; x ++) {
        IO_OUTPORT (0x3c9, 0);        
        IO_OUTPORT (0x3c9, 0);        
        IO_OUTPORT (0x3c9, 0);        
      }
      for (x =0; x < 64; x ++) {
        IO_OUTPORT (0x3c9, x);        
        IO_OUTPORT (0x3c9, 0);        
        IO_OUTPORT (0x3c9, 0);        
      }
      for (x =0; x < 64; x ++) {
        IO_OUTPORT (0x3c9, 63);        
        IO_OUTPORT (0x3c9, x);        
        IO_OUTPORT (0x3c9, 0);        
      }
      for (x =0; x < 64; x ++) {
        IO_OUTPORT (0x3c9, 63);        
        IO_OUTPORT (0x3c9, 63);        
        IO_OUTPORT (0x3c9, x);        
      }
    #endif
		/* Main animation loop */
    do {      
      tim = 0;
        /* Create random line */
      for (x=XMARGIN; x<VDUX-XMARGIN; x++) {
        pVduTop [(VDUY-2)*VDUX+x] = 64 | (io_rand () & 255);	    
        pVduTop [(VDUY-1)*VDUX+x] = 255;	    
      }
      for (y=100; y<VDUY-2; y++) {
        a = 0;
        rn = io_rand ();
        pVdu = pVduTop + y * VDUX + XMARGIN;
        for (x=VDUX+XMARGIN*2; x; x--) {
          a = (a + pVdu [1] + pVdu[VDUX] +  pVdu[VDUX*2] + ((rn += io_randv2 ^ io_randv--)&63)-34)/4;
          /* a = (a + pVdu [1] + pVdu[VDUX] +  pVdu[VDUX*2] + (io_rand ()&63)-35)/4; */
          if ((unsigned) a > 255) a = 0; 
          *pVdu = a;
          pVdu ++;
        }
      }
      
      tim ++;
      IO_GETKEY(ch);
    } while (tim && !ch);
    IO_VIDEOMODE (3);	/* Back to text mode */
    IO_PUTS ("TOASTY! (C) A.Millett 2018. Freeware!\n$");
}
