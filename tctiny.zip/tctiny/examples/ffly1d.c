/* MAGIXFLY.C  - Tiny 3d fly landscape demo.
   (C) A.Millett 2012-2025. Released as free software under GNU GPL3 license. 
	(See: www.gnu.org/licenses/gpl-3.0.html )
   Simple Demo of ultra-small compilation under TurboC.

   To compile: TCTINY [tc3path] magixfly
   ie: tctiny \m\tc3\bin magixfly
   (needs MASM and exe2bin, or TASM)
*/

#include "tctiny.c" 

/* int _stklen = 0x200; */

char far *pVdu;
int ch;

main() 
{
    int y;
    register int x;
    int tim,t1,v1;

    IO_VIDEOMODE (0x13);	/* Set VGA video mode 13h 320x200x256 */
    
    do {
      tim= (tim+1)&127;
      t1=tim-64; t1=(t1*t1)>>6;
      for (y=1; y<200; y++) {
        v1 = ((1190/y) + (tim>>1)) & 15;
        pVdu = (char far *) ((long) 0xa0000000 + ((unsigned int) y) * 320);
        for (x=0; x<320; x ++) {
          pVdu [x] = (((((159+t1-x)<<3)/y) & 15) ^ v1) + 12;
        }
      }
      IO_GETKEY(ch);               /* See if ESC key hit */
    } while (ch != 27);
}
