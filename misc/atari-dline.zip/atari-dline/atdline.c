/* ATDLINE.C - Atari800 - simple Atari lib + random line demo for Oscar64 C Compiler..
  By orac81, Free/open software.   About 700 Bytes.

To Build:  oscar64 -tm=atari atari-demoline.c -Os
 
*/

#include <stdio.h>

/*========================================================================
   Common Atari Library, asm, defines, routine, vars, fwd declarations
==========================================================================*/

typedef unsigned char BYTE;
typedef unsigned int UINT;

#define TDL_POKE(AD,BY) *((BYTE *) ((UINT) (AD)))=(BYTE) (BY);
#define TDL_PEEK(AD) ((BYTE) *((BYTE *) ((UINT) (AD))))
#define TDL_DOKE(AD,VAR) *((UINT *) ((UINT) (AD)))=(UINT) (VAR);
#define TDL_DEEK(AD) ( *((UINT *) ((UINT) (AD))))

#define ATARI_VDU      88	// Screen top
#define ATARI_RAMTOP   106	// Hi of ram top
#define ATARI_MEMTOP   741	// Ptr memtop
#define ATARI_DISPLIST 560	// Display list
#define ATARI_CHBAS    756	// Char set base, shadow D409
#define ATARI_ROMSET   0xE000

#define ATARI_CIOV   $E456
#define ATARI_ICHID  $0340
#define ATARI_ICDNO  $0341
#define ATARI_ICCOM  $0342
#define ATARI_ICSTA  $0343
#define ATARI_ICBAL  $0344
#define ATARI_ICBAH  $0345
#define ATARI_ICPTL  $0346
#define ATARI_ICPTH  $0347
#define ATARI_ICBLL  $0348
#define ATARI_ICBLH  $0349
#define ATARI_ICAX1  $034A
#define ATARI_ICAX2  $034B

#define ATARI_COLOR0    0x02C4
#define ATARI_COLCRS    0x55
#define ATARI_ROWCRS    0x54
#define ATARI_ATACHR    0x02FB
#define ATARI_STORE1    0xCC
#define ATARI_STOCOL    0xCD

char atari_scr[] = "S:";

  /* Set Atari Graphics mode using OS */
void atari_Graphics (BYTE mode)
{
    __asm {
      ldx # $60			// use IOCB6 
      lda # $0c			// Close old
      sta ATARI_ICCOM,x
      jsr ATARI_CIOV

      ldx # $60
      lda # $03			// open
      sta ATARI_ICCOM,x
      lda # < atari_scr 	// Address "S:" string
      sta ATARI_ICBAL,x
      lda # > atari_scr 
      sta ATARI_ICBAH,x
      lda mode
      sta ATARI_ICAX2,x
      and #$f0
      eor #$10
      ora #$0c
      sta ATARI_ICAX1,x
      jsr ATARI_CIOV
    }
}

void atari_SetColor (BYTE col, BYTE hue, BYTE lum)
{
    TDL_POKE (ATARI_COLOR0+col, (hue << 4) | lum);
    /*
    __asm {
      ldx col
      lda hue
      asl
      asl
      asl
      asl
      adc lum
      sta ATARI_COLOR0,x
    }*/
}

void atari_Color (BYTE col)
{
    TDL_POKE (ATARI_STOCOL,col);
}

void atari_Position (UINT x, BYTE y)
{
    TDL_DOKE (ATARI_COLCRS, x);
    TDL_POKE (ATARI_ROWCRS, y);
}

void atari_Plot (UINT x, BYTE y)
{
    atari_Position (x,y);
    __asm {
      ldx # $60			// use IOCB6 
      lda # $0b		
      sta ATARI_ICCOM,x
      lda #0
      sta ATARI_ICBLL,x
      sta ATARI_ICBLH,x
      lda ATARI_STOCOL
      jsr ATARI_CIOV
    }
}

void atari_DrawTo (UINT x, BYTE y)
{
    atari_Position (x,y);
    __asm {
      lda ATARI_STOCOL
      sta ATARI_ATACHR
      ldx # $60			// use IOCB6 
      lda # $11		
      sta ATARI_ICCOM,x
      lda #$0c
      sta ATARI_ICAX1,x
      lda #0
      sta ATARI_ICAX2,x
      jsr ATARI_CIOV
    }
}

/*========================================================================
   Char I/O
==========================================================================*/

  // Low level get char from keybd in (A)
void io_getch2 ()
{
__asm {
      lda $e425		// Look up tab for kbd sub
      pha 
      lda $e424
      pha
      rts
    }
}

  // Get char from keybd
BYTE io_getch ()
{
    if (TDL_PEEK(764) == 255) return 0;
    return __asm {
      jsr io_getch2	// Return key in Acc
      sta accu
    };
}

  /* Print a char */
void io_putch (int ch)
{ 
    //if (ch == '\n') putchar ('\r');
    putchar (ch); 
}

  /* Print a string */
void io_puts (const char *ostr) 
{ 
    char ch;
    while (ch = *ostr) {
      io_putch (ch);
      ostr ++;
    }
}

  /* Print an int */
void io_putint (int x)
{
    if (x<0) {
      x = -x; 
      io_putch ('-');
    }
    if (x>9) {
      io_putint (x/10);
    }
    io_putch ('0' + x%10);
}

  /* Print a hex int */
void io_puthex (UINT x, BYTE n)
{
    BYTE c;
    do {
      n--;
      c = (x>>(n*4)) & 15;
      if (c>9) c+= 7;
      io_putch ('0'+c);
    } while (n);
}

void io_putsi (const char *ostr, int val)
{
    io_puts (ostr);
    io_putint (val); 
}

/*========================================================================
   Main demo program
==========================================================================*/


int main ()
{
    UINT x;
    BYTE y,key;
    BYTE mode = 1;
    srand (11);
    do {
      atari_Graphics (8-mode);
      //atari_SetColor (0, 0, 0);
      for (y=0; y< 5; y++) {
        atari_SetColor (y, rand () & 15, rand () & 15);
      }
      atari_Color (1);
      io_puts ("GFX DEMO, BY A.MILLETT\n");
      io_puts ("HIT RET=NEW, SPACE=MODE");
      atari_Plot (1,1);
      do {
        if (mode) {
          x = rand () % 160; y = rand () % 80;
        } else {
          x = rand () % 320; y = rand () % 160;
        }
        atari_Color ( (rand () & 3));
        atari_DrawTo (x,y);
        //atari_Plot (x,y);    // Use this for pixels
        key = io_getch();
        if (key == ' ') mode = !mode;
      } while (key == 0);
    } while (1);
}
